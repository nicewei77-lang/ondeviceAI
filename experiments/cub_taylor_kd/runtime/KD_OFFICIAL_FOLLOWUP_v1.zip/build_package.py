from pathlib import Path,PurePosixPath
import ast,hashlib,json,zipfile,sys
import nbformat
ROOT=Path(__file__).resolve().parent;sys.path[:0]=[str(ROOT),str(ROOT/'vendor_base')]
from lightio.identity import identity,sha,atomic_json,NAMESPACE
BASE=ROOT.parent/'cub_git_b0_taylor_v1_2/colab_packages/GIT_B0_TAYLOR_30_50_70_v1_2.zip'
BASE_SHA='1926e8886f486a269398e86b42170c350d3c5f4b3fae655686a79792daf58272'

def notebook(kind,zip_sha,code_id):
    M,C=nbformat.v4.new_markdown_cell,nbformat.v4.new_code_cell
    kd=kind=='CUB_KD';dataset={'FLOWERS':'flowers102','AIRCRAFT':'aircraft'}.get(kind)
    title='CUB GitB0/30/50/70 Teacher → Student KD,3seeds' if kd else f'{dataset} Taylor+CE+KL30/50/70,80epochs'
    intro=('# '+title+'\n\n새 준비물입니다. 현재 CUB v1_2 학습/노트북은 변경하지 않습니다. START=False 기본, GPU 할당 없음. 코드1→2→3 순서.\n\n'+
        ('Teacher80와Test strict완료 및 실제 runtime반환/idle 확인 후만 실행합니다. B0·30·50·70×seed42/43/44×60=신규720 Student epochs, Student-only는 검증된 기존 Native 재사용. Student평가batch16으로 기존recipe를 유지하며 Teacher평가batch8과 구분합니다. Test 수치를 Teacher선정에 쓰지 않습니다.' if kd else
        f'Git 관리자가 확정한 {dataset} B0는 없습니다. 기존 Native dense 후보를 명시한 준비물이며 CUB B0를 사용하지 않습니다. 준비만 승인되었고 지금 실행하지 않습니다. Native 대안을 선택할 때 BASELINE_KIND를 명시적으로 설정합니다. calibration은 Train2/class로 '+('204장/102classes,Hard21' if kind=='FLOWERS' else '200장/100classes,Hard20')+'입니다. 실제 checkpoint/metadata/class/split/strict restore는 실행초기에 Colab에서 한 번 검증합니다.'))
    options='''START_TRAINING = False
RESUME = False
RUN_TEST_AFTER_TRAINING = True
AUTO_RELEASE = True
DATA_ROOT = None
RUNTIME_RELEASE_EVIDENCE = None
STOP_AFTER_EPOCH = None
'''
    if kd:
        options+='''# 담당자가 현재 Teacher 종료와 runtime/세션을 실제 확인한 값만 입력합니다.
TERMINAL_OBSERVATION = {}
# 예: {'observed_at_utc':'실제UTC','teacher_run_and_Test_ended':True,
#      'teacher_runtime_released_or_idle':True,'total_active_sessions':1,
#      'KD_sessions':1,'additional_purchases':0}
'''
    else:
        options+="BASELINE_KIND = None  # 기존 Native 대안 선택 시 'EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_B0'\nPAUSE_AFTER_TARGET = None\nEVALUATION_BATCH_SIZE = 8\nassert EVALUATION_BATCH_SIZE == 8\n"
    setup=f'''from pathlib import Path,PurePosixPath
from google.colab import drive,auth
import os,sys,hashlib,stat,tempfile,zipfile
if not os.path.ismount('/content/drive'):drive.mount('/content/drive',timeout_ms=900000)
BASE=Path('/content/drive/MyDrive/온디바이스AI')
PROJECT=BASE/'cub_focus_light_io_v1/CUB_KD_AND_OFFICIAL_TAYLOR_v1'
PACKAGE=PROJECT/'KD_OFFICIAL_FOLLOWUP_v1.zip'
assert hashlib.sha256(PACKAGE.read_bytes()).hexdigest()=='{zip_sha}'
if 'FOLLOWUP_CODE' not in globals():
    assert not any(n=='lightio' or n.startswith('lightio.') for n in sys.modules),'Preserve current Teacher/other run: use separate clean Python kernel'
    FOLLOWUP_CODE=Path(tempfile.mkdtemp(prefix='ondevice_followup_',dir='/content'))
    with zipfile.ZipFile(PACKAGE) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for m in z.infolist():
            p=PurePosixPath(m.filename)
            assert not p.is_absolute() and '..' not in p.parts and chr(92) not in m.filename and not stat.S_ISLNK(m.external_attr>>16)
        z.extractall(FOLLOWUP_CODE)
    sys.path[:0]=[str(FOLLOWUP_CODE),str(FOLLOWUP_CODE/'vendor_base')]
from lightio.contracts import verify_delivery
assert verify_delivery(FOLLOWUP_CODE)['code_id']=='{code_id}'
from phaseb.native import config
cfg=config('{dataset or 'cub200'}')  # Verified vendored bootstrap BEFORE any direct b1kd import.
from lightio.{'kd_runner' if kd else 'official_flowers_runner' if kind=='FLOWERS' else 'official_aircraft_runner'} import run,plan
assert Path(run.__code__.co_filename).resolve().is_relative_to(FOLLOWUP_CODE.resolve())
print('FOLLOWUP_CODE_VERIFIED','{code_id}');print(plan())
'''
    if kd:
        call='''if START_TRAINING:
    auth.authenticate_user()
    from types import SimpleNamespace
    FOLLOWUP_REPORT=run(SimpleNamespace(start_training=True,resume=RESUME,auto_release=AUTO_RELEASE,
        test_after_training=RUN_TEST_AFTER_TRAINING,terminal_observation=TERMINAL_OBSERVATION,
        data_root=DATA_ROOT,inputs=str(BASE/'TeacherSizeKD_NoPruning/inputs'),
        stop_after_epoch=STOP_AFTER_EPOCH,runtime_release_evidence=RUNTIME_RELEASE_EVIDENCE))
    print(FOLLOWUP_REPORT)
else:print('PREPARED: no Student training/Test/GPU allocation')
'''
    else:
        call=f'''if START_TRAINING:
    assert BASELINE_KIND=='EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_B0','Dataset-specific baseline must be explicitly chosen; do not use CUB B0'
    auth.authenticate_user()
    from types import SimpleNamespace
    FOLLOWUP_REPORT=run(SimpleNamespace(start_training=True,resume=RESUME,auto_release=AUTO_RELEASE,
        test_after_training=RUN_TEST_AFTER_TRAINING,baseline_kind=BASELINE_KIND,expected_source_sha=None,
        run_name='{dataset}_TaylorCEKL_30_50_70_v1',data_root=DATA_ROOT,
        inputs=str(BASE/'TeacherSizeKD_NoPruning/inputs'),stop_after_epoch=STOP_AFTER_EPOCH,
        pause_after_target=PAUSE_AFTER_TARGET,runtime_release_evidence=RUNTIME_RELEASE_EVIDENCE))
    print(FOLLOWUP_REPORT)
else:print('PREPARED_ONLY: dataset baseline choice and execution still required; GPU0')
'''
    notes='''## 저장·재개와 검증 범위
작은progress/history는 매epoch, local원자resume/best, Drive900초+단계/최종/계획중단 강제flush입니다. computed/durable을 구분하며15분hard 손실상한은 아닙니다.
중단 후 동일계약을 명시적으로 재개할 때만 RESUME=True를 사용하며 완료한 job/Test를 반복하지 않습니다. PAUSE/STOP을 사용했다면 재개 시 None으로 되돌립니다. 기존owner/lock 삭제나 unclean runtime takeover는 하지 않습니다.
기존결과는 불변, 모델payload는 Colab/Drive 안에서만 처리합니다. 새GPU나추가결제를코드가하지않습니다.
준비 검증은 변경부 CPU fixture 및 packaged cold import/AST/nbformat이며 실제 신규 Colab 전체학습/Test 통과를 뜻하지 않습니다.
Teacher/Student 모두 Validation으로 checkpoint를 잠근 후 Test를 평가합니다. 이미 관찰한Test를 새holdout이라고 부르지 않습니다. AUTO_RELEASE=True이면 최종결과 안전저장 후 unassign을 요청합니다. receipt requested와 실제해제확인은 구분해야 합니다.
'''
    cells=[M(intro),M('## 1. 옵션'),C(options),M('## 2. Drive·새 ZIP·code identity 및 import 검증'),C(setup),M('## 3. 실행'),C(call),M(notes)]
    for c in cells:
        if c.cell_type=='code':ast.parse(c.source)
    nb=nbformat.v4.new_notebook(cells=cells,metadata={'colab':{'name':f'START_{kind}_FOLLOWUP_v1.ipynb','provenance':[]},'kernelspec':{'name':'python3','display_name':'Python3'},'language_info':{'name':'python'}})
    nbformat.validate(nb);return nb

def main():
    assert sha(BASE)==BASE_SHA
    paths=[ROOT/'README.md',Path(__file__).resolve(),ROOT/'tests/test_followup.py',ROOT/'tests/fixture_models.py',ROOT/'tests/__init__.py']+list((ROOT/'lightio').glob('*.py'))+list((ROOT/'assets').glob('*.json'))
    paths=sorted(set(paths));hashes={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    for p in paths:
        if p.suffix=='.py':ast.parse(p.read_text(encoding='utf8'))
    manifest={'namespace':NAMESPACE,'code_id':identity(hashes),'sha256':hashes,'vendor_source_ZIP_SHA256':BASE_SHA,'prepared_only':True,'new_GPU_allocations':0};atomic_json(ROOT/'SOURCE_MANIFEST.json',manifest)
    out=ROOT/'colab_packages';out.mkdir(exist_ok=True);package=out/'KD_OFFICIAL_FOLLOWUP_v1.zip'
    with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for m in old.infolist():
            if m.filename.startswith('vendor_base/'):z.writestr(m,old.read(m.filename))
        for p in paths+[ROOT/'SOURCE_MANIFEST.json']:z.write(p,p.relative_to(ROOT).as_posix())
    files={}
    for kind in ('CUB_KD','FLOWERS','AIRCRAFT'):
        path=out/f'START_{kind}_FOLLOWUP_v1.ipynb';nbformat.write(notebook(kind,sha(package),manifest['code_id']),path);files[kind]={'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path)}
    delivery={'state':'PREPARED_LOCAL_ACCEPTANCE_PENDING','code_id':manifest['code_id'],'ZIP_sha256':sha(package),'ZIP_bytes':package.stat().st_size,'notebooks':files,'source_files':len(paths),'actual_GPU_training':False,'Teacher_run_modified':False};atomic_json(out/'DELIVERY.json',delivery);print(json.dumps(delivery,indent=2))
if __name__=='__main__':main()
