from pathlib import Path
import copy,json,tempfile,unittest,sys,contextlib
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'vendor_base')]
import torch
from torch import nn
from lightio.identity import identity
from lightio.backend import LocalBackend
from lightio.lease import WriterLease
from lightio.student_io import StudentIO
from lightio.official_taylor import calibration_indices
from lightio.official_extension import ExtensionRecipe
from lightio.official_source import validate_native_payload
from tests.fixture_models import CalData

class Focused(unittest.TestCase):
    def test_official_two_per_class_and_80epoch_plan(self):
        class Data:
            def __init__(self,n,c):self.records=[{'image_id':i,'label':i%c} for i in range(n)]
            def __len__(self):return len(self.records)
        for dataset,n,c,total in [('flowers102',1020,102,204),('aircraft',3334,100,200)]:
            data=Data(n,c);indices=calibration_indices(data,c)
            self.assertEqual(indices,calibration_indices(data,c));self.assertEqual(len(indices),total)
            self.assertEqual([sum(data.records[i]['label']==j for i in indices) for j in range(c)],[2]*c)
            budgets=[]
            for start,target,offset,budget in [(0,30,0,40),(30,50,40,20),(50,70,60,20)]:
                r=ExtensionRecipe(dataset,'IT',target,budget,20261013,'a'*64,'b'*64,'c'*64,start_percent=start,stream_offset=offset,tail_arm=f'TAYLOR_CEKL_TO{target}')
                budgets.append(budget);self.assertEqual(r.stream_epoch(0),offset)
                self.assertEqual(r.width(512,3),-(-(512*(100-target))//100))
            self.assertEqual(sum(budgets),80)
            from dataclasses import asdict
            from phaseb.native import ROOT as NATIVE_ROOT
            from lightio.identity import read
            pin=read(NATIVE_ROOT/'configs/readonly_inputs.json')['datasets'][dataset]
            hard={'baseline_sha256':'a'*64,'class_ids':[0]};b0={'file_id':pin['source_metadata']['id'],'sha256':'a'*64,'hard_identity':identity(hard)}
            source={'file_id':b0['file_id'],'reference':{'sha256':'a'*64}};report={'state':'complete','new_Teacher_epochs':80,'B0':b0,'hard_set':hard,'hard_set_id':identity(hard),'source30':source,'targets':{}}
            for start,target,offset,budget in [(0,30,0,40),(30,50,40,20),(50,70,60,20)]:
                recipe=ExtensionRecipe(dataset,'IT',target,budget,20261013,identity(source),'b'*64,'c'*64,start_percent=start,stream_offset=offset,tail_arm=f'TAYLOR_CEKL_TO{target}')
                last={'file_id':f'last{target}'};report['targets'][str(target)]={'source':source,'recipe':asdict(recipe),'last_model':last,'target_percent':target};source={'position':f'last{target}','reference':last}
            from lightio import official_flowers_test,official_aircraft_test
            validate=(official_flowers_test if dataset=='flowers102' else official_aircraft_test).validate_lineage
            validate(report);changed=copy.deepcopy(report);changed['B0']['file_id']='1xwR2mviCdrSYJ-n2eZuFbd14reVcXuiq'
            with self.assertRaises(ValueError):validate(changed)
        with self.assertRaises(ValueError):calibration_indices(Data(4794,200),200)

    def test_native_payload_class_contract_and_digest_guard(self):
        from phaseb.native import module
        io=module('flowers102','io');value={'contract':{'dataset':'flowers102','split_id':'split102','classes':['a','b']},'model_spec':{'num_classes':102},'epoch':5,'model_state':{'weight':torch.ones(2)}}
        pin={'expected_full_native_contract':value['contract'],'base_reference':{'model_spec':value['model_spec'],'epoch':5,'contract_id':io.identity(value['contract']),'model_digest':io.model_state_identity(value['model_state'])}}
        validate_native_payload(value,pin,io)
        for altered in [dict(value,model_spec={'num_classes':200}),dict(value,epoch=10),dict(value,contract={'dataset':'cub200'}),dict(value,model_state={'weight':torch.zeros(2)})]:
            with self.assertRaises(ValueError):validate_native_payload(altered,pin,io)

    def test_native_Student_loss_and_sparse_cold_resume(self):
        from phaseb.native import module
        io_native,train=module('cub200','io'),module('cub200','train')
        torch.set_num_threads(1)
        logits=torch.tensor([[1.,-1.,.2],[.3,.8,-.4]],requires_grad=True);target=torch.tensor([[.8,-.5,.3],[.2,.9,-.2]]);labels=torch.tensor([0,1])
        loss,_,_=train.kd_loss(logits,labels,target,4.,.5)
        expected=.5*torch.nn.functional.cross_entropy(logits,labels)+.5*16*torch.nn.functional.kl_div(torch.nn.functional.log_softmax(logits/4,1),torch.nn.functional.softmax(target/4,1),reduction='batchmean')
        self.assertTrue(torch.equal(loss,expected));loss.backward();self.assertIsNone(target.grad)
        cfg={'batch_size':3,'effective_batch_size':6,'num_workers':0,'student_lr':.0003,'student_weight_decay':.0001,'amp':False,'warmup_epochs':5,'num_classes':3,'temperature':4.,'kd_alpha':.5}
        contract={'config':cfg,'seed':42,'job':'fixture/student'};cid=identity(contract);spec={'kind':'fixture','num_classes':3}
        def model():return nn.Sequential(nn.Linear(4,5),nn.ReLU(),nn.Linear(5,3))
        torch.manual_seed(123);initial=copy.deepcopy(model().state_dict());teacher=model();before=io_native.model_state_identity(teacher.state_dict());data=CalData()
        original=(train.json_write,train.checkpoint_write)
        scratch=ROOT/'codex_ws/CPU_fixtures';scratch.mkdir(parents=True,exist_ok=True)
        with contextlib.nullcontext(tempfile.mkdtemp(dir=scratch)) as tmp:
            tmp=Path(tmp);full=tmp/'full';m=model();m.load_state_dict(initial)
            train.fit(m,data,data,full,2,42,cfg,contract,spec,teacher=teacher,device='cpu')
            digest=io_native.checkpoint_read(full/'last.pt')['model_digest']
            backend=LocalBackend(tmp/'remote',cid);local=tmp/'partial'
            with WriterLease(local,backend,cid,runtime_id='fixture-runtime') as lease:
                io=StudentIO(local,backend,cid,epochs=2);m=model();m.load_state_dict(initial)
                with io.hooked(train):train.fit(m,data,data,local,2,42,cfg,contract,spec,teacher=teacher,stop_after_epoch=1,device='cpu')
                self.assertEqual(io.pointer['completed_epochs'],1);self.assertEqual(io.updates,[{'epoch':1,'attempted':2,'applied':2,'AMP_skipped':0,'scale':None}]);lease.finish('paused',1)
            with WriterLease(tmp/'cold',backend,cid,resume=True,runtime_id='fixture-runtime') as lease:
                io=StudentIO(tmp/'cold',backend,cid,epochs=2);io.restore(io_native);m=model()
                with io.hooked(train):train.fit(m,data,data,tmp/'cold',2,42,cfg,contract,spec,teacher=teacher,device='cpu')
                self.assertEqual(io_native.checkpoint_read(tmp/'cold/last.pt')['model_digest'],digest);self.assertEqual(io.pointer['completed_epochs'],2);self.assertEqual(sum(r['applied'] for r in io.updates),4);lease.finish('complete',2)
                previous=backend.get('STUDENT_COMMITTED.json');io.best_epoch=99
                with self.assertRaisesRegex(ValueError,'binding incomplete'):io.flush(2)
                self.assertEqual(backend.get('STUDENT_COMMITTED.json'),previous)
            self.assertEqual((train.json_write,train.checkpoint_write),original)
            self.assertEqual(io_native.model_state_identity(teacher.state_dict()),before);self.assertTrue(all(p.grad is None for p in teacher.parameters()))

    def test_entrypoints_and_teacher_terminal_fail_closed(self):
        from types import SimpleNamespace
        from lightio import kd_runner,official_flowers_runner,official_aircraft_runner
        self.assertEqual(kd_runner.run(SimpleNamespace(start_training=False))['new_Student_epochs'],720)
        self.assertEqual(official_flowers_runner.run(SimpleNamespace(start_training=False))['calibration_count'],204)
        self.assertEqual(official_aircraft_runner.run(SimpleNamespace(start_training=False))['calibration_count'],200)
        from lightio.followup_common import teacher_terminal
        class Empty:
            def get(self,name):return None
        with patch('lightio.followup_common.TeacherReader',return_value=Empty()):
            with self.assertRaisesRegex(ValueError,'Required completed artifact'):teacher_terminal(None)
        with self.assertRaises(ValueError):kd_runner.observation({'teacher_run_and_Test_ended':False})

    def test_completed_Teacher_reader_is_readonly_and_keeps_old_tags(self):
        from lightio.teacher_reader import TeacherReader,OLD_NAMESPACE
        class Query:
            def __init__(self,value):self.value=value
            def execute(self):return self.value
        class API:
            def files(self):return self
            def get(self,fileId,fields):
                return Query({'id':'folder','mimeType':'application/vnd.google-apps.folder'} if fileId=='folder' else {'id':'file','name':'selected_teacher.pt','size':'5','sha256Checksum':'a'*64,'trashed':False,'appProperties':self.tags})
            def list(self,**kwargs):return Query({'files':[{'id':'file','name':'selected_teacher.pt','appProperties':self.tags}]})
            tags={'lightio_namespace':OLD_NAMESPACE,'lightio_contract':'contract','lightio_object':'selected_teacher.pt'}
        api=API();r=TeacherReader('folder','contract',service=api)
        self.assertFalse(hasattr(r,'put'));self.assertFalse(hasattr(r,'claim_owner'))
        self.assertTrue(r.verify_ref({'file':'selected_teacher.pt','file_id':'file','bytes':5,'sha256':'a'*64}))
        with self.assertRaises(ValueError):r.verify_ref({'file':'selected_teacher.pt','file_id':'file','bytes':6,'sha256':'a'*64})
        api.tags=dict(api.tags,lightio_contract='foreign')
        with self.assertRaises(ValueError):TeacherReader('folder','contract',service=api)

if __name__=='__main__':unittest.main()
