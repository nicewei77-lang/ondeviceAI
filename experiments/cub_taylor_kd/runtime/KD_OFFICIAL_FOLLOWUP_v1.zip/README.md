# CUB Student KD / Flowers / Aircraft follow-up v1

현재 CUB GitB0 v1_2 실행·코드·결과는 변경하지 않는 별도 준비물입니다. GPU 자동할당·추가구매·PC 모델다운로드가 없습니다.

CUB KD는 현재 source sequence `3243d033...`의 B0와 Validation-selected30/50/70 네 Teacher, seed42/43/44 각60epoch로 고정합니다(신규720 Student epochs). MobileNetV3-Large width1/dropout.2/ImageNet1K V2의 원래 same-seed 초기화, Native Student loss `.5 CE + .5 T² KL`, T4, batch16/effective64, LR.0003/WD.0001, warmup5/globalcosine60, AMP16 training/Teacher autocast 및 FP32 eval batch16, 전체60epoch Val OA→CE→earliest 선정 규칙을 재사용합니다. Teacher 가지치기의 CE+.5T²KL/FP32 dense Teacher 및 evalbatch8과 혼용하지 않습니다.

Student-only3seed는 원래 Native 동일 split/config/init/60완료/history/last59/선택best/strict 모델을 Colab에서 확인 후 읽기전용 재사용합니다. 신규 Student-only 학습은 없습니다. 기존 baseline Test logits도 SHA·checkpoint·orderedID/labels가 일치하면 재사용하며 새B0 Hard40로 지표만 다시 계산합니다. 12개 KD job가 모두 완료되기 전에 Test를 읽지 않고, 모든 Validation 선정본을 고정한 뒤 3seed 결과/평균/표준편차를 저장합니다. 이전 CUB Test 노출을 새holdout으로 주장하지 않습니다.

KD 실행 전 현재 Teacher80epoch와 기존 Teacher Test가 strict 완료되어야 하며, 실제 UI로 학습셀 종료 및 기존 runtime 반환/idle·세션 수를 확인한 최근10분 `TERMINAL_OBSERVATION`이 필요합니다. 준비 시점에는 `{}`이고 `START_TRAINING=False`입니다. 사용자가 완료후 KD실행을 승인했으므로 담당자가 실제 종료 관측을 채운 뒤 실행하며 재승인을 요구하지 않습니다. 현재 Teacher가 실행 중이면 KD는 HOLD하고 새 GPU를 잡지 않습니다.

Flowers102/Aircraft의 Git-manager 확정 B0는 조사한 dev096e1f1 트리에 없습니다. 기존 Native dense 후보는 FlowersID1Iop8feqcAEF7wySvpSuuwnu1fG6lsZuB(102classes), AircraftID1s0LZw1sNqmtWWd-8VEbOAZiWsSKg1Tui(100classes)입니다. 이는 CUB GitB0와 다른 학습 출처이며 Gitbaseline 확정으로 표시하지 않습니다. 두 노트북은 준비만 승인됐고 `BASELINE_KIND=None`, `START_TRAINING=False`입니다. 기존 Native 후보 사용을 선택하면 정확히 `EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_B0`로 설정합니다. 다른 Git baseline을 받으면 새 ID/spec/클래스/계약 검증이 필요하며 이 값으로 조용히 대체하지 않습니다.

Flowers official split1020/1020/6149, Aircraft3334/3333/3333, 원래 dataset별 preprocessing/class order/bottom-crop를 유지합니다. Train-only calibration은 동일2/class 규칙으로 각각204/200장입니다. 고정 Hard는 dense batch8 Val에서 원래 규칙으로 각각21/20클래스 선정 후 보존하며 기존Hard는 보조지표입니다. 7.5/15/22.5/30각10,35/40/45/50/55/60/65/70각5, dataset마다 신규80Teacher epochs입니다. 현재weights Taylor CE중요도, 원래dataset dense를 frozen CE+.5T4²KL Teacher로 사용, stage-local LRrestart/freshoptimizer·scaler, train16/eff64/eval8, 목표별final-quarter Valbest와last분리, LAST30→50/LAST50→70, 최종선정잠금 Test 옵션을 재사용합니다. CUB B0는 다른dataset에 로드하지 않습니다.

세 노트북은 새 파일이며 code cell1(옵션)→2(Drive·ZIP·manifest검증·Native import bootstrap)→3(실행) 순서입니다. 각각 별도의 Python kernel을 사용하고 현재 학습 kernel에 모듈을 섞지 않습니다. `RESUME=True`는 명시적으로 중단된 동일계약 재개에만 쓰며 owner/lock을 삭제하지 않습니다. 다른runtime으로 unclean active takeover는 거부합니다.

매epoch 작은 progress/history 및 local atomic last/best, Drive900초+단계/최종/계획중단 강제flush를 사용합니다. Student는 원래 Native fit 함수 자체를 바꾸지 않고 local IO callback만 연결하며 optimizer 실제 step counter에서 applied/AMPskip을 기록합니다. computed와durable을 구분하고 VM손실은900초+현재epoch/save지연을 초과할 수 있습니다. 원격 snapshot3세대 중 current/prior를 보호합니다. 실제 새 Colab/model/provider 실행은 준비시험과 별개이며 startup에서만 실제 checkpoint/labels/strict restore를 검증합니다.

준비 검증은 새 KDloss/IO/coldresume/공식dataset calibration·lineage/entrypoint의 focused CPU fixtures 및 ZIP/manifest/AST/nbformat입니다. 기존80epoch scientific suite는 재실행하지 않습니다. 신규720Student 및 각80Teacher GPU실행은 아직 시작하지 않았습니다. KD ETA는 과거 처리량 기준 대략8–16시간+환경·I/O의 계획치이며 첫실제2epochs 후 갱신합니다. Flowers/Aircraft ETA는 calibration 및 최초2epochs 측정 전 확정하지 않습니다.
