"""Owned fixed-name checkpoint objects; discovery happens only at startup.

No rename, trash, delete, broad Drive walk, or authentication retry is exposed.
The filesystem backend is a CPU fixture and never actual provider evidence.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path
import time
import uuid


NAMESPACE = 'kd_official_followup_v1'
RESUME = tuple(f'resume_remote_{i}.pt' for i in range(3))
BEST = tuple(f'best_head_{i}.pt' for i in range(3))
ANCHORS = tuple([f'anchor_post_{i}.pt' for i in range(4)] +
                [f'anchor_pre_{i}.pt' for i in range(1, 4)])
CONTROL = {'REMOTE_COMMITTED.json', 'progress.json', 'history.json',
           'COMPLETE.json', 'PAUSED.json', 'ANCHORS.json', 'ROLLBACK.json',
           'OWNER.json', 'OPERATIONAL_CONTRACT.json', 'READINESS.json'}
CONTROL |= {'SOURCE_VERIFIED.json','BRANCH_START.json','RUN_STARTED.json',
            'RUN_RESULT.json','COMPARISON.json','SEQUENCE.json','RELEASE_REQUEST.json'}
CONTROL |= {'BOUNDARY_01_AUDIT.json','BOUNDARY_02_AUDIT.json','BOUNDARY_03_AUDIT.json'}
CONTROL |= {'CALIBRATION_00.json','BOUNDARY_00_AUDIT.json','CALIBRATION_01.json','CALIBRATION_02.json','CALIBRATION_03.json','SEQUENCE_PROGRESS.json'}
ALLOWED = {'last_teacher.pt','TEST_SELECTION_LOCK.json','B0_SOURCE.json','B0_VALIDATION.json','HARD_SET.json','best.pth','config.json','github_history.json','pruning_spec.json'} | {f'TEST_{t}{suffix}' for t in (0,30,50,70) for suffix in ('.json','.csv','.pt','_COMPLETE.json')} | set(RESUME + BEST + ANCHORS + ('selected_teacher.pt',)) | CONTROL


ALLOWED |= {'KD_TEACHERS_LOCK.json','KD_TRAINING_COMPLETE.json','STUDENT_COMMITTED.json','EPOCH_UPDATES.json','BASELINE_REUSE.json','KD_RESULT.json','STUDENT_TEST_SELECTION_LOCK.json'}
ALLOWED |= {f'STUDENT_TEST_{t}_{seed}{suffix}' for t in ('baseline','B0','30','50','70') for seed in (42,43,44) for suffix in ('.json','.csv','.pt','_COMPLETE.json')}

def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_bytes(path, data):
    """Atomic replacement is used only on the local filesystem/CPU fixtures."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                break
            except PermissionError as error:
                if getattr(error, 'winerror', None) not in (5, 32, 33) or attempt == 5:
                    raise
                # Windows indexer/OneDrive locks are local atomic-file races,
                # not retries of uncertain provider uploads or authentication.
                time.sleep(.05 * (attempt + 1))
    finally:
        temporary.unlink(missing_ok=True)


def require_name(name):
    if name not in ALLOWED:
        raise ValueError('Unknown light-I/O remote object: ' + str(name))


def _claim_guard(backend, record, lease, expected_prior):
    if (lease is None or getattr(lease, 'handle', None) is None or
            getattr(lease, 'record', None) != record or
            record.get('writer_token') != getattr(lease, 'token', None) or
            record.get('operational_id') != backend.contract_id or
            record.get('namespace') != NAMESPACE or record.get('state') != 'active'):
        raise ValueError('Owner bootstrap requires the currently OS-locked claimant')
    raw = backend.get('OWNER.json')
    prior = None if raw is None else json.loads(raw)
    if prior != expected_prior:
        raise ValueError('Owner changed before claim; HOLD')


def _create_owner(backend, record, lease, expected_prior):
    _claim_guard(backend, record, lease, expected_prior)
    backend.lease = lease
    backend._claiming_owner = True
    try:
        receipt = backend.put('OWNER.json', json.dumps(record, sort_keys=True).encode('utf8'))
        if json.loads(backend.get('OWNER.json')) != record:
            raise ValueError('Owner claim readback differs')
        return receipt
    finally:
        backend._claiming_owner = False


class LocalBackend:
    """Separate-directory CPU stand-in for a remote object service."""
    fixture = True

    def __init__(self, directory, contract_id, lease=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.contract_id, self.lease = contract_id, lease
        self.put_events = []

    def _active(self):
        if self.lease is not None and not getattr(self, '_claiming_owner', False):
            self.lease.assert_active()

    def create_owner(self, record, lease, *, expected_prior=None):
        return _create_owner(self, record, lease, expected_prior)

    def get(self, name, expected_id=None):
        require_name(name)
        if expected_id is not None and expected_id != 'fixture:' + name:
            raise ValueError('Fixture object identity changed')
        path = self.directory / name
        return path.read_bytes() if path.is_file() else None

    def put(self, name, data):
        require_name(name)
        if getattr(self, '_claiming_owner', False) and name != 'OWNER.json':
            raise ValueError('Owner bootstrap cannot write other objects')
        self._active()
        atomic_bytes(self.directory / name, data)
        observed = self.get(name)
        if observed != data:
            raise ValueError('Fixture raw readback differs')
        self.put_events.append(name)
        return {'file': name, 'file_id': 'fixture:' + name,
                'sha256': digest(data), 'bytes': len(data), 'fixture': True,
                'remote_verification': 'CPU_fixture_raw_readback'}

    def close(self):
        pass

    def verify_ref(self, ref):
        raw = self.get(ref['file'], expected_id=ref.get('file_id'))
        if raw is None or len(raw) != ref['bytes'] or digest(raw) != ref['sha256']:
            raise ValueError('Fixture referenced object changed')
        return True


class DriveBackend:
    """Official Drive API, direct folder ID, cached fixed file IDs.

    An unknown-outcome upload stops the operation. A fresh process must perform
    startup discovery before another attempt; this object refuses an in-process
    retry so an uncertain create cannot silently create duplicate names.
    """
    fixture = False

    def __init__(self, folder_id, contract_id, lease=None, *, namespace=NAMESPACE):
        if namespace != NAMESPACE or not isinstance(folder_id, str) or not folder_id:
            raise ValueError('Explicit new namespace folder ID is required')
        import google.auth
        from googleapiclient.discovery import build
        credentials, _ = google.auth.default()
        self.service = build('drive', 'v3', credentials=credentials, cache_discovery=False)
        self.folder_id, self.contract_id = folder_id, contract_id
        self.lease, self.namespace = lease, namespace
        self.ids, self.uncertain = {}, False
        metadata = self.service.files().get(fileId=folder_id, fields='id,mimeType').execute()
        if metadata.get('mimeType') != 'application/vnd.google-apps.folder':
            raise ValueError('Light-I/O destination is not a Drive folder')
        token = None
        while True:
            result = self.service.files().list(
                q=f"'{folder_id}' in parents and trashed = false",
                fields='files(id,name,appProperties),nextPageToken',
                pageSize=100, pageToken=token).execute()
            for row in result.get('files', []):
                name = row['name']
                if name not in ALLOWED:
                    continue
                if name in self.ids:
                    raise ValueError('Duplicate fixed-name remote object')
                tags = row.get('appProperties', {})
                if (tags.get('lightio_namespace') != namespace or
                        tags.get('lightio_contract') != contract_id or
                        tags.get('lightio_object') != name):
                    raise ValueError('Refuse existing unowned checkpoint/control object')
                self.ids[name] = row['id']
            token = result.get('nextPageToken')
            if not token:
                break

    def _metadata(self, file_id):
        return self.service.files().get(
            fileId=file_id, fields='id,name,size,sha256Checksum,quotaBytesUsed,version').execute()

    def create_owner(self, record, lease, *, expected_prior=None):
        return _create_owner(self, record, lease, expected_prior)

    def get(self, name, expected_id=None):
        from googleapiclient.http import MediaIoBaseDownload
        require_name(name)
        file_id = self.ids.get(name)
        if file_id is None:
            if expected_id is not None:
                raise ValueError('Bound remote object is absent')
            return None
        if expected_id is not None and expected_id != file_id:
            raise ValueError('Bound remote file ID changed')
        metadata = self._metadata(file_id)
        size = int(metadata.get('size', -1))
        cap = 2 * 1024**3 if name.endswith(('.pt','.pth')) else 16 * 1024**2
        if size < 0 or size > cap:
            raise ValueError('Unexpected remote object size')
        stream = io.BytesIO()
        request = MediaIoBaseDownload(stream, self.service.files().get_media(fileId=file_id),
                                     chunksize=8 * 1024**2)
        done = False
        while not done:
            _, done = request.next_chunk(num_retries=0)
        raw = stream.getvalue()
        if len(raw) != size or (metadata.get('sha256Checksum') and
                                digest(raw) != metadata['sha256Checksum']):
            raise ValueError('Remote read integrity differs')
        return raw

    def put(self, name, data):
        from googleapiclient.http import MediaIoBaseUpload
        require_name(name)
        if self.lease is None:
            raise ValueError('Read-only Drive backend cannot write')
        if getattr(self, '_claiming_owner', False):
            if name != 'OWNER.json':
                raise ValueError('Owner bootstrap cannot write other objects')
        else:
            self.lease.assert_active()
        if self.uncertain:
            raise RuntimeError('Previous provider outcome uncertain; restart discovery before retry')
        existing = self.ids.get(name)
        media = MediaIoBaseUpload(io.BytesIO(data), mimetype='application/octet-stream',
                                 chunksize=8 * 1024**2, resumable=True)
        if existing:
            request = self.service.files().update(fileId=existing, media_body=media,
                                                  keepRevisionForever=False, fields='id')
        else:
            request = self.service.files().create(body={
                'name': name, 'parents': [self.folder_id], 'mimeType': 'application/octet-stream',
                'appProperties': {'lightio_namespace': self.namespace,
                                  'lightio_contract': self.contract_id,
                                  'lightio_object': name}}, media_body=media, fields='id')
        try:
            response = None
            while response is None:
                _, response = request.next_chunk(num_retries=0)
            file_id = response['id']
            if existing and file_id != existing:
                raise ValueError('Content update changed fixed file ID')
            self.ids[name] = file_id
            metadata = self._metadata(file_id)
            expected = digest(data)
            if int(metadata['size']) != len(data):
                raise ValueError('Provider readback size differs')
            server = metadata.get('sha256Checksum')
            if server and server != expected:
                raise ValueError('Provider SHA256 differs')
            verification = 'provider_SHA256_and_size'
            if not server:
                if self.get(name, expected_id=file_id) != data:
                    raise ValueError('Colab raw readback SHA256/size differs')
                verification = 'Colab_API_raw_readback_SHA256_and_size'
            return {'file': name, 'file_id': file_id, 'sha256': expected, 'bytes': len(data),
                    'provider_sha256': server, 'provider_version': metadata.get('version'),
                    'provider_quota_bytes': metadata.get('quotaBytesUsed'),
                    'remote_verification': verification, 'fixture': False}
        except BaseException:
            self.uncertain = True
            raise

    def close(self):
        if hasattr(self.service, 'close'):
            self.service.close()

    def verify_ref(self, ref):
        require_name(ref['file'])
        if self.ids.get(ref['file']) != ref['file_id']:
            raise ValueError('Bound remote reference file ID changed')
        metadata = self._metadata(ref['file_id'])
        if int(metadata['size']) != ref['bytes']:
            raise ValueError('Final referenced object size changed')
        server = metadata.get('sha256Checksum')
        if server:
            if server != ref['sha256']:
                raise ValueError('Final referenced object provider SHA256 changed')
        else:
            raw = self.get(ref['file'], expected_id=ref['file_id'])
            if raw is None or digest(raw) != ref['sha256']:
                raise ValueError('Final referenced object Colab raw SHA256 changed')
        return True
