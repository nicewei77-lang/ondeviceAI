"""Four fixed Teachers x three original Native Student seeds,60epoch each."""
from pathlib import Path
from dataclasses import asdict
import hashlib,io,json,math,os,time
from .identity import identity,read,sha,NAMESPACE
from .contracts import verify_delivery
from .backend import DriveBackend
from .lease import WriterLease,runtime_identity
from .staged_runner import owned_folder,put_json
from .followup_common import require_colab,native,teacher_terminal,native_saved,ensure_dataset,required_json
from .student_io import StudentIO

def plan():
    return {'state':'PREPARED_NO_EXECUTION','teachers':['B0','30','50','70'],'seeds':[42,43,44],'Student_epochs_each':60,'new_Student_epochs':720,'Student_only':'reuse pinned same-recipe Native60; no retraining','Student_eval_batch':16,'Teacher_pruning_eval_batch':8,'GPU_allocation':False}

def observation(value):
    from datetime import datetime,timezone
    if not isinstance(value,dict) or value.get('teacher_run_and_Test_ended') is not True or value.get('teacher_runtime_released_or_idle') is not True or value.get('additional_purchases')!=0 or not 1<=value.get('total_active_sessions',99)<=2 or value.get('KD_sessions')!=1:raise ValueError('Fresh actual UI terminal/session observation required; no overlapping Teacher/KD')
    age=(datetime.now(timezone.utc)-datetime.fromisoformat(value['observed_at_utc'].replace('Z','+00:00'))).total_seconds()
    if not 0<=age<=600:raise ValueError('UI observation older than10minutes')

def load_teacher(arm,report,sources,service,module,cache):
    import torch
    from .github_source import load_b0,same_version
    io_native,models=module('cub200','io'),module('cub200','models')
    if arm=='B0':
        model,evidence=load_b0(service,cache,models,io_native,report['B0']['class_names'],report['B0']['sha256'])
        same_version(report['B0']['provider_metadata'],evidence['provider_metadata'])
        return model
    from .kernel import strict_verifier
    from followup_iterative_v2.surgery import restore
    backend,recipe=sources[arm];ref=report['targets'][arm]['checkpoint_receipt']['selected_teacher'];backend.verify_ref(ref)
    raw=backend.get(ref['file'],expected_id=ref['file_id'])
    if len(raw)!=ref['bytes'] or hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('Selected Teacher bytes differ')
    factory=lambda:models.build_from_spec(report['B0']['model_spec'])
    value=strict_verifier(recipe,io_native,factory)(raw)
    return restore(factory,value['model_state'],value['layout'],digest=value['model_digest'],state_identity=io_native.model_state_identity)

def completed_student(backend,contract_id):
    raw=backend.get('KD_RESULT.json')
    if raw is None:return None
    result=json.loads(raw)
    if result['contract_id']!=contract_id or result['completed_epochs']!=60 or required_json(backend,'OWNER.json')['state']!='complete' or required_json(backend,'COMPLETE.json')!=result:raise ValueError('Student completion differs')
    for ref in (result['best'],result['last']):backend.verify_ref(ref)
    return result

def run(args):
    if not args.start_training:return plan()
    require_colab();observation(args.terminal_observation)
    import torch,google.auth
    from googleapiclient.discovery import build
    from phaseb.native import ROOT
    from phaseb.pipeline import verify_training_complete
    cfg,pin,module=native('cub200');package=Path(__file__).resolve().parents[1];code=verify_delivery(package)
    if (cfg['student_epochs'],cfg['batch_size'],cfg['effective_batch_size'],cfg['temperature'],cfg['kd_alpha'],cfg['student_lr'],cfg['student_weight_decay'])!=(60,16,64,4.,.5,.0003,.0001):raise ValueError('Frozen Native Student recipe differs')
    credentials,_=google.auth.default();service=build('drive','v3',credentials=credentials,cache_discovery=False)
    report,lock,sources=teacher_terminal(service)  # Before any output claim or optimizer creation.
    sets,data,manifest=ensure_dataset('cub200',args.inputs,Path('/content/KD_followup_data'),args.data_root)
    body={'namespace':NAMESPACE,'role':'CUB_GitB0_TeacherKD','Teacher_lock':lock,'seeds':[42,43,44],'epochs_each':60,'Student_recipe':cfg,'code_id':code['code_id'],'split_id':pin['split_id'],'Hard_id':report['hard_set_id']}
    op={**body,'operational_id':identity(body)};dest=read(package/'assets/DRIVE_DESTINATION.json')
    folder=owned_folder(service,dest['runs_folder_id'],'CUB_STUDENT_KD_4x3',op['operational_id']);backend=DriveBackend(folder,op['operational_id'])
    local=Path('/content/KD_followup')/op['operational_id'];released=read(args.runtime_release_evidence) if args.runtime_release_evidence else {};results={};baselines={};state='complete'
    previous=backend.get('COMPLETE.json')
    if previous is not None:
        done=json.loads(previous)
        if done['Teacher_lock_id']!=lock['lock_id']:raise ValueError('Prior KD source differs')
        for result in done['results'].values():
            child=DriveBackend(result['folder_id'],result['contract_id'])
            if completed_student(child,result['contract_id'])!=result:raise ValueError('Completed KD child changed')
        for ref in done.get('Test_result',{}).get('artifact_refs',[]):backend.verify_ref(ref)
        return done
    with WriterLease(local,backend,op['operational_id'],resume=args.resume,prior_release=released.get('sequence')) as outer:
        from .runner import quota_gate
        quota_gate(backend,minimum_free=10*1024**3)
        put_json(backend,'OPERATIONAL_CONTRACT.json',op);put_json(backend,'KD_TEACHERS_LOCK.json',lock)
        put_json(backend,'RUN_STARTED.json',{'PID':os.getpid(),'runtime_id':runtime_identity(),'Teacher_lock_id':lock['lock_id'],'new_Student_epochs_planned':720,'Student_only_retraining':False})
        print('KD_SEQUENCE_READY',op['operational_id'],folder,flush=True)
        native_io,train,models=(module('cub200',n) for n in ('io','train','models'))
        for seed in (42,43,44):
            model,value,ref=native_saved('cub200','baseline',seed);baselines[str(seed)]={'checkpoint':ref,'model_spec':value['model_spec'],'epoch':value['epoch'],'contract':value['contract']};del model,value
        put_json(backend,'BASELINE_REUSE.json',baselines)
        for arm in ('B0','30','50','70'):
            teacher=load_teacher(arm,report,sources,service,module,Path('/content/KD_followup_B0_source'))
            teacher_digest=native_io.model_state_identity(teacher.state_dict())
            try:
                for seed in (42,43,44):
                    model,initial,initial_ref=native_saved('cub200','initial',seed);spec=initial['model_spec'];del initial
                    contract={'schema_version':1,'config':cfg,'split_id':pin['split_id'],'job':f'cub200/student_KD_GitB0_{arm}/seed_{seed}','seed':seed,
                              'source':{'Teacher_lock_id':lock['lock_id'],'teacher':lock['B0'] if arm=='B0' else lock['selected'][arm],'student_initial':initial_ref},'code_id':code['code_id']}
                    contract_id=identity(contract);name=f'KD_{arm}_seed{seed}';child=owned_folder(service,folder,name,contract_id);out=DriveBackend(child,contract_id)
                    done=completed_student(out,contract_id)
                    if done is None:
                        work=local/name
                        with WriterLease(work,out,contract_id,resume=args.resume and out.get('OWNER.json') is not None,prior_release=released.get(name)) as lease:
                            put_json(out,'OPERATIONAL_CONTRACT.json',{'contract':contract,'contract_id':contract_id,'Teacher_lock_id':lock['lock_id']})
                            remote=StudentIO(work,out,contract_id);remote.restore(native_io)
                            with remote.hooked(train):rows=train.fit(model,sets['train'],sets['val'],work,60,seed,cfg,contract,spec,teacher=teacher,stop_after_epoch=args.stop_after_epoch,device='cuda')
                            if len(rows)!=60:
                                remote.flush(len(rows));lease.finish('paused',len(rows));state='paused';break
                            best=verify_training_complete(work,60,contract,spec)
                            if remote.pointer is None or remote.pointer['completed_epochs']!=60:raise ValueError('Final Student snapshot absent')
                            if native_io.model_state_identity(teacher.state_dict())!=teacher_digest or any(p.grad is not None for p in teacher.parameters()):raise ValueError('KD Teacher was updated')
                            model.load_state_dict(best['model_state'],strict=True)
                            done={'state':'complete','contract_id':contract_id,'completed_epochs':60,'arm':arm,'seed':seed,'folder_id':child,'Teacher_lock_id':lock['lock_id'],
                                  'best':remote.pointer['best'],'last':remote.pointer['last'],'selected_epoch':best['epoch']+1,'selected_validation':best['val_metrics'],'model_spec':spec,'model_digest':best['model_digest'],
                                  'applied_steps':sum(r['applied'] for r in remote.updates),'AMP_skips':sum(r['AMP_skipped'] for r in remote.updates),'initial':initial_ref}
                            put_json(out,'KD_RESULT.json',done);put_json(out,'COMPLETE.json',done);lease.finish('complete',60)
                    elif not args.resume:raise ValueError('Completed Student exists; explicit resume required')
                    results[name]=done;put_json(backend,'SEQUENCE_PROGRESS.json',{'completed_Student_jobs':len(results),'planned_Student_jobs':12,'latest':name,'latest_completed_epochs':60})
                    del model;torch.cuda.empty_cache()
                if state=='paused':break
            finally:
                if arm!='B0':sources[arm][0].verify_ref(report['targets'][arm]['checkpoint_receipt']['selected_teacher'])
                else:
                    from .github_source import same_version,metadata
                    same_version(report['B0']['provider_metadata'],metadata(service))
                del teacher;torch.cuda.empty_cache()
        trained={'state':state,'Teacher_lock_id':lock['lock_id'],'results':results,'baselines':baselines,'output_folder_id':folder,'sequence_id':op['operational_id'],'hard_set':report['hard_set'],'data_root':data['data_root'],'new_Student_epochs':sum(r['completed_epochs'] for r in results.values())}
        put_json(backend,'KD_TRAINING_COMPLETE.json' if state=='complete' else 'PAUSED.json',trained)
        if state=='complete' and args.test_after_training:
            from .kd_test import evaluate
            evaluated=evaluate(trained,backend,service,module,cfg,manifest,args.inputs,resume=args.resume)
            trained['Test_result']=evaluated
        trained['artifact_refs']=[ref for r in results.values() for ref in (r['best'],r['last'])]
        # Refs belong to child namespaces; completion reuse verifies them through each child.
        put_json(backend,'COMPARISON.json',trained);put_json(backend,'COMPLETE.json' if state=='complete' else 'PAUSED.json',trained)
        if args.auto_release:put_json(backend,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,'after':state,'runtime_id':runtime_identity()})
        outer.finish(state,trained['new_Student_epochs'])
    if args.auto_release:
        from google.colab import runtime
        runtime.unassign()
    return trained
