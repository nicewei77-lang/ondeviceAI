"""Native Student fit unchanged: local writes plus sparse owned remote snapshots."""
from contextlib import contextmanager
from pathlib import Path
import hashlib,json,time
from .identity import identity,read
from .backend import atomic_bytes
from .staged_runner import put_json

class StudentIO:
    def __init__(self,directory,backend,contract_id,*,interval=900,epochs=60):
        self.directory=Path(directory);self.backend=backend;self.contract_id=contract_id;self.interval=interval;self.epochs=epochs
        raw=backend.get('STUDENT_COMMITTED.json');self.pointer=None if raw is None else json.loads(raw)
        self.last_success=time.monotonic();self.updates=[];self.previous_steps=0
        self.best_epoch=None;self.last_epoch=None;self.expected_best_epoch=None
        if self.pointer and self.pointer['contract_id']!=contract_id:raise ValueError('Student resume contract differs')
    def restore(self,native_io=None):
        local_last=self.directory/'last.pt'
        if local_last.exists():
            if native_io is None:raise ValueError('Local Student resume requires strict Native IO')
            last=native_io.checkpoint_read(local_last);best=native_io.checkpoint_read(self.directory/'best.pt')
            if identity(last['contract'])!=self.contract_id or best['contract']!=last['contract'] or native_io.model_state_identity(last['model_state'])!=last['model_digest'] or native_io.model_state_identity(best['model_state'])!=best['model_digest']:raise ValueError('Local Student source/contract differs')
            selected=min(last['history'],key=lambda r:(-r['val_accuracy_pct'],r['val_loss'],r['epoch']))
            if best['epoch']!=selected['epoch']-1 or (self.pointer and last['epoch']+1<self.pointer['completed_epochs']):raise ValueError('Local Student selection/progress differs')
            self.updates=read(self.directory/'EPOCH_UPDATES.json')
            if len(self.updates)!=last['epoch']+1:raise ValueError('Local Student step ledger differs')
            self.previous_steps=sum(r['applied'] for r in self.updates)
            self.best_epoch=best['epoch'];self.last_epoch=last['epoch'];self.expected_best_epoch=selected['epoch']-1
            steps={int(v['step']) for v in last['optimizer_state']['state'].values()}
            if steps!={self.previous_steps}:raise ValueError('Local Student optimizer step ledger differs')
            atomic_bytes(self.directory/'history.json',json.dumps(last['history']).encode())
            return
        if not self.pointer:return
        for key,name in [('last','last.pt'),('best','best.pt')]:
            ref=self.pointer[key];self.backend.verify_ref(ref)
            raw=self.backend.get(ref['file'],expected_id=ref['file_id'])
            if len(raw)!=ref['bytes'] or hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('Student resume bytes differ')
            local=self.directory/name
            if local.exists() and local.read_bytes()!=raw:raise ValueError('Existing local state differs from durable resume; preserve/HOLD')
            if not local.exists():atomic_bytes(local,raw)
        if not (self.directory/'EPOCH_UPDATES.json').exists():atomic_bytes(self.directory/'EPOCH_UPDATES.json',json.dumps(self.pointer['updates']).encode())
        self.updates=list(self.pointer['updates']);self.previous_steps=sum(r['applied'] for r in self.updates)
        if native_io is None:raise ValueError('Cold Student restore requires strict Native IO')
        last=native_io.checkpoint_read(self.directory/'last.pt')
        if identity(last['contract'])!=self.contract_id or last['epoch']+1!=self.pointer['completed_epochs'] or native_io.model_state_identity(last['model_state'])!=last['model_digest']:raise ValueError('Cold Student payload/contract differs')
        atomic_bytes(self.directory/'history.json',json.dumps(last['history']).encode())
        best=native_io.checkpoint_read(self.directory/'best.pt');selected=min(last['history'],key=lambda r:(-r['val_accuracy_pct'],r['val_loss'],r['epoch']))
        if best['contract']!=last['contract'] or best['epoch']!=selected['epoch']-1 or native_io.model_state_identity(best['model_state'])!=best['model_digest']:raise ValueError('Cold Student best/last binding differs')
        self.best_epoch=best['epoch'];self.last_epoch=last['epoch'];self.expected_best_epoch=selected['epoch']-1
    def checkpoint_observation(self,path,payload):
        if Path(path).name=='best.pt':self.best_epoch=payload['epoch'];return
        if Path(path).name!='last.pt':return
        steps=[int(v['step']) for v in payload['optimizer_state']['state'].values() if 'step' in v]
        if not steps or len(set(steps))!=1:raise ValueError('Student Adam step count differs between parameters')
        step=steps[0];epoch=payload['epoch'];samples=payload['history'][-1]['train_samples'];cfg=payload['execution']['config']
        attempted=(samples+cfg['effective_batch_size']-1)//cfg['effective_batch_size'];applied=step-self.previous_steps
        if not 0<=applied<=attempted:raise ValueError('Student step accounting differs')
        self.updates.append({'epoch':epoch+1,'attempted':attempted,'applied':applied,'AMP_skipped':attempted-applied,'scale':payload['scaler_state'].get('scale')})
        self.previous_steps=step
        self.last_epoch=epoch;self.expected_best_epoch=min(payload['history'],key=lambda r:(-r['val_accuracy_pct'],r['val_loss'],r['epoch']))['epoch']-1
        atomic_bytes(self.directory/'EPOCH_UPDATES.json',json.dumps(self.updates).encode())
    def flush(self,completed):
        if self.last_epoch is None or self.last_epoch+1!=completed or self.best_epoch!=self.expected_best_epoch:raise ValueError('Student best/last/history binding incomplete; prior durable snapshot preserved')
        protected=set() if not self.pointer else {self.pointer['slot'],*([] if self.pointer.get('prior_slot') is None else [self.pointer['prior_slot']])}
        slot=next(i for i in range(3) if i not in protected)
        refs={}
        for key,local,name in [('best','best.pt',f'best_head_{slot}.pt'),('last','last.pt',f'resume_remote_{slot}.pt')]:
            raw=(self.directory/local).read_bytes();refs[key]=self.backend.put(name,raw);self.backend.verify_ref(refs[key])
        pointer={'schema':'native.Student.sparse.v1','contract_id':self.contract_id,'slot':slot,'prior_slot':None if self.pointer is None else self.pointer['slot'],'completed_epochs':completed,'updates':list(self.updates),**refs}
        put_json(self.backend,'STUDENT_COMMITTED.json',pointer)
        self.pointer=pointer;self.last_success=time.monotonic()
    def status(self,value):
        completed=value.get('completed_epochs',0)
        if not completed:return
        if value['state'] in ('complete','paused_at_epoch_boundary','failed','interrupted') or time.monotonic()-self.last_success>=self.interval:self.flush(completed)
        put_json(self.backend,'history.json',read(self.directory/'history.json'))
        put_json(self.backend,'EPOCH_UPDATES.json',self.updates)
        put_json(self.backend,'progress.json',{'schema':'native.Student.progress.v1','contract_id':self.contract_id,'computed_epochs':completed,'planned_epochs':self.epochs,'durable_epochs':0 if self.pointer is None else self.pointer['completed_epochs'],'state':value['state']})
    @contextmanager
    def hooked(self,train):
        original_json,original_checkpoint=train.json_write,train.checkpoint_write
        def checkpoint(path,value):
            original_checkpoint(path,value);self.checkpoint_observation(path,value)
        def write(path,value):
            original_json(path,value)
            if Path(path).resolve()==(self.directory/'status.json').resolve():self.status(value)
        train.json_write,train.checkpoint_write=write,checkpoint
        try:yield self
        finally:train.json_write,train.checkpoint_write=original_json,original_checkpoint
