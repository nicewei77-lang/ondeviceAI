"""Frozen official Native runtime bindings, initialized before direct b1kd imports."""
def bindings(dataset):
    from phaseb.native import config
    cfg=config(dataset)
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    return cfg,current_training_runtime,validate_runtime_match
def flowers_runtime_bindings():return bindings('flowers102')
def aircraft_runtime_bindings():return bindings('aircraft')
