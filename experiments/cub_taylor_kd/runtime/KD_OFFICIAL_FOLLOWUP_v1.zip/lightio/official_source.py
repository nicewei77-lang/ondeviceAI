"""Explicit official-dataset Native alternatives. Never load CUB Git B0."""
from pathlib import Path
import json,math
from .identity import identity,read,sha
from .followup_common import native,ensure_dataset
from .github_source import same_version,export_checkpoint,restore_export,export_history
from .eval_policy import evaluation_native

def metadata_for(service,dataset):
    cfg,pin,module=native(dataset);expected=pin['source_metadata'];m=service.files().get(fileId=expected['id'],fields='id,name,size,version,sha256Checksum,md5Checksum,mimeType,trashed').execute()
    if m['id']!=expected['id'] or m['name']!='best.pt' or m.get('trashed') or int(m['size'])!=int(expected['size']) or not m.get('version'):raise ValueError('Dataset-specific exact Native source metadata differs')
    return m

def validate_native_payload(value,pin,native_io):
    ref=pin['base_reference']
    if value['contract']!=pin['expected_full_native_contract'] or value['model_spec']!=ref['model_spec'] or value['epoch']!=ref['epoch'] or native_io.identity(value['contract'])!=ref['contract_id'] or native_io.model_state_identity(value['model_state'])!=ref['model_digest']:raise ValueError('Native dataset/spec/class/split/recipe/model digest differs')

def prepare_for(dataset,service,package,sets,cfg,cache,expected_sha=None):
    import torch
    from phaseb.native import ROOT
    _,pin,module=native(dataset);io=models=None
    native_io,models,train,metrics=(module(dataset,n) for n in ('io','models','train','metrics'))
    source_pin=read(ROOT/'followup_iterative_v2/assets/source_pins.json')['datasets'][dataset];wanted=source_pin['raw_sha256']
    if expected_sha not in (None,wanted):raise ValueError('Official Native SHA differs')
    path=Path(pin['base_reference']['path']);before=metadata_for(service,dataset)
    if sha(path)!=wanted or (before.get('sha256Checksum') and before['sha256Checksum']!=wanted):raise ValueError('Official Native FUSE/API SHA differs')
    value=native_io.checkpoint_read(path);ref=pin['base_reference'];manifest=read(ROOT/pin['reference_manifest']);classes=[r['name'] for r in manifest['classes']]
    validate_native_payload(value,pin,native_io)
    if any(not bool(torch.isfinite(t).all()) for t in value['model_state'].values()):raise ValueError('Nonfinite Native source')
    dense=models.build_from_spec(value['model_spec']);dense.load_state_dict(value['model_state'],strict=True)
    state={k:v.detach().cpu().clone() for k,v in dense.state_dict().items()}
    def factory():
        m=models.build_from_spec(value['model_spec']);m.load_state_dict(state,strict=True);return m
    logits,labels,ids=evaluation_native(train).predict(dense.to('cuda').eval(),sets['val'],8,cfg['num_workers'],'cuda')
    if ids!=[r['image_id'] for r in manifest['val']] or labels.tolist()!=[r['label'] for r in manifest['val']] or not bool(torch.isfinite(logits).all()):raise ValueError('Official ordered Val/class labels/finite differs')
    stats=metrics.classification_metrics(logits,labels,len(classes))
    # Baseline tensor/recipe is independently pinned. Report batch8 re-evaluation;
    # do not impose CUB1000/1200 or quietly equate it to old Native batch16 selection.
    hard=metrics.select_hard_classes(logits,labels,classes,len(pin['hard_set']['class_ids']),teacher_checkpoint=wanted)
    hard.update(schema=f'{dataset}.Native_dense_Hard.v1',baseline_sha256=wanted,legacy_auxiliary_class_ids=pin['hard_set']['class_ids'],legacy_Hard_identity=pin['hard_set']['identity'],primary_Hard_changed_from_historical='Recomputed once from same dense batch8 Val; legacy Hard only auxiliary')
    evidence={'baseline_kind':'EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_MANAGER_B0','Git_manager_baseline_confirmed':False,'dataset':dataset,'file_id':before['id'],'bytes':int(before['size']),'sha256':wanted,'provider_metadata':before,'model_spec':value['model_spec'],'model_digest':ref['model_digest'],'class_names':classes,
        'checkpoint_epoch_0based':value['epoch'],'source_checkpoint_class_names_schema':'Native manifest ordered labels pinned in contract','source_training_config':value['contract']['config'],'historical_DINO_commit':value['model_spec']['upstream_commit'],'restoration_DINO_commit':value['model_spec']['upstream_commit'],
        'validation':stats,'historical_selected_validation_batch16':value['val_metrics'],'evaluation_batch_size':8,'training_batch_size':16,'effective_training_batch':64,'validation_ID_identity':identity(ids),'hard_identity':identity(hard),'source_recipe_is_not_recovery_recipe':True}
    same_version(before,metadata_for(service,dataset))
    from followup_iterative_v2.surgery import dense_layout
    payload={'model_state':state,'model_digest':ref['model_digest'],'layout':dense_layout(dense)}
    source={'position':f'{dataset}_Native_dense','file_id':before['id'],'reference':{'sha256':wanted,'bytes':int(before['size']),'provider_metadata':before},'source_model_digest':ref['model_digest'],'historical_exact_resume':False,'Git_B0':False}
    print('OFFICIAL_SOURCE_VERIFIED',dataset,json.dumps({'baseline_kind':evidence['baseline_kind'],'file_id':before['id'],'sha256':wanted,'model_digest':ref['model_digest'],'eval_batch':8,'validation_accuracy_pct':stats['accuracy_pct'],'classes':len(classes),'train_calibration_count':2*len(classes)}),flush=True)
    return payload,source,factory,evidence,hard

def prepare_flowers(*a,**k):return prepare_for('flowers102',*a,**k)
def prepare_aircraft(*a,**k):return prepare_for('aircraft',*a,**k)
def metadata_flowers(service):return metadata_for(service,'flowers102')
def metadata_aircraft(service):return metadata_for(service,'aircraft')
def ensure_flowers_data(inputs,local_root,existing_root=None):
    sets,receipt,_=ensure_dataset('flowers102',inputs,local_root,existing_root);return sets,receipt
def ensure_aircraft_data(inputs,local_root,existing_root=None):
    sets,receipt,_=ensure_dataset('aircraft',inputs,local_root,existing_root);return sets,receipt
