"""Small explicit source/runtime gates for new follow-up outputs only."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
from .identity import identity,read,sha
from .backend import DriveBackend,atomic_bytes
from .teacher_reader import TeacherReader

OLD_NAMESPACE='cub_git_b0_taylor_v1_2'
TEACHER_FOLDER='1Z4YgqijqEnD9z88BgFpQCLK9306ofpzy'
TEACHER_SEQUENCE='3243d033e97b5c4f1db2406c68a74a429cdb2f178533bff97ec37380128f383d'

def native(dataset):
    from phaseb.native import config,module,ROOT
    cfg=config(dataset)  # Register verified vendor parent BEFORE b1kd imports.
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset]
    validate_runtime_match(pin['baseline_execution_runtime'],current_training_runtime())
    return cfg,pin,module

def require_colab():
    import torch,shutil
    if os.name!='posix' or not Path('/content/drive').is_dir() or not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':
        raise ValueError('Use one already assigned mounted Colab L4; code never allocates a GPU')
    if shutil.disk_usage('/content').free<8*1024**3:raise ValueError('Colab free disk below8GiB')

def one_folder(service,parent,name):
    escaped=name.replace("'","\\'")
    rows=[];token=None
    while True:
        r=service.files().list(q=f"'{parent}' in parents and name='{escaped}' and trashed=false",fields='files(id,name,mimeType,parents),nextPageToken',pageToken=token).execute()
        rows+=r.get('files',[]);token=r.get('nextPageToken')
        if not token:break
    if len(rows)!=1 or rows[0]['mimeType']!='application/vnd.google-apps.folder' or rows[0].get('parents')!=[parent]:raise ValueError('Exact unique source folder absent/ambiguous: '+name)
    return rows[0]['id']

def required_json(backend,name):
    raw=backend.get(name)
    if raw is None:raise ValueError('Required completed artifact missing: '+name)
    return json.loads(raw)

def teacher_terminal(service):
    """Read completion/selection only. Never choose Teachers using Test metrics."""
    from .extend_test import validate_lineage
    from .extend_runner import completed_segment
    from .extension import ExtensionRecipe
    sequence=TeacherReader(TEACHER_FOLDER,TEACHER_SEQUENCE,namespace=OLD_NAMESPACE,service=service)
    report=required_json(sequence,'COMPLETE.json');validate_lineage(report)
    op=required_json(sequence,'OPERATIONAL_CONTRACT.json')
    if report['sequence_id']!=TEACHER_SEQUENCE or report['new_Teacher_epochs']!=80 or required_json(sequence,'OWNER.json')['state']!='complete':raise ValueError('Teacher80 not terminal')
    if op['code_id']!='81aefa8e76aa6e245c427745c532d0545ebd072d14669da21e0a057cdcde5a7d':raise ValueError('Unexpected Teacher code')
    sources={};locked={}
    for key in ('30','50','70'):
        result=report['targets'][key];recipe=ExtensionRecipe(**result['recipe'])
        backend=TeacherReader(result['folder_id'],result['operational_id'],namespace=OLD_NAMESPACE,service=service)
        if completed_segment(backend,recipe,required_json(backend,'OPERATIONAL_CONTRACT.json'))!=result:raise ValueError('Teacher target not closed')
        rows=required_json(backend,'history.json');best=min(rows[recipe.budget*3//4:],key=lambda x:(-x['val_accuracy_pct'],x['val_loss'],x['epoch']))
        if best!=result['selected_validation']:raise ValueError('Teacher selection differs from Validation rule')
        locked[key]={'checkpoint':result['checkpoint_receipt']['selected_teacher'],'validation_epoch':best['epoch'],'contract_id':recipe.contract_id}
        sources[key]=(backend,recipe)
    # Test must already have completed, but no Test scores enter KD selection/contracts.
    folder=one_folder(service,TEACHER_FOLDER,'TEST_SELECTED_30_50_70')
    lock_raw=service.files().list(q=f"'{folder}' in parents and name='COMPLETE.json' and trashed=false",fields='files(id),nextPageToken').execute()
    if len(lock_raw.get('files',[]))!=1 or lock_raw.get('nextPageToken'):raise ValueError('Teacher Test not complete')
    done=json.loads(service.files().get_media(fileId=lock_raw['files'][0]['id']).execute())
    if done.get('state')!='complete' or set(done.get('targets',{}))!={'0','30','50','70'}:raise ValueError('Teacher Test incomplete')
    test_id=identity({'role':'extension_Test','lock':done['selection_lock_id']})
    test_backend=TeacherReader(folder,test_id,namespace=OLD_NAMESPACE,service=service)
    if required_json(test_backend,'OWNER.json')['state']!='complete' or required_json(test_backend,'TEST_SELECTION_LOCK.json')['selection_lock_id']!=done['selection_lock_id'] or done['targets']['0']['checkpoint_sha256']!=report['B0']['sha256']:raise ValueError('Teacher Test writer/selection/B0 closure differs')
    # Each fixed target must refer to the same validation-selected checkpoint.
    for k in ('30','50','70'):
        if done['targets'][k]['checkpoint']!=locked[k]['checkpoint']:raise ValueError('Teacher Test/Val checkpoint binding differs')
    from phaseb.native import ROOT
    split_id=read(ROOT/'configs/readonly_inputs.json')['datasets']['cub200']['split_id']
    lock={'source_sequence':TEACHER_SEQUENCE,'B0':{k:report['B0'][k] for k in ('file_id','sha256','model_digest','provider_metadata')},'selected':locked,
          'split_id':split_id,'validation_ID_identity':op['B0']['validation_ID_identity'],'Hard_identity':report['hard_set_id'],'Teacher_selection_basis':'Validation only; Test metrics excluded','teachers':['B0','30','50','70']}
    return report,{**lock,'lock_id':identity(lock)},sources

def ensure_dataset(dataset,inputs,local_root,existing_root=None,test=False):
    from phaseb.native import ROOT
    from phaseb.pipeline import context
    cfg,pin,module=native(dataset);local_root=Path(local_root).resolve()
    if not local_root.is_relative_to('/content') or local_root.is_relative_to('/content/drive'):raise ValueError('Local cache must be Colab-local')
    cmd=[sys.executable,'-B','-u',str(ROOT/'vendor/native_parent/tools/prepare_data.py'),'--dataset',dataset,'--inputs',str(inputs),'--cache-root',str(local_root/'raw'),'--work-dir',str(local_root/'preflight'),'--native-results',pin['native_results']]
    if existing_root:cmd+=['--data-root',str(existing_root)]
    subprocess.run(cmd,check=True,cwd=ROOT)
    receipt=read(local_root/f'preflight/data/{dataset}/B1_DATA_RECEIPT.json')
    if receipt['split_id']!=pin['split_id'] or not receipt['full_image_preflight_complete'] or not receipt['exact_native_manifest_parity']:raise ValueError('Dataset native full-image parity differs')
    _,manifest,sets=context(dataset,{}, {dataset:receipt['data_root']},test=test)
    return sets,receipt,manifest

def native_saved(dataset,kind,seed=None):
    """Read only original frozen Native initializer/baseline; no random fallback."""
    cfg,pin,module=native(dataset);io=module(dataset,'io');models=module(dataset,'models')
    from phaseb.native import ROOT
    source=read(ROOT/'followup_iterative_v2/assets/source_pins.json')['datasets'][dataset]
    if kind=='initial':ref=pin['initializations'][str(seed)];path=Path(ref['path']);expected_sha=source['initializations'][str(seed)]['raw_sha256']
    else:ref=pin['baselines'][str(seed)];path=Path(ref['path']);expected_sha=sha(path)
    if sha(path)!=expected_sha:raise ValueError('Pinned Native source raw SHA changed')
    value=io.checkpoint_read(path)
    if io.identity(value['contract'])!=ref['contract_id'] or io.model_state_identity(value['model_state'])!=ref['model_digest']:raise ValueError('Pinned Native model/contract differs')
    if value['model_spec']!={'schema_version':1,'kind':'student','architecture':'mobilenet_v3_large','num_classes':cfg['num_classes'],'width_mult':1.0,'dropout':.2,'test_fixture':False}:raise ValueError('Native Student specification differs')
    if kind=='baseline':
        from phaseb.pipeline import verify_training_complete
        if value['contract']['config']!=cfg or value['contract']['seed']!=seed:raise ValueError('Student-only recipe differs; cannot silently reuse')
        verified=verify_training_complete(path.parent,60,value['contract'],value['model_spec'])
        if verified['model_digest']!=value['model_digest']:raise ValueError('Student-only completion differs')
        if sha(path)!=expected_sha:raise ValueError('Student-only source changed during read-only verification')
    model=models.build_from_spec(value['model_spec']);model.load_state_dict(value['model_state'],strict=True)
    return model,value,{'path':str(path),'sha256':expected_sha,'model_digest':ref['model_digest'],'contract_id':ref['contract_id'],'seed':seed,'kind':kind}
