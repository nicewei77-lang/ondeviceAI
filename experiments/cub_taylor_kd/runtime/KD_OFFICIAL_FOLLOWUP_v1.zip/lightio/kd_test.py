"""Locked all-seed Native Student Test; no training or Teacher re-selection."""
import csv,hashlib,io,json,math,time
from pathlib import Path
from .identity import identity,read,sha
from .backend import DriveBackend
from .staged_runner import put_json
from .followup_common import ensure_dataset,native_saved

def evaluate(report,output,service,module,cfg,manifest,inputs,*,resume=False):
    import torch
    if len(report['results'])!=12 or set(report['baselines'])!={'42','43','44'}:raise ValueError('All four Teachers x three seeds required before Student Test')
    locked={name:{k:r[k] for k in ('best','contract_id','selected_epoch','model_digest','Teacher_lock_id')} for name,r in report['results'].items()}
    body={'Teacher_lock_id':report['Teacher_lock_id'],'students':locked,'baselines':{s:v['checkpoint'] for s,v in report['baselines'].items()},'ordered_Test_identity':identity(manifest['test']),'hard_identity':identity(report['hard_set']),'selection':'Native all60 Validation only; OA/CE/earliest','Test_used_for_selection':False,'previously_exposed_CUB_Test':True,'new_holdout_claim':False,'student_eval_batch':16}
    lock={**body,'selection_lock_id':identity(body)};put_json(output,'STUDENT_TEST_SELECTION_LOCK.json',lock)
    sets,_,_=ensure_dataset('cub200',inputs,Path('/content/KD_followup_data'),report['data_root'],test=True)
    train,models,native_io,metrics=(module('cub200',n) for n in ('train','models','io','metrics'))
    records={};refs=[];hard=report['hard_set']['class_ids']
    for arm in ('baseline','B0','30','50','70'):
        for seed in (42,43,44):
            key=f'{arm}_{seed}';name=f'STUDENT_TEST_{key}';old=output.get(name+'_COMPLETE.json')
            if old is not None:
                done=json.loads(old)
                if done['selection_lock_id']!=lock['selection_lock_id']:raise ValueError('Prior Student Test selection differs')
                for ref in done['artifact_refs']:output.verify_ref(ref)
                records[key]=done;refs+=done['artifact_refs'];continue
            cached=None;model=None;value=None
            if arm=='baseline':
                from phaseb.native import ROOT
                pin=read(ROOT/'configs/readonly_inputs.json')['datasets']['cub200'];saved_ref=pin['baseline_saved_predictions']['test'][str(seed)]
                path=Path(saved_ref['path']);checkpoint=report['baselines'][str(seed)]['checkpoint']
                if path.exists():
                    if sha(path)!=saved_ref['sha256'] or sha(checkpoint['path'])!=checkpoint['sha256']:raise ValueError('Pinned baseline prediction/model bytes differ')
                    cached=torch.load(path,map_location='cpu',weights_only=True)
                    c=cached['checkpoint']
                    if cached['split']!='test' or c['path']!=checkpoint['path'] or c['model_digest']!=checkpoint['model_digest'] or c['contract_id']!=checkpoint['contract_id']:raise ValueError('Baseline cached Test source differs')
                else:model,value,checkpoint=native_saved('cub200','baseline',seed)
            else:
                result=report['results'][f'KD_{arm}_seed{seed}'];src=DriveBackend(result['folder_id'],result['contract_id']);ref=result['best'];src.verify_ref(ref)
                raw=src.get(ref['file'],expected_id=ref['file_id'])
                if len(raw)!=ref['bytes'] or hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('Student Test model bytes changed')
                value=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
                if identity(value['contract'])!=result['contract_id'] or value['model_spec']!=result['model_spec'] or native_io.model_state_identity(value['model_state'])!=result['model_digest'] or value['epoch']+1!=result['selected_epoch']:raise ValueError('Student Test checkpoint contract differs')
                model=models.build_from_spec(value['model_spec']);model.load_state_dict(value['model_state'],strict=True);checkpoint=ref
            start=time.monotonic()
            if cached is not None:logits,labels,ids=cached['logits'],cached['labels'],cached['image_ids']
            else:
                model=model.to('cuda').eval()
                logits,labels,ids=train.predict(model,sets['test'],cfg['batch_size'],cfg['num_workers'],'cuda')
            if ids!=[r['image_id'] for r in manifest['test']] or labels.tolist()!=[r['label'] for r in manifest['test']] or not bool(torch.isfinite(logits).all()):raise ValueError('Student Test IDs/labels/finite differs')
            stat=metrics.classification_metrics(logits,labels,200,hard);supported=[a for a in stat['per_class_accuracy_pct'] if a is not None];mask=torch.tensor([int(y) in hard for y in labels])
            stat.update(macro_accuracy_pct=sum(supported)/len(supported),hard_ce=float(torch.nn.functional.cross_entropy(logits[mask].double(),labels[mask])),seed=seed,teacher_arm=arm,selection_lock_id=lock['selection_lock_id'],checkpoint=checkpoint,evaluation_batch_size=16,inference_seconds=0. if cached is not None else time.monotonic()-start,reused_original_Native_Test_logits=cached is not None)
            text=io.StringIO(newline='');writer=csv.writer(text);writer.writerow(['image_id','label','prediction','correct','is_hard','CE'])
            losses=torch.nn.functional.cross_entropy(logits.double(),labels,reduction='none').tolist()
            for iid,y,pred,loss in zip(ids,labels.tolist(),logits.argmax(1).tolist(),losses):writer.writerow([iid,y,pred,int(y==pred),int(y in hard),loss])
            stream=io.BytesIO();torch.save({'logits':logits,'labels':labels,'image_ids':ids,'checkpoint':checkpoint,'selection_lock_id':lock['selection_lock_id']},stream)
            parts=[put_json(output,name+'.json',stat),output.put(name+'.csv',text.getvalue().encode()),output.put(name+'.pt',stream.getvalue())]
            for ref in parts:output.verify_ref(ref)
            done={'selection_lock_id':lock['selection_lock_id'],'metrics':stat,'artifact_refs':parts};put_json(output,name+'_COMPLETE.json',done);records[key]=done;refs+=parts
            del model,value,logits;torch.cuda.empty_cache()
    summary={}
    for arm in ('baseline','B0','30','50','70'):
        summary[arm]={}
        for metric in ('accuracy_pct','hard_accuracy_pct','macro_accuracy_pct','loss','hard_ce'):
            values=[records[f'{arm}_{s}']['metrics'][metric] for s in (42,43,44)];mean=sum(values)/3
            summary[arm][metric]={'values':values,'mean':mean,'sample_std':math.sqrt(sum((v-mean)**2 for v in values)/2)}
    return {'state':'complete','selection_lock_id':lock['selection_lock_id'],'records':records,'summary':summary,'artifact_refs':refs,'Test_used_for_tuning':False}
