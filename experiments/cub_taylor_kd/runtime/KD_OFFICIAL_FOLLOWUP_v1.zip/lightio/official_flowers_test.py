"""Optional Test-only phase for locked50/70 validation-best checkpoints."""
from pathlib import Path
from dataclasses import asdict
import csv,hashlib,io,json,os,time
from .identity import identity,read
from .backend import DriveBackend
from .lease import WriterLease
from .staged_runner import owned_folder,put_json
from .official_extension import ExtensionRecipe
from .official_flowers_runner import completed_segment

def validate_lineage(report):
    from phaseb.native import ROOT
    # Source exact ID is locked per dataset in the report
    if report.get('state')!='complete' or set(report.get('targets',{}))!={'30','50','70'}:raise ValueError('All3 targets required before Test')
    b0,hard=report['B0'],report['hard_set']
    if b0['file_id']!=read(ROOT/'configs/readonly_inputs.json')['datasets']['flowers102']['source_metadata']['id'] or hard['baseline_sha256']!=b0['sha256'] or identity(hard)!=report['hard_set_id'] or b0['hard_identity']!=report['hard_set_id']:
        raise ValueError('B0/Hard lineage differs')
    prior=None
    for target in ('30','50','70'):
        result=report['targets'][target];source=result['source']
        if ExtensionRecipe(**result['recipe']).source_id!=identity(source):raise ValueError('Pruning source contract differs')
        if prior is None:
            if source!=report['source30'] or source['file_id']!=report['B0']['file_id'] or source['reference']['sha256']!=b0['sha256']:raise ValueError('30% did not start at exact Git B0')
        elif source['reference']!=prior['last_model'] or source['position']!=f"last{prior['target_percent']}":raise ValueError('Next target did not use previous LAST')
        prior=result

def evaluate(report,code,service,*,inputs,data_root=None,resume=False,request_release=False,prior_release=None):
    report={k:v for k,v in report.items() if k!='Test_result'}
    import torch
    from phaseb.native import ROOT,module
    from .official_bootstrap import flowers_runtime_bindings
    from .kernel import strict_verifier
    from followup_iterative_v2.surgery import restore,assert_stage_widths
    validate_lineage(report)
    if os.name!='posix' or not Path('/content/drive').is_dir() or not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':raise ValueError('Assigned mounted Colab L4 required; no PC model read')
    cfg,_,_=flowers_runtime_bindings();pin=read(ROOT/'configs/readonly_inputs.json')['datasets']['flowers102'];manifest=read(ROOT/pin['reference_manifest'])
    sequence=DriveBackend(report['output_folder_id'],report['sequence_id']);op=json.loads(sequence.get('OPERATIONAL_CONTRACT.json'))
    if json.loads(sequence.get('OWNER.json'))['state']!='complete' or op['B0']!=report['B0'] or op['hard_set']!=report['hard_set'] or json.loads(sequence.get('COMPLETE.json'))!=report:
        raise ValueError('Completed sequence/source/Hard differs before Test lock')
    hard=report['hard_set']
    if identity(manifest)!=pin['split_id'] or identity(hard)!=report['hard_set_id']:raise ValueError('Split/Hard changed')
    locked={};sources={};recipes={}
    for target,result in report['targets'].items():
        recipe=ExtensionRecipe(**result['recipe']);source=DriveBackend(result['folder_id'],result['operational_id']);op=json.loads(source.get('OPERATIONAL_CONTRACT.json'))
        if completed_segment(source,recipe,op)!=result:raise ValueError('Target not closed')
        rows=json.loads(source.get('history.json'));selected=min(rows[recipe.budget*3//4:],key=lambda x:(-x['val_accuracy_pct'],x['val_loss'],x['epoch']))
        if selected!=result['selected_validation']:raise ValueError('Validation-best differs')
        locked[target]={'checkpoint':result['checkpoint_receipt']['selected_teacher'],'validation':selected,'recipe_contract_id':recipe.contract_id}
        sources[target],recipes[target]=source,recipe
    body={'training_sequence':report['sequence_id'],'selected':locked,'split_id':pin['split_id'],'hard_id':report['hard_set_id'],'B0':report['B0'],
        'ordered_Test_records_identity':identity(manifest['test']),'methods':['30percent_validation_best','50percent_validation_best','70percent_validation_best','same_frozen_dataset_Native_dense'],
        'Test_used_for_selection':False,'prior_dataset_Test_exposure':True,'new_holdout_claim':False}
    lock={**body,'selection_lock_id':identity(body)};eval_id=identity({'role':'flowers102_extension_Test','lock':lock['selection_lock_id']})
    folder=owned_folder(service,report['output_folder_id'],'TEST_SELECTED_30_50_70',eval_id);output=DriveBackend(folder,eval_id)
    old=output.get('COMPLETE.json')
    if old is not None:
        done=json.loads(old)
        if done['selection_lock_id']!=lock['selection_lock_id']:raise ValueError('Prior Test lock differs')
        for ref in done['artifact_refs']:output.verify_ref(ref)
        return done
    with WriterLease(Path('/content/cub_GitB0_Test')/eval_id,output,eval_id,resume=resume,prior_release=prior_release) as lease:
        put_json(output,'TEST_SELECTION_LOCK.json',lock)
        from .official_source import ensure_flowers_data as ensure_data
        _,data=ensure_data(inputs,Path('/content/cub_taylor_extend_Test/data'),data_root)
        from phaseb.pipeline import context
        _,_,sets=context('flowers102',{}, {'flowers102':data['data_root']},test=True)
        native_io,train,metrics_lib,models=(module('flowers102',n) for n in ('io','train','metrics','models'))
        from .eval_policy import evaluation_native,EVALUATION_BATCH_SIZE
        train=evaluation_native(train)
        factory=lambda:models.build_from_spec(report['B0']['model_spec'])
        records={};refs=[]
        try:
            for target,source in sources.items():
                old=output.get(f'TEST_{target}_COMPLETE.json')
                if old:
                    done=json.loads(old)
                    if done['selection_lock_id']!=lock['selection_lock_id'] or done['checkpoint']!=locked[target]['checkpoint']:raise ValueError('Completed target Test differs')
                    for r in done['artifact_refs']:output.verify_ref(r)
                    records[target]=done;refs+=done['artifact_refs'];continue
                ref=locked[target]['checkpoint'];source.verify_ref(ref);raw=source.get('selected_teacher.pt',expected_id=ref['file_id'])
                if hashlib.sha256(raw).hexdigest()!=ref['sha256']:raise ValueError('Model raw SHA changed')
                payload = strict_verifier(recipes[target],native_io,factory)(raw)
                model=restore(factory,payload['model_state'],payload['layout'],digest=payload['model_digest'],state_identity=native_io.model_state_identity).to('cuda')
                assert_stage_widths(model,payload['layout'],recipes[target],3)
                start=time.monotonic();logits,labels,ids=train.predict(model,sets['test'],cfg['batch_size'],cfg['num_workers'],'cuda')
                if ids!=[r['image_id'] for r in manifest['test']] or labels.tolist()!=[r['label'] for r in manifest['test']]:raise ValueError('Ordered Test IDs/labels differ')
                metrics=metrics_lib.classification_metrics(logits,labels,102,hard['class_ids']);supported=[x for x in metrics['per_class_accuracy_pct'] if x is not None]
                mask=torch.tensor([int(y) in hard['class_ids'] for y in labels]);metrics.update(macro_accuracy_pct=sum(supported)/len(supported),
                    hard_ce=float(torch.nn.functional.cross_entropy(logits[mask].double(),labels[mask])),inference_seconds=time.monotonic()-start,
                    checkpoint=ref,selection_lock_id=lock['selection_lock_id'],split='test',evaluation_batch_size=EVALUATION_BATCH_SIZE)
                auxiliary=metrics_lib.classification_metrics(logits,labels,102,hard['legacy_auxiliary_class_ids'])
                metrics.update(legacy_Hard_accuracy_pct=auxiliary['hard_accuracy_pct'],legacy_Hard_identity=hard['legacy_Hard_identity'],primary_Hard_identity=report['hard_set_id'])
                text=io.StringIO(newline='');writer=csv.writer(text);writer.writerow(['image_id','label','prediction','correct','is_hard','ce_loss'])
                losses=torch.nn.functional.cross_entropy(logits.double(),labels,reduction='none').tolist()
                for image_id,y,pred,loss in zip(ids,labels.tolist(),logits.argmax(1).tolist(),losses):writer.writerow([image_id,y,pred,int(y==pred),int(y in hard['class_ids']),loss])
                stream=io.BytesIO();torch.save({'logits':logits,'labels':labels,'image_ids':ids,'checkpoint':ref,'selection_lock_id':lock['selection_lock_id']},stream)
                parts=[put_json(output,f'TEST_{target}.json',metrics),output.put(f'TEST_{target}.csv',text.getvalue().encode()),output.put(f'TEST_{target}.pt',stream.getvalue())]
                source.verify_ref(ref)
                for r in parts:output.verify_ref(r)
                done={'checkpoint':ref,'selection_lock_id':lock['selection_lock_id'],'metrics':metrics,'artifact_refs':parts}
                put_json(output,f'TEST_{target}_COMPLETE.json',done);records[target]=done;refs+=parts
                del model,payload,raw,logits;torch.cuda.empty_cache()
        except KeyboardInterrupt:
            lease.finish('paused',0)
            raise
        # Same frozen B0 evaluated once after selection lock; never use Test to choose Hard/checkpoint.
        from .official_source import prepare_flowers as prepare_baseline,same_version,metadata_flowers as metadata
        old=output.get('TEST_0_COMPLETE.json')
        if old:
            dense_done=json.loads(old)
            if dense_done['selection_lock_id']!=lock['selection_lock_id'] or dense_done['checkpoint_sha256']!=report['B0']['sha256']:raise ValueError('Prior B0 Test identity differs')
            for ref in dense_done['artifact_refs']:output.verify_ref(ref)
        else:
            from .official_source import metadata_for
            source_path=Path(report['source30']['reference']['provider_metadata']['source_path']) if 'source_path' in report['source30']['reference']['provider_metadata'] else Path(read(ROOT/'configs/readonly_inputs.json')['datasets']['flowers102']['base_reference']['path'])
            if sha(source_path)!=report['B0']['sha256']:raise ValueError('Official dense source changed')
            dense_value=native_io.checkpoint_read(source_path)
            if native_io.model_state_identity(dense_value['model_state'])!=report['B0']['model_digest']:raise ValueError('Official dense model differs')
            dense=models.build_from_spec(report['B0']['model_spec']);dense.load_state_dict(dense_value['model_state'],strict=True)
            source_evidence={'provider_metadata':metadata(service)}
            same_version(report['B0']['provider_metadata'],source_evidence['provider_metadata'])
            dense=dense.to('cuda').eval();start=time.monotonic()
            logits,labels,ids=train.predict(dense,sets['test'],cfg['batch_size'],cfg['num_workers'],'cuda')
            if ids!=[r['image_id'] for r in manifest['test']] or labels.tolist()!=[r['label'] for r in manifest['test']]:raise ValueError('B0 ordered Test IDs differ')
            stats=metrics_lib.classification_metrics(logits,labels,102,hard['class_ids'])
            auxiliary=metrics_lib.classification_metrics(logits,labels,102,hard['legacy_auxiliary_class_ids'])
            stats.update(primary_Hard_identity=report['hard_set_id'],legacy_Hard_accuracy_pct=auxiliary['hard_accuracy_pct'],legacy_Hard_identity=hard['legacy_Hard_identity'],inference_seconds=time.monotonic()-start,evaluation_batch_size=EVALUATION_BATCH_SIZE)
            supported=[x for x in stats['per_class_accuracy_pct'] if x is not None]
            mask=torch.tensor([int(y) in hard['class_ids'] for y in labels])
            stats.update(macro_accuracy_pct=sum(supported)/len(supported),hard_ce=float(torch.nn.functional.cross_entropy(logits[mask].double(),labels[mask])))
            text=io.StringIO(newline='');writer=csv.writer(text);writer.writerow(['image_id','label','prediction','correct','is_hard','ce_loss'])
            losses=torch.nn.functional.cross_entropy(logits.double(),labels,reduction='none').tolist()
            for iid,y,pred,loss in zip(ids,labels.tolist(),logits.argmax(1).tolist(),losses):writer.writerow([iid,y,pred,int(y==pred),int(y in hard['class_ids']),loss])
            stream=io.BytesIO();torch.save({'logits':logits,'labels':labels,'image_ids':ids,'B0_sha256':report['B0']['sha256'],'selection_lock_id':lock['selection_lock_id']},stream)
            parts=[put_json(output,'TEST_0.json',stats),output.put('TEST_0.csv',text.getvalue().encode()),output.put('TEST_0.pt',stream.getvalue())]
            same_version(report['B0']['provider_metadata'],metadata(service))
            for ref in parts:output.verify_ref(ref)
            dense_done={'checkpoint_sha256':report['B0']['sha256'],'selection_lock_id':lock['selection_lock_id'],'metrics':stats,'artifact_refs':parts}
            put_json(output,'TEST_0_COMPLETE.json',dense_done)
            del dense,logits;torch.cuda.empty_cache()
        records['0']=dense_done;refs+=dense_done['artifact_refs']
        result={'state':'complete','selection_lock_id':lock['selection_lock_id'],'targets':records,'artifact_refs':refs,'Student_epochs':0,
            'prior_dataset_Test_exposure':True,'new_holdout_claim':False,'Test_reselection':False,'folder_id':folder}
        put_json(output,'COMPLETE.json',result);put_json(output,'COMPARISON.json',result)
        if request_release:put_json(output,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,'after':'verifiedB0/30/50/70 Test outputs'})
        lease.finish('complete',0)
    return result
