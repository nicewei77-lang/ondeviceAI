"""Prepared extension:30% Val-best ->50%, then50% last ->70%; no allocation."""
from pathlib import Path
from dataclasses import asdict
import argparse,io,json,os,time,types
from .identity import identity,read,sha,NAMESPACE
from .contracts import verify_delivery,OPTIONS
from .official_extension import ExtensionRecipe,branch_options,bootstrap_factory,metrics_factory
from .staged_runner import owned_folder,put_json
from .lease import WriterLease,runtime_identity
from .backend import DriveBackend
from .kernel import load_kernel,strict_verifier
from .official_taylor import TaylorCalibrator
from .recovery_loss import RecoveryLoss
from . import store

def plan():
    return {'state':'PREPARED_NOT_EXECUTED','baseline':'Explicit dataset-specific existing Native alternative; not Git B0; prunable source and frozen KL Teacher identical',
        'targets':[30,50,70],'stages':[[7.5,15,22.5,30],[35,40,45,50],[55,60,65,70]],
        'epochs_per_stage':[10,5,5],'new_Teacher_epochs_total':80,'old_anchor_reuse':False,
        'continuation':'target30 LAST ->50; target50 LAST ->70; each best separately preserved',
        'recovery':'seed20261013,batch16/eff64,WD.05,LR1e-5/head1e-4,local restart,fresh AdamW/scaler,CE+.5*T4^2*KL',
        'Hard':'dataset dense Val fixedHard; fixed before pruning/Test; old Hard only auxiliary',
        'Student_epochs':0,'Test_calls':0,'GPU_allocations':0,'automatic_accuracy_stop':False}

def _json(b,n):
    raw=b.get(n)
    if raw is None:raise ValueError('Required artifact absent: '+n)
    return json.loads(raw)

def completed_segment(backend,recipe,op):
    raw=backend.get('RUN_RESULT.json')
    if raw is None:return None
    result=json.loads(raw)
    if _json(backend,'OWNER.json').get('state')!='complete':return None
    complete=_json(backend,'COMPLETE.json');pointer=_json(backend,'REMOTE_COMMITTED.json')
    if result.get('state')!='complete' or result['experiment_id']!=recipe.contract_id or result['operational_id']!=op['operational_id'] or complete['remote_commit']!=pointer or pointer['active']['next_epoch']!=recipe.budget:
        raise ValueError('Completed extension identity differs')
    for ref in [*result.get('GitHub_export_refs',[]),pointer['active'],pointer['selected_teacher'],result['last_model'],*pointer['anchors'].values(),*pointer['calibrations'].values(),*pointer['boundary_audits'].values()]:backend.verify_ref(ref)
    return result

def run(args):
    if not args.start_training:return {**plan(),'dataset':'flowers102','Git_manager_baseline_confirmed':False,'calibration_count':204}
    if args.baseline_kind!='EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_B0':raise ValueError('Select explicit dataset-specific baseline; no CUB B0 substitution')
    import torch,hashlib,google.auth,shutil
    from googleapiclient.discovery import build
    if os.name!='posix' or not Path('/content/drive').is_dir() or not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':raise ValueError('Mounted assigned Colab L4 required; no allocation')
    if shutil.disk_usage('/content').free<8*1024**3:raise ValueError('Colab disk reserve below8GiB')
    package=Path(__file__).resolve().parents[1];code=verify_delivery(package)
    from .official_bootstrap import flowers_runtime_bindings
    cfg,current_runtime,validate_runtime=flowers_runtime_bindings()
    from .eval_policy import evaluation_native,EVALUATION_BATCH_SIZE
    cfg={**cfg,'evaluation_batch_size':EVALUATION_BATCH_SIZE}
    from phaseb.native import ROOT,module
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets']['flowers102'];validate_runtime(pin['baseline_execution_runtime'],current_runtime())
    native_io,native_train=module('flowers102','io'),module('flowers102','train')
    native_train=evaluation_native(native_train)
    creds,_=google.auth.default();service=build('drive','v3',credentials=creds,cache_discovery=False)
    from .official_source import ensure_flowers_data as ensure_data
    sets,data=ensure_data(args.inputs,Path('/content/official_flowers102_Taylor_v1/data'),args.data_root)
    from .official_source import prepare_flowers as prepare_baseline,metadata_flowers as metadata,same_version,export_checkpoint,restore_export,export_history
    payload,source,factory,b0,hard=prepare_baseline(service,package,sets,cfg,Path('/content/official_flowers102_Taylor_v1/source'),args.expected_source_sha)
    body={'namespace':NAMESPACE,'role':'Native_flowers102_TaylorCEKL_0to30to50to70','code_id':code['code_id'],'B0':b0,
        'hard_set':hard,'hard_set_id':identity(hard),'source30':source,
        'conditions_sha256':sha(package/'assets/FOLLOWUP_CONDITIONS.json'),'stages':[[7.5,15,22.5,30],[35,40,45,50],[55,60,65,70]],
        'epochs_per_stage':[10,5,5],'new_epochs_total':80,'Student_epochs':0,'Test_calls':0,'automatic_accuracy_stop':False}
    op={**body,'operational_id':identity(body)};dest=read(package/'assets/DRIVE_DESTINATION.json')
    folder=owned_folder(service,dest['runs_folder_id'],args.run_name,op['operational_id']);sequence=DriveBackend(folder,op['operational_id'])
    local=Path('/content/official_flowers102_Taylor_v1/runs')/op['operational_id'];results={};state='complete'
    released=read(args.runtime_release_evidence) if args.runtime_release_evidence else {}
    with WriterLease(local,sequence,op['operational_id'],resume=args.resume,prior_release=released.get('sequence')) as sequence_lease:
        from .runner import quota_gate
        quota_gate(sequence,minimum_free=20*1024**3)
        put_json(sequence,'B0_SOURCE.json',b0);put_json(sequence,'B0_VALIDATION.json',b0['validation']);put_json(sequence,'HARD_SET.json',hard)
        put_json(sequence,'OPERATIONAL_CONTRACT.json',op);put_json(sequence,'RUN_STARTED.json',{'pid':os.getpid(),'runtime_id':runtime_identity(),'source30':source,'state':'prepared_new_epochs0','new_epochs_planned':80})
        print('EXTENSION_SEQUENCE_READY',op['operational_id'],folder,source,flush=True)
        try:
            for start,target,offset,budget in ((0,30,0,40),(30,50,40,20),(50,70,60,20)):
                arm=f'TAYLOR_CEKL_TO{target}'
                recipe=ExtensionRecipe('flowers102','IT',target,budget,20261013,identity(source),body['conditions_sha256'],code['code_id'],start_percent=start,stream_offset=offset,tail_arm=arm)
                segment_body={'namespace':NAMESPACE,'target':target,'source':source,'recipe':asdict(recipe),
                    'code_id':code['code_id'],'checkpoint_options':OPTIONS,'branch':branch_options(source,budget),'sequence_id':op['operational_id']}
                segment_op={**segment_body,'operational_id':identity(segment_body)}
                child_folder=owned_folder(service,folder,arm,segment_op['operational_id']);backend=DriveBackend(child_folder,segment_op['operational_id'])
                done=completed_segment(backend,recipe,segment_op)
                if done is not None:
                    if not args.resume:raise ValueError('Completed target exists; explicit RESUME required')
                else:
                    with WriterLease(local/arm,backend,segment_op['operational_id'],resume=args.resume and backend.get('OWNER.json') is not None,prior_release=released.get(str(target))) as lease:
                        put_json(backend,'OPERATIONAL_CONTRACT.json',segment_op);put_json(backend,'RUN_STARTED.json',{'pid':os.getpid(),'runtime_id':runtime_identity(),'source':source,'planned_new_epochs':budget})
                        if args.stop_after_epoch is not None and args.stop_after_epoch>budget:raise ValueError('Planned pause exceeds this segment; use <=20 for50/70')
                        cal=TaylorCalibrator(sets['train'],native_io,102,directory=local/arm)
                        teacher=factory().to('cuda').eval();teacher_digest=native_io.model_state_identity(teacher.state_dict());objective=RecoveryLoss(teacher)
                        store.register(local/arm,backend=backend,operational_contract=segment_op,verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=args.stop_after_epoch)
                        bootstrap=bootstrap_factory(recipe,cfg,native_io,factory,payload,source,cal.prune)
                        try:
                            kernel=load_kernel(bootstrap=bootstrap,metrics=metrics_factory(hard['class_ids'],recipe,objective,hard['legacy_auxiliary_class_ids'],identity(hard)),branch_start=0,pruner=cal.prune,recovery_loss=objective)
                            result=kernel.fit_teacher(factory,sets['train'],sets['val'],local/arm,recipe,cfg,native_io,native_train,lease=lease,device='cuda',stop_after_epoch=args.stop_after_epoch)
                            current=store.get_store(local/arm);last,_=current.load()
                            if result['completed_epochs']!=budget:
                                current.finalize(state='paused');lease.finish('paused',result['completed_epochs']);state='paused';break
                            if native_io.model_state_identity(teacher.state_dict())!=teacher_digest or any(p.grad is not None for p in teacher.parameters()):raise ValueError('Dense Teacher changed')
                            receipt=current.finalize(state='complete')
                            last_model={'schema':'iterative.segment_last.v1','position':'last','contract_id':recipe.contract_id,'recipe':asdict(recipe),
                                'epoch':budget-1,'stage':3,'model_state':last['model_state'],'model_digest':last['model_digest'],'layout':last['layout']}
                            last_ref=backend.put('last_teacher.pt',store.encode_model(last_model));backend.verify_ref(last_ref)
                            rows=result['history'];best=result['best']
                            selected_ref=receipt['selected_teacher'];selected_raw=backend.get('selected_teacher.pt',expected_id=selected_ref['file_id'])
                            selected=strict_verifier(recipe,native_io,factory)(selected_raw)
                            exported=export_checkpoint(selected,b0,rows[best['epoch']],recipe)
                            restored=restore_export(exported,factory,native_io)
                            if native_io.model_state_identity(restored.state_dict())!=selected['model_digest']:raise ValueError('Git export roundtrip differs')
                            del restored
                            export_refs=[backend.put('best.pth',store.encode_model(exported)),
                                put_json(backend,'pruning_spec.json',exported['pruning_spec']),
                                put_json(backend,'config.json',exported['config']),
                                put_json(backend,'github_history.json',export_history(rows,offset))]
                            for ref in export_refs:backend.verify_ref(ref)
                            del selected,selected_raw,exported

                            done={'state':'complete','target_percent':target,'experiment_id':recipe.contract_id,'operational_id':segment_op['operational_id'],
                                'folder_id':child_folder,'source':source,'source_position_for_next_target':'last',
                                'new_Teacher_epochs':budget,'selected_validation':rows[best['epoch']],'last_validation':rows[-1],
                                'checkpoint_receipt':receipt,'last_model':last_ref,'recipe':asdict(recipe),
                                'applied_steps':sum(x['applied_optimizer_steps'] for x in rows),'AMP_skips':sum(x['skipped_optimizer_steps'] for x in rows),
                                'GitHub_export_refs':export_refs,'Teacher_forward_only':True,'Student_epochs':0,'Test_calls':0}
                            put_json(backend,'RUN_RESULT.json',done);lease.finish('complete',budget)
                        except KeyboardInterrupt:
                            current=store.get_store(local/arm)
                            if current.pointer() is not None:current.finalize(state='paused')
                            lease.finish('paused',0);raise
                        finally:
                            store.release(local/arm);objective.teacher=None;teacher=None;torch.cuda.empty_cache()
                if state=='paused':break
                results[str(target)]=done
                # Exact verified model-only LAST50 is the70 source;50 best stays for evaluation.
                raw=backend.get('last_teacher.pt',expected_id=done['last_model']['file_id'])
                if hashlib.sha256(raw).hexdigest()!=done['last_model']['sha256']:raise ValueError('Last-source raw SHA changed')
                payload=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
                source={'position':f'last{target}','reference':done['last_model'],'source_contract_id':recipe.contract_id,
                    'source_operation_id':segment_op['operational_id'],'source_code_id':code['code_id'],'historical_exact_resume':False}
                put_json(sequence,'SEQUENCE_PROGRESS.json',{'completed_targets':list(results),'next_target':{30:50,50:70,70:None}[target]})
                if args.pause_after_target==target:state='paused';break
            same_version(b0['provider_metadata'],metadata(service))
            report={'state':state,'sequence_id':op['operational_id'],'targets':results,'source30':body['source30'],'B0':b0,'hard_set':hard,'hard_set_id':identity(hard),'new_Teacher_epochs':sum(r['new_Teacher_epochs'] for r in results.values()),'Student_epochs':0,'Test_calls':0,'output_folder_id':folder}
            put_json(sequence,'COMPLETE.json' if state=='complete' else 'PAUSED.json',report)
            if state=='complete':put_json(sequence,'COMPARISON.json',report)
            if args.auto_release and (not args.test_after_training or state!='complete'):put_json(sequence,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,'runtime_id':runtime_identity(),'after':state})
            sequence_lease.finish(state,0)
        except KeyboardInterrupt:
            sequence_lease.finish('paused',0);raise
    if args.test_after_training and state=='complete':
        from .official_flowers_test import evaluate
        report['Test_result']=evaluate(report,package,service,inputs=args.inputs,data_root=data['data_root'],resume=args.resume,request_release=args.auto_release,prior_release=released.get('Test'))
    print('EXTENSION_FINAL_STATE',state,'folder',folder,'Test_done',bool(report.get('Test_result')),flush=True)
    if args.auto_release:
        from google.colab import runtime
        runtime.unassign()
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--start-training',action='store_true');p.add_argument('--resume',action='store_true')
    p.add_argument('--run-name',default='GitB0_TaylorCEKL_30_50_70_v1_2');p.add_argument('--inputs',default='/content/drive/MyDrive/온디바이스AI/TeacherSizeKD_NoPruning/inputs')
    p.add_argument('--expected-source-sha');p.add_argument('--baseline-kind',choices=['EXISTING_NATIVE_ALTERNATIVE_NOT_GIT_B0']);p.add_argument('--test-after-training',action='store_true');p.add_argument('--runtime-release-evidence');p.add_argument('--data-root');p.add_argument('--stop-after-epoch',type=int);p.add_argument('--pause-after-target',type=int,choices=(30,50,70));p.add_argument('--auto-release',action='store_true')
    args=p.parse_args()
    if args.stop_after_epoch is not None and not 1<=args.stop_after_epoch<=40:p.error('Segment stop epoch must be1..40 (segment30=40,50/70=20)')
    print(json.dumps(run(args),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
