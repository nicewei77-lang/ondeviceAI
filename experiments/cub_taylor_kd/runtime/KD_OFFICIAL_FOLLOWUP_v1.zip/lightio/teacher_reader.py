"""Read-only access to the completed v1_2 Teacher namespace; no write API."""
import hashlib,io
from .backend import ALLOWED,require_name
OLD_NAMESPACE='cub_git_b0_taylor_v1_2'

class TeacherReader:
    def __init__(self,folder_id,contract_id,*,namespace=OLD_NAMESPACE,service=None):
        if namespace!=OLD_NAMESPACE or not folder_id or not contract_id:raise ValueError('Exact old Teacher namespace required')
        if service is None:
            import google.auth
            from googleapiclient.discovery import build
            credentials,_=google.auth.default();service=build('drive','v3',credentials=credentials,cache_discovery=False)
        self.service,self.folder_id,self.contract_id=service,folder_id,contract_id;self.ids={}
        metadata=service.files().get(fileId=folder_id,fields='id,mimeType').execute()
        if metadata.get('id')!=folder_id or metadata.get('mimeType')!='application/vnd.google-apps.folder':raise ValueError('Teacher source is not exact folder')
        token=None
        while True:
            result=service.files().list(q=f"'{folder_id}' in parents and trashed=false",fields='files(id,name,appProperties),nextPageToken',pageSize=100,pageToken=token).execute()
            for row in result.get('files',[]):
                name=row['name']
                if name not in ALLOWED:continue
                tags=row.get('appProperties',{})
                if name in self.ids or tags.get('lightio_namespace')!=OLD_NAMESPACE or tags.get('lightio_contract')!=contract_id or tags.get('lightio_object')!=name:raise ValueError('Teacher source duplicate/unowned object')
                self.ids[name]=row['id']
            token=result.get('nextPageToken')
            if not token:break
    def _metadata(self,name):
        require_name(name);file_id=self.ids.get(name)
        if file_id is None:return None
        value=self.service.files().get(fileId=file_id,fields='id,name,size,sha256Checksum,version,trashed,appProperties').execute();tags=value.get('appProperties',{})
        if value.get('id')!=file_id or value.get('name')!=name or value.get('trashed') or tags.get('lightio_namespace')!=OLD_NAMESPACE or tags.get('lightio_contract')!=self.contract_id or tags.get('lightio_object')!=name:raise ValueError('Teacher source identity changed')
        return value
    def get(self,name,expected_id=None):
        metadata=self._metadata(name)
        if metadata is None:
            if expected_id is not None:raise ValueError('Teacher bound source absent')
            return None
        if expected_id is not None and expected_id!=metadata['id']:raise ValueError('Teacher bound ID changed')
        size=int(metadata['size']);cap=2*1024**3 if name.endswith(('.pt','.pth')) else 16*1024**2
        if not 0<=size<=cap:raise ValueError('Teacher source size outside bound')
        from googleapiclient.http import MediaIoBaseDownload
        stream=io.BytesIO();download=MediaIoBaseDownload(stream,self.service.files().get_media(fileId=metadata['id']),chunksize=8*1024**2);done=False
        while not done:_,done=download.next_chunk(num_retries=0)
        raw=stream.getvalue()
        if len(raw)!=size or (metadata.get('sha256Checksum') and hashlib.sha256(raw).hexdigest()!=metadata['sha256Checksum']):raise ValueError('Teacher raw source differs')
        return raw
    def verify_ref(self,ref):
        metadata=self._metadata(ref['file'])
        if metadata is None or metadata['id']!=ref['file_id'] or int(metadata['size'])!=ref['bytes']:raise ValueError('Teacher reference ID/size differs')
        checksum=metadata.get('sha256Checksum')
        if checksum is not None:
            if checksum!=ref['sha256']:raise ValueError('Teacher reference SHA differs')
        elif hashlib.sha256(self.get(ref['file'],expected_id=ref['file_id'])).hexdigest()!=ref['sha256']:raise ValueError('Teacher reference raw SHA differs')
        return True
