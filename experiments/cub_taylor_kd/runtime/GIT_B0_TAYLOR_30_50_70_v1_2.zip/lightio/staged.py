"""ASTRA-reviewed Session A: shared first10, local-LR stages2–4 only."""
from dataclasses import asdict, dataclass
import math
import torch
from followup_iterative_v2.policy import Recipe
from followup_iterative_v2.surgery import restore, assert_stage_widths, prune_stage
from .identity import identity, immutable_json

START, END = 10, 40
ANCHOR_ID = '1skKljVMF__Bb9niPh2MS6KKggg4JxsJO'
ANCHOR_SHA = '98a1eb259a96d426b9e10a82b7adea5a5dc73b7a0bfd78c059ef0b277ae98016'
ANCHOR_DIGEST = '538bff66dbab4e338264eb48f1f466abd6982742c91007863467bd35839627ce'
ANCHOR_CONTRACT = 'fac93e0502ba7879af0f10d8881969ab894f852f0e93c681e66fc04687546372'
REQUIRED_ANCHORS = ('anchor_pre_1.pt','anchor_post_1.pt','anchor_pre_2.pt',
                    'anchor_post_2.pt','anchor_pre_3.pt','anchor_post_3.pt')

@dataclass(frozen=True)
class StageRestartRecipe(Recipe):
    tail_arm: str = 'TAYLOR_CE'
    importance_method: str = 'mean_per_example_squared_hidden_gate_gradient'
    calibration_seed: int = 20261027
    calibration_per_class: int = 2
    temperature: float = 4.0
    kd_weight: float = 0.5

    def __post_init__(self):
        super().__post_init__()
        if (self.arm!='IT' or self.target_percent!=30 or self.budget!=40 or self.tail_arm not in ('TAYLOR_CE','TAYLOR_CEKL')
                or self.importance_method!='mean_per_example_squared_hidden_gate_gradient'
                or self.calibration_seed!=20261027 or self.calibration_per_class!=2
                or self.temperature!=4.0 or self.kd_weight!=0.5
                or (not self.fixture and (self.dataset!='cub200' or self.seed!=20261013))):
            raise ValueError('Session A permits CUB IT30 nominal40/shared10/new30 only')

    def learning_factor(self, epoch, warmup=5):
        if not 0 <= epoch < END:
            raise ValueError('Global epoch outside nominal40')
        if epoch < START:
            return super().learning_factor(epoch,warmup)
        u=epoch % 10
        return min(1.,(u+1)/2)*.5*(1+math.cos(math.pi*u/10))

def branch_options(evidence,arm='TAYLOR_CE'):
    return {'mode':'taylor_after_L1_prefix','tail_arm':arm,'start_global_epoch':10,
        'end_global_epoch_exclusive':40,'source_anchor_sha256':ANCHOR_SHA,
        'source_anchor_file_id':ANCHOR_ID,'required_anchor_names':list(REQUIRED_ANCHORS),
        'source_evidence':evidence,'new_teacher_epochs':30,
        'new_fresh_optimizer_boundaries':3,'external_prefix_epochs':10,
        'external_anchor_names':['anchor_post_0.pt'],
        'exact_resume_of_historical_training':False,
        'max_epoch_AMP_skip_fraction':.25,'max_consecutive_AMP_skips':16}

def validate_branch_contract(branch, recipe):
    expected=branch_options(branch.get('source_evidence'),recipe.tail_arm)
    if branch!=expected or not isinstance(recipe,StageRestartRecipe):
        raise ValueError('Session A storage requires the exact reviewed pre1/shared10/new30 contract')

def check_pre_anchor(anchor, original, native_io, factory, *, expected_digest=ANCHOR_DIGEST):
    if (anchor.get('schema')!='iterative.stage_anchor.v2' or
        anchor.get('contract_id')!=original.contract_id or anchor.get('recipe')!=asdict(original) or
        anchor.get('stage')!=0 or anchor.get('code_stage_index')!=1 or anchor.get('anchor_j')!=2 or
        anchor.get('global_epoch')!=10 or anchor.get('position')!='pre' or
        anchor.get('model_digest')!=expected_digest or
        {'optimizer_state','scaler_state','rng_state'} & set(anchor)):
        raise ValueError('Expected original7.5% pre1/global10 model-only anchor')
    model=restore(factory,anchor['model_state'],anchor['layout'],digest=expected_digest,
        state_identity=native_io.model_state_identity)
    assert_stage_widths(model,anchor['layout'],original,0)
    return model

def validate_prefix(history,original,config):
    if len(history)!=40:
        raise ValueError('Expected immutable original full40 history')
    prefix=history[:10]
    for e,row in enumerate(prefix):
        if (row.get('epoch')!=e or row.get('completed_epochs')!=e+1 or row.get('stage')!=0 or
            row.get('epoch_seed')!=original.epoch_seed(e) or row.get('train_samples')!=4794 or
            not math.isclose(row['learning_factor'],original.learning_factor(e,config.get('warmup_epochs',5)),
                             rel_tol=1e-14,abs_tol=1e-16)):
            raise ValueError('Historical shared first10 source/stream/LR differs')
    return prefix

def bootstrap_factory(recipe,config,native_io,factory,anchor,prefix,evidence,*,pruner):
    """Apply15% surgery exactly once, then commit a new stage1 boundary."""
    def bootstrap(store,execution):
        from .kernel import load_kernel
        if len(prefix)!=10:
            raise ValueError('Only shared first10 may be imported')
        model=restore(factory,anchor['model_state'],anchor['layout'],digest=anchor['model_digest'],
            state_identity=native_io.model_state_identity).to(execution['runtime']['device_type'])
        layout=anchor['layout']
        assert_stage_widths(model,layout,recipe,0)
        native_io.seed_everything(recipe.epoch_seed(10))
        before=native_io.model_state_identity(model.state_dict())
        def save_anchor(position,stage):
            return store.anchor(f'anchor_{position}_1.pt',{
                'schema':'iterative.stage_anchor.v2','contract_id':recipe.contract_id,'recipe':asdict(recipe),
                'stage':stage,'anchor_j':2,'code_stage_index':1,'global_epoch':10,'position':position,
                'model_state':model.state_dict(),'model_digest':native_io.model_state_identity(model.state_dict()),
                'layout':layout})
        pre=save_anchor('pre',0)
        audit=[]
        layout=pruner(model,layout,recipe,1,audit=audit)
        assert_stage_widths(model,layout,recipe,1)
        optimizer,scaler,manifest=load_kernel().fresh_optimizer(model,config,execution['runtime']['device_type'])
        if optimizer.state:
            raise ValueError('Stage2 optimizer must be fresh')
        post=save_anchor('post',1)
        audit_payload={'anchor_j':2,'code_stage_index':1,'global_epoch':10,
            'pre_anchor':pre,'post_anchor':post,'Taylor_records':audit,
            'optimizer_reset_is_not_part_of_model_only_digest':True}
        immutable_json(store.directory/'BOUNDARY_01_AUDIT.json',audit_payload)
        initialization={'mode':'L1_prefix_pre1_then_Taylor_15percent_once','tail_arm':recipe.tail_arm,
            'global_next_epoch':10,'branch_completed_epochs':0,'source_evidence':evidence,
            'source_pre_digest':before,'model_digest':post['model_digest'],'layout_id':identity(layout),
            'parameter_manifest':manifest,'optimizer_class':'torch.optim.AdamW',
            'optimizer_groups':[{k:v for k,v in g.items() if k!='params'} for g in optimizer.param_groups],
            'optimizer_state_entries':0,'scaler_initial_state':scaler.state_dict(),
            'prefix_history_id':identity(prefix),'external_prefix_epochs':10,
            'newly_trained_epochs':0,'exact_historical_resume':False,'15percent_surgery_count':1}
        events=[{'boundary_id':0,'global_epoch':0,'source_reference_only':True,
                 'executed_in_this_branch':False,'source_evidence':evidence},
                {'boundary_id':1,'global_epoch':10,'pre_digest':before,'post_digest':post['model_digest'],
                 'layout_id':identity(layout),'reset_optimizer':True,'reset_scaler':True,
                 'parameter_manifest_id':identity(manifest),'optimizer_state_entries_after_reset':0}]
        store.commit({'schema':'iterative.teacher.v1','kind':'boundary','next_epoch':10,'stage':1,
            'contract_id':recipe.contract_id,'execution':execution,'model_state':model.state_dict(),
            'model_digest':post['model_digest'],'layout':layout,'applied_boundaries':[0,1],
            'boundary_events':events,'optimizer_state':optimizer.state_dict(),'scaler_state':scaler.state_dict(),
            'parameter_manifest':manifest,'rng_state':native_io.rng_state(),'best':None,'history':prefix,
            'branch_initialization':initialization})
        return initialization
    return bootstrap

def metrics_factory(hard_ids):
    from .tail import metrics_factory as existing
    measure=existing(hard_ids)
    def metrics(logits,labels,epoch,row):
        result=measure(logits,labels,epoch,row)
        result.update(branch_completed_epochs=epoch-START+1,branch_epoch_index=epoch-START)
        return result
    return metrics
