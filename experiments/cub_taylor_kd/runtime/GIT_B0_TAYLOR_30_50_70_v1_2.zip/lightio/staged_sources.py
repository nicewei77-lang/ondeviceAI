"""Read only the reviewed pre1 target and its small source links in Colab."""
from pathlib import Path
from dataclasses import asdict
import io,json,os,torch
from .identity import identity
from .tail_sources import fetch,FOLDER
from .staged import ANCHOR_ID,ANCHOR_SHA,ANCHOR_DIGEST,ANCHOR_CONTRACT,check_pre_anchor,validate_prefix

REFS={
 'anchor':(ANCHOR_ID,'anchor_pre_1.pt',ANCHOR_SHA,326327887),
 'ledger':('1OP14AoVeoapEhp2KW0ELRHfK5EycFyUP','ANCHORS.json','1ebc7977869cfe8a55722a297a7e62d8ac2f6ba7579f8452cd6e856ddcd9cf8a',4439),
 'history':('1hI1Bao7ia3ohLqI01jgs7MkQxKKdG7wD','history.json','1f11c5c2803f5a17405fd16e7723287d6baa087f66120ccc23e862a82af6ac04',111398),
 'complete':('1VAgGKi4F_hAJIvkjgug-1dQ9zOCDDKep','COMPLETE.json','c5b2b2bc442dc524aab729f6d49347075d4e475942439feff5fde6ce66294099',15096),
 'boundary_audit':('1QKH3oLiDfH7bXBhF1bV5np69ogAKdORu','BOUNDARY_01_AUDIT.json',None,3550050),
 'boundary_transaction':('1I7zOZFCXqRDcO_sQXk9vFgCeBWLEo2c8','TRANSACTION_0011.json',None,1817),
}

def metadata(service,fid):
    return service.files().get(fileId=fid,fields='id,name,size,sha256Checksum,parents,version').execute()

def verify_external_anchor(service,ref):
    m=metadata(service,ref['file_id'])
    if (m.get('id')!=ref['file_id'] or m.get('name')!=ref['file'] or m.get('parents')!=[FOLDER]
        or int(m.get('size',-1))!=ref['bytes'] or m.get('sha256Checksum')!=ref['sha256']
        or str(m.get('version'))!=str(ref['provider_version'])):
        raise ValueError('Read-only historical post0 anchor metadata changed')
    return m

def load_sources(service,science,config,native_io):
    if os.name!='posix' or not Path('/content/drive').is_dir():
        raise ValueError('Model payload reads are Colab-only')
    from followup_iterative_v2.policy import Recipe
    from followup_iterative_v2.pipeline import dense_source
    original=Recipe('cub200','IT',30,40,20261013,
        identity(science['source_pins']['datasets']['cub200']['source_reference']),
        science['protocol_id'],science['code_id'])
    if original.contract_id!=ANCHOR_CONTRACT:
        raise ValueError('Original source recipe identity differs')
    raws,refs={},{}
    before={k:metadata(service,v[0]) for k,v in REFS.items()}
    if str(before['anchor'].get('version'))!='1':
        raise ValueError('Reviewed immutable pre1 provider version differs')
    for key,(fid,name,wanted,size) in REFS.items():
        raw,ref=fetch(service,fid,name=name,size=size,sha256=wanted,parent=FOLDER,
            cap=400*1024**2 if key=='anchor' else 4*1024**2)
        if metadata(service,fid)!=before[key]:
            raise ValueError('Source changed while reading '+name)
        refs[key]={**ref,'provider_version':before[key].get('version')}
        raws[key]=raw
    ledger,history,complete,audit,transaction=(json.loads(raws[k]) for k in
        ('ledger','history','complete','boundary_audit','boundary_transaction'))
    anchor=torch.load(io.BytesIO(raws['anchor']),map_location='cpu',weights_only=True)
    pre,post=ledger['anchor_pre_1.pt'],ledger['anchor_post_1.pt']
    if (pre.get('file_id')!=ANCHOR_ID or pre.get('sha256')!=ANCHOR_SHA or
        pre.get('model_digest')!=ANCHOR_DIGEST or pre.get('contract_id')!=ANCHOR_CONTRACT or
        complete.get('completed_epochs')!=40 or complete.get('state')!='complete' or
        audit.get('global_epoch')!=10 or audit.get('code_stage_index')!=1 or
        audit.get('pre_anchor',{}).get('sha256')!=ANCHOR_SHA or
        audit.get('pre_anchor',{}).get('model_digest')!=ANCHOR_DIGEST or
        audit.get('post_anchor',{}).get('sha256')!=post.get('sha256') or
        audit.get('post_anchor',{}).get('model_digest')!=post.get('model_digest') or
        transaction.get('next_epoch')!=10 or transaction.get('kind')!='boundary'):
        raise ValueError('Pre1/first10/BOUNDARY01/source transaction linkage differs')
    prefix=validate_prefix(history,original,config)
    source,factory=dense_source('cub200',science)
    rebuilt=check_pre_anchor(anchor,original,native_io,factory)
    del rebuilt,raws
    external=ledger['anchor_post_0.pt']
    external_metadata=verify_external_anchor(service,external)
    evidence={'schema':'cub.stage_restart_A.sources.v1','refs':refs,
        'source_original_recipe':asdict(original),'source_original_contract_id':ANCHOR_CONTRACT,
        'source_anchor_model_digest':ANCHOR_DIGEST,'source_anchor_layout_id':identity(anchor['layout']),
        'source_prefix_history_id':identity(prefix),'source_prefix_epochs':10,
        'source_boundary_transaction_identity':identity(transaction),
        'dense_source_reference':source.reference,
        'historical_anchor_post_0':external,'historical_anchor_post_0_metadata':external_metadata,
        'historical_control_OA_pct':72.33333333333333,'dense_source_OA_pct':83.66666666666667,
        'historical_exact_resume_claim':False,'PC_model_downloads':0}
    return anchor,prefix,evidence,source,factory
