"""One explicitly started CUB IT30 Teacher session. No automatic GPU allocation."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import shutil
import sys
from .identity import identity, read, atomic_json, immutable_json, NAMESPACE
from .contracts import OPTIONS, source_contract, operation, verify_delivery
from .kernel import load_kernel, strict_verifier
from .lease import WriterLease, runtime_identity

def plan(budget=40):
    if budget not in (20, 40):
        raise ValueError('Only the original independent B20/B40 budgets are implemented')
    return {'state': 'PREPARATION_ONLY', 'dataset': 'cub200', 'arm': 'IT',
        'final_MLP_hidden_removal_percent': 30, 'cumulative_stage_percent': [7.5,15,22.5,30],
        'global_epochs': budget, 'stage_epochs': budget//4,
        'eligible_global_epochs_one_based': [3*budget//4+1, budget],
        'options': OPTIONS, 'training_calls': 0, 'GPU_allocations': 0,
        'anchor_tail_or_LR_restart_diagnostic_implemented': False}

def quota_gate(backend, minimum_free=12*1024**3):
    service = getattr(backend, 'service', None)
    if service is None:
        return {'scope': 'CPU_fixture_only'}
    quota = service.about().get(fields='storageQuota').execute()['storageQuota']
    limit, used = quota.get('limit'), quota.get('usage')
    if used is None:
        raise ValueError('Drive quota usage is unavailable; HOLD')
    free = int(limit)-int(used) if limit is not None else None
    if free is not None and free < minimum_free:
        raise ValueError('Insufficient Drive free-space reserve; HOLD')
    return {'quota': quota, 'free_bytes': free, 'minimum_free_bytes': minimum_free,
        'scope': 'Provider quota now; future revision/writeback usage is not bounded'}

def run(args):
    raise RuntimeError('Full-budget execution is disabled in this delivery; use lightio.tail_runner for G10 then R10 only')
    if not args.start_training:
        raise ValueError('START_TRAINING=False; no actual work started')
    import torch
    from phaseb.native import config, module
    from followup_iterative_v2.pipeline import dense_source
    from followup_iterative_v2.policy import Recipe
    from .backend import DriveBackend
    from . import store as storage
    from .readiness import validate_existing_gate, ensure_data

    package = Path(__file__).resolve().parents[1]
    code = verify_delivery(package)
    science = source_contract()
    cfg = config('cub200')
    recipe = Recipe('cub200','IT',30,args.budget,cfg['teacher_seed'],
        identity(science['source_pins']['datasets']['cub200']['source_reference']),
        science['protocol_id'], science['code_id'])
    op = operation(recipe,cfg,run_name=args.run_name,code_id=code['code_id'])
    # Strong separation from old results: only a fresh local Colab directory is
    # a kernel output. The backend accepts one explicitly created Drive run ID.
    local = Path(args.local_root).resolve()/args.run_name
    if (not local.is_relative_to(Path('/content/cub_focus_light_io_v1'))
            or local.is_relative_to(Path('/content/drive'))):
        raise ValueError('Local outputs must be under /content/cub_focus_light_io_v1')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0) != 'NVIDIA L4':
        raise ValueError('The frozen runtime requires an already assigned NVIDIA L4')
    if shutil.disk_usage('/content').free < 8*1024**3:
        raise ValueError('Colab local free space below 8 GiB reserve; HOLD')
    if args.stop_after_epoch is not None and not 1 <= args.stop_after_epoch <= args.budget:
        raise ValueError('Planned stop must be a completed global epoch in the budget')
    historical = validate_existing_gate(args.source_gate, args.source_review, recipe,
        science['source_pins']['datasets']['cub200']['source_reference'])
    backend = DriveBackend(args.run_folder_id, op['operational_id'])
    destination = read(package/'assets/DRIVE_DESTINATION.json')
    folder = backend.service.files().get(fileId=args.run_folder_id,fields='id,name,parents').execute()
    if folder.get('name') != args.run_name or folder.get('parents') != [destination['runs_folder_id']]:
        raise ValueError('Run folder must be a direct child of the separate light-I/O runs root')
    quota = quota_gate(backend)
    remote_op = backend.get('OPERATIONAL_CONTRACT.json')
    if remote_op and json.loads(remote_op) != op:
        raise ValueError('Remote operational contract differs')
    if not remote_op and args.resume:
        raise ValueError('RESUME requested without a remote operational contract')
    prior_release = read(args.runtime_release_evidence) if args.runtime_release_evidence else None
    local.mkdir(parents=True, exist_ok=True)
    with WriterLease(local,backend,op['operational_id'],resume=args.resume,
                     prior_release=prior_release) as lease:
        backend.lease = lease
        immutable_json(local/'OPERATIONAL_CONTRACT.json',op)
        backend.put('OPERATIONAL_CONTRACT.json',json.dumps(op,ensure_ascii=False,sort_keys=True).encode())
        atomic_json(local/'READINESS.json',{'historical':historical,'quota':quota,
            'runtime_id':runtime_identity(),'actual_training_started':False})
        sets, data = ensure_data(args.inputs, Path('/content/cub_focus_light_io_v1/data'),args.data_root)
        # Actual source SHA/tensors/spec and compact reconstruction are checked
        # by the unchanged pinned Native source loader before any training.
        source, factory = dense_source('cub200',science)
        native_io, native_train = module('cub200','io'), module('cub200','train')
        from b1kd.runtime import current_training_runtime, validate_runtime_match
        from phaseb.native import ROOT as old_root
        baseline = read(old_root/'configs/readonly_inputs.json')['datasets']['cub200']['baseline_execution_runtime']
        validate_runtime_match(baseline,current_training_runtime())
        storage.register(local,backend=backend,operational_contract=op,
            verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=args.stop_after_epoch)
        kernel = load_kernel()
        try:
            result = kernel.fit_teacher(factory,sets['train'],sets['val'],local,recipe,cfg,
                native_io,native_train,lease=lease,device='cuda',stop_after_epoch=args.stop_after_epoch)
            checkpoint = storage.get_store(local)
            final_state = 'complete' if result['completed_epochs'] == recipe.budget else 'paused'
            verified = checkpoint.finalize(state=final_state)
            record = {'state':final_state,'namespace':NAMESPACE,'operational_id':op['operational_id'],
                'completed_epochs':result['completed_epochs'],'remote_durable_epoch':result['completed_epochs'],
                'checkpoint_evidence':verified,'research_result_evaluation_complete':False,
                'actual_training':True,'PC_model_downloads':0,'data_receipt':data}
            # Store owns the single durable COMPLETE/PAUSED marker. Extra
            # descriptive details remain local and never precede that marker.
            atomic_json(local/'RUN_RESULT.json',record)
            lease.finish(final_state,result['completed_epochs'])
            return record
        except KeyboardInterrupt:
            # Never serialize partial in-memory training. Flush the store's
            # most recent atomic completed epoch/boundary, then release cleanly.
            checkpoint = storage.get_store(local)
            if checkpoint.pointer() is not None:
                verified = checkpoint.finalize(state='paused')
                pointer = checkpoint.pointer()['active']
                epoch = pointer['next_epoch']
                record = {'state':'paused','operational_id':op['operational_id'],
                    'completed_epochs':epoch,'remote_durable_epoch':epoch,
                    'checkpoint_evidence':verified,'partial_epoch_discarded':True}
                atomic_json(local/'RUN_RESULT.json',record)
                lease.finish('paused',epoch)
            raise
        finally:
            storage.release(local)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['plan','run'])
    parser.add_argument('--budget',type=int,choices=[20,40],default=40)
    parser.add_argument('--start-training',action='store_true')
    parser.add_argument('--run-name',default='cub_it30_b40_sessionA')
    parser.add_argument('--run-folder-id')
    parser.add_argument('--local-root',default='/content/cub_focus_light_io_v1/runs')
    parser.add_argument('--inputs',default='/content/drive/MyDrive/온디바이스AI/TeacherSizeKD_NoPruning/inputs')
    parser.add_argument('--data-root')
    parser.add_argument('--source-gate')
    parser.add_argument('--source-review')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--runtime-release-evidence')
    parser.add_argument('--stop-after-epoch',type=int)
    args=parser.parse_args()
    if args.command=='run' and any(not getattr(args,name) for name in ('run_folder_id','source_gate','source_review')):
        parser.error('run needs exact --run-folder-id, --source-gate and --source-review')
    value = plan(args.budget) if args.command=='plan' else run(args)
    print(json.dumps(value,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
