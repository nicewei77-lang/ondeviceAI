"""One-session independent Taylor CE/CE+KL arms; prepare by default."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,time
from .identity import read,identity,sha,atomic_json,NAMESPACE
from .contracts import source_contract,verify_delivery,operation
from .staged import StageRestartRecipe,branch_options,bootstrap_factory,metrics_factory,ANCHOR_SHA
from .staged_runner import owned_folder,put_json,verify_source_end
from .lease import WriterLease,runtime_identity
from .backend import DriveBackend
from .kernel import load_kernel,strict_verifier
from .taylor import TaylorCalibrator
from .recovery_loss import RecoveryLoss
from . import store as storage

ARMS=('TAYLOR_CE','TAYLOR_CEKL')

def plan():
    return {'state':'PREPARED_NOT_STARTED','order':list(ARMS),
        'shared_L1_prefix_epochs':10,'new_epochs_per_arm':30,'total_new_Teacher_epochs':60,
        'independent_start':'same original L1 anchor_pre_1 at7.5%,global10; no CE-final to KD continuation',
        'targets_percent':[7.5,15,22.5,30],'stage_epochs':10,
        'calibration':'train-only400 images,2/class,seed20261027,fixed train augmentation epoch0,batch1',
        'importance':'mean per-example squared post-GELU hidden-gate CE gradient; FP32→FP64 accumulation',
        'losses':{'TAYLOR_CE':'CE','TAYLOR_CEKL':'CE+0.5*4²*KL(dense||pruned)'},
        'calibration_objective':'CE in both arms','recovery_LR':'same A stage2–4 restart',
        'Student_epochs':0,'Test_calls':0,'GPU_allocations':0,'START_TRAINING':False,
        'automatic_accuracy_gate':False,'automatic_wall_stop':False,
        'calibration_forward_backward_evaluations_total_each':2400,
        'ETA':'unmeasured Taylor/KD overhead; update from first calibration and recovery epochs'}

def release_evidence(value,key):
    if value is None:return None
    return value.get(key) if 'sequence' in value else value

def completed_arm(backend,recipe,op):
    raw=backend.get('COMPLETE.json')
    if raw is None:return None
    complete=json.loads(raw);pointer=json.loads(backend.get('REMOTE_COMMITTED.json'))
    result=json.loads(backend.get('RUN_RESULT.json'))
    if (complete.get('contract_id')!=recipe.contract_id or complete.get('operational_contract_id')!=op['operational_id']
        or complete.get('branch_completed_epochs')!=30 or complete.get('remote_commit')!=pointer
        or pointer['active']['kind']!='epoch' or pointer['active']['next_epoch']!=40
        or result.get('experiment_id')!=recipe.contract_id or result.get('state')!='complete'):
        raise ValueError('Completed arm contract/checkpoint/result differs')
    if (set(pointer['anchors'])!=set(branch_options({},recipe.tail_arm)['required_anchor_names'])
        or set(pointer['boundary_audits'])!={f'BOUNDARY_{s:02d}_AUDIT.json' for s in (1,2,3)}
        or set(pointer['calibrations'])!={f'CALIBRATION_{s:02d}.json' for s in (1,2,3)}):
        raise ValueError('Completed arm lacks its exact anchor/audit/calibration set')
    refs=[pointer['active'],pointer['active']['best'],pointer['selected_teacher'],
          *pointer['anchors'].values(),*pointer['boundary_audits'].values(),*pointer['calibrations'].values()]
    for ref in refs:backend.verify_ref(ref)
    return result

def run(args):
    raise RuntimeError("Use lightio.extend_runner in this separate50/70 delivery")
    if not args.start_training:return plan()
    import torch,shutil,google.auth
    from googleapiclient.discovery import build
    from .runtime_bootstrap import cub_runtime_bindings
    cfg,current_runtime,validate_runtime=cub_runtime_bindings()
    from phaseb.native import ROOT as frozen_root,module
    from .readiness import ensure_data
    from .staged_sources import load_sources
    from .runner import quota_gate
    if os.name!='posix' or not Path('/content/drive').is_dir() or not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':
        raise ValueError('Use the explicitly assigned mounted Colab L4; no allocation is performed here')
    validate_runtime(read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['baseline_execution_runtime'],current_runtime())
    if (cfg['batch_size']!=16 or cfg['effective_batch_size']!=64 or cfg['teacher_weight_decay']!=.05 or cfg['teacher_seed']!=20261013):
        raise ValueError('Frozen A recovery configuration differs')
    if shutil.disk_usage('/content').free<8*1024**3:raise ValueError('Local disk reserve below8GiB')
    package=Path(__file__).resolve().parents[1];code=verify_delivery(package);science=source_contract()
    credentials,_=google.auth.default();service=build('drive','v3',credentials=credentials,cache_discovery=False)
    sets,data=ensure_data(args.inputs,Path('/content/cub_taylor_distill_v1/data'),args.data_root)
    started=datetime.now(timezone.utc).isoformat()
    native_io,native_train=module('cub200','io'),module('cub200','train')
    anchor,prefix,evidence,source,factory=load_sources(service,science,cfg,native_io)
    condition_sha=sha(package/'assets/SEQUENCE_CONDITIONS.json')
    body={'namespace':NAMESPACE,'code_id':code['code_id'],'condition_sha256':condition_sha,
        'source_evidence':evidence,'config':cfg,'order':list(ARMS),'new_Teacher_epochs_total':60,
        'Student_epochs':0,'Test_calls':0,'sessions':1,'automatic_accuracy_gate':False,'automatic_wall_stop':False}
    seq={**body,'operational_id':identity(body)}
    dest=read(package/'assets/DRIVE_DESTINATION.json')
    folder=owned_folder(service,dest['runs_folder_id'],args.sequence_name,seq['operational_id'])
    seq_backend=DriveBackend(folder,seq['operational_id'])
    local=Path('/content/cub_taylor_distill_v1/runs')/seq['operational_id']
    released=read(args.runtime_release_evidence) if args.runtime_release_evidence else None
    outputs={};last_global=10;clean_state=None
    with WriterLease(local,seq_backend,seq['operational_id'],resume=args.resume,
                     prior_release=release_evidence(released,'sequence')) as seq_lease:
        quota_gate(seq_backend,minimum_free=20*1024**3)
        put_json(seq_backend,'OPERATIONAL_CONTRACT.json',seq)
        old_start=seq_backend.get('RUN_STARTED.json')
        if old_start is None:put_json(seq_backend,'RUN_STARTED.json',{'state':'prepared_not_yet_training',
            'sequence_id':seq['operational_id'],'run_folder_id':folder,'pid':os.getpid(),
            'runtime_id':runtime_identity(),'started_at_utc':started,'order':list(ARMS),
            'new_Teacher_epochs_total':60,'shared_L1_prefix_epochs':10})
        print('TAYLOR_SEQUENCE_PREPARED',seq['operational_id'],folder,flush=True)
        pin=read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['hard_set']
        hard=read(pin['path'])
        if identity(hard)!=pin['identity']:raise ValueError('Frozen Hard40 differs')
        try:
            for arm in ARMS:
                recipe=StageRestartRecipe('cub200','IT',30,40,20261013,ANCHOR_SHA,
                    condition_sha,code['code_id'],tail_arm=arm)
                base=operation(recipe,cfg,run_name=arm,code_id=code['code_id'])
                b={k:v for k,v in base.items() if k!='operational_id'}
                b.update(branch=branch_options(evidence,arm),sequence_id=seq['operational_id'],
                    recovery_objective=arm,scientific_changes=['L1→per-example squared gate Taylor after common first10',
                        'CEKL arm adds CE+0.5*T²KL atT4; calibration remains CE'],max_sessions=1)
                op={**b,'operational_id':identity(b)}
                arm_folder=owned_folder(service,folder,arm,op['operational_id'])
                backend=DriveBackend(arm_folder,op['operational_id'])
                existing=completed_arm(backend,recipe,op)
                if existing is not None:
                    if not args.resume:raise ValueError('Completed arm exists; explicit RESUME required')
                    outputs[arm]=existing;backend.close();last_global=40
                    print('SKIP_VERIFIED_COMPLETE_ARM',arm,flush=True)
                    if args.pause_after_arm==arm:clean_state='paused';break
                    continue
                directory=local/arm
                prior_owner=backend.get('OWNER.json')
                teacher=None
                with WriterLease(directory,backend,op['operational_id'],resume=args.resume and prior_owner is not None,
                                 prior_release=release_evidence(released,arm)) as lease:
                    put_json(backend,'OPERATIONAL_CONTRACT.json',op)
                    put_json(backend,'RUN_STARTED.json',{'role':arm,'experiment_id':recipe.contract_id,
                        'operational_id':op['operational_id'],'pid':os.getpid(),'runtime_id':runtime_identity(),
                        'global_next_epoch':10,'newly_planned_epochs':30,'independent_source_anchor_sha256':ANCHOR_SHA})
                    arm_started=time.monotonic()
                    calibrator=TaylorCalibrator(sets['train'],native_io,cfg['num_classes'],directory=directory)
                    if arm=='TAYLOR_CEKL':
                        teacher=factory().to('cuda').eval()
                        if native_io.model_state_identity(teacher.state_dict())!=evidence['dense_source_reference']['model_digest']:
                            raise ValueError('Original dense Teacher weights differ')
                    objective=RecoveryLoss(teacher)
                    storage.register(directory,backend=backend,operational_contract=op,
                        verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=args.stop_after_epoch)
                    def bootstrap(current,execution):
                        init=bootstrap_factory(recipe,cfg,native_io,factory,anchor,prefix,evidence,
                            pruner=calibrator.prune)(current,execution)
                        put_json(backend,'BRANCH_START.json',init)
                    measure=metrics_factory(hard['class_ids'])
                    def metrics(logits,labels,epoch,row):
                        return {**measure(logits,labels,epoch,row),**objective.enrich(row,epoch)}
                    try:
                        kernel=load_kernel(bootstrap=bootstrap,metrics=metrics,branch_start=10,
                            pruner=calibrator.prune,recovery_loss=objective)
                        result=kernel.fit_teacher(factory,sets['train'],sets['val'],directory,recipe,cfg,
                            native_io,native_train,lease=lease,device='cuda',stop_after_epoch=args.stop_after_epoch)
                        current=storage.get_store(directory);last_global=result['completed_epochs']
                        state='complete' if last_global==40 else 'paused'
                        verify_source_end(service,evidence)
                        if teacher is not None:
                            if (native_io.model_state_identity(teacher.state_dict())!=evidence['dense_source_reference']['model_digest']
                                or any(p.grad is not None or p.requires_grad for p in teacher.parameters())):
                                raise ValueError('Dense Teacher changed or received gradients')
                        receipt=current.finalize(state=state)
                        new=result['history'][10:];best=result['best']
                        record={'state':state,'arm':arm,'experiment_id':recipe.contract_id,
                            'operational_id':op['operational_id'],'folder_id':arm_folder,'global_next_epoch':last_global,
                            'new_Teacher_epochs':len(new),'selected_validation':None if best is None else result['history'][best['epoch']],
                            'last_validation':None if not new else new[-1],
                            'this_attempt_wall_seconds':time.monotonic()-arm_started,
                            'training_and_validation_compute_seconds':sum(x['train_seconds']+x['validation_seconds'] for x in new),
                            'checkpoint_receipt':receipt,'teacher_optimizer_steps':0,'dense_teacher_unchanged':True,
                            'teacher_forward_training_samples':sum(x['train_samples'] for x in new) if arm=='TAYLOR_CEKL' else 0,
                            'this_attempt_teacher_forward_samples':objective.teacher_forward_samples,
                            'applied_steps':sum(x['applied_optimizer_steps'] for x in new),
                            'AMP_skipped_steps':sum(x['skipped_optimizer_steps'] for x in new),
                            'Student_epochs':0,'Test_calls':0,'source_unchanged':True}
                        put_json(backend,'RUN_RESULT.json',record);lease.finish(state,last_global)
                        if state=='complete':outputs[arm]=record
                        else:
                            clean_state='paused';break
                    except KeyboardInterrupt:
                        current=storage.get_store(directory)
                        if current.pointer() is not None:
                            receipt=current.finalize(state='paused');last_global=receipt['remote_durable_epoch']
                        else:
                            put_json(backend,'PAUSED.json',{'state':'paused','new_Teacher_epochs':0,
                                'reconstruct_from_source_pre1':True,'operational_id':op['operational_id']})
                            last_global=10
                        lease.finish('paused',last_global)
                        raise
                    finally:
                        storage.release(directory);objective.teacher=None;teacher=None
                        torch.cuda.empty_cache()
                put_json(seq_backend,'SEQUENCE_PROGRESS.json',{'completed_arms':list(outputs),
                    'next_arm':None if len(outputs)==2 else ARMS[len(outputs)],'last_global_epoch':last_global})
                if args.pause_after_arm==arm:
                    clean_state='paused';break
            clean_state=clean_state or 'complete'
            summary={'state':clean_state,'sequence_id':seq['operational_id'],'completed_arms':outputs,
                'total_new_Teacher_epochs':sum(x['new_Teacher_epochs'] for x in outputs.values()),
                'Student_epochs':0,'Test_calls':0,'independent_same_budget_starts':True,
                'scope':'common L1 first10 then Taylor; single-seed validation only'}
            put_json(seq_backend,'COMPLETE.json' if clean_state=='complete' else 'PAUSED.json',summary)
            if clean_state=='complete':put_json(seq_backend,'COMPARISON.json',summary)
            if args.auto_release:put_json(seq_backend,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,
                'after_durable_state':clean_state,'runtime_id':runtime_identity()})
            seq_lease.finish(clean_state,last_global)
        except KeyboardInterrupt:
            put_json(seq_backend,'SEQUENCE_PROGRESS.json',{'state':'paused','completed_arms':list(outputs),
                'last_global_epoch':last_global,'partial_epoch_discarded':True})
            seq_lease.finish('paused',last_global)
            raise
    seq_backend.close()
    if args.auto_release:
        from google.colab import runtime
        print('SELF_RUNTIME_RELEASE_REQUEST',clean_state,flush=True)
        runtime.unassign()
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--start-training',action='store_true');p.add_argument('--resume',action='store_true')
    p.add_argument('--sequence-name',default='Taylor_CE_then_independent_CEKL_v1')
    p.add_argument('--inputs',default='/content/drive/MyDrive/온디바이스AI/TeacherSizeKD_NoPruning/inputs')
    p.add_argument('--data-root');p.add_argument('--runtime-release-evidence')
    p.add_argument('--stop-after-epoch',type=int);p.add_argument('--pause-after-arm',choices=ARMS)
    p.add_argument('--auto-release',action='store_true')
    args=p.parse_args()
    if args.stop_after_epoch is not None and not 11<=args.stop_after_epoch<=40:p.error('stop epoch must be11..40')
    print(json.dumps(run(args),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
