"""Independent version: 30-best ->35/40/45/50, then50-last ->55/60/65/70."""
from dataclasses import dataclass,asdict
from fractions import Fraction
import math
from followup_iterative_v2.policy import Recipe
from followup_iterative_v2.surgery import restore,assert_stage_widths
from .identity import identity,immutable_json

@dataclass(frozen=True)
class ExtensionRecipe(Recipe):
    start_percent:int=30
    stream_offset:int=40
    tail_arm:str='TAYLOR_CEKL_TO50'
    importance_method:str='mean_per_example_squared_hidden_gate_gradient'
    calibration_seed:int=20261027
    calibration_per_class:int=2
    temperature:float=4.
    kd_weight:float=.5
    def __post_init__(self):
        super().__post_init__()
        if (self.arm!='IT' or
            (self.start_percent,self.target_percent,self.stream_offset,self.tail_arm,self.budget) not in
            ((0,30,0,'TAYLOR_CEKL_TO30',40),(30,50,40,'TAYLOR_CEKL_TO50',20),(50,70,60,'TAYLOR_CEKL_TO70',20)) or
            self.temperature!=4 or self.kd_weight!=.5 or self.calibration_seed!=20261027 or self.calibration_per_class!=2 or
            (not self.fixture and (self.dataset!='cub200' or self.seed!=20261013))):raise ValueError('Exact reviewed extension segments only')
    def width(self,original_hidden,stage):
        if type(stage) is not int or not 0<=stage<4 or type(original_hidden) is not int or original_hidden<1:raise ValueError('Width/stage invalid')
        percent=Fraction(self.start_percent)+(Fraction(self.target_percent-self.start_percent,4)*(stage+1))
        value=Fraction(original_hidden)*(100-percent)/100
        return -(-value.numerator//value.denominator)
    def learning_factor(self,epoch,warmup=5):
        self.stage(epoch);length=self.budget//4;u=epoch%length
        return min(1.,(u+1)/2)*.5*(1+math.cos(math.pi*u/length))
    def stream_epoch(self,epoch):self.stage(epoch);return self.stream_offset+epoch
    def epoch_seed(self,epoch):return self.seed+self.stream_epoch(epoch)*100003

def branch_options(source,budget=20):
    return {'mode':'taylor_extension','source':source,'start_epoch':0,'new_epochs':budget,'historical_exact_resume':False}

def bootstrap_factory(recipe,cfg,native_io,factory,payload,source,pruner):
    def bootstrap(store,execution):
        model=restore(factory,payload['model_state'],payload['layout'],digest=payload['model_digest'],state_identity=native_io.model_state_identity).to(execution['runtime']['device_type'])
        layout=payload['layout']
        if any(r['hidden']!=-(-(r['original_hidden']*(100-recipe.start_percent))//100) for r in layout):raise ValueError('Source cumulative widths differ')
        native_io.seed_everything(recipe.epoch_seed(0));before=native_io.model_state_identity(model.state_dict());audit=[]
        layout=pruner(model,layout,recipe,0,audit=audit);assert_stage_widths(model,layout,recipe,0)
        from .kernel import load_kernel
        optimizer,scaler,manifest=load_kernel().fresh_optimizer(model,cfg,execution['runtime']['device_type'])
        post=store.anchor('anchor_post_0.pt',{'schema':'iterative.stage_anchor.v2','recipe':asdict(recipe),'contract_id':recipe.contract_id,
            'stage':0,'anchor_j':1,'code_stage_index':0,'global_epoch':0,'position':'post','model_state':model.state_dict(),
            'model_digest':native_io.model_state_identity(model.state_dict()),'layout':layout})
        immutable_json(store.directory/'BOUNDARY_00_AUDIT.json',{'anchor_j':1,'code_stage_index':0,'global_epoch':0,
            'pre_anchor':{'source_id':recipe.source_id,'model_digest':before,'reference':source},'post_anchor':post,'Taylor_records':audit})
        store.commit({'schema':'iterative.teacher.v1','kind':'boundary','next_epoch':0,'stage':0,'recipe':asdict(recipe),
            'contract_id':recipe.contract_id,'execution':execution,'model_state':model.state_dict(),'model_digest':post['model_digest'],
            'layout':layout,'applied_boundaries':[0],'boundary_events':[{'boundary_id':0,'global_epoch':0,'pre_digest':before,
                'post_digest':post['model_digest'],'layout_id':identity(layout),'reset_optimizer':True,'reset_scaler':True,
                'parameter_manifest_id':identity(manifest),'optimizer_state_entries_after_reset':0}],
            'optimizer_state':optimizer.state_dict(),'scaler_state':scaler.state_dict(),'parameter_manifest':manifest,
            'rng_state':native_io.rng_state(),'best':None,'history':[]})
    return bootstrap

def metrics_factory(hard_ids,recipe,objective,legacy_ids=None,hard_identity=None):
    from .tail import metrics_factory as base
    measure=base(hard_ids)
    def metrics(logits,labels,epoch,row):
        result=measure(logits,labels,epoch,row)
        result.pop('global_epoch_index',None);result.pop('global_epoch_one_based',None)
        result.update(segment_completed_epochs=epoch+1,branch_completed_epochs=epoch+1,branch_epoch_index=epoch,
            input_stream_epoch=recipe.stream_epoch(epoch),cumulative_hidden_removal_percent=recipe.start_percent+(recipe.target_percent-recipe.start_percent)*(recipe.stage(epoch)+1)/4)
        if legacy_ids is not None:
            import torch
            mask=torch.tensor([int(y) in legacy_ids for y in labels],device=labels.device)
            result.update(legacy_hard_accuracy_pct=100*int((logits.argmax(1)[mask]==labels[mask]).sum())/int(mask.sum()),
                primary_Hard_identity=hard_identity,legacy_Hard_auxiliary_only=True)
        return {**result,**objective.enrich(row,epoch)}
    return metrics
