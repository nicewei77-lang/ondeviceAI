"""Session A preparation/explicit one-session run; no GPU allocation or Test."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,time
from .identity import read,identity,sha,atomic_json,NAMESPACE
from .contracts import verify_delivery,source_contract,operation
from .staged import StageRestartRecipe,branch_options,bootstrap_factory,metrics_factory,ANCHOR_SHA
from .lease import WriterLease,runtime_identity
from .backend import DriveBackend
from .kernel import load_kernel,strict_verifier
from . import store as storage

def plan():
    return {'state':'PREPARED_NOT_STARTED','role':'Session A; Session B is already complete',
        'shared_prefix_epochs':10,'new_Teacher_epochs':30,'nominal_epochs':40,
        'targets_percent':[7.5,15,22.5,30],'stage_epochs':10,
        'start':'original anchor_pre_1,7.5%,global10;15% surgery exactly once',
        'changed_variable':'stage2–4 local LR restart only; later masks adapt to current weights',
        'selection_global_epochs_one_based':[31,40],'Student_epochs':0,'Test_calls':0,
        'remote_interval_seconds':900,'review_cap_seconds':7200,
        'GPU_allocations':0,'START_TRAINING':False}

def put_json(backend,name,value):
    return backend.put(name,json.dumps(value,ensure_ascii=False,sort_keys=True,allow_nan=False).encode())

def owned_folder(service,parent,name,op_id):
    if not name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in name):
        raise ValueError('Use a simple explicit run name')
    result=service.files().list(q=f"'{parent}' in parents and name = '{name}' and trashed = false",
        fields='files(id,name,mimeType,appProperties),nextPageToken',pageSize=100).execute()
    rows=result.get('files',[])
    tags={'lightio_namespace':NAMESPACE,'session_A_contract':op_id}
    if len(rows)>1 or result.get('nextPageToken'):
        raise ValueError('Ambiguous Session A run folder')
    if rows:
        row=rows[0]
        if row.get('mimeType')!='application/vnd.google-apps.folder' or row.get('appProperties')!=tags:
            raise ValueError('Existing output folder is not this owned Session A run')
        return row['id']
    return service.files().create(body={'name':name,'mimeType':'application/vnd.google-apps.folder',
        'parents':[parent],'appProperties':tags},fields='id').execute()['id']

def verify_source_end(service,evidence):
    from .staged_sources import metadata,FOLDER,verify_external_anchor
    for ref in evidence['refs'].values():
        m=metadata(service,ref['file_id'])
        if (m.get('name')!=ref['name'] or m.get('parents')!=[FOLDER] or int(m.get('size',-1))!=ref['bytes']
            or str(m.get('version'))!=str(ref['provider_version'])
            or (m.get('sha256Checksum') and m['sha256Checksum']!=ref['sha256'])):
            raise ValueError('Immutable original source metadata changed')
    verify_external_anchor(service,evidence['historical_anchor_post_0'])

def run(args):
    raise RuntimeError("Use lightio.sequence_runner for this two-arm delivery")
    if not args.start_training:
        return plan()
    import torch,shutil
    if os.name!='posix' or not Path('/content/drive').is_dir():
        raise ValueError('Training requires the mounted, explicitly assigned Colab runtime')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':
        raise ValueError('An already assigned L4 is required; this code allocates none')
    if shutil.disk_usage('/content').free <8*1024**3:
        raise ValueError('Colab free disk below8GiB; HOLD')
    if args.stop_after_epoch is not None and not 11<=args.stop_after_epoch<=40:
        raise ValueError('Planned stop must be a newly completed global epoch11..40')
    from .runtime_bootstrap import cub_runtime_bindings
    cfg,current_runtime,validate_runtime=cub_runtime_bindings()
    from phaseb.native import ROOT as frozen_root,module
    validate_runtime(read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['baseline_execution_runtime'],current_runtime())
    if (cfg['batch_size']!=16 or cfg['effective_batch_size']!=64 or cfg['teacher_weight_decay']!=.05
        or cfg['teacher_seed']!=20261013):
        raise ValueError('Frozen data/optimizer configuration differs')
    import google.auth
    from googleapiclient.discovery import build
    from .readiness import ensure_data
    from .staged_sources import load_sources
    from .runner import quota_gate
    package=Path(__file__).resolve().parents[1]
    delivery=verify_delivery(package)
    science=source_contract()
    credentials,_=google.auth.default()
    service=build('drive','v3',credentials=credentials,cache_discovery=False)
    sets,data=ensure_data(args.inputs,Path('/content/cub_stage_restart_a_v1/data'),args.data_root)
    # The review cap begins after environment/data readiness and includes anchor restoration.
    attempt_started=datetime.now(timezone.utc)
    started_monotonic=time.monotonic()
    native_io,native_train=module('cub200','io'),module('cub200','train')
    anchor,prefix,evidence,source,factory=load_sources(service,science,cfg,native_io)
    condition=read(package/'assets/A_CONDITIONS.json')
    recipe=StageRestartRecipe('cub200','IT',30,40,20261013,ANCHOR_SHA,
        sha(package/'assets/A_CONDITIONS.json'),delivery['code_id'])
    base=operation(recipe,cfg,run_name=args.run_name,code_id=delivery['code_id'])
    body={k:v for k,v in base.items() if k!='operational_id'}
    body.update(branch=branch_options(evidence),scientific_changes=['stage2–4 local LR schedule'],
        estimand=condition['question'],max_sessions=1,Student_epochs=0,Test_calls=0,
        nominal_epochs=40,new_Teacher_epochs=30,review_cap_seconds=7200)
    op={**body,'operational_id':identity(body)}
    destination=read(package/'assets/DRIVE_DESTINATION.json')
    folder=owned_folder(service,destination['runs_folder_id'],args.run_name,op['operational_id'])
    backend=DriveBackend(folder,op['operational_id'])
    local=Path('/content/cub_stage_restart_a_v1/runs')/op['operational_id']
    prior_release=read(args.runtime_release_evidence) if args.runtime_release_evidence else None
    previous=backend.get('RUN_STARTED.json')
    if previous and not args.resume:
        raise ValueError('Existing run requires explicit RESUME, never a duplicate start')
    if args.resume and not previous:
        raise ValueError('RESUME without the original run provenance')
    previous=None if previous is None else json.loads(previous)
    if previous and (previous.get('operational_id')!=op['operational_id'] or
                     previous.get('experiment_id')!=recipe.contract_id):
        raise ValueError('Original run provenance differs')
    original_start=attempt_started if previous is None else datetime.fromisoformat(previous['A_RUN_STARTED_UTC'])
    if original_start.tzinfo is None or original_start>attempt_started:
        raise ValueError('Invalid persisted review-cap origin')
    deadline=started_monotonic+7200-(attempt_started-original_start).total_seconds()
    if time.monotonic()>=deadline:
        raise ValueError('Original2h review cap exhausted; review required before another attempt')
    final_state=None
    with WriterLease(local,backend,op['operational_id'],resume=args.resume,prior_release=prior_release) as lease:
        quota=quota_gate(backend)
        put_json(backend,'OPERATIONAL_CONTRACT.json',op)
        put_json(backend,'SOURCE_VERIFIED.json',evidence)
        put_json(backend,'READINESS.json',{'quota':quota,'data':data,'current_runtime':current_runtime(),
            'historical_prefix_only':True,'actual_new_training_started':False})
        if previous is None:
            previous={'state':'prepared_actual_training_not_yet_started','role':'Session A',
                'experiment_id':recipe.contract_id,'operational_id':op['operational_id'],
                'run_folder_id':folder,'pid':os.getpid(),'runtime_id':runtime_identity(),
                'A_RUN_STARTED_UTC':original_start.isoformat(),'review_cap_seconds':7200,
                'global_next_epoch':10,'new_Teacher_epochs':0,'nominal_epochs':40,
                'shared_prefix_epochs':10,'source_anchor_sha256':ANCHOR_SHA}
            put_json(backend,'RUN_STARTED.json',previous)
        print('A_RUN_PREPARED',json.dumps(previous,ensure_ascii=False),flush=True)
        hard=read(read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['hard_set']['path'])
        hard_pin=read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['hard_set']
        if identity(hard)!=hard_pin['identity'] or len(hard['class_ids'])!=40:
            raise ValueError('Frozen Hard40 changed')
        storage.register(local,backend=backend,operational_contract=op,
            verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=args.stop_after_epoch)
        def bootstrap(current,execution):
            initial=bootstrap_factory(recipe,cfg,native_io,factory,anchor,prefix,evidence)(current,execution)
            put_json(backend,'BRANCH_START.json',initial)
        try:
            kernel=load_kernel(bootstrap=bootstrap,metrics=metrics_factory(hard['class_ids']),
                branch_start=10,pause_check=lambda:time.monotonic()>=deadline)
            result=kernel.fit_teacher(factory,sets['train'],sets['val'],local,recipe,cfg,native_io,native_train,
                lease=lease,device='cuda',stop_after_epoch=args.stop_after_epoch)
            current=storage.get_store(local)
            verify_source_end(service,evidence)
            final_state='complete' if result['completed_epochs']==40 else 'paused'
            receipt=current.finalize(state=final_state)
            rows=result['history'][10:]
            selected=None if result['best'] is None else result['history'][result['best']['epoch']]
            record={'state':final_state,'role':'Session A','experiment_id':recipe.contract_id,
                'operational_id':op['operational_id'],'shared_prefix_epochs':10,
                'new_Teacher_epochs':len(rows),'global_next_epoch':result['completed_epochs'],
                'Student_epochs':0,'Test_calls':0,'selected_validation':selected,'checkpoint_receipt':receipt,
                'historical_anchor_post_0':evidence['historical_anchor_post_0'],
                'attempted_steps':sum(r['attempted_optimizer_steps'] for r in rows),
                'applied_steps':sum(r['applied_optimizer_steps'] for r in rows),
                'AMP_skipped_steps':sum(r['skipped_optimizer_steps'] for r in rows),
                'delta_oldIT40_OA_pp':None if selected is None else selected['val_accuracy_pct']-72.33333333333333,
                'delta_dense_OA_pp':None if selected is None else selected['val_accuracy_pct']-83.66666666666667,
                'source_unchanged_at_final_metadata_check':True,
                'scope':'single-seed validation adaptive-IT policy comparison with historical control'}
            put_json(backend,'RUN_RESULT.json',record)
            if args.auto_release:
                put_json(backend,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,
                    'after_durable_state':final_state,'runtime_id':runtime_identity(),
                    'operational_id':op['operational_id'],'method':'google.colab.runtime.unassign'})
            lease.finish(final_state,result['completed_epochs'])
            print('A_DURABLE_'+final_state.upper(),json.dumps(record,ensure_ascii=False),flush=True)
        except KeyboardInterrupt:
            current=storage.get_store(local)
            if current.pointer() is not None:
                receipt=current.finalize(state='paused')
                final_state='paused'
                lease.finish('paused',receipt['remote_durable_epoch'])
            raise
        finally:
            storage.release(local)
    if args.auto_release and final_state in ('complete','paused'):
        # A request is not a confirmed release; operator observes actual Colab session absence.
        release={'requested':True,'confirmed':False,'after_durable_state':final_state,
            'runtime_id':runtime_identity(),'operational_id':op['operational_id'],
            'method':'google.colab.runtime.unassign'}
        # The remote request was written before clean owner release; repeat only the small local receipt.
        atomic_json(local/'RELEASE_REQUEST.json',release)
        print('A_RELEASE_REQUEST',json.dumps(release),flush=True)
        from google.colab import runtime
        runtime.unassign()
    return record

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start-training',action='store_true')
    parser.add_argument('--run-name',default='cub_A_stage2to4_LRrestart_v1')
    parser.add_argument('--inputs',default='/content/drive/MyDrive/온디바이스AI/TeacherSizeKD_NoPruning/inputs')
    parser.add_argument('--data-root')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--runtime-release-evidence')
    parser.add_argument('--stop-after-epoch',type=int)
    parser.add_argument('--auto-release',action='store_true')
    args=parser.parse_args()
    print(json.dumps(run(args),ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
