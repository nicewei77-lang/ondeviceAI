"""Train-only, per-example squared hidden-gate gradient importance.

Gate placement: post-GELU input of each pwconv2 Linear. One gate/channel is
shared over spatial positions. S_j=mean_i[(d CE_i/d gate_j at gate=1)^2].
Spatial signed terms sum inside each example; examples are squared BEFORE
averaging, never squared minibatch-mean gradients. All gates are scored jointly
on the complete pre-surgery model. No global/layer normalization or clipping.
"""
from copy import copy
import hashlib,inspect,json,random,time
from pathlib import Path
import torch
from torch.nn import functional as F
from followup_iterative_v2 import surgery
from .identity import identity,atomic_json,read,sha

SURGERY_SHA='376430220073a0a381772b7a7c78fdf92868297cfcc6d08f3fb32621f6523e3e'
SEED=20261027

def calibration_indices(dataset,num_classes,*,fixture=False):
    records=dataset.records
    if len(records)!=len(dataset) or (not fixture and (num_classes!=200 or len(dataset)!=4794)):
        raise ValueError('Calibration must use the frozen4794 training records')
    groups={c:[] for c in range(num_classes)}
    for i,row in enumerate(records):
        label=row['label']
        if type(label) is not int or label not in groups:raise ValueError('Calibration label differs')
        groups[label].append(i)
    rng=random.Random(SEED)
    indices=sorted(i for c in range(num_classes) for i in rng.sample(groups[c],2))
    ids=[records[i]['image_id'] for i in indices]
    if len(ids)!=len(set(ids)):raise ValueError('Calibration image IDs must be unique')
    return indices

def _flags():
    return {'precision':torch.get_float32_matmul_precision(),
        'cudnn_tf32':torch.backends.cudnn.allow_tf32,
        'cudnn_deterministic':torch.backends.cudnn.deterministic,
        'cudnn_benchmark':torch.backends.cudnn.benchmark,
        'deterministic':torch.are_deterministic_algorithms_enabled(),
        'warn_only':torch.is_deterministic_algorithms_warn_only_enabled()}

def _restore_flags(flags):
    torch.set_float32_matmul_precision(flags['precision'])
    torch.backends.cudnn.allow_tf32=flags['cudnn_tf32']
    torch.backends.cudnn.deterministic=flags['cudnn_deterministic']
    torch.backends.cudnn.benchmark=flags['cudnn_benchmark']
    torch.use_deterministic_algorithms(flags['deterministic'],warn_only=flags['warn_only'])

class TaylorCalibrator:
    def __init__(self,train_dataset,native_io,num_classes,*,directory,fixture=False):
        self.dataset=copy(train_dataset)
        self.dataset.set_epoch(0,SEED)  # Fixed Native train-transform pixels at every boundary/arm.
        self.indices=calibration_indices(train_dataset,num_classes,fixture=fixture)
        self.samples=[{'index':i,'image_id':train_dataset.records[i]['image_id'],
                       'label':train_dataset.records[i]['label']} for i in self.indices]
        self.native_io=native_io;self.num_classes=num_classes
        self.directory=Path(directory);self.fixture=fixture;self.calls=[]

    def compute(self,model,layout,stage):
        if stage not in (0,1,2,3):raise ValueError('Extension boundary must be0..3')
        surgery.validate_layout(model,layout)
        layers=list(surgery.blocks(model))
        if not self.fixture and len(layers)!=36:raise ValueError('Expected36 ConvNeXt blocks')
        params=list(model.parameters())
        if not params or any(p.dtype!=torch.float32 for p in params):
            raise ValueError('Calibration requires existing FP32 master weights')
        device=params[0].device
        before=self.native_io.model_state_identity(model.state_dict())
        rng=self.native_io.rng_state();flags=_flags()
        modes=[(m,m.training) for m in model.modules()]
        requires=[p.requires_grad for p in params]
        gates=[];handles=[];sums=[]
        started=time.monotonic()
        try:
            self.native_io.seed_everything(SEED)
            torch.set_float32_matmul_precision('highest')
            torch.backends.cudnn.allow_tf32=False
            torch.use_deterministic_algorithms(True,warn_only=False)
            model.eval()
            for p in params:p.requires_grad_(False)
            for (_,_,block),row in zip(layers,layout):
                gate=torch.ones(row['hidden'],device=device,dtype=torch.float32,requires_grad=True)
                gates.append(gate);sums.append(torch.zeros(row['hidden'],dtype=torch.float64))
                def hook(module,args,g=gate):
                    if args[0].shape[-1]!=g.numel():raise ValueError('pwconv2 hidden-gate shape mismatch')
                    return (args[0]*g,*args[1:])
                handles.append(block.pwconv2.register_forward_pre_hook(hook))
            for index in self.indices:
                image,label,image_id=self.dataset[index]
                expected=self.dataset.records[index]
                if int(label)!=expected['label'] or int(image_id)!=expected['image_id']:
                    raise ValueError('Calibration training sample provenance differs')
                images=image.unsqueeze(0).to(device=device,dtype=torch.float32)
                labels=torch.tensor([label],device=device,dtype=torch.long)
                with torch.enable_grad(),torch.autocast(device_type=device.type,enabled=False):
                    logits=model(images)
                    if tuple(logits.shape)!=(1,self.num_classes) or not bool(torch.isfinite(logits).all()):
                        raise FloatingPointError('Nonfinite/invalid calibration output')
                    loss=F.cross_entropy(logits.float(),labels,reduction='sum')
                    gradients=torch.autograd.grad(loss,gates,allow_unused=False)
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite calibration CE')
                for total,g in zip(sums,gradients):
                    if not bool(torch.isfinite(g).all()):raise FloatingPointError('Nonfinite gate gradient')
                    total.add_(g.detach().cpu().double().square())
            scores=[s/len(self.indices) for s in sums]
            if any(not bool(torch.isfinite(s).all()) or bool((s<0).any()) for s in scores):
                raise FloatingPointError('Invalid Taylor scores')
        finally:
            for h in handles:h.remove()
            for p,value in zip(params,requires):p.requires_grad_(value)
            for module,value in modes:module.training=value
            _restore_flags(flags)
            self.native_io.restore_rng(rng)
            if self.native_io.model_state_identity(model.state_dict())!=before:
                raise ValueError('Calibration changed source weights or persistent buffers')
        score_map={(s,b):score for (s,b,_),score in zip(layers,scores)}
        summaries=[{'stage':s,'block':b,'hidden':len(score),
            'scores_sha256':hashlib.sha256(score.numpy().tobytes()).hexdigest(),
            'minimum':float(score.min()),'maximum':float(score.max()),
            'zero_channels':int((score==0).sum())} for (s,b),score in score_map.items()]
        core={'method':'mean_i_squared_dCE_i_d_gate','placement':'post_GELU_pwconv2_input',
            'calibration_loss':'CE only in both recovery arms','sample_seed':SEED,
            'transform_epoch':0,'samples':self.samples,'samples_per_class':2,
            'sample_count':len(self.indices),'batch_size':1,'gradient_dtype':'FP32',
            'accumulation_and_ranking_dtype':'FP64','normalization':'divide by N only; no layer/spatial normalization',
            'TF32':False,'autocast':False,'model_mode':'eval','source_model_digest':before,
            'source_unchanged':True,'stage_boundary':stage,'layers':summaries,
            'forward_evaluations':len(self.indices),'backward_evaluations':len(self.indices),
            'optimizer_steps':0,'RNG_training_flags_requires_grad_restored':True}
        path=self.directory/f'CALIBRATION_{stage:02d}.json'
        ident=identity(core)
        prior=read(path) if path.exists() else None
        if prior and prior['calibration_identity']!=ident:
            raise ValueError('Calibration replay scores/provenance changed')
        attempts=[] if prior is None else prior['attempt_seconds']
        receipt={'calibration_identity':ident,'core':core,
            'attempt_seconds':attempts+[time.monotonic()-started]}
        atomic_json(path,receipt)
        self.calls.append(stage)
        return score_map,receipt

    def prune(self,model,layout,recipe,stage,*,audit=None):
        if sha(Path(surgery.__file__))!=SURGERY_SHA:raise ValueError('Frozen surgery source differs')
        scores,receipt=self.compute(model,layout,stage)
        # Only score assignment/audit labels change. Widths/ties/bias/column slicing remain frozen.
        source=inspect.getsource(surgery.prune_stage)
        replacements=[('scores = layer.pwconv1.weight.detach().float().abs().sum(dim=1)',
                       "scores = _scores[(row['stage'],row['block'])]"),
            ("'L1_FP32':scores.cpu().tolist()","'Taylor_gate_grad_sq_FP64':scores.cpu().tolist()"),
            ("'bias_in_importance':False","'bias_in_importance':True")]
        for old,new in replacements:
            if source.count(old)!=1:raise ValueError('Frozen scoring insertion point changed')
            source=source.replace(old,new)
        namespace={**vars(surgery),'_scores':scores}
        exec(compile(source,str(surgery.__file__)+'[Taylor_scores]','exec'),namespace)
        rows=[]
        result=namespace['prune_stage'](model,layout,recipe,stage,audit=rows)
        for row in rows:
            row['calibration_identity']=receipt['calibration_identity']
            row['score_definition']='mean_per_example_squared_hidden_gate_gradient'
        if audit is not None:audit.extend(rows)
        return result
