"""Resolve the bundled Native runtime only after its verified path is registered."""

def cub_runtime_bindings():
    from phaseb.native import config
    # config() calls the pinned parent loader, verifies its manifest and adds
    # vendor/native_parent to sys.path before the first direct b1kd import.
    cfg=config('cub200')
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    return cfg,current_training_runtime,validate_runtime_match
