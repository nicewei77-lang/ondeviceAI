"""Local atomic epochs and sparse, verified remote checkpoint sets.

Only storage semantics differ from the frozen Teacher loop. Local progress is
never evidence of remote resumability. Three remote heads protect the active
and prior checkpoint sets while the next set is uploaded and verified.
"""
from __future__ import annotations

from dataclasses import asdict
from functools import wraps
import hashlib
import io
import json
from pathlib import Path
import threading
import time
import torch

from .backend import (ALLOWED, ANCHORS, BEST, RESUME, NAMESPACE, LocalBackend,
                      atomic_bytes, digest)


LOCAL_RESUME = ('resume_local_0.pt', 'resume_local_1.pt')
_SETTINGS, _STORES = {}, {}


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode('utf8')).hexdigest()


def contract_identity(value):
    declared = value.get('operational_id')
    if declared is None:
        return identity(value)
    observed = identity({k: v for k, v in value.items() if k != 'operational_id'})
    if declared != observed:
        raise ValueError('Declared operational identity differs')
    return declared


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      allow_nan=False).encode('utf8')


def encode_model(value):
    stream = io.BytesIO()
    torch.save(value, stream)
    return stream.getvalue()


def atomic_json(path, value):
    atomic_bytes(path, encoded(value))


def _key(directory):
    return str(Path(directory).resolve())


def register(directory, *, backend, operational_contract, clock=time.monotonic,
             verifier=None, planned_stop_epoch=None):
    """Bind one explicit new output path before the adapted kernel is called.

    verifier(raw_bytes) returns the fully verified payload and may perform the
    frozen strict model/optimizer/RNG restore. It runs on actual resume/final,
    never on each epoch commit. The outer lease owns cross-process exclusivity.
    """
    key = _key(directory)
    if key in _STORES:
        raise ValueError('Cannot change a live light-I/O context')
    if operational_contract.get('namespace') != NAMESPACE:
        raise ValueError('Explicit light-I/O operational contract required')
    interval = operational_contract.get('remote_resume_interval_seconds',
        operational_contract.get('checkpoint_options', {}).get('REMOTE_RESUME_INTERVAL_SECONDS', 900))
    if type(interval) not in (int, float) or interval != 900:
        raise ValueError('Frozen sparse resume interval must be 900 seconds')
    contract_id = contract_identity(operational_contract)
    if backend.contract_id != contract_id:
        raise ValueError('Backend and operational contract identity differ')
    _SETTINGS[key] = dict(backend=backend, operational_contract=operational_contract,
                          clock=clock, verifier=verifier,
                          planned_stop_epoch=planned_stop_epoch)
    return contract_id


class LightStore:
    def __init__(self, directory, recipe, native_io, dense_factory, lease=None, *,
                 backend, operational_contract, clock=time.monotonic, verifier=None,
                 planned_stop_epoch=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.recipe, self.native_io, self.factory, self.lease = recipe, native_io, dense_factory, lease
        self.backend, self.contract = backend, operational_contract
        branch = self.contract.get('branch')
        self.start_epoch = 0
        self.expected_anchors = set(ANCHORS)
        if branch is not None:
            if branch.get('mode') == 'taylor_extension':
                if branch.get('start_epoch')!=0 or branch.get('new_epochs')!=recipe.budget:raise ValueError('Exact reviewed branch budget required')
            elif branch.get('mode') == 'taylor_after_L1_prefix':
                from .staged import validate_branch_contract, REQUIRED_ANCHORS
                validate_branch_contract(branch, recipe)
                self.start_epoch = 10
                self.expected_anchors = set(REQUIRED_ANCHORS)
            elif (branch.get('mode') != 'anchor_tail' or branch.get('start_global_epoch') != 30 or
                branch.get('end_global_epoch_exclusive') != 40 or
                branch.get('source_anchor_sha256') != '71051a97e2856dd0b8bb1bce34c69d658f797cc205939778c05b8c94d4dee675' or
                branch.get('tail_arm') not in ('G10','R10') or
                branch.get('tail_arm') != getattr(recipe,'tail_arm',None) or recipe.budget != 40 or
                branch.get('required_anchor_names') != ['anchor_post_3.pt']):
                raise ValueError('Tail storage exception requires the exact separate branch contract')
            else:
                self.start_epoch = 30
                self.expected_anchors = {'anchor_post_3.pt'}
        self.operational_contract_id = contract_identity(operational_contract)
        self.clock, self.verifier = clock, verifier
        self.planned_stop_epoch = planned_stop_epoch
        self.interval = 900
        self.lock = threading.RLock()
        self.last_success_monotonic = clock()
        self.next_deadline = self.last_success_monotonic + self.interval
        self.pending_best = None
        self.known_best = {}
        self.pending_anchors = {}
        self.upload_count = 0
        self.resume_origin = None
        self._pointer = self._read_local_pointer()
        raw = self.backend.get('REMOTE_COMMITTED.json')
        self.remote_pointer = None if raw is None else self._decode_pointer(raw, remote=True)
        if not recipe.fixture and (backend.fixture or verifier is None or lease is None):
            raise ValueError('Research store requires actual Drive, full verifier and live writer lease')
        if self._pointer is not None:
            self.resume_origin = 'local_atomic_commit'
        elif self.remote_pointer is not None:
            self._hydrate_remote()

    def _active(self):
        if self.lease is not None:
            self.lease.assert_active()
            self.lease.assert_output_path(self.directory)

    def _bound(self, value):
        if (value.get('operational_contract_id') != self.operational_contract_id or
                value.get('contract_id') != self.recipe.contract_id):
            raise ValueError('Checkpoint operational/scientific contract differs')

    def _decode_pointer(self, raw, *, remote):
        value = json.loads(raw)
        self._bound(value)
        expected = 'cub.lightio.remote.v1' if remote else 'cub.lightio.local.v1'
        if value.get('schema') != expected or not value.get('active'):
            raise ValueError('Invalid light-I/O pointer schema')
        names = RESUME if remote else LOCAL_RESUME
        for ref in (value['active'], value.get('prior')):
            if ref and (ref.get('file') not in names or
                        ref.get('operational_contract_id') != self.operational_contract_id or
                        ref.get('contract_id') != self.recipe.contract_id):
                raise ValueError('Invalid bound checkpoint reference')
        if value.get('prior') and value['prior']['file'] == value['active']['file']:
            raise ValueError('Active/prior checkpoint alias')
        return value

    def _read_local_pointer(self):
        path = self.directory / 'LOCAL_COMMITTED.json'
        return self._decode_pointer(path.read_bytes(), remote=False) if path.is_file() else None

    def _ref(self, name, raw, payload, *, remote_ref=None):
        return {**(remote_ref or {'file': name, 'sha256': digest(raw), 'bytes': len(raw),
                                 'file_id': 'local:' + name}),
                'contract_id': self.recipe.contract_id,
                'operational_contract_id': self.operational_contract_id,
                'model_digest': payload['model_digest'], 'stage': payload['stage'],
                'kind': payload.get('kind', 'model_only'),
                'next_epoch': payload.get('next_epoch')}

    def _raw_ref(self, ref, *, remote=False):
        if remote:
            raw = self.backend.get(ref['file'], expected_id=ref.get('file_id'))
        else:
            name = ref['file']
            if name not in set(LOCAL_RESUME + BEST + ANCHORS + ('selected_teacher.pt',)):
                raise ValueError('Invalid local checkpoint name')
            path = self.directory / name
            raw = path.read_bytes() if path.is_file() else None
        if raw is None or len(raw) != ref['bytes'] or digest(raw) != ref['sha256']:
            raise ValueError('Referenced checkpoint SHA256/size changed')
        return raw

    def _verified(self, raw):
        value = (self.verifier(raw) if self.verifier is not None else
                 torch.load(io.BytesIO(raw), map_location='cpu', weights_only=True))
        self._bound(value)
        return value

    def _hydrate_remote(self):
        """Only a committed remote set is adopted, never progress/history alone."""
        remote = self.remote_pointer
        ref = remote['active']
        raw = self._raw_ref(ref, remote=True)
        value = self._verified(raw)
        best = value.get('best')
        if best is not None:
            best_raw = self._raw_ref(best, remote=True)
            self._verified(best_raw)
            atomic_bytes(self.directory / best['file'], best_raw)
            self.known_best[best['file']] = best['sha256']
        for name, anchor in remote.get('anchors', {}).items():
            if name not in ANCHORS:
                raise ValueError('Invalid remote anchor ledger')
            anchor_raw = self._raw_ref(anchor, remote=True)
            # Model-only anchors are immutable; source/stage strict restoration
            # was verified by the kernel when they were produced.
            self._bound(torch.load(io.BytesIO(anchor_raw), map_location='cpu', weights_only=True))
            atomic_bytes(self.directory / name, anchor_raw)
        local_name = LOCAL_RESUME[0]
        atomic_bytes(self.directory / local_name, raw)
        local = self._ref(local_name, raw, value)
        local['best'] = best
        self._pointer = {'schema': 'cub.lightio.local.v1',
                         'contract_id': self.recipe.contract_id,
                         'operational_contract_id': self.operational_contract_id,
                         'sequence': 0, 'active': local, 'prior': None}
        atomic_json(self.directory / 'LOCAL_COMMITTED.json', self._pointer)
        atomic_json(self.directory / 'history.json', value['history'])
        progress = self.backend.get('progress.json')
        previous = {} if progress is None else json.loads(progress)
        if previous:
            self._bound(previous)
        prior_epoch = previous.get('latest_completed_epoch', value['next_epoch'])
        self.resume_origin = 'remote_durable_commit'
        if prior_epoch > value['next_epoch']:
            rollback = {'contract_id': self.recipe.contract_id,
                        'operational_contract_id': self.operational_contract_id,
                        'observed_latest_completed_epoch': prior_epoch,
                        'resumed_remote_durable_epoch': value['next_epoch'],
                        'discarded_progress_epochs': prior_epoch - value['next_epoch'],
                        'reason': 'Progress ahead of durable snapshot is not resumable'}
            atomic_json(self.directory / 'ROLLBACK.json', rollback)
            self.backend.put('ROLLBACK.json', encoded(rollback))

    def pointer(self):
        return self._pointer

    def load(self):
        if self._pointer is None:
            raise FileNotFoundError('No committed local or remote checkpoint')
        ref = self._pointer['active']
        value = self._verified(self._raw_ref(ref))
        if value.get('best') is not None:
            self._verified(self._raw_ref(value['best']))
            self.known_best[value['best']['file']] = value['best']['sha256']
        return value, ref

    def read_ref(self, ref):
        return self._raw_ref(ref)

    def _bind_payload(self, payload):
        if payload['contract_id'] != self.recipe.contract_id:
            raise ValueError('Scientific recipe changed')
        result = dict(payload)
        result['operational_contract_id'] = self.operational_contract_id
        if self.start_epoch:
            result['branch_contract'] = self.contract['branch']
        return result

    def save_best(self, payload):
        with self.lock:
            self._active()
            if {'optimizer_state', 'scaler_state', 'rng_state'} & set(payload):
                raise ValueError('Best must be model-only')
            if (not self._pointer or payload.get('epoch') != self._pointer['active']['next_epoch'] or
                    payload.get('stage') != 3 or payload.get('eligibility') != 'final_quarter' or
                    not self.recipe.eligible(payload['epoch'])):
                raise ValueError('Best is not the next eligible final-quarter epoch')
            protected = {r['best']['file'] for r in
                         (self._pointer['active'], self._pointer.get('prior'))
                         if r and r.get('best')}
            if self.pending_best:
                protected.add(self.pending_best['file'])
            name = next((n for n in BEST if n not in protected), None)
            if name is None:
                raise ValueError('No unreferenced local best slot')
            value = self._bind_payload(payload)
            raw = encode_model(value)
            atomic_bytes(self.directory / name, raw)
            ref = self._ref(name, raw, value)
            self.pending_best = ref
            self.known_best[name] = ref['sha256']
            return ref

    def anchor(self, name, payload):
        with self.lock:
            self._active()
            if name not in ANCHORS or {'optimizer_state', 'scaler_state', 'rng_state'} & set(payload):
                raise ValueError('Invalid model-only stage anchor')
            index, position = payload['code_stage_index'], payload['position']
            if (payload['anchor_j'] != index + 1 or
                    payload['global_epoch'] != index * self.recipe.budget // 4 or
                    payload['stage'] != (index if position == 'post' else index - 1) or
                    name != f'anchor_{position}_{index}.pt'):
                raise ValueError('Stage anchor index/epoch convention differs')
            value = self._bind_payload(payload)
            path = self.directory / name
            if path.is_file():
                raw = path.read_bytes()
                prior = torch.load(io.BytesIO(raw), map_location='cpu', weights_only=True)
                self._bound(prior)
                fields = ('model_digest', 'stage', 'anchor_j', 'global_epoch', 'position', 'layout')
                if any(prior.get(k) != value.get(k) for k in fields):
                    raise ValueError('Immutable stage anchor differs on replay')
            else:
                raw = encode_model(value)
                atomic_bytes(path, raw)
            ref = self._ref(name, raw, value)
            self.pending_anchors[name] = ref
            return ref

    def commit(self, payload):
        with self.lock:
            self._active()
            value = self._bind_payload(payload)
            epoch, kind = value['next_epoch'], value['kind']
            if type(epoch) is not int or not 0 <= epoch <= self.recipe.budget or kind not in ('boundary', 'epoch'):
                raise ValueError('Invalid completed epoch transaction')
            stage = self.recipe.stage(epoch if kind == 'boundary' else epoch - 1)
            if (value['stage'] != stage or len(value['history']) != epoch or
                    value['applied_boundaries'] != list(range(stage + 1))):
                raise ValueError('Committed stage/history/reset ledger differs')
            previous = None if self._pointer is None else self._pointer['active']
            if previous is None:
                valid = epoch == self.start_epoch and kind == 'boundary'
            elif previous['next_epoch'] >= self.recipe.budget:
                valid = False
            elif kind == 'boundary':
                valid = (previous['kind'] == 'epoch' and epoch == previous['next_epoch'] and
                         self.recipe.stage_start(epoch) and stage == previous['stage'] + 1)
            else:
                valid = epoch == previous['next_epoch'] + 1 and stage == previous['stage']
            if not valid:
                raise ValueError('Duplicate/out-of-order local epoch or boundary')
            if value.get('best') is not None:
                if self.known_best.get(value['best']['file']) != value['best']['sha256']:
                    raise ValueError('Best was not saved or verified in this local context')
            name = next(n for n in LOCAL_RESUME if previous is None or n != previous['file'])
            raw = encode_model(value)
            atomic_bytes(self.directory / name, raw)
            ref = self._ref(name, raw, value)
            ref['best'] = value.get('best')
            candidate_pointer = {'schema': 'cub.lightio.local.v1',
                             'contract_id': self.recipe.contract_id,
                             'operational_contract_id': self.operational_contract_id,
                             'sequence': 0 if self._pointer is None else self._pointer['sequence'] + 1,
                             'active': ref, 'prior': previous}
            atomic_json(self.directory / 'LOCAL_COMMITTED.json', candidate_pointer)
            self._pointer = candidate_pointer
            self.pending_best = None
            reasons = set()
            if kind == 'boundary':
                reasons.add('stage_boundary')
            if kind == 'epoch' and epoch == self.recipe.budget:
                reasons.add('final')
            if kind == 'epoch' and self.planned_stop_epoch is not None and epoch >= self.planned_stop_epoch:
                reasons.add('planned_pause')
            if self.clock() >= self.next_deadline:
                reasons.add('interval_900_seconds')
            if reasons:
                self.flush(reasons)
            self._publish_progress(value)
            return ref

    def _publish_progress(self, payload):
        durable = None if self.remote_pointer is None else self.remote_pointer['active']['next_epoch']
        progress = {'schema': 'cub.lightio.progress.v1',
                    'contract_id': self.recipe.contract_id,
                    'operational_contract_id': self.operational_contract_id,
                    'latest_completed_epoch': payload['next_epoch'],
                    'remote_durable_epoch': durable,
                    'planned_epochs': self.recipe.budget, 'stage': payload['stage'],
                    'state': 'epoch_committed_locally',
                    'remote_checkpoint_set_complete': durable == payload['next_epoch'],
                    'resume_origin': self.resume_origin,
                    'snapshot_upload_count_this_process': self.upload_count}
        if self.start_epoch:
            progress.update(global_next_epoch=payload['next_epoch'],
                branch_completed_epochs=payload['next_epoch']-self.start_epoch,
                remote_durable_branch_epochs=None if durable is None else durable-self.start_epoch,
                newly_planned_epochs=self.recipe.budget-self.start_epoch,external_prefix_epochs=self.start_epoch,
                tail_arm=self.contract['branch']['tail_arm'])
        self.backend.put('history.json', encoded(payload['history']))
        self.backend.put('progress.json', encoded(progress))
        atomic_json(self.directory / 'progress.json', progress)

    def flush(self, reason='planned_pause'):
        """Flush only the last local transaction; multiple triggers upload once."""
        with self.lock:
            self._active()
            if self._pointer is None:
                raise ValueError('No completed local transaction to flush')
            reasons = {reason} if isinstance(reason, str) else set(reason)
            allowed = {'planned_pause', 'final', 'stage_boundary', 'interval_900_seconds'}
            if not reasons or not reasons <= allowed:
                raise ValueError('Unknown snapshot trigger')
            local_ref = self._pointer['active']
            local_raw = self._raw_ref(local_ref)
            value = torch.load(io.BytesIO(local_raw), map_location='cpu', weights_only=True)
            self._bound(value)
            if 'final' in reasons and (value['kind'] != 'epoch' or value['next_epoch'] != self.recipe.budget):
                raise ValueError('Cannot finalize an incomplete Teacher')
            final = 'final' in reasons
            if final:
                self._verified(local_raw)
            old = self.remote_pointer
            if final:
                available_anchors = set(self.pending_anchors) | (set(old.get('anchors', {})) if old else set())
                expected_anchors = self.expected_anchors
                if available_anchors != expected_anchors:
                    raise ValueError('Final Teacher requires all seven model-only stage anchors')
            already = old is not None and local_ref['sha256'] in {
                old.get('local_commit_sha256'), old['active']['sha256']}
            if already and (not final or old.get('selected_teacher')):
                return old
            protected = set() if old is None else {r['file'] for r in (old['active'], old.get('prior')) if r}
            name = next(n for n in RESUME if n not in protected)
            remote_value = dict(value)
            remote_best = None
            if value.get('best') is not None:
                best = value['best']
                best_raw = self._raw_ref(best)
                protected_best = set() if old is None else {
                    r['best']['file'] for r in (old['active'], old.get('prior')) if r and r.get('best')}
                existing = [] if old is None else [r['best'] for r in (old['active'], old.get('prior')) if r and r.get('best')]
                remote_best = next((r for r in existing if r['sha256'] == best['sha256']), None)
                if remote_best is None:
                    best_name = next(n for n in BEST if n not in protected_best)
                    best_value = torch.load(io.BytesIO(best_raw), map_location='cpu', weights_only=True)
                    uploaded = self.backend.put(best_name, best_raw)
                    remote_best = {**best, **self._ref(best_name, best_raw, best_value, remote_ref=uploaded)}
                remote_value['best'] = remote_best
            anchors = {} if old is None else dict(old.get('anchors', {}))
            audits = {} if old is None else dict(old.get('boundary_audits', {}))
            calibrations = {} if old is None else dict(old.get('calibrations', {}))
            for anchor_name, local_anchor in self.pending_anchors.items():
                if anchor_name in anchors:
                    if anchors[anchor_name]['sha256'] != local_anchor['sha256']:
                        raise ValueError('Remote immutable anchor differs')
                    continue
                anchor_raw = self._raw_ref(local_anchor)
                uploaded = self.backend.put(anchor_name, anchor_raw)
                anchors[anchor_name] = {**local_anchor, **uploaded}
            if self.contract.get('branch',{}).get('mode') in ('taylor_after_L1_prefix','taylor_extension'):
                for stage in ((0,1,2,3) if self.contract['branch']['mode']=='taylor_extension' else (1,2,3)):
                    audit_name=f'BOUNDARY_{stage:02d}_AUDIT.json'
                    path=self.directory/audit_name
                    if path.is_file() and audit_name not in audits:
                        raw=path.read_bytes()
                        record=json.loads(raw)
                        if (record.get('global_epoch')!=stage*(self.recipe.budget//4) or record.get('code_stage_index')!=stage
                            or (stage>0 and record.get('pre_anchor',{}).get('model_digest')!=anchors[f'anchor_pre_{stage}.pt']['model_digest'])
                            or record.get('post_anchor',{}).get('model_digest')!=anchors[f'anchor_post_{stage}.pt']['model_digest']):
                            raise ValueError('Stage L1 audit is not bound to owned anchors')
                        calibration_name=f'CALIBRATION_{stage:02d}.json'
                        calibration_raw=(self.directory/calibration_name).read_bytes()
                        calibration=json.loads(calibration_raw)
                        if (calibration['core']['source_model_digest']!=record['pre_anchor']['model_digest'] or
                            any(row.get('calibration_identity')!=calibration['calibration_identity'] for row in record['Taylor_records'])):
                            raise ValueError('Taylor audit/calibration identity mismatch')
                        calibrations[calibration_name]=self.backend.put(calibration_name,calibration_raw)
                        audits[audit_name]=self.backend.put(audit_name,raw)
            selected_ref = None
            if final:
                if remote_best is None:
                    raise ValueError('Final Teacher lacks selected model-only best')
                selected_raw = self._raw_ref(value['best'])
                self._verified(selected_raw)
                selected_ref = self.backend.put('selected_teacher.pt', selected_raw)
            remote_raw = encode_model(remote_value)
            uploaded = self.backend.put(name, remote_raw)
            ref = self._ref(name, remote_raw, remote_value, remote_ref=uploaded)
            ref['best'] = remote_best
            pointer = {'schema': 'cub.lightio.remote.v1',
                       'contract_id': self.recipe.contract_id,
                       'operational_contract_id': self.operational_contract_id,
                       'sequence': 0 if old is None else old['sequence'] + 1,
                       'active': ref, 'prior': None if old is None else old['active'],
                       'anchors': anchors, 'boundary_audits':audits, 'calibrations':calibrations,'selected_teacher': selected_ref,
                       'local_commit_sha256': local_ref['sha256'],
                       'triggers': sorted(reasons), 'candidate_set_verified_before_pointer': True}
            self.backend.put('REMOTE_COMMITTED.json', encoded(pointer))
            # Timer/durable state advance only after every object and the pointer
            # itself have completed verified provider writes.
            self.remote_pointer = pointer
            self.last_success_monotonic = self.clock()
            self.next_deadline = self.last_success_monotonic + self.interval
            self.pending_anchors.clear()
            self.upload_count += 1
            atomic_json(self.directory / 'REMOTE_DURABLE.json', pointer)
            return pointer

    def validate_final(self):
        if self._pointer is None:
            raise ValueError('No committed checkpoint')
        value, _ = self.load()
        remote = self.remote_pointer
        if (value['next_epoch'] != self.recipe.budget or value['kind'] != 'epoch' or remote is None or
                remote['active']['next_epoch'] != self.recipe.budget or
                self._pointer['active']['sha256'] not in {
                    remote.get('local_commit_sha256'), remote['active']['sha256']} or
                not remote.get('selected_teacher')):
            raise ValueError('Final checkpoint set is not durable and selected')
        expected_anchors = self.expected_anchors
        if set(remote.get('anchors', {})) != expected_anchors:
            raise ValueError('Final remote ledger lacks the seven required stage anchors')
        if self.contract.get('branch',{}).get('mode') in ('taylor_after_L1_prefix','taylor_extension'):
            if set(remote.get('boundary_audits',{})) != {f'BOUNDARY_{s:02d}_AUDIT.json' for s in ((0,1,2,3) if self.contract['branch']['mode']=='taylor_extension' else (1,2,3))}:
                raise ValueError('Session A lacks its three owned L1 boundary audits')
            for ref in remote['boundary_audits'].values():
                self.backend.verify_ref(ref)
            if set(remote.get('calibrations',{}))!={f'CALIBRATION_{s:02d}.json' for s in ((0,1,2,3) if self.contract['branch']['mode']=='taylor_extension' else (1,2,3))}:
                raise ValueError('Three Taylor calibration receipts are required')
            for ref in remote['calibrations'].values():self.backend.verify_ref(ref)
        for ref in [remote['active'], remote['active']['best'], remote['selected_teacher'],
                    *remote['anchors'].values()]:
            self.backend.verify_ref(ref)
        return {'contract_id': self.recipe.contract_id,
                'operational_contract_id': self.operational_contract_id,
                'latest_completed_epoch': value['next_epoch'],
                'remote_durable_epoch': remote['active']['next_epoch'],
                'selected_teacher': remote['selected_teacher'],
                'remote_commit': remote, 'state': 'verified_final_checkpoint_set'}

    def finalize(self, *, state):
        if state == 'complete':
            self.flush('final')
            receipt = self.validate_final()
            name = 'COMPLETE.json'
        elif state == 'paused':
            pointer = self.flush('planned_pause')
            receipt = {'contract_id': self.recipe.contract_id,
                       'operational_contract_id': self.operational_contract_id,
                       'latest_completed_epoch': self._pointer['active']['next_epoch'],
                       'remote_durable_epoch': pointer['active']['next_epoch'],
                       'remote_commit': pointer}
            name = 'PAUSED.json'
        else:
            raise ValueError('Only complete/paused final states are supported')
        receipt['state'] = state
        if self.start_epoch:
            receipt.update(global_next_epoch=self._pointer['active']['next_epoch'],
                branch_completed_epochs=self._pointer['active']['next_epoch']-self.start_epoch,
                tail_arm=self.contract['branch']['tail_arm'],external_prefix_epochs=self.start_epoch,
                newly_trained_epoch_count=self._pointer['active']['next_epoch']-self.start_epoch)
        self.backend.put(name, encoded(receipt))
        atomic_json(self.directory / name, receipt)
        return receipt


def configure(directory, recipe, native_io, dense_factory, lease=None, **unsupported):
    if unsupported:
        raise ValueError('Use register() for explicit storage injection')
    key = _key(directory)
    if key not in _SETTINGS:
        raise ValueError('Explicit new operational context must be registered')
    if key not in _STORES:
        _STORES[key] = LightStore(directory, recipe, native_io, dense_factory, lease,
                                  **_SETTINGS[key])
    elif _STORES[key].recipe != recipe:
        raise ValueError('Active recipe changed')
    return _STORES[key]


def get_store(directory):
    key = _key(directory)
    if key not in _STORES:
        raise ValueError('Light-I/O store context is required')
    return _STORES[key]


def release(directory):
    store = _STORES.pop(_key(directory), None)
    _SETTINGS.pop(_key(directory), None)
    if store is not None:
        store.backend.close()
        store.factory, store.lease = None, None


def release_after_fit(function):
    """The outer one-session runner owns final flush and explicit release."""
    @wraps(function)
    def wrapped(*args, **kwargs):
        return function(*args, **kwargs)
    return wrapped


def has_commit(directory):
    return get_store(directory).pointer() is not None


def save_commit(directory, payload, *, tag):
    return get_store(directory).commit(payload)


def load_commit(directory):
    return get_store(directory).load()


def save_best(directory, payload):
    return get_store(directory).save_best(payload)


def model_bytes(directory, reference):
    return get_store(directory).read_ref(reference)
