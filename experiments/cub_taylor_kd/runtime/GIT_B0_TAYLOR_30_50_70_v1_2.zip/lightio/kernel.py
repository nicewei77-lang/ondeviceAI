"""Execute the pinned Teacher kernel with three audited operational substitutions.

The frozen loop/optimizer/data/selection remain unchanged. Explicit audited
Taylor scorer and recovery-loss callbacks implement the declared new variables.
The original package remains byte-identical and read-only.
"""
from __future__ import annotations
import types
from pathlib import Path
from .identity import sha

KERNEL_SHA = 'f31eeff4c9a3ddebf54a68c980d753292e339485317677bb53deab95e823160a'
FROZEN_CODE_ID = 'e0e0ecf60a1fe3965b5b10f16da51240fc4c90c07ba85d3edeb3a7a50ddbd8e9'

def load_kernel(*, bootstrap=None, metrics=None, branch_start=30, pause_check=None,
                pruner=None, recovery_loss=None):
    import followup_iterative_v2.training as original
    path = Path(original.__file__)
    if sha(path) != KERNEL_SHA:
        raise ValueError('Pinned frozen Teacher kernel differs')
    text = path.read_text(encoding='utf8')
    substitutions = (
        ('from .common import ', 'from lightio.common import ', 1),
        ('from .model_store import ', 'from lightio.store import ', 2),
        ("'checkpoint_policy':'per_job_3resume_3best_7anchors_v2_1'",
         "'checkpoint_policy':'cub_focus_light_io_v1'", 1),
    )
    for before, after, count in substitutions:
        if text.count(before) != count:
            raise ValueError('Audited kernel substitution count changed: '+before)
        text = text.replace(before, after)
    if bootstrap is not None:
        marker = '    if resuming:\n        saved, _ = load_commit(directory)'
        replacement = ('    if not resuming:\n'
            '        _branch_bootstrap(store, execution)\n'
            '        resuming = has_commit(directory)\n'
            + marker)
        if text.count(marker) != 1:
            raise ValueError('Tail bootstrap insertion point changed')
        text = text.replace(marker,replacement)
        marker = "            print(f'{recipe.dataset} {recipe.arm} r{recipe.target_percent} B{recipe.budget} {epoch + 1}/{recipe.budget} val={accuracy:.3f}', flush=True)"
        if text.count(marker) != 1:
            raise ValueError('Tail progress print insertion point changed')
        text = text.replace(marker,
            "            print(f'{recipe.dataset} {recipe.tail_arm} branch{epoch-_branch_start+1}/{recipe.budget-_branch_start} stream{recipe.stream_epoch(epoch)+1} val={accuracy:.3f}', flush=True)")
    if metrics is not None:
        marker = '            history.append(row)'
        if text.count(marker) != 1:
            raise ValueError('Tail validation-metric insertion point changed')
        text = text.replace(marker,
            '            row.update(_branch_metrics(logits, labels, epoch, row))\n'+marker)
        marker = '            loss_sum = 0.0'
        if text.count(marker) != 1:
            raise ValueError('Tail AMP counter insertion point changed')
        text = text.replace(marker,marker+'\n            consecutive_skips = 0')
        marker = '                    skipped += int(not finite)'
        if text.count(marker) != 1:
            raise ValueError('Tail AMP guard insertion point changed')
        text = text.replace(marker,marker+'\n'
            '                    consecutive_skips = consecutive_skips + 1 if not finite else 0\n'
            '                    if consecutive_skips > 16:\n'
            "                        raise FloatingPointError('More than16 consecutive AMP skips; HOLD')")
    if pause_check is not None:
        marker = '            if stop_after_epoch is not None and epoch + 1 >= stop_after_epoch:'
        if text.count(marker) != 1:
            raise ValueError('Completed-epoch pause insertion point changed')
        text = text.replace(marker, '            if (stop_after_epoch is not None and epoch + 1 >= stop_after_epoch) or _pause_check():')
    if pruner is not None:
        marker="'L1_records':audit"
        if text.count(marker)!=1:raise ValueError('Importance audit binding changed')
        text=text.replace(marker,"'Taylor_records':audit")
    if recovery_loss is not None:
        marker='loss = F.cross_entropy(output.float(), labels)'
        if text.count(marker)!=1:raise ValueError('Recovery objective binding changed')
        text=text.replace(marker,'loss = _recovery_loss(output.float(), labels, images, epoch)')
    marker='train_dataset.set_epoch(epoch, recipe.seed)'
    if text.count(marker)!=1:raise ValueError('Dataset stream binding changed')
    text=text.replace(marker,"train_dataset.set_epoch(recipe.stream_epoch(epoch) if hasattr(recipe,'stream_epoch') else epoch, recipe.seed)")
    module = types.ModuleType('lightio._pinned_teacher_kernel')
    module.__package__ = 'followup_iterative_v2'
    module.__file__ = str(path)
    module._branch_bootstrap = bootstrap
    module._branch_metrics = metrics
    module._branch_start = branch_start
    module._pause_check = pause_check
    exec(compile(text, str(path)+'[light_io_bindings]', 'exec'), module.__dict__)
    if pruner is not None:module.prune_stage=pruner
    module._recovery_loss=recovery_loss
    return module

def strict_verifier(recipe, native_io, factory):
    from followup_iterative_v2.model_store import ModelStore
    verifier = ModelStore.__new__(ModelStore)
    verifier.recipe = recipe
    verifier.native_io = native_io
    verifier.factory = factory
    return verifier._verify
