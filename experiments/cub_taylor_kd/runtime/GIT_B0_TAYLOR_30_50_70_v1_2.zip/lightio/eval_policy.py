"""Match Git B0 evaluation batch8; never alter training batch/accumulation."""
EVALUATION_BATCH_SIZE=8

class FixedEvaluation:
    def __init__(self,native):self.native=native
    def predict(self,model,dataset,batch_size=16,num_workers=0,device='cpu',max_batches=None):
        return self.native.predict(model,dataset,batch_size=EVALUATION_BATCH_SIZE,
            num_workers=num_workers,device=device,max_batches=max_batches)

def evaluation_native(native):
    return native if isinstance(native,FixedEvaluation) else FixedEvaluation(native)
