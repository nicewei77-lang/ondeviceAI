"""Exact-ID B0 read/verification runs only inside Colab, never on the user's PC."""
from pathlib import Path
import hashlib,json,math,os
from .identity import identity,read,sha,atomic_json

B0_ID='1xwR2mviCdrSYJ-n2eZuFbd14reVcXuiq'
VERIFIED_B0_SHA='3ceffe27b7d41a711937961e117a28d95b2d5611be4dc473969155b78620f207'
REPO_COMMIT='096e1f12185dca70c51296596499706b3378e1e7'
FIELDS='id,name,size,version,sha256Checksum,md5Checksum,mimeType,trashed'

def metadata(service):
    m=service.files().get(fileId=B0_ID,fields=FIELDS).execute()
    if m.get('id')!=B0_ID or m.get('name')!='best.pth' or m.get('trashed') or int(m.get('size',0))!=351205675 or not m.get('version'):
        raise ValueError('Exact Git B0 ID/name/size/version differs')
    return m

def same_version(a,b):
    keys=('id','name','size','version','sha256Checksum','md5Checksum')
    if any(a.get(k)!=b.get(k) for k in keys):raise ValueError('Git B0 changed during operation; HOLD')

def validate_payload(payload,models,native_io,class_names,*,fixture=False):
    """No key renaming, missing weights, classifier remapping or random fallback."""
    import torch
    if not isinstance(payload,dict) or payload.get('epoch')!=10 or len(class_names)!=(3 if fixture else 200):
        raise ValueError('B0 epoch or expected class count differs')
    names=payload.get('class_names')
    if isinstance(names,dict):
        if any(type(k) is not int for k in names) or set(names)!=set(range(len(class_names))):
            raise ValueError('B0 class mapping must have exact zero-based integer labels')
        ordered=[names[i] for i in range(len(class_names))];names_schema='zero_based_integer_dictionary'
    elif isinstance(names,list):ordered=names;names_schema='ordered_list'
    else:raise ValueError('Unsupported B0 class-name representation')
    if ordered!=list(class_names):raise ValueError('B0 class-name values/order mismatch')
    config=payload.get('config',{})
    expected={'seed':0,'epochs':20,'batch_size':8,'backbone_lr':1e-5,'head_lr':1e-4,'weight_decay':.01,'scheduler':None}
    if any(config.get(k)!=v for k,v in expected.items()):raise ValueError('B0 source training provenance differs')
    if not math.isclose(float(payload.get('validation_accuracy',-1)),1000/1200,abs_tol=1e-9):raise ValueError('B0 selected Val accuracy differs')
    if not math.isclose(float(payload.get('validation_loss',-1)),.7331,abs_tol=.00005):raise ValueError('B0 recorded selected Val CE differs')
    state=payload.get('model_state_dict')
    if not isinstance(state,dict) or not state or any(not isinstance(v,torch.Tensor) or not bool(torch.isfinite(v).all()) for v in state.values()):
        raise ValueError('B0 nonfinite/missing tensor state')
    model=models.build_test_teacher(3) if fixture else models.build_teacher('base',200,allow_random=True)
    expected_state=model.state_dict()
    if set(state)!=set(expected_state) or any(state[k].shape!=v.shape or state[k].dtype!=v.dtype for k,v in expected_state.items()):raise ValueError('B0 exact model state schema differs')
    models._check_norm_aliases(state)
    model.load_state_dict(state,strict=True)
    spec=models.model_spec(model)
    return model,{'model_spec':spec,'model_digest':native_io.model_state_identity(model.state_dict()),
        'class_names':list(class_names),'source_checkpoint_class_names_schema':names_schema,
        'class_mapping_rule':'exact integer label lookup; no class sorting or remapping',
        'checkpoint_epoch_1based':10,'source_training_config':config,
        'historical_DINO_commit':payload.get('dino_commit'),
        'historical_DINO_commit_missing':not bool(payload.get('dino_commit')),
        'restoration_DINO_commit':models.UPSTREAM_COMMIT,
        'historical_code_identity_claim':False}

def load_b0(service,cache,models,native_io,class_names,expected_sha=None):
    import torch
    cache=Path(cache).resolve()
    if os.name!='posix' or not cache.is_relative_to(Path('/content')) or cache.is_relative_to(Path('/content/drive')):
        raise ValueError('Model bytes restricted to Colab-local cache')
    from googleapiclient.http import MediaIoBaseDownload
    if expected_sha not in (None,VERIFIED_B0_SHA):raise ValueError('Only actually verified Git B0 SHA permitted')
    expected_sha=VERIFIED_B0_SHA
    cache.mkdir(parents=True,exist_ok=True);path=cache/'Git_B0_best.pth';stamp=cache/'B0_PIN.json';before=metadata(service)
    if before.get('sha256Checksum') and before['sha256Checksum']!=VERIFIED_B0_SHA:raise ValueError('Git B0 provider checksum changed')
    if path.exists():
        if not stamp.exists():raise ValueError('Unpinned B0 cache; preserve and HOLD')
        pin=read(stamp);same_version(pin['metadata'],before)
        digest=sha(path)
        if path.stat().st_size!=int(before['size']) or digest!=pin['sha256']:raise ValueError('B0 cached bytes differ')
    else:
        part=cache/'Git_B0_best.pth.part'
        if part.exists():raise ValueError('Partial prior B0 download; preserve and HOLD')
        with part.open('xb') as stream:
            downloader=MediaIoBaseDownload(stream,service.files().get_media(fileId=B0_ID),chunksize=8*1024**2)
            done=False
            while not done:_,done=downloader.next_chunk(num_retries=0)
        after=metadata(service);same_version(before,after)
        digest=sha(part)
        if part.stat().st_size!=int(before['size']) or (before.get('sha256Checksum') and digest!=before['sha256Checksum']) or (expected_sha and digest!=expected_sha):
            raise ValueError('B0 raw/provider SHA or byte-count mismatch')
        os.replace(part,path);atomic_json(stamp,{'metadata':before,'sha256':digest})
    if expected_sha and digest!=expected_sha:raise ValueError('Explicit B0 SHA mismatch')
    payload=torch.load(path,map_location='cpu',weights_only=True)
    model,evidence=validate_payload(payload,models,native_io,class_names)
    evidence.update(file_id=B0_ID,bytes=path.stat().st_size,sha256=digest,provider_metadata=before,repository_commit=REPO_COMMIT)
    same_version(before,metadata(service))
    return model,evidence

def pair_dataset(dataset):
    """Repository pair interface; internal train/val records retain image IDs."""
    class PairView:
        def __len__(self):return len(dataset)
        def __getitem__(self,i):
            image,label,_=dataset[i];return image,label
    return PairView()

def export_history(rows,offset):
    return [{'epoch':offset+r['epoch']+1,'train_loss':r['train_loss'],
        'train_accuracy':r['train_accuracy_pct']/100,'validation_loss':r['val_loss'],
        'validation_accuracy':r['val_accuracy_pct']/100,
        'seconds':r['train_seconds']+r['validation_seconds'],
        'recovery_loss_definition':'CE + .5*16*KL(B0||pruned),T4',
        'native_row':r} for r in rows]

def export_checkpoint(payload,evidence,validation,recipe):
    """Tensor-preserving export. Repository restore must apply exact pruning_spec."""
    return {'model_state_dict':payload['model_state'],'pruning_spec':{'schema':'original_index_layout.v1',
        'method':'Taylor_per_example_gate_CE_gradient_squared','target_percent':recipe.target_percent,
        'blocks':payload['layout']},'class_names':{i:n for i,n in enumerate(evidence['class_names'])},
        'class_names_ordered':list(evidence['class_names']),'num_classes':len(evidence['class_names']),
        'dino_commit':evidence['restoration_DINO_commit'],'epoch':recipe.stream_offset+payload['epoch']+1,
        'validation_accuracy':validation['val_accuracy_pct']/100,'validation_loss':validation['val_loss'],
        'config':{'pruning_recovery_recipe':__import__('dataclasses').asdict(recipe),'source_B0':evidence},
        'model_digest':payload['model_digest'],'contract_id':payload['contract_id'],
        'historical_DINO_commit':evidence['historical_DINO_commit']}

def restore_export(value,factory,native_io):
    from followup_iterative_v2.surgery import restore
    return restore(factory,value['model_state_dict'],value['pruning_spec']['blocks'],
        digest=value['model_digest'],state_identity=native_io.model_state_identity)

def prepare_baseline(service,package,sets,cfg,cache,expected_sha=None):
    """One B0 validation pass; define/freeze Hard before any Test or pruning."""
    import torch
    from phaseb.native import ROOT,module
    models,native_io,train,data_lib,metrics=(module('cub200',n) for n in ('models','io','train','data','metrics'))
    from .eval_policy import evaluation_native,EVALUATION_BATCH_SIZE
    train=evaluation_native(train)
    root=data_lib.resolve_dataset_root('cub200',sets['val'].root)
    classes=[line.split(maxsplit=1)[1] for line in (root/'classes.txt').read_text().splitlines() if line.strip()]
    dense,evidence=load_b0(service,cache,models,native_io,classes,expected_sha)
    state={k:v.detach().cpu().clone() for k,v in dense.state_dict().items()}
    def factory():
        m=models.build_from_spec(evidence['model_spec']);m.load_state_dict(state,strict=True);return m
    dense=dense.to('cuda').eval()
    logits,labels,ids=train.predict(dense,sets['val'],cfg['batch_size'],cfg['num_workers'],'cuda')
    expected=[r['image_id'] for r in sets['val'].records]
    if ids!=expected or labels.tolist()!=[r['label'] for r in sets['val'].records] or len(ids)!=1200:raise ValueError('B0 ordered Val IDs differ')
    stats=metrics.classification_metrics(logits,labels,200)
    correct=sum(int(a==b) for a,b in zip(logits.argmax(1),labels))
    if correct!=1000 or not math.isclose(stats['loss'],.7331,abs_tol=.0005):
        raise ValueError(f'B0 Val mismatch: eval_batch={EVALUATION_BATCH_SIZE}, correct={correct}/1200, OA={stats["accuracy_pct"]}, CE={stats["loss"]}; expected1000/1200 and CE.7331±.0005; HOLD')
    hard=metrics.select_hard_classes(logits,labels,classes,40,teacher_checkpoint=evidence['sha256'])
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets']['cub200']
    legacy=read(pin['hard_set']['path'])
    if identity(legacy)!=pin['hard_set']['identity']:raise ValueError('Legacy auxiliary Hard pin changed')
    hard.update(schema='github_B0_Hard40.v1',baseline_sha256=evidence['sha256'],
        old_dense_Hard_comparison='Different primary Hard set: do not directly compare old Hard numbers',
        legacy_auxiliary_class_ids=legacy['class_ids'],legacy_Hard_identity=pin['hard_set']['identity'])
    evidence.update(validation=stats,validation_ID_identity=identity(ids),hard_identity=identity(hard),
        evaluation_batch_size=EVALUATION_BATCH_SIZE,training_batch_size=cfg['batch_size'],effective_training_batch=cfg['effective_batch_size'],
        validation_logits_identity=native_io.model_state_identity({'logits':logits}),
        source_recipe_is_not_recovery_recipe=True)
    from followup_iterative_v2.surgery import dense_layout
    payload={'model_state':state,'model_digest':native_io.model_state_identity(state),'layout':dense_layout(dense)}
    source={'position':'GitHub_B0_dense','file_id':B0_ID,'reference':{k:evidence[k] for k in ('sha256','bytes','provider_metadata')},
        'source_model_digest':payload['model_digest'],'historical_exact_resume':False}
    del dense,logits;torch.cuda.empty_cache()
    print('B0_STARTUP_VERIFIED',json.dumps({'source_SHA':evidence['sha256'],'provider_version':evidence['provider_metadata']['version'],
        'model_digest':evidence['model_digest'],'class_names_schema':evidence['source_checkpoint_class_names_schema'],
        'evaluation_batch_size':EVALUATION_BATCH_SIZE,'validation_accuracy_pct':stats['accuracy_pct'],'validation_CE':stats['loss']},ensure_ascii=False),flush=True)
    return payload,source,factory,evidence,hard
