"""Explicit CUB-only science references and a separate operational contract."""
from pathlib import Path
from .identity import read, identity, sha, NAMESPACE
from .kernel import KERNEL_SHA, FROZEN_CODE_ID

OPTIONS = {
    'REMOTE_RESUME_INTERVAL_SECONDS': 900,
    'REMOTE_ON_STAGE_BOUNDARY': True,
    'REMOTE_ON_FINAL': True,
    'REMOTE_ON_PLANNED_PAUSE': True,
    'REMOTE_PROGRESS_EACH_EPOCH': True,
    'REMOTE_HISTORY_EACH_EPOCH': True,
    'LOCAL_ATOMIC_LATEST_RESUME': True,
    'LOCAL_ATOMIC_BEST': True,
    'REMOTE_RESUME_HEADS': 3,
    'REMOTE_BEST_HEADS': 3,
    'PRESERVE_MODEL_ONLY_ANCHORS': True,
    'REMOTE_FINAL_SELECTED': True,
    'VERIFY_AT_START_RESUME_FINAL': True,
    'VERIFY_FULL_RESTORE_EACH_EPOCH': False,
    'MAX_WRITERS': 1,
    'COALESCE_SIMULTANEOUS_TRIGGERS': True,
    'REMOTE_TIMER': 'monotonic_since_last_successful_durable_snapshot',
}

def source_contract():
    import followup_iterative_v2.common as common
    from followup_iterative_v2.execution import code_manifest
    manifest = code_manifest()
    if manifest['code_id'] != FROZEN_CODE_ID:
        raise ValueError('Frozen scientific source differs')
    return {'source_pins': read(common.ROOT/'assets/source_pins.json'),
            'protocol_id': sha(common.ROOT/'assets/PROTOCOL_DRAFT.md'),
            'code_id': manifest['code_id']}

def operation(recipe, config, *, run_name, code_id):
    if recipe.dataset not in ('cub200', 'fixture') or recipe.arm != 'IT' or recipe.target_percent != 30:
        raise ValueError('This package only permits CUB IT30 (or explicit CPU fixture)')
    if not run_name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in run_name):
        raise ValueError('Use a simple explicit RUN_NAME')
    value = {'namespace': NAMESPACE, 'run_name': run_name, 'code_id': code_id,
        'frozen_kernel_sha256': KERNEL_SHA, 'frozen_scientific_code_id': FROZEN_CODE_ID,
        'recipe_contract_id': recipe.contract_id, 'config': config,
        'checkpoint_options': OPTIONS,
        'scientific_changes': [],
        'operational_changes': ['local atomic checkpoint each epoch',
            'sparse remote checkpoint sets', 'startup/resume/final full verification'],
        'student_training': False, 'test_evaluation': False, 'max_sessions': 1,
        'new_runtime_allocation_by_package': False, 'additional_purchases': 0}
    return {**value, 'operational_id': identity(value)}

def verify_delivery(root):
    root = Path(root).resolve()
    manifest = read(root/'SOURCE_MANIFEST.json')
    if identity(manifest['sha256']) != manifest['code_id']:
        raise ValueError('Light I/O code identity differs')
    for name, expected in manifest['sha256'].items():
        path = (root/name).resolve()
        if not path.is_relative_to(root) or sha(path) != expected:
            raise ValueError('Light I/O source changed: '+name)
    return manifest
