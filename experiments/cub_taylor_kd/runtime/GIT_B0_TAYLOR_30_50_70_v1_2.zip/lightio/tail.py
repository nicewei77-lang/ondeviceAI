"""Same-anchor G10/R10 branches; only local LR index differs.

Original model-only anchor is validated before it is wrapped in a new branch
contract. External prefix history is provenance, never newly executed epochs.
"""
from dataclasses import dataclass,asdict
import math
import torch
from followup_iterative_v2.policy import Recipe
from followup_iterative_v2.surgery import restore,assert_stage_widths
from .identity import identity

START = 30
END = 40
ANCHOR_SHA = '71051a97e2856dd0b8bb1bce34c69d658f797cc205939778c05b8c94d4dee675'
ANCHOR_DIGEST = '9ab857c66c0c56455c9be5b04b5857b987007f5f34856b6291aa92573c517e77'
ANCHOR_CONTRACT = 'fac93e0502ba7879af0f10d8881969ab894f852f0e93c681e66fc04687546372'

@dataclass(frozen=True)
class TailRecipe(Recipe):
    tail_arm: str = 'G10'

    def __post_init__(self):
        super().__post_init__()
        if (self.tail_arm not in ('G10','R10') or self.arm!='IT' or
            self.target_percent!=30 or self.budget!=40 or
            (not self.fixture and (self.dataset!='cub200' or self.seed!=20261013))):
            raise ValueError('Only matched CUB global30..39 G10/R10 branches are permitted')

    def learning_factor(self,epoch,warmup=5):
        if not START <= epoch < END:
            raise ValueError('Tail branch may only train global epoch30..39')
        if self.tail_arm=='G10':
            return .5*(1+math.cos(math.pi*epoch/40))
        local=epoch-START
        return min(1.,(local+1)/2)*.5*(1+math.cos(math.pi*local/10))

def check_original_anchor(anchor,original_recipe,native_io,factory,*,expected_digest=ANCHOR_DIGEST):
    if (anchor.get('schema')!='iterative.stage_anchor.v2' or
        anchor.get('contract_id')!=original_recipe.contract_id or
        anchor.get('recipe')!=asdict(original_recipe) or
        anchor.get('stage')!=3 or anchor.get('code_stage_index')!=3 or
        anchor.get('anchor_j')!=4 or anchor.get('global_epoch')!=START or
        anchor.get('position')!='post' or anchor.get('model_digest')!=expected_digest or
        {'optimizer_state','scaler_state','rng_state'} & set(anchor)):
        raise ValueError('Original post30 model-only anchor/source/recipe differs')
    model=restore(factory,anchor['model_state'],anchor['layout'],digest=expected_digest,
                  state_identity=native_io.model_state_identity)
    assert_stage_widths(model,anchor['layout'],original_recipe,3)
    return model

def validate_prefix(history,original_recipe,config):
    if len(history)!=40:
        raise ValueError('Expected the frozen full40 history as the prefix source')
    prefix=history[:START]
    for epoch,row in enumerate(prefix):
        if (row.get('epoch')!=epoch or row.get('completed_epochs')!=epoch+1 or
            row.get('stage')!=original_recipe.stage(epoch) or
            row.get('epoch_seed')!=original_recipe.epoch_seed(epoch) or
            row.get('train_samples')!=4794):
            raise ValueError('Frozen source-prefix epoch/split/seed/sample coverage differs')
        wanted=original_recipe.learning_factor(epoch,config.get('warmup_epochs',5))
        if not math.isclose(row['learning_factor'],wanted,rel_tol=1e-14,abs_tol=1e-16):
            raise ValueError('Frozen source-prefix global LR differs')
    return prefix

def branch_options(arm,source_evidence):
    return {'mode':'anchor_tail','tail_arm':arm,'start_global_epoch':START,
        'end_global_epoch_exclusive':END,'source_anchor_sha256':ANCHOR_SHA,
        'required_anchor_names':['anchor_post_3.pt'],
        'source_evidence':source_evidence,'new_teacher_epochs':10,
        'new_fresh_optimizer_boundaries':1,'external_prefix_boundary_references':3,
        'exact_resume_of_historical_training':False,
        'max_epoch_AMP_skip_fraction':.25,'max_consecutive_AMP_skips':16}

def assert_matched_initializations(first,second):
    fields=('model_digest','layout_id','parameter_manifest','optimizer_class',
        'optimizer_groups','optimizer_state_entries','scaler_initial_state','prefix_history_id')
    if any(first.get(key)!=second.get(key) for key in fields):
        raise ValueError('G10/R10 starting model/optimizer/scaler/prefix differ')

def bootstrap_factory(recipe,config,native_io,factory,anchor,prefix,source_evidence):
    """Create a fresh boundary state; never import the original optimizer/RNG."""
    def bootstrap(store,execution):
        from .kernel import load_kernel
        model=restore(factory,anchor['model_state'],anchor['layout'],
            digest=anchor['model_digest'],state_identity=native_io.model_state_identity)
        assert_stage_widths(model,anchor['layout'],recipe,3)
        model=model.to(execution['runtime']['device_type'])
        native_io.seed_everything(recipe.epoch_seed(START))
        optimizer,scaler,manifest=load_kernel().fresh_optimizer(model,config,execution['runtime']['device_type'])
        if optimizer.state:
            raise ValueError('A fresh branch optimizer must have no Adam moments')
        groups=[{k:v for k,v in g.items() if k!='params'} for g in optimizer.param_groups]
        initialization={'mode':'fresh_model_only_anchor_branch','tail_arm':recipe.tail_arm,
            'global_next_epoch':START,'branch_completed_epochs':0,'source_evidence':source_evidence,
            'model_digest':anchor['model_digest'],'layout_id':identity(anchor['layout']),
            'parameter_manifest':manifest,'optimizer_class':'torch.optim.AdamW',
            'optimizer_groups':groups,'optimizer_state_entries':len(optimizer.state),
            'scaler_initial_state':scaler.state_dict(),'prefix_history_id':identity(prefix),
            'external_prefix_epochs':30,'newly_trained_epochs':0,'exact_historical_resume':False}
        # Prior pruning events belong to the immutable source, not this run.
        events=[{'boundary_id':j,'global_epoch':j*10,'source_reference_only':True,
            'executed_in_this_branch':False,'source_evidence':source_evidence} for j in range(3)]
        events.append({'boundary_id':3,'global_epoch':START,'new_branch_fresh_reset':True,
            'post_digest':anchor['model_digest'],'layout_id':identity(anchor['layout']),
            'reset_optimizer':True,'reset_scaler':True,'parameter_manifest_id':identity(manifest),
            'optimizer_state_entries_after_reset':0})
        model_anchor={**anchor,'contract_id':recipe.contract_id,'recipe':asdict(recipe),
            'source_original_anchor_sha256':ANCHOR_SHA,'new_branch_initialization':initialization}
        store.anchor('anchor_post_3.pt',model_anchor)
        payload={'schema':'iterative.teacher.v1','kind':'boundary','next_epoch':START,
            'stage':3,'contract_id':recipe.contract_id,'execution':execution,
            'model_state':model.state_dict(),'model_digest':anchor['model_digest'],
            'layout':anchor['layout'],'applied_boundaries':[0,1,2,3],
            'boundary_events':events,'optimizer_state':optimizer.state_dict(),
            'scaler_state':scaler.state_dict(),'parameter_manifest':manifest,
            'rng_state':native_io.rng_state(),'best':None,'history':prefix,
            'branch_initialization':initialization}
        store.commit(payload)
        return initialization
    return bootstrap

def metrics_factory(hard_ids):
    hard_ids=tuple(hard_ids)
    def metrics(logits,labels,epoch,row):
        from torch.nn import functional as F
        mask=torch.zeros_like(labels,dtype=torch.bool)
        for label in hard_ids:
            mask |= labels==label
        if not bool(mask.any()):
            raise ValueError('No fixed hard-class validation samples')
        predicted=logits.argmax(1)
        perclass=[100*int((predicted[labels==c]==c).sum())/int((labels==c).sum())
                  for c in hard_ids if bool((labels==c).any())]
        attempted=row['attempted_optimizer_steps']
        if attempted<1 or row['skipped_optimizer_steps']/attempted>.25:
            raise FloatingPointError('AMP skip fraction above fixed 0.25 epoch limit')
        return {'global_epoch_index':epoch,'global_epoch_one_based':epoch+1,
            'branch_completed_epochs':epoch-START+1,'branch_epoch_index':epoch-START,
            'hard_accuracy_pct':100*int((predicted[mask]==labels[mask]).sum())/int(mask.sum()),
            'hard_macro_accuracy_pct':sum(perclass)/len(perclass),
            'hard_ce':float(F.cross_entropy(logits[mask].float(),labels[mask])),
            'hard_samples':int(mask.sum()),'finite_validation_logits':True,
            'new_training_epoch':True}
    return metrics
