"""G10 then R10, one already assigned Colab L4, exactly20 new Teacher epochs."""
from pathlib import Path
from dataclasses import asdict
from datetime import datetime,timezone
import argparse
import io
import json
import os
import time
import torch
from .identity import read,identity,atomic_json,NAMESPACE
from .contracts import source_contract,verify_delivery,operation
from .lease import WriterLease,runtime_identity
from .backend import DriveBackend
from .kernel import load_kernel,strict_verifier
from .tail import (TailRecipe,branch_options,bootstrap_factory,metrics_factory,ANCHOR_SHA,
                   assert_matched_initializations)
from . import store as storage

def put_json(backend,name,value):
    return backend.put(name,json.dumps(value,ensure_ascii=False,sort_keys=True,allow_nan=False).encode())

def owned_folder(service,parent,name,contract_id):
    escaped=name.replace("'","\\'")
    result=service.files().list(q=f"'{parent}' in parents and name = '{escaped}' and trashed = false",
        fields='files(id,name,mimeType,appProperties),nextPageToken',pageSize=100).execute()
    rows=result.get('files',[])
    if len(rows)>1 or result.get('nextPageToken'):
        raise ValueError('Ambiguous new tail folder')
    tags={'lightio_namespace':NAMESPACE,'tail_sequence_contract':contract_id}
    if rows:
        row=rows[0]
        if row.get('mimeType')!='application/vnd.google-apps.folder' or row.get('appProperties')!=tags:
            raise ValueError('Refuse existing unowned tail folder')
        return row['id']
    # One create only. Unknown outcome propagates; no second-folder retry.
    return service.files().create(body={'name':name,'mimeType':'application/vnd.google-apps.folder',
        'parents':[parent],'appProperties':tags},fields='id').execute()['id']

def run(args):
    raise RuntimeError("Use lightio.sequence_runner for this two-arm delivery")
    raise RuntimeError('Session B is historical; this isolated Session A package only exposes lightio.staged_runner')
    if args.start_training is not True:
        return {'state':'START_TRAINING_FALSE','new_teacher_epochs':0,'GPU_allocations':0}
    if os.name!='posix' or not Path('/content/drive').is_dir():
        raise ValueError('Run only inside the explicitly assigned mounted Colab runtime')
    if not torch.cuda.is_available() or torch.cuda.get_device_name(0)!='NVIDIA L4':
        raise ValueError('An already allocated NVIDIA L4 is required; this code allocates none')
    import google.auth
    from googleapiclient.discovery import build
    from phaseb.native import config,module,ROOT as frozen_root
    from .tail_sources import load_sources
    from .readiness import ensure_data
    from .runner import quota_gate
    from .runtime_bootstrap import cub_runtime_bindings
    package=Path(__file__).resolve().parents[1]
    code=verify_delivery(package)
    science=source_contract()
    cfg,current_training_runtime,validate_runtime_match=cub_runtime_bindings()
    if (cfg['batch_size']!=16 or cfg['effective_batch_size']!=64 or
        cfg['teacher_weight_decay']!=.05 or cfg['teacher_seed']!=20261013):
        raise ValueError('ASTRA matched data/optimizer recipe differs')
    validate_runtime_match(read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']['baseline_execution_runtime'],
                           current_training_runtime())
    credentials,_=google.auth.default()
    service=build('drive','v3',credentials=credentials,cache_discovery=False)
    native_io,native_train=module('cub200','io'),module('cub200','train')
    anchor,prefix,evidence,source,factory=load_sources(service,science,cfg,native_io)
    plan=read(package/'assets/TAIL_PLAN_REF.json')
    sequence_body={'namespace':NAMESPACE,'kind':'same_anchor_G10_then_R10','code_id':code['code_id'],
        'plan_sha256':plan['plan_sha256'],'source_evidence':evidence,'config':cfg,
        'arms':['G10','R10'],'global_epoch_indices':list(range(30,40)),
        'new_teacher_epochs_total':20,'Student_epochs':0,'Test_calls':0,'session_count':1}
    sequence={**sequence_body,'operational_id':identity(sequence_body)}
    destination=read(package/'assets/DRIVE_DESTINATION.json')
    sequence_id=owned_folder(service,destination['runs_folder_id'],args.sequence_name,sequence['operational_id'])
    seq_backend=DriveBackend(sequence_id,sequence['operational_id'])
    local_root=Path('/content/cub_focus_light_io_v1/tails')/sequence['operational_id']
    prior_release=read(args.runtime_release_evidence) if args.runtime_release_evidence else None
    with WriterLease(local_root,seq_backend,sequence['operational_id'],resume=args.resume,
                     prior_release=prior_release) as seq_lease:
        quota_gate(seq_backend,minimum_free=12*1024**3)
        put_json(seq_backend,'OPERATIONAL_CONTRACT.json',sequence)
        put_json(seq_backend,'SOURCE_VERIFIED.json',evidence)
        started={'state':'prepared_actual_training_not_yet_started','sequence_id':sequence['operational_id'],
            'runtime_id':runtime_identity(),'pid':os.getpid(),'namespace':NAMESPACE,
            'sequence_folder_id':sequence_id,'global_next_epoch':30,'new_teacher_epochs':0,
            'started_at_utc':datetime.now(timezone.utc).isoformat(),'arms':['G10','R10'],
            'source_anchor_sha256':ANCHOR_SHA,'config_id':identity(cfg)}
        put_json(seq_backend,'RUN_STARTED.json',started)
        print('TAIL_SEQUENCE_READY',json.dumps(started,ensure_ascii=False),flush=True)
        sets,data=ensure_data(args.inputs,Path('/content/cub_focus_light_io_v1/data'),args.data_root)
        pin=read(frozen_root/'configs/readonly_inputs.json')['datasets']['cub200']
        hard=read(pin['hard_set']['path'])
        hard_ids=hard['class_ids']
        if identity(hard)!=pin['hard_set']['identity'] or len(hard_ids)!=40:
            raise ValueError('Frozen CUB Hard40 differs')
        outputs={}
        start_states={}
        try:
            for arm in ('G10','R10'):
                recipe=TailRecipe('cub200','IT',30,40,20261013,ANCHOR_SHA,
                    plan['plan_sha256'],code['code_id'],tail_arm=arm)
                base_op=operation(recipe,cfg,run_name=arm,code_id=code['code_id'])
                body={k:v for k,v in base_op.items() if k!='operational_id'}
                body.update(branch=branch_options(arm,evidence),sequence_id=sequence['operational_id'],
                    scientific_changes=['new matched branch from final30 model-only anchor',
                        'R10 uses the fixed local LR restart; G10 retains global LR'])
                op={**body,'operational_id':identity(body)}
                folder_id=owned_folder(service,sequence_id,arm,sequence['operational_id'])
                backend=DriveBackend(folder_id,op['operational_id'])
                complete=backend.get('COMPLETE.json')
                if complete:
                    if not args.resume:
                        raise ValueError('Completed tail exists; explicit RESUME is required to skip it')
                    prior=json.loads(complete)
                    pointer=json.loads(backend.get('REMOTE_COMMITTED.json'))
                    if (prior.get('operational_contract_id')!=op['operational_id'] or
                        prior.get('branch_completed_epochs')!=10 or pointer['active']['next_epoch']!=40):
                        raise ValueError('Completed tail receipt differs')
                    for ref in [pointer['active'],pointer['active']['best'],pointer['selected_teacher'],*pointer['anchors'].values()]:
                        backend.verify_ref(ref)
                    history=json.loads(backend.get('history.json'))
                    best=pointer['active']['best']
                    outputs[arm]={'selected':history[best['epoch']], 'receipt':prior,
                                  'folder_id':folder_id,'best':best,'reused_completed_branch':True}
                    start_states[arm]=json.loads(backend.get('BRANCH_START.json'))
                    backend.close()
                    continue
                directory=local_root/arm
                old_owner=backend.get('OWNER.json')
                branch_resume=args.resume and old_owner is not None
                with WriterLease(directory,backend,op['operational_id'],resume=branch_resume,
                                 prior_release=prior_release) as lease:
                    put_json(backend,'OPERATIONAL_CONTRACT.json',op)
                    start_record={**started,'tail_arm':arm,'experiment_id':recipe.contract_id,
                        'operational_id':op['operational_id'],'run_folder_id':folder_id,
                        'learning_rate_policy':arm,'branch_completed_epochs':0,'global_next_epoch':30}
                    put_json(backend,'RUN_STARTED.json',start_record)
                    storage.register(directory,backend=backend,operational_contract=op,
                        verifier=strict_verifier(recipe,native_io,factory))
                    old_start=backend.get('BRANCH_START.json')
                    if old_start:
                        start_states[arm]=json.loads(old_start)
                        if arm=='R10':
                            assert_matched_initializations(start_states['G10'],start_states['R10'])
                    def bootstrap(current,execution):
                        record=bootstrap_factory(recipe,cfg,native_io,factory,anchor,prefix,evidence)(current,execution)
                        if arm=='R10':
                            assert_matched_initializations(start_states['G10'],record)
                        put_json(backend,'BRANCH_START.json',record)
                        start_states[arm]=record
                    kernel=load_kernel(bootstrap=bootstrap,metrics=metrics_factory(hard_ids))
                    try:
                        result=kernel.fit_teacher(factory,sets['train'],sets['val'],directory,recipe,cfg,
                            native_io,native_train,lease=lease,device='cuda')
                        current=storage.get_store(directory)
                        receipt=current.finalize(state='complete')
                        if receipt['branch_completed_epochs']!=10:
                            raise ValueError('Tail did not complete exactly10 new epochs')
                        best=result['best']
                        outputs[arm]={'selected':result['history'][best['epoch']],
                            'receipt':receipt,'folder_id':folder_id,'best':best,
                            'new_fresh_optimizer_boundaries':1,'external_prefix_epochs':30}
                        put_json(backend,'RUN_RESULT.json',outputs[arm])
                        lease.finish('complete',40)
                    except KeyboardInterrupt:
                        current=storage.get_store(directory)
                        if current.pointer() is not None:
                            receipt=current.finalize(state='paused')
                            lease.finish('paused',receipt['remote_durable_epoch'])
                        raise
                    finally:
                        storage.release(directory)
                if arm=='G10':
                    torch.cuda.empty_cache()
            if set(outputs)!={'G10','R10'}:
                raise ValueError('Both matched tails must complete before comparison')
            selected={arm:value['selected'] for arm,value in outputs.items()}
            comparison={'state':'complete','sequence_id':sequence['operational_id'],
                'new_teacher_epochs':20,'global_epoch_range_one_based':[31,40],
                'selected_validation':selected,
                'R10_minus_G10_OA_pp':selected['R10']['val_accuracy_pct']-selected['G10']['val_accuracy_pct'],
                'dense_source_OA_pct':1004/1200*100,
                'delta_source_OA_pp':{arm:row['val_accuracy_pct']-1004/1200*100 for arm,row in selected.items()},
                'branch_outputs':outputs,'source_evidence':evidence,'Student_epochs':0,'Test_calls':0,
                'scope':'Single-seed validation-selected Teacher diagnostic; not Student KD or Test evidence'}
            put_json(seq_backend,'COMPARISON.json',comparison)
            put_json(seq_backend,'COMPLETE.json',comparison)
            if args.auto_release:
                put_json(seq_backend,'RELEASE_REQUEST.json',{'requested':True,'confirmed':False,
                    'method':'google.colab.runtime.unassign','sequence_id':sequence['operational_id'],
                    'runtime_id':runtime_identity(),'after_both_branches_durable':True})
            atomic_json(local_root/'COMPARISON.json',comparison)
            seq_lease.finish('complete',40)
            print('TAIL_G10_R10_BOTH_DURABLE_COMPLETE',json.dumps(comparison,ensure_ascii=False),flush=True)
        except KeyboardInterrupt:
            seq_lease.finish('paused',30)
            raise
    seq_backend.close()
    if args.auto_release:
        # A request is not a confirmed release. The coordinator checks Colab UI.
        release={'requested':True,'confirmed':False,'method':'google.colab.runtime.unassign',
                 'sequence_id':sequence['operational_id'],'runtime_id':runtime_identity()}
        atomic_json(local_root/'RELEASE_REQUEST.json',release)
        print('SELF_RUNTIME_RELEASE_REQUEST',json.dumps(release),flush=True)
        from google.colab import runtime
        runtime.unassign()
    return comparison

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start-training',action='store_true')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--sequence-name',default='cub_anchor30_G10_R10_v1')
    parser.add_argument('--inputs',default='/content/drive/MyDrive/온디바이스AI/TeacherSizeKD_NoPruning/inputs')
    parser.add_argument('--data-root')
    parser.add_argument('--runtime-release-evidence')
    parser.add_argument('--auto-release',action='store_true')
    args=parser.parse_args()
    print(json.dumps(run(args),ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
