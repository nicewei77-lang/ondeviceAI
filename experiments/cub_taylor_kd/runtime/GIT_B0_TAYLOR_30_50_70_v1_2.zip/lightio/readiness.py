"""Validate existing source evidence; never invent a new actual CUDA PASS."""
from pathlib import Path
from .identity import read, sha, identity, atomic_json

GATE_SHA = '7fc515127668ccfce563a5029b2cec1421c1cd9de240e628c52d79e57e792df7'
GATE_ID = '643a1cef5bb6230acf58b7b11af9caece593ae02094549cc14d2c8f9d8d8e30e'
FROZEN_CONTRACT = '48e7b1b31f2843cf6ac483a4160d39817c89f9ceb528e10f654888d64252fdb3'
REVIEW_SHA = 'ded7fefb80f2ed92da64a340c2e8e092e0294e564a3a6f754f7b159fb724a733'

def validate_existing_gate(gate_path, review_path, recipe, source_reference):
    from followup_iterative_v2.precision import require_candidate
    gate_path, review_path = Path(gate_path), Path(review_path)
    if sha(gate_path) != GATE_SHA or sha(review_path) != REVIEW_SHA:
        raise ValueError('Pinned historical source gate/review raw SHA differs')
    complete = read(gate_path)
    # Source aggregate COMPLETE embeds the full source gate under result in some
    # orchestration receipts. Accept only the exact expected identity.
    candidates = [complete] + [v for v in complete.values() if isinstance(v, dict)]
    matches = [v for v in candidates if identity(v) == GATE_ID]
    if len(matches) != 1:
        raise ValueError('Pinned source aggregate identity is unavailable')
    gate = matches[0]
    if gate.get('frozen_contract_id') != FROZEN_CONTRACT:
        raise ValueError('Historical source contract changed')
    selected = []
    for stage in range(4):
        rows = [r for r in gate['candidates'] if r['dataset'] == 'cub200'
            and r['candidate']['arm'] == 'IT' and r['candidate']['budget'] == recipe.budget
            and r['candidate']['target_percent'] == 30 and r['candidate']['stage'] == stage]
        if len(rows) != 1:
            raise ValueError('CUB IT30 historical stage coverage differs')
        row = rows[0]
        require_candidate(row, contract_id=FROZEN_CONTRACT, candidate=row['candidate'],
                          reference=source_reference)
        selected.append({'stage': stage, 'candidate_identity': identity(row)})
    return {'historical_source_gate_sha256': GATE_SHA, 'historical_source_gate_identity': GATE_ID,
        'historical_review_sha256': REVIEW_SHA, 'stages': selected,
        'scope': 'Revalidated pinned historical CUDA evidence; current GPU execution not yet verified'}

def ensure_data(inputs, local_root, existing_root=None):
    import sys
    import subprocess
    from phaseb.native import ROOT
    from phaseb.pipeline import context
    cfg = read(ROOT/'configs/readonly_inputs.json')['datasets']['cub200']
    local_root = Path(local_root).resolve()
    if not local_root.is_relative_to(Path('/content')) or local_root.is_relative_to(Path('/content/drive')):
        raise ValueError('CUB cache/preflight must stay on Colab local disk')
    command = [sys.executable, '-B', '-u', str(ROOT/'vendor/native_parent/tools/prepare_data.py'),
        '--dataset', 'cub200', '--inputs', str(inputs), '--cache-root', str(local_root/'raw'),
        '--work-dir', str(local_root/'preflight'), '--native-results', cfg['native_results']]
    if existing_root:
        command.extend(['--data-root', str(existing_root)])
    subprocess.run(command, check=True, cwd=ROOT)
    receipt = read(local_root/'preflight/data/cub200/B1_DATA_RECEIPT.json')
    if (receipt['split_id'] != cfg['split_id'] or not receipt['full_image_preflight_complete']
            or not receipt['exact_native_manifest_parity']):
        raise ValueError('CUB full-image parity gate differs')
    roots = {'cub200': receipt['data_root']}
    _, _, sets = context('cub200', {}, roots)
    return sets, receipt
