"""Small atomic records and source integrity for the separate CUB namespace."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import uuid
import time

NAMESPACE = 'cub_git_b0_taylor_v1_2'

def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode('utf8')).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024**2), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with tmp.open('w', encoding='utf8', newline='\n') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(tmp,path)
                break
            except PermissionError as error:
                if getattr(error,'winerror',None) not in (5,32,33) or attempt==5:
                    raise
                time.sleep(.05*(attempt+1))
    finally:
        tmp.unlink(missing_ok=True)

def immutable_json(path, value):
    path = Path(path)
    if path.exists():
        if read(path) != value:
            raise ValueError('Immutable record differs: '+str(path))
    else:
        atomic_json(path, value)
