"""Storage bindings for the unchanged Teacher computation kernel."""
from .identity import atomic_json, immutable_json, identity, sha
from .store import has_commit, save_commit, load_commit, save_best, model_bytes
