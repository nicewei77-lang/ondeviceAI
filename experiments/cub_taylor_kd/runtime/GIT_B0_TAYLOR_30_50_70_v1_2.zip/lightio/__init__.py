"""Sparse durable checkpoints; no training runs at import time."""
"""Bind only this package's vendored scientific modules for cold CLI imports."""
from pathlib import Path
import sys
_vendor=Path(__file__).resolve().parents[1]/'vendor_base'
if _vendor.is_dir() and str(_vendor) not in sys.path:
    sys.path.insert(0,str(_vendor))
