"""Same-budget CE vs CE + 0.5*T² KL(dense||pruned), T=4."""
import torch
from torch.nn import functional as F

def ce_kl(student_logits,labels,teacher_logits=None,*,temperature=4.,weight=.5):
    ce=F.cross_entropy(student_logits.float(),labels)
    if teacher_logits is None:return ce,ce,ce.detach()*0
    if not bool(torch.isfinite(teacher_logits).all()):raise FloatingPointError('Nonfinite dense Teacher logits')
    if student_logits.shape!=teacher_logits.shape:raise ValueError('Teacher/student class shape differs')
    T=temperature
    kl=F.kl_div(F.log_softmax(student_logits.float()/T,dim=1),
        F.softmax(teacher_logits.detach().float()/T,dim=1),reduction='batchmean')*(T*T)
    total=ce+weight*kl
    if not bool(torch.isfinite(total)):raise FloatingPointError('Nonfinite CE+KL loss')
    return total,ce,kl

class RecoveryLoss:
    def __init__(self,teacher=None):
        self.teacher=teacher;self.rows={};self.teacher_forward_samples=0
        if teacher is not None:
            teacher.eval()
            for p in teacher.parameters():p.requires_grad_(False)
    def __call__(self,student,labels,images,epoch):
        with torch.autocast(device_type=images.device.type,enabled=False):
            target=None
            if self.teacher is not None:
                with torch.no_grad():target=self.teacher(images.float()).float()
                self.teacher_forward_samples+=len(labels)
            total,ce,kl=ce_kl(student,labels,target)
        r=self.rows.setdefault(epoch,{'samples':0,'CE_sum':0.,'KL_T2_sum':0.})
        r['samples']+=len(labels);r['CE_sum']+=float(ce.detach())*len(labels)
        r['KL_T2_sum']+=float(kl.detach())*len(labels)
        return total
    def enrich(self,row,epoch):
        r=self.rows.pop(epoch)
        if r['samples']!=row['train_samples']:raise ValueError('Loss-component sample accounting differs')
        return {'train_CE':r['CE_sum']/r['samples'],'train_KL_T2':r['KL_T2_sum']/r['samples'],
            'recovery_objective':'CE' if self.teacher is None else 'CE+0.5*T²KL(dense||pruned)',
            'KD_temperature':4.,'KD_weight':0. if self.teacher is None else .5,
            'dense_teacher_optimizer_steps':0,'dense_teacher_precision':'FP32,no_grad,eval'}
