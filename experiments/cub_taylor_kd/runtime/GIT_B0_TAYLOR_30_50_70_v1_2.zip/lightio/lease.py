"""One assigned writer, with local OS locking and explicit remote ownership.

An unclean runtime loss does not authorize cross-runtime takeover. A new runtime
may resume a clean PAUSED writer or an explicitly provided release receipt.
"""
from __future__ import annotations
from pathlib import Path
import json
import os
import platform
import uuid
from .identity import atomic_json, read, identity, NAMESPACE

def runtime_identity():
    boot = Path('/proc/sys/kernel/random/boot_id')
    return 'runtime-'+identity({'host': platform.node(), 'boot': boot.read_text().strip()
        if boot.exists() else str(__import__('psutil').boot_time())})

class WriterLease:
    def __init__(self, directory, backend, operational_id, *, runtime_id=None,
                 resume=False, prior_release=None):
        self.directory = Path(directory).resolve()
        self.backend = backend
        self.operational_id = operational_id
        self.runtime_id = runtime_id or runtime_identity()
        self.token = uuid.uuid4().hex
        self.handle = None
        self.resume = resume
        self.prior_release = prior_release
        self.record = None

    def __enter__(self):
        self.directory.mkdir(parents=True, exist_ok=True)
        self.handle = (self.directory/'WRITER.lock').open('a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                self.handle.seek(0)
                if self.handle.read(1) == b'':
                    self.handle.write(b'0'); self.handle.flush()
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as error:
            self.handle.close(); self.handle = None
            raise RuntimeError('Duplicate local writer; HOLD') from error
        try:
            raw = self.backend.get('OWNER.json')
            prior = json.loads(raw) if raw else None
            if prior:
                if prior.get('operational_id') != self.operational_id:
                    raise ValueError('Remote writer contract differs')
                if not self.resume:
                    raise ValueError('Existing remote run requires explicit RESUME=True')
                if prior.get('state') == 'complete':
                    raise ValueError('Completed run is read-only; choose a new RUN_NAME')
                if prior.get('runtime_id') != self.runtime_id and prior.get('state') != 'paused':
                    release = self.prior_release
                    if not (isinstance(release, dict) and release.get('old_runtime_confirmed_absent') is True
                            and release.get('old_owner_identity') == identity(prior)
                            and release.get('operational_id') == self.operational_id):
                        raise ValueError('Unclean remote writer needs explicit matching runtime-release evidence')
            elif self.resume:
                raise ValueError('RESUME requested but no remote ownership record exists')
            self.record = {'namespace': NAMESPACE, 'operational_id': self.operational_id,
                'runtime_id': self.runtime_id, 'writer_token': self.token, 'state': 'active',
                'pid': os.getpid(), 'prior_owner_identity': identity(prior) if prior else None}
            self.backend.create_owner(self.record,self,expected_prior=prior)
            observed = json.loads(self.backend.get('OWNER.json'))
            if observed != self.record:
                raise RuntimeError('Remote owner changed during acquisition; HOLD')
            atomic_json(self.directory/'OWNER.json', self.record)
            return self
        except BaseException:
            self._unlock()
            raise

    def assert_active(self):
        if self.handle is None or self.record is None or self.record['state'] != 'active':
            raise RuntimeError('Writer lease is not active')
        if read(self.directory/'OWNER.json') != self.record:
            raise RuntimeError('Local owner changed; HOLD')
        remote = self.backend.get('OWNER.json')
        if remote is None or json.loads(remote) != self.record:
            raise RuntimeError('Remote owner changed; HOLD')

    def assert_output_path(self, path):
        self.assert_active()
        if not Path(path).resolve().is_relative_to(self.directory):
            raise ValueError('Output escapes the new run directory')

    def finish(self, state, durable_epoch):
        self.assert_active()
        if state not in ('paused', 'complete'):
            raise ValueError('Only verified pause/completion releases a writer')
        record = {**self.record, 'state': state, 'remote_durable_epoch': durable_epoch}
        self.backend.put('OWNER.json', json.dumps(record, sort_keys=True).encode())
        self.record = record
        atomic_json(self.directory/'OWNER.json', record)

    def _unlock(self):
        if self.handle is not None:
            if os.name == 'nt':
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close(); self.handle = None

    def __exit__(self, *exc):
        self._unlock()
