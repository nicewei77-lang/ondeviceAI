"""Targeted Colab-only reads of the frozen anchor and small source-prefix evidence."""
from pathlib import Path
from dataclasses import asdict
import hashlib
import io
import json
import os
import torch
from .identity import identity
from .tail import ANCHOR_SHA,ANCHOR_DIGEST,ANCHOR_CONTRACT,check_original_anchor,validate_prefix

FOLDER='1BWAe7JvDL5NByXfjqywDjtpfiz-ToDVH'
REFS={
    'anchor':('1gpXLSv4U8nnsRqKydsOCitnmnrEvuJ93','anchor_post_3.pt',ANCHOR_SHA,250825999),
    'ledger':('1OP14AoVeoapEhp2KW0ELRHfK5EycFyUP','ANCHORS.json',
              '1ebc7977869cfe8a55722a297a7e62d8ac2f6ba7579f8452cd6e856ddcd9cf8a',4439),
    'history':('1hI1Bao7ia3ohLqI01jgs7MkQxKKdG7wD','history.json',
              '1f11c5c2803f5a17405fd16e7723287d6baa087f66120ccc23e862a82af6ac04',111398),
    'complete':('1VAgGKi4F_hAJIvkjgug-1dQ9zOCDDKep','COMPLETE.json',
              'c5b2b2bc442dc524aab729f6d49347075d4e475942439feff5fde6ce66294099',15096),
    'boundary_audit':('19v8qtRVmk6H1LL9tYX7czrWQKNOhDEks','BOUNDARY_03_AUDIT.json',None,2965077),
    'boundary_transaction':('18U-prtvbEWayug66pt5Q3PXWi__7nz7j','TRANSACTION_0033.json',None,1855),
}

def fetch(service,file_id,*,name,size=None,sha256=None,parent=None,cap=16*1024**2):
    from googleapiclient.http import MediaIoBaseDownload
    meta=service.files().get(fileId=file_id,fields='id,name,size,sha256Checksum,parents').execute()
    actual_size=int(meta.get('size',-1))
    if (meta['id']!=file_id or meta.get('name')!=name or actual_size<0 or actual_size>cap or
        (size is not None and actual_size!=size) or
        (parent is not None and meta.get('parents')!=[parent])):
        raise ValueError('Exact source file metadata differs: '+name)
    stream=io.BytesIO()
    request=MediaIoBaseDownload(stream,service.files().get_media(fileId=file_id),chunksize=8*1024**2)
    done=False
    while not done:
        _,done=request.next_chunk(num_retries=0)
    raw=stream.getvalue()
    digest=hashlib.sha256(raw).hexdigest()
    if len(raw)!=actual_size or (sha256 and digest!=sha256) or (meta.get('sha256Checksum') and digest!=meta['sha256Checksum']):
        raise ValueError('Source raw SHA/size differs: '+name)
    return raw,{'file_id':file_id,'name':name,'bytes':len(raw),'sha256':digest}

def load_sources(service,science,config,native_io):
    if os.name!='posix' or not Path('/content/drive').is_dir():
        raise ValueError('Actual source model reads are restricted to the mounted Colab runtime')
    from followup_iterative_v2.policy import Recipe
    from followup_iterative_v2.pipeline import dense_source
    original=Recipe('cub200','IT',30,40,20261013,
        identity(science['source_pins']['datasets']['cub200']['source_reference']),
        science['protocol_id'],science['code_id'])
    if original.contract_id!=ANCHOR_CONTRACT:
        raise ValueError('Original IT30 B40 source recipe differs')
    raws,refs={},{}
    for key,(fid,name,wanted,size) in REFS.items():
        raw,ref=fetch(service,fid,name=name,size=size,sha256=wanted,parent=FOLDER,
                      cap=300*1024**2 if key=='anchor' else 4*1024**2)
        raws[key],refs[key]=raw,ref
    ledger,history,complete,audit,transaction=(json.loads(raws[k]) for k in
        ('ledger','history','complete','boundary_audit','boundary_transaction'))
    anchor=torch.load(io.BytesIO(raws['anchor']),map_location='cpu',weights_only=True)
    reference=ledger.get('anchor_post_3.pt',{})
    if (reference.get('sha256')!=ANCHOR_SHA or reference.get('model_digest')!=ANCHOR_DIGEST or
        reference.get('file_id')!=REFS['anchor'][0] or reference.get('contract_id')!=ANCHOR_CONTRACT or
        complete.get('completed_epochs')!=40 or complete.get('state')!='complete' or
        audit.get('global_epoch')!=30 or audit.get('code_stage_index')!=3 or
        audit.get('post_anchor',{}).get('sha256')!=ANCHOR_SHA or
        audit.get('post_anchor',{}).get('model_digest')!=ANCHOR_DIGEST or
        audit.get('pre_anchor',{}).get('sha256')!=ledger['anchor_pre_3.pt']['sha256']):
        raise ValueError('Anchor/source-prefix/boundary audit link differs')
    # This is a newly matched branch. The small boundary transaction is retained
    # as provenance; no original optimizer head is imported as an exact resume.
    prefix=validate_prefix(history,original,config)
    source,factory=dense_source('cub200',science)
    rebuilt=check_original_anchor(anchor,original,native_io,factory)
    del rebuilt,raws
    evidence={'schema':'cub.anchor_tail.sources.v1','refs':refs,
        'source_original_recipe':asdict(original),'source_original_contract_id':ANCHOR_CONTRACT,
        'source_anchor_model_digest':ANCHOR_DIGEST,'source_anchor_layout_id':identity(anchor['layout']),
        'source_prefix_history_id':identity(prefix),'source_prefix_epochs':30,
        'source_boundary_transaction_identity':identity(transaction),
        'dense_source_reference':source.reference,'original_seven_anchor_ledger':ledger,
        'boundary_audit_hash_observed_and_frozen_before_training':True,
        'historical_exact_resume_claim':False,'PC_model_downloads':0}
    return anchor,prefix,evidence,source,factory
