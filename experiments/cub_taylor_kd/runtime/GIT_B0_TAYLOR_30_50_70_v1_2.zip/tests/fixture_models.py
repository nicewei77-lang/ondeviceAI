import torch
from torch import nn
from torch.utils.data import Dataset
class Block(nn.Module):
    def __init__(self):
        super().__init__();self.pwconv1=nn.Linear(4,16);self.pwconv2=nn.Linear(16,4)
    def forward(self,x):return x+self.pwconv2(torch.nn.functional.gelu(self.pwconv1(x)))
class Model(nn.Module):
    def __init__(self):
        super().__init__();self.stages=nn.ModuleList([nn.Sequential(Block(),Block())]);self.head=nn.Linear(4,3)
    def forward(self,x):
        for stage in self.stages:x=stage(x)
        return self.head(x)
class CalData(Dataset):
    def __init__(self):
        self.images=torch.randn(7,4,generator=torch.Generator().manual_seed(5));self.records=[{'image_id':i,'label':i%3} for i in range(7)];self.epoch=0;self.seed=0
    def set_epoch(self,epoch,seed):self.epoch,self.seed=epoch,seed
    def __len__(self):return 7
    def __getitem__(self,i):return self.images[i],i%3,i
CFG={'batch_size':3,'effective_batch_size':6,'num_workers':0,'teacher_weight_decay':.01,'amp':False,'warmup_epochs':5,'num_classes':3}
