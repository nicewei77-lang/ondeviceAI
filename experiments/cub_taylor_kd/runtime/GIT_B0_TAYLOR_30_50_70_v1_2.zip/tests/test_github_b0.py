"""Changed baseline schema, 40+20+20 schedules, export and cold-resume only."""
from pathlib import Path
from dataclasses import asdict
import contextlib,copy,io,sys,tempfile,unittest
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'vendor_base'),str(ROOT/'tests')]
from fixture_models import Model,CFG,CalData
from phaseb.native import module
from followup_iterative_v2.surgery import dense_layout
from lightio.extension import ExtensionRecipe,branch_options,bootstrap_factory,metrics_factory
from lightio.taylor import TaylorCalibrator
from lightio.recovery_loss import RecoveryLoss
from lightio.backend import LocalBackend
from lightio.kernel import load_kernel,strict_verifier
from lightio.identity import identity
from lightio.github_source import validate_payload,export_checkpoint,restore_export,export_history,same_version
from lightio import store
torch.set_num_threads(1)
def factory():torch.manual_seed(42);return Model()

class Focused(unittest.TestCase):
    def test_eval_batch8_path_keeps_train16_accum64(self):
        from lightio.eval_policy import evaluation_native
        native_io,native_train=module('cub200','io'),module('cub200','train')
        cfg={**CFG,'batch_size':16,'effective_batch_size':64,'evaluation_batch_size':8}
        requests=[]
        class Spy:
            def predict(self,model,dataset,batch_size=16,num_workers=0,device='cpu',max_batches=None):
                requests.append((batch_size,num_workers,device,max_batches))
                return native_train.predict(model,dataset,batch_size,num_workers,device,max_batches=max_batches)
        proxy=evaluation_native(Spy())
        recipe=ExtensionRecipe('fixture','IT',30,40,42,'a'*64,'b'*64,'c'*64,fixture=True,start_percent=0,stream_offset=0,tail_arm='TAYLOR_CEKL_TO30')
        scratch=ROOT/'codex_ws/fixtures';scratch.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            root=Path(tmp);directory=root/'worker';m=factory()
            payload={'model_state':copy.deepcopy(m.state_dict()),'model_digest':native_io.model_state_identity(m.state_dict()),'layout':dense_layout(m)}
            body={'namespace':'cub_git_b0_taylor_v1_2','branch':branch_options({'fixture':True},40),'recipe':asdict(recipe)}
            op={**body,'operational_id':identity(body)};backend=LocalBackend(root/'remote',op['operational_id'])
            objective=RecoveryLoss(factory());cal=TaylorCalibrator(CalData(),native_io,3,directory=directory,fixture=True)
            store.register(directory,backend=backend,operational_contract=op,verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=1)
            kernel=load_kernel(bootstrap=bootstrap_factory(recipe,cfg,native_io,factory,payload,{'fixture':True},cal.prune),metrics=metrics_factory([0,1],recipe,objective),branch_start=0,pruner=cal.prune,recovery_loss=objective)
            with contextlib.redirect_stdout(io.StringIO()):result=kernel.fit_teacher(factory,CalData(),CalData(),directory,recipe,cfg,native_io,proxy,device='cpu',stop_after_epoch=1)
            self.assertEqual(requests,[(8,0,'cpu',None)])
            self.assertEqual(result['history'][0]['train_samples'],7)
            self.assertEqual(result['history'][0]['attempted_optimizer_steps'],1)
            self.assertEqual((cfg['batch_size'],cfg['effective_batch_size']),(16,64))
            # Baseline and Test use the same immutable wrapper, including positional/keyword calls.
            proxy.predict(factory(),CalData(),batch_size=32,num_workers=0,device='cpu',max_batches=1)
            self.assertEqual(requests[-1],(8,0,'cpu',1))
            store.get_store(directory).finalize(state='paused');store.release(directory)

    def test_Test_lock_lineage_and_PC_source_read_refusal(self):
        from lightio.extend_test import validate_lineage
        from lightio.github_source import B0_ID,load_b0
        hard={'baseline_sha256':'e'*64};hid=identity(hard)
        source={'file_id':B0_ID,'position':'GitHub_B0_dense','reference':{'sha256':'e'*64}}
        report={'state':'complete','B0':{'file_id':B0_ID,'sha256':'e'*64,'hard_identity':hid},'hard_set':hard,'hard_set_id':hid,'source30':source,'targets':{}}
        for start,target,offset,budget in ((0,30,0,40),(30,50,40,20),(50,70,60,20)):
            recipe=ExtensionRecipe('fixture','IT',target,budget,42,identity(source),'b'*64,'c'*64,fixture=True,start_percent=start,stream_offset=offset,tail_arm=f'TAYLOR_CEKL_TO{target}')
            last={'file_id':f'fixture{target}','sha256':str(target)*32}
            report['targets'][str(target)]={'target_percent':target,'source':source,'recipe':asdict(recipe),'last_model':last}
            source={'position':f'last{target}','reference':last}
        validate_lineage(report)
        bad=copy.deepcopy(report);bad['hard_set']['baseline_sha256']='f'*64
        with self.assertRaises(ValueError):validate_lineage(bad)
        bad=copy.deepcopy(report);bad['targets']['50']['source']['position']='validation_best30'
        with self.assertRaises(ValueError):validate_lineage(bad)
        with self.assertRaises(ValueError):load_b0(None,ROOT/'codex_ws/source_forbidden',None,None,[])

    def test_new80_epoch_segments_export_and_cold_resume(self):
        scratch=ROOT/'codex_ws/fixtures';scratch.mkdir(parents=True,exist_ok=True)
        native_io,native_train=module('cub200','io'),module('cub200','train')
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            root=Path(tmp);m=factory();source={'model_state':copy.deepcopy(m.state_dict()),'model_digest':native_io.model_state_identity(m.state_dict()),'layout':dense_layout(m)}
            source_id=source['model_digest']
            def fit(name,start,target,offset,budget,payload,remote=None,stop=None):
                recipe=ExtensionRecipe('fixture','IT',target,budget,42,'a'*64,'b'*64,'c'*64,fixture=True,start_percent=start,stream_offset=offset,tail_arm=f'TAYLOR_CEKL_TO{target}')
                body={'namespace':'cub_git_b0_taylor_v1_2','branch':branch_options({'fixture':True},budget),'recipe':asdict(recipe)};op={**body,'operational_id':identity(body)}
                backend=remote or LocalBackend(root/(name+'_remote'),op['operational_id']);directory=root/name
                objective=RecoveryLoss(factory());cal=TaylorCalibrator(CalData(),native_io,3,directory=directory,fixture=True)
                store.register(directory,backend=backend,operational_contract=op,verifier=strict_verifier(recipe,native_io,factory),planned_stop_epoch=stop)
                kernel=load_kernel(bootstrap=bootstrap_factory(recipe,CFG,native_io,factory,payload,{'fixture':True},cal.prune),metrics=metrics_factory([0,1],recipe,objective),branch_start=0,pruner=cal.prune,recovery_loss=objective)
                with contextlib.redirect_stdout(io.StringIO()):result=kernel.fit_teacher(factory,CalData(),CalData(),directory,recipe,CFG,native_io,native_train,device='cpu',stop_after_epoch=stop)
                current=store.get_store(directory);last,_=current.load();receipt=current.finalize(state='complete' if last['next_epoch']==budget else 'paused')
                if last['next_epoch']==budget:
                    raw=backend.get('selected_teacher.pt');best=strict_verifier(recipe,native_io,factory)(raw)
                    evidence={'class_names':['a','b','c'],'restoration_DINO_commit':'fixture','historical_DINO_commit':None}
                    exported=export_checkpoint(best,evidence,result['history'][result['best']['epoch']],recipe)
                    restored=restore_export(exported,factory,native_io)
                    self.assertEqual(native_io.model_state_identity(restored.state_dict()),best['model_digest'])
                    self.assertEqual(exported['validation_accuracy'],result['history'][result['best']['epoch']]['val_accuracy_pct']/100)
                    self.assertEqual(len(export_history(result['history'],offset)),budget)
                store.release(directory);return result,last,receipt,backend,cal.calls,recipe
            full=fit('full30',0,30,0,40,source)
            part=fit('part30',0,30,0,40,source,stop=11);resumed=fit('resume30',0,30,0,40,source,remote=part[3])
            self.assertEqual(full[1]['model_digest'],resumed[1]['model_digest']);self.assertEqual(part[4]+resumed[4],[0,1,2,3])
            fifty=fit('full50',30,50,40,20,full[1]);seventy=fit('full70',50,70,60,20,fifty[1])
            self.assertEqual(sum(len(x[0]['history']) for x in (full,fifty,seventy)),80)
            for item,ratios,offset,budget in ((full,[7.5,15,22.5,30],0,40),(fifty,[35,40,45,50],40,20),(seventy,[55,60,65,70],60,20)):
                self.assertEqual(item[4],[0,1,2,3]);self.assertEqual(len(item[2]['remote_commit']['anchors']),7)
                self.assertEqual(len(item[2]['remote_commit']['calibrations']),4)
                self.assertEqual([e['global_epoch'] for e in item[1]['boundary_events']],list(range(0,budget,budget//4)))
                for e,row in enumerate(item[0]['history']):
                    self.assertEqual(row['input_stream_epoch'],offset+e);self.assertEqual(row['cumulative_hidden_removal_percent'],ratios[e//(budget//4)])
                self.assertGreaterEqual(item[0]['best']['epoch'],budget*3//4)
            self.assertEqual(native_io.model_state_identity(source['model_state']),source_id)
        for k in list(store._STORES):store.release(k)

    def test_B0_schema_class_order_and_version_fail_closed(self):
        models,native_io=module('cub200','models'),module('cub200','io')
        m=models.build_test_teacher(3)
        p={'model_state_dict':m.state_dict(),'epoch':10,'class_names':['a','b','c'],
            'validation_accuracy':1000/1200,'validation_loss':.7331,
            'config':{'seed':0,'epochs':20,'batch_size':8,'backbone_lr':1e-5,'head_lr':1e-4,'weight_decay':.01,'scheduler':None}}
        model,proof=validate_payload(p,models,native_io,['a','b','c'],fixture=True)
        self.assertEqual(native_io.model_state_identity(model.state_dict()),proof['model_digest'])
        mapped=copy.deepcopy(p);mapped['class_names']={0:'a',1:'b',2:'c'}
        mapped_model,mapped_proof=validate_payload(mapped,models,native_io,['a','b','c'],fixture=True)
        self.assertEqual(mapped_proof['model_digest'],proof['model_digest'])
        self.assertEqual(mapped_proof['source_checkpoint_class_names_schema'],'zero_based_integer_dictionary')
        from followup_iterative_v2.surgery import dense_layout
        model_only={'model_state':m.state_dict(),'layout':dense_layout(m),'model_digest':proof['model_digest'],'contract_id':'a'*64,'epoch':39}
        recipe=ExtensionRecipe('fixture','IT',30,40,42,'a'*64,'b'*64,'c'*64,fixture=True,start_percent=0,stream_offset=0,tail_arm='TAYLOR_CEKL_TO30')
        exported=export_checkpoint(model_only,mapped_proof,{'val_accuracy_pct':50,'val_loss':1.},recipe)
        self.assertEqual(exported['class_names'],{0:'a',1:'b',2:'c'})
        self.assertEqual(native_io.model_state_identity(restore_export(exported,lambda:models.build_test_teacher(3),native_io).state_dict()),proof['model_digest'])
        for names in ({0:'b',1:'a',2:'c'},{1:'a',2:'b',3:'c'},{'0':'a','1':'b','2':'c'}):
            bad=copy.deepcopy(p);bad['class_names']=names
            with self.assertRaises(ValueError):validate_payload(bad,models,native_io,['a','b','c'],fixture=True)
        with self.assertRaises(ValueError):validate_payload(p,models,native_io,['b','a','c'],fixture=True)
        wrong=copy.deepcopy(p);wrong['model_state_dict']['head.weight'][0,0]=float('inf')
        with self.assertRaises(ValueError):validate_payload(wrong,models,native_io,['a','b','c'],fixture=True)
        with self.assertRaises(ValueError):same_version({'id':'x','version':'1'},{'id':'x','version':'2'})
        from lightio.extend_test import evaluate
        with self.assertRaises(ValueError):evaluate({'state':'paused','targets':{}},None,None,inputs='unused')

if __name__=='__main__':unittest.main()
