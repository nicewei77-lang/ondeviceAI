"""CLI shim; all model operations remain in the frozen phaseb pipeline."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from phaseb.cli import main


if __name__ == '__main__':
    raise SystemExit(main())
