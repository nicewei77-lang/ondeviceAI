"""00-stage CPU source verification only. There is no training/launch command."""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import os
import sys

os.environ['CUDA_VISIBLE_DEVICES']=''
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from phaseb.io import read,write,verify_code,identity,sha
from phaseb.contracts import output_root,build_contract

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work-dir',required=True)
    p.add_argument('--plan-only',action='store_true')
    a=p.parse_args();code=verify_code(ROOT);work=output_root(a.work_dir)
    inputs=read(ROOT/'configs/readonly_inputs.json')
    if a.plan_only:
        print('PLAN_ONLY_NO_MODEL_READ_NO_TRAINING',code)
        for d,pin in inputs['datasets'].items():print(d,pin['base_reference']['path'],pin['base_reference']['model_digest'])
        return
    import torch
    torch.set_num_threads(2)
    if torch.cuda.is_initialized():raise RuntimeError('Run 00 on a fresh CPU kernel; GPU initialization already observed')
    from phaseb.sources import inspect_sources
    print('SOURCE_PREFLIGHT_CPU_START',flush=True)
    record=inspect_sources(work,verify_zero_output=True)
    contract=build_contract(read(ROOT/'configs/policy.json'),record,code)
    # Input/source contract only: no runtime assignment and no CUDA numerical gate yet.
    contract_path=work/'preparation/source_contract_prepared.json'
    if contract_path.exists() and read(contract_path)!=contract:raise ValueError('Prior source contract changed; preserve it and use a new version')
    if not contract_path.exists():write(contract_path,contract)
    summary={'state':'passed_source_CPU_only','at_utc':datetime.now(timezone.utc).isoformat(),'code_id':code,
             'source_contract_id':contract['contract_id'],'source_pins_sha256':sha(work/'preparation/source_pins.json'),
             'datasets':{d:{'Base_raw_sha256':r['raw_sha256'],'Base_model_digest':r['base_reference']['model_digest'],
                           'branches':r['branches'],'initial_seeds':list(r['initializations'])} for d,r in record['datasets'].items()},
             'actual_Base_checkpoints':3,'physical_prune_strict_restores':12,'Native_initializations':9,
             'GPU_model_operations':0,'CUDA_AMP_verified':False,'training_ready':False,'recovery_epochs_completed':0,
             'Student_epochs_completed':0,'state_after_this_notebook':'Await actual CUDA AMP and two-runtime ownership validation before training'}
    write(work/'preparation/SOURCE_PREFLIGHT_SUMMARY.json',summary)
    print('SOURCE_PREFLIGHT_COMPLETE_NO_TRAINING',flush=True)
    print('SUMMARY',work/'preparation/SOURCE_PREFLIGHT_SUMMARY.json',flush=True)
    print('NEXT_GATE actual CUDA AMP + runtime ownership; do not start legacy03/04',flush=True)

if __name__=='__main__':main()
