"""CPU-only receipt/checkpoint/consumer regression tests. No actual CUDA receipt is produced."""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch

import torch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from phaseb import pipeline as p
from phaseb.io import identity,read,write
from phaseb.native import module,config
from phaseb.ownership import JobKey,freeze_assignment,OwnershipGuard,current_runtime_id

class RunnerIntegrityTests(unittest.TestCase):
    def setUp(self):
        scratch=ROOT.parent/'codex_ws/runs/phaseb_integrity_fixtures'
        scratch.mkdir(parents=True,exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(prefix='phaseb_integrity_fixture_',dir=scratch)
        self.base=Path(self.tmp.name);self.work=self.base/'TeacherCompressionKD_TeamNative_Base_v1/results'
        self.cid='a'*64
        self.owner='fixture-owner-tag'
        self.grid=p.jobs()
        self.assignment=freeze_assignment(self.grid,p.partition(),frozen_contract_id=self.cid,
            source_ids={d:{'fixture':'not-real-source'} for d in p.DATASETS},output_root=self.work,
            slot_owners={'A':{'runtime_id':current_runtime_id(),'owner_token':self.owner},
                         'B':{'runtime_id':'fixture-other-boot','owner_token':'fixture-B'}},
            local_lock_root=self.base/'local-locks')
        self.guard=OwnershipGuard(self.assignment,'A',expected_contract_id=self.cid,
            expected_source_ids=self.assignment['source_ids'],expected_jobs=self.grid,
            expected_assignment_id=self.assignment['assignment_id'],local_lock_root=self.base/'local-locks',owner_token=self.owner)
        self.job=JobKey('cub200','recovery',0,config('cub200')['teacher_seed'])

    def tearDown(self):self.tmp.cleanup()

    def finish(self,job,result):
        with self.guard.claim(job) as lease:
            name='precision_gate.json' if job.dataset=='all' else ('bank_gate.json' if job.stage=='aggregate' else 'COMPLETE.json')
            write(lease.output_dir/name,result);lease.complete(result)
        return p.job_dir(self.work,self.assignment,job)

    def checkpoint(self,epoch=2):
        native_io=module('cub200','io');state={'fixture_weight':torch.tensor([1.,2.])}
        spec={'kind':'teacher','pruning_layout':[{'fixture_only':True}]}
        provenance={'initial_compact_digest':'c'*64}
        pin=read(ROOT/'configs/readonly_inputs.json')['datasets']['cub200']
        policy=read(ROOT/'configs/policy.json')
        contract={'contract_id':self.cid,'code_id':'f'*64,'policy':policy,'source_pins':{'datasets':{'cub200':{
            'split_id':pin['split_id'],'source_reference':{'fixture':'not-real-source'},'branches':[{'ratio':0.,'initial_compact_digest':'c'*64,
            'model_spec_id':identity(spec),'layout_id':identity(spec['pruning_layout'])}]}}}}
        source={'adapter_provenance':provenance,'Hard_set':pin['hard_set']}
        saved={'model_state':state,'model_digest':native_io.model_state_identity(state),'model_spec':spec,'epoch':epoch,
               'contract':p.job_contract(contract,'cub200','recovery',0.,self.job.seed,source)}
        folder=p.job_dir(self.work,self.assignment,self.job)
        # Use a real lease for creation so permanent owner fields match the production format.
        with self.guard.claim(self.job) as lease:
            native_io.checkpoint_write(lease.output_dir/'best.pt',saved)
            result={'state':'complete','job':self.job.to_dict(),'frozen_contract_id':self.cid,'completed_epochs':20,
                    'best_raw_sha256':hashlib.sha256((lease.output_dir/'best.pt').read_bytes()).hexdigest(),
                    'best_model_digest':saved['model_digest']}
            write(lease.output_dir/'COMPLETE.json',result);lease.complete(result)
        return contract,saved,folder

    def test_complete_rejects_each_permanent_owner_field(self):
        result={'state':'complete','job':self.job.to_dict(),'frozen_contract_id':self.cid,'completed_epochs':20,
                'best_raw_sha256':'b'*64,'best_model_digest':'c'*64}
        folder=self.finish(self.job,result);original=read(folder/'.owner.json')
        self.assertTrue(p.complete(self.work,self.assignment,self.job))
        for field in ('schema','generation','slot','runtime_id','owner_token_sha256','frozen_contract_id','source_ids_sha256'):
            changed=deepcopy(original);changed[field]='corrupted-fixture';write(folder/'.owner.json',changed)
            with self.subTest(field=field),self.assertRaises(ValueError):p.complete(self.work,self.assignment,self.job)
        write(folder/'.owner.json',original)

    def test_missing_completion_blocks_model_restore(self):
        with patch.object(p,'strict_restore_compact') as restore:
            with self.assertRaises(ValueError):p.recovery_model(self.work,self.assignment,{'source_pins':{}},'cub200',0.)
            restore.assert_not_called()

    def test_changed_recovered_bytes_block_before_deserialization(self):
        contract,_,folder=self.checkpoint();(folder/'best.pt').write_bytes(b'changed fixture bytes')
        with patch.object(p.torch,'load') as load,patch.object(p,'strict_restore_compact') as restore:
            with self.assertRaisesRegex(ValueError,'raw SHA'):p.recovery_model(self.work,self.assignment,contract,'cub200',0.)
            load.assert_not_called();restore.assert_not_called()

    def test_selected_epoch_outside_recovery_budget_blocks_restore(self):
        contract,_,_=self.checkpoint(epoch=400)
        with patch.object(p,'strict_restore_compact') as restore:
            with self.assertRaisesRegex(ValueError,'outside budget'):p.recovery_model(self.work,self.assignment,contract,'cub200',0.)
            restore.assert_not_called()

    def test_contract_tamper_is_rejected_even_with_updated_raw_receipt(self):
        contract,saved,folder=self.checkpoint();saved['contract']['seed']+=1
        module('cub200','io').checkpoint_write(folder/'best.pt',saved)
        result=read(folder/'COMPLETE.json');result['best_raw_sha256']=hashlib.sha256((folder/'best.pt').read_bytes()).hexdigest()
        owner=read(folder/'.owner.json');owner['completion_receipt']=result
        write(folder/'COMPLETE.json',result);write(folder/'.owner.json',owner)
        with self.assertRaisesRegex(ValueError,'independent job contract'):p.completed_checkpoint(self.work,self.assignment,contract,self.job)

    def test_valid_recovered_ref_links_the_pinned_raw_bytes(self):
        contract,saved,folder=self.checkpoint()
        actual,ref=p.completed_checkpoint(self.work,self.assignment,contract,self.job)
        self.assertEqual(actual['model_digest'],saved['model_digest'])
        self.assertEqual(ref['raw_sha256'],read(folder/'COMPLETE.json')['best_raw_sha256'])
        self.assertEqual(ref['path'],(folder/'best.pt').as_posix())

    def test_probe_then_teacher_change_blocks_fit(self):
        spec=importlib.util.spec_from_file_location('runner_precision_fixture',ROOT/'tests/test_precision.py')
        fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
        from phaseb.precision import validate_full_coverage
        gate=validate_full_coverage([fixture.synthetic_schema_receipt(d) for d in p.DATASETS],
             frozen_contract_id=fixture.synthetic_schema_receipt('cub200')['frozen_contract_id'],phase_label='source')
        before=gate['source_refs']['cub200']['0.0'];after=deepcopy(before);after['sha256']='e'*64
        fit=Mock()
        with self.assertRaises(ValueError):
            p.require_probed_teacher(gate,'cub200',0.,after)
            fit()
        fit.assert_not_called()

if __name__=='__main__':unittest.main()
