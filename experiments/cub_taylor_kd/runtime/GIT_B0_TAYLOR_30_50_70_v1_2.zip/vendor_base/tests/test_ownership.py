"""Synthetic ownership/receipt tests, including real local process contention.

These tests do not train models, access Drive, or establish GPU/accuracy evidence.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from phaseb.ownership import (
    JobKey, OwnershipError, OwnershipGuard, current_runtime_id,
    freeze_assignment, validate_assignment,
)


PROJECT = Path(__file__).resolve().parents[1]


class OwnershipTests(unittest.TestCase):
    def setUp(self):
        runs = PROJECT / "codex_ws" / "runs" / "ownership_tests"
        runs.mkdir(parents=True, exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=runs)
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source_root = self.root / "native_readonly"
        self.source_root.mkdir()
        self.source = self.source_root / "source_receipt.json"
        self.runtime_code = self.source_root / "runtime_policy.py"
        self.source.write_text('{"source":"native_base45_best_fixture"}', encoding="utf-8")
        self.runtime_code.write_text("FROZEN_RUNTIME = True\n", encoding="utf-8")
        self.jobs = [
            JobKey("cub200", "recovery", 0, 45),
            JobKey("cub200", "student", 30, 42),
            JobKey("cub200", "student", 50, 43),
            JobKey("cub200", "finalizer", None, None),
        ]
        self.partition = {job: ("B" if job == self.jobs[1] else "A") for job in self.jobs}
        self.sources = {"cub200": {"base45_best_sha256": "fixture-source-hash",
                                    "nativehard_id": "fixture-native-hard"},
                        "runtime_sha256": hashlib.sha256(self.runtime_code.read_bytes()).hexdigest()}
        self.contract_id = "fixture-frozen-contract-v1"
        self.owner_a = {"runtime_id": "fixture-runtime-A", "owner_token": "fixture-owner-token-A"}
        self.owner_b = {"runtime_id": "fixture-runtime-B", "owner_token": "fixture-owner-token-B"}
        self.assignment = self.freeze()
        self.runtime_patch = mock.patch("phaseb.ownership.current_runtime_id", return_value="fixture-runtime-A")
        self.runtime_patch.start()
        self.addCleanup(self.runtime_patch.stop)

    def freeze(self, **kwargs):
        config = {
            "frozen_contract_id": self.contract_id, "source_ids": self.sources,
            "output_root": self.root / "results", "local_lock_root": self.root / "local_locks",
            "slot_owners": {"A": self.owner_a, "B": self.owner_b},
            "readonly_roots": [self.source_root],
            "source_receipts": [{"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                                for path in (self.source, self.runtime_code)],
        }
        config.update(kwargs)
        return freeze_assignment(self.jobs, self.partition, **config)

    def validate(self, assignment=None, **kwargs):
        config = {"expected_contract_id": self.contract_id, "expected_source_ids": self.sources,
                  "expected_jobs": self.jobs,
                  "expected_assignment_id": self.assignment["assignment_id"]}
        config.update(kwargs)
        return validate_assignment(assignment or self.assignment, **config)

    def guard(self, assignment=None, slot="A", **kwargs):
        assignment = assignment or self.assignment
        config = {"expected_contract_id": self.contract_id, "expected_source_ids": self.sources,
                  "expected_jobs": self.jobs, "expected_assignment_id": assignment["assignment_id"],
                  "local_lock_root": self.root / "local_locks",
                  "owner_token": self.owner_a["owner_token"] if slot == "A" else self.owner_b["owner_token"]}
        config.update(kwargs)
        return OwnershipGuard(assignment, slot, **config)

    def rehash(self, assignment):
        payload = {name: value for name, value in assignment.items() if name != "assignment_id"}
        assignment["assignment_id"] = hashlib.sha256(json.dumps(
            payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False,
        ).encode("utf-8")).hexdigest()
        return assignment

    def test_prepared_unbound_is_valid_but_cannot_execute(self):
        prepared = self.freeze(slot_owners=None)
        self.assertEqual(prepared["state"], "prepared_not_executable")
        self.validate(prepared, expected_assignment_id=prepared["assignment_id"])
        with self.assertRaisesRegex(OwnershipError, "prepared_not_executable"):
            self.guard(prepared)
        self.assertFalse((self.root / "results").exists())

    def test_exact_grid_supports_three_datasets_four_recovery_twelve_kd_one_finalizer(self):
        jobs = []
        for dataset in ("cub200", "flowers102", "aircraft"):
            for ratio in (0, 30, 50, 70):
                jobs.append(JobKey(dataset, "recovery", ratio, 45))
                jobs.extend(JobKey(dataset, "student", ratio, seed) for seed in (42, 43, 44))
            jobs.append(JobKey(dataset, "finalizer", None, None))
        partition = {job: ("A" if job.stage == "finalizer" else ("A", "B")[index % 2])
                     for index, job in enumerate(jobs)}
        assignment = freeze_assignment(jobs, partition, frozen_contract_id=self.contract_id,
                                       source_ids=self.sources, output_root=self.root / "full_grid")
        self.assertEqual(len(assignment["jobs"]), 51)
        self.assertEqual(assignment["slots"], ["A", "B"])

    def test_duplicate_unknown_missing_and_third_slot_assignments_rejected(self):
        with self.assertRaisesRegex(OwnershipError, "duplicate job"):
            freeze_assignment(self.jobs + self.jobs[:1], self.partition,
                              frozen_contract_id=self.contract_id, source_ids=self.sources,
                              output_root=self.root / "bad")
        for partition in (
            {**self.partition, JobKey("aircraft", "recovery", 0, 45): "A"},
            {job: slot for job, slot in self.partition.items() if job != self.jobs[1]},
            {**self.partition, self.jobs[1]: "C"},
            {**self.partition, self.jobs[0].job_id: "A"},
        ):
            with self.assertRaises(OwnershipError):
                freeze_assignment(self.jobs, partition, frozen_contract_id=self.contract_id,
                                  source_ids=self.sources, output_root=self.root / "bad")

    def test_finalizer_b_and_duplicate_runtime_bindings_rejected(self):
        with self.assertRaisesRegex(OwnershipError, "finalizer must belong"):
            freeze_assignment(self.jobs, {**self.partition, self.jobs[-1]: "B"},
                              frozen_contract_id=self.contract_id, source_ids=self.sources,
                              output_root=self.root / "bad")
        with self.assertRaisesRegex(OwnershipError, "distinct OS runtimes"):
            self.freeze(slot_owners={"A": self.owner_a, "B": self.owner_a})
        with self.assertRaisesRegex(OwnershipError, "all used slots"):
            self.freeze(slot_owners={"A": self.owner_a})

    def test_contract_source_grid_and_frozen_assignment_pins_checked(self):
        for arguments in (
            {"expected_contract_id": "other-contract"},
            {"expected_source_ids": {"cub200": "changed"}},
            {"expected_jobs": self.jobs[:-1]},
            {"expected_assignment_id": "0" * 64},
        ):
            with self.assertRaises(OwnershipError):
                self.validate(**arguments)
        changed = copy.deepcopy(self.assignment)
        changed["jobs"][0]["slot"] = "B"
        self.rehash(changed)
        with self.assertRaisesRegex(OwnershipError, "identity changed"):
            self.validate(changed)

    def test_rehashed_duplicate_unknown_and_finalizer_assignment_still_rejected(self):
        mutations = []
        duplicate = copy.deepcopy(self.assignment)
        duplicate["jobs"].append(copy.deepcopy(duplicate["jobs"][0]))
        mutations.append(duplicate)
        unknown = copy.deepcopy(self.assignment)
        unknown["jobs"][0]["key"]["seed"] = 999
        mutations.append(unknown)
        wrong_finalizer = copy.deepcopy(self.assignment)
        next(record for record in wrong_finalizer["jobs"] if record["key"]["stage"] == "finalizer")["slot"] = "B"
        mutations.append(wrong_finalizer)
        for changed in mutations:
            self.rehash(changed)
            with self.assertRaises(OwnershipError):
                self.validate(changed, expected_assignment_id=changed["assignment_id"])

    def test_runtime_reset_token_slot_and_lock_cache_changes_fail_closed(self):
        with mock.patch("phaseb.ownership.current_runtime_id", return_value="a-new-runtime-after-reset"):
            with self.assertRaisesRegex(OwnershipError, "wrong OS runtime"):
                self.guard()
        with self.assertRaisesRegex(OwnershipError, "token mismatch"):
            self.guard(owner_token="different-owner-token")
        with self.assertRaisesRegex(OwnershipError, "unknown runtime slot"):
            self.guard(slot="C")
        with self.assertRaisesRegex(OwnershipError, "cache differs"):
            self.guard(local_lock_root=self.root / "different_locks")
        with self.assertRaisesRegex(OwnershipError, "transfer/generation"):
            self.freeze(generation=2)

    def test_source_receipt_and_runtime_code_mutation_block_claim(self):
        guard = self.guard()
        for path in (self.source, self.runtime_code):
            original = path.read_bytes()
            path.write_bytes(original + b"changed")
            with self.assertRaisesRegex(OwnershipError, "receipt changed"):
                with guard.claim(self.jobs[0]):
                    self.fail("source changed yet writer started")
            path.write_bytes(original)

    def test_wrong_slot_unknown_job_and_output_path_escape_rejected(self):
        guard = self.guard()
        for job in (self.jobs[1], JobKey("aircraft", "recovery", 0, 45)):
            with self.assertRaises(OwnershipError):
                with guard.claim(job):
                    self.fail("unexpected writer")
        with self.assertRaisesRegex(OwnershipError, "differs from frozen"):
            with guard.claim(self.jobs[0], output_dir=self.source_root):
                self.fail("source overwritten")
        with guard.claim(self.jobs[0]) as lease:
            self.assertIn("slot_A", lease.output_dir.parts)
            self.assertIn(self.assignment["assignment_id"], lease.output_dir.parts)
            self.assertEqual(lease.assert_output_path(lease.output_dir / "best.pt"), lease.output_dir / "best.pt")
            with self.assertRaisesRegex(OwnershipError, "escapes"):
                lease.assert_output_path(lease.output_dir / ".." / "elsewhere.pt")
        with self.assertRaisesRegex(OwnershipError, "no longer active"):
            lease.assert_active()

    def test_output_root_must_not_overlap_readonly_sources_or_shared_locks(self):
        overlap = self.freeze(output_root=self.source_root / "results")
        with self.assertRaisesRegex(OwnershipError, "read-only"):
            self.guard(overlap)
        lock_overlap = self.freeze(local_lock_root=self.root / "results" / "locks")
        with self.assertRaisesRegex(OwnershipError, "separate from shared outputs"):
            self.guard(lock_overlap, local_lock_root=self.root / "results" / "locks")
        source_locks = self.freeze(local_lock_root=self.source_root / "locks")
        with self.assertRaisesRegex(OwnershipError, "read-only"):
            self.guard(source_locks, local_lock_root=self.source_root / "locks")

    def test_same_slot_different_jobs_and_finalizer_contend(self):
        guard = self.guard()
        with guard.claim(self.jobs[0]):
            for job in (self.jobs[0], self.jobs[2], self.jobs[3]):
                with self.assertRaisesRegex(OwnershipError, "already has a local writer"):
                    with self.guard().claim(job):
                        self.fail("duplicate writer")
        with guard.claim(self.jobs[3]) as lease:
            self.assertEqual(lease.key.stage, "finalizer")

    def test_complete_refuses_repeat_and_owner_state_tampering_refuses_resume(self):
        guard = self.guard()
        with guard.claim(self.jobs[0]) as lease:
            lease.complete({"fixture": "caller-complete-only", "gpu_training": False})
        with self.assertRaisesRegex(OwnershipError, "already complete"):
            with guard.claim(self.jobs[0]):
                self.fail("completed fixture rerun")
        with guard.claim(self.jobs[2]) as lease:
            path = lease.output_dir / ".owner.json"
        owner = json.loads(path.read_text(encoding="utf-8"))
        owner["source_ids_sha256"] = "changed"
        path.write_text(json.dumps(owner), encoding="utf-8")
        with self.assertRaisesRegex(OwnershipError, "state mismatch"):
            with guard.claim(self.jobs[2]):
                self.fail("source state altered")

    def test_interrupt_then_same_runtime_resume_and_unowned_output_refusal(self):
        guard = self.guard()
        with self.assertRaisesRegex(ValueError, "synthetic interruption"):
            with guard.claim(self.jobs[0]) as lease:
                (lease.output_dir / "fixture.txt").write_text("partial", encoding="utf-8")
                raise ValueError("synthetic interruption")
        with guard.claim(self.jobs[0]) as resumed:
            self.assertEqual((resumed.output_dir / "fixture.txt").read_text(), "partial")
        orphan = (self.root / "results" / self.assignment["assignment_id"] / "slot_A" /
                  "jobs" / self.jobs[2].job_id)
        orphan.mkdir(parents=True)
        (orphan / "unknown.pt").write_bytes(b"fixture")
        with self.assertRaisesRegex(OwnershipError, "no matching writer state"):
            with guard.claim(self.jobs[2]):
                self.fail("unowned files accepted")

    def test_symlink_job_namespace_cannot_alias_another_job(self):
        guard = self.guard()
        base = self.root / "results" / self.assignment["assignment_id"] / "slot_A" / "jobs"
        target = base / self.jobs[2].job_id
        target.mkdir(parents=True)
        try:
            (base / self.jobs[0].job_id).symlink_to(target, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("local OS does not permit creating a symlink")
        with self.assertRaisesRegex(OwnershipError, "redirected by a symlink"):
            with guard.claim(self.jobs[0]):
                self.fail("job namespace alias accepted")

    def test_simulated_resolved_slot_and_job_aliases_are_rejected(self):
        # Independent of OS symlink permissions; actual symlink test stays above.
        guard = self.guard()
        slot = self.root / "results" / self.assignment["assignment_id"] / "slot_A"
        job = slot / "jobs" / self.jobs[0].job_id
        original_resolve = Path.resolve
        for redirected in (slot, job):
            def alias(path, *args, **kwargs):
                if path == redirected:
                    return self.root / "results" / self.assignment["assignment_id"] / "slot_B"
                return original_resolve(path, *args, **kwargs)
            with mock.patch.object(Path, "resolve", alias):
                with self.assertRaises(OwnershipError):
                    with guard.claim(self.jobs[0]):
                        self.fail("resolved alias accepted")

    def test_two_real_independent_processes_reject_duplicate_and_release_for_resume(self):
        # This deliberately uses actual OS runtime identity and subprocess locks.
        self.runtime_patch.stop()
        self.owner_a = {**self.owner_a, "runtime_id": current_runtime_id()}
        assignment = self.freeze()
        assignment_path = self.root / "assignment.json"
        assignment_path.write_text(json.dumps(assignment), encoding="utf-8")
        script = r'''
import json, sys
from phaseb.ownership import JobKey, OwnershipError, OwnershipGuard
assignment = json.load(open(sys.argv[1], encoding="utf-8"))
jobs = [JobKey.from_value(record["key"]) for record in assignment["jobs"]]
guard = OwnershipGuard(assignment, "A", expected_contract_id=assignment["frozen_contract_id"],
    expected_source_ids=assignment["source_ids"], expected_jobs=jobs,
    expected_assignment_id=assignment["assignment_id"],
    local_lock_root=assignment["local_lock_root"], owner_token="fixture-owner-token-A")
job = next(job for job in jobs if job.stage == sys.argv[2])
try:
    with guard.claim(job):
        print("ACQUIRED", flush=True)
        sys.stdin.readline()
except OwnershipError as exc:
    print("REFUSED: " + str(exc), flush=True)
    sys.exit(9)
'''
        environment = {**os.environ, "PYTHONPATH": str(PROJECT), "PYTHONIOENCODING": "utf-8"}
        command = [sys.executable, "-X", "utf8", "-c", script, str(assignment_path)]
        holder = subprocess.Popen(command + ["recovery"], cwd=PROJECT, env=environment,
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, text=True)
        try:
            self.assertEqual(holder.stdout.readline().strip(), "ACQUIRED")
            for stage in ("recovery", "finalizer"):
                duplicate = subprocess.run(command + [stage], input="\n", cwd=PROJECT,
                                           env=environment, capture_output=True, text=True, timeout=45)
                self.assertEqual(duplicate.returncode, 9, duplicate.stderr)
                self.assertIn("already has a local writer", duplicate.stdout)
            holder.communicate(input="\n", timeout=15)
            self.assertEqual(holder.returncode, 0)
            resumed = subprocess.run(command + ["recovery"], input="\n", cwd=PROJECT,
                                     env=environment, capture_output=True, text=True, timeout=45)
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            self.assertEqual(resumed.stdout.strip(), "ACQUIRED")
        finally:
            if holder.poll() is None:
                holder.kill()
                holder.communicate(timeout=15)


if __name__ == "__main__":
    unittest.main()
