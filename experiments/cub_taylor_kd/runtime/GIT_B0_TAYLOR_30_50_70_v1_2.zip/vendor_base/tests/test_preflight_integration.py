"""CPU-only cross-module/source-package guards; no pretrained or CUDA success claim."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from phaseb.io import read,identity
from phaseb.contracts import build_contract,require_precision_receipt

class PreflightIntegrationTests(unittest.TestCase):
    def test_missing_actual_source_is_rejected_before_freeze(self):
        policy=read(ROOT/'configs/policy.json')
        with self.assertRaises(ValueError):build_contract(policy,{'state':'pending','datasets':{}},'a'*64)

    def test_missing_cuda_evidence_is_rejected(self):
        with self.assertRaises(ValueError):require_precision_receipt({}, {'contract_id':'a'*64,'policy':{'KD_Teacher_precision':'AMP'}},'source')

    def test_real_helper_schema_maps_AMP_policy(self):
        spec=importlib.util.spec_from_file_location('preflight_precision_fixtures',ROOT/'tests/test_precision.py')
        fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
        from phaseb.precision import validate_full_coverage
        # Existing schema fixture constructs no model, no actual CUDA result file.
        import inspect
        function=fixture.synthetic_schema_receipt
        signature=inspect.signature(function)
        parameters=list(signature.parameters)
        self.assertIn('dataset',parameters)
        records=[function(d) for d in ('cub200','flowers102','aircraft')]
        contract_id=records[0]['frozen_contract_id']
        gate=validate_full_coverage(records,frozen_contract_id=contract_id,phase_label='source')
        require_precision_receipt(gate,{'contract_id':contract_id,'policy':{'KD_Teacher_precision':'AMP'}},'source')

    def test_training_modules_not_needed_for_source_import(self):
        from phaseb.sources import inspect_sources
        self.assertTrue(callable(inspect_sources))

if __name__=='__main__':unittest.main()
