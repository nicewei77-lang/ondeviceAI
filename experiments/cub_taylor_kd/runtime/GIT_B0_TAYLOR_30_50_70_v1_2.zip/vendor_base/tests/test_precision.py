"""CPU guards/schema tests only: no actual CUDA, AMP readiness or training claim."""

import ast
from copy import deepcopy
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
import warnings
from unittest.mock import Mock, patch

import torch
from torch.utils.data import DataLoader, TensorDataset


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from phaseb import precision as p

CONTRACT = "a" * 64


def config(dataset="cub200"):
    return {"dataset": dataset, "num_classes": p.DATASETS[dataset], "amp": True,
            "batch_size": 2, "effective_batch_size": 4, "num_workers": 0,
            "temperature": 4.0, "kd_alpha": .5}


def synthetic_schema_receipt(dataset="cub200", phase="source"):
    """Fabricated schema fixture; never a runtime evidence artifact."""
    rows = []
    for ratio in p.RATIOS:
        for split in p.SPLITS:
            for batch in range(3):
                for role in p.ROLES:
                    frozen = role == "teacher_frozen"
                    row = {"dataset": dataset, "ratio": ratio, "phase_label": phase, "split": split,
                           "batch_index": batch, "image_ids": [f"{split}_{2*batch}", f"{split}_{2*batch+1}"],
                           "role": role, "status": "PASS", "teacher_precision": p.PRECISION,
                           "dtype": {"input": "torch.float32", "logits": "torch.float16"},
                           "loss": None if frozen else .4, "finite_logits": True,
                           "finite_loss": None if frozen else True,
                           "finite_gradients": None if frozen else True,
                           "scale": None if frozen else 65536.0, "optimizer_steps": 0,
                           "initial_scale": None if frozen else 65536.0,
                           "overflow_count": 0, "first_overflow": None, "scale_attempts": []}
                    if frozen:
                        row["teacher_requires_grad"] = False
                        row["dtype"]["kd_target"] = "torch.float32"
                    else:
                        row["dtype"]["loss"] = "torch.float32"
                        row["scale_attempts"] = [{"attempt": 1, "scale_before": 65536.0,
                            "scale_after": 65536.0, "finite_gradients": True, "gradient_tensors": 2,
                            "nonfinite_gradient_tensors": 0, "nonfinite_gradient_values": 0,
                            "first_nonfinite_parameter": None}]
                    rows.append(row)
    return {"schema_version": 1, "kind": "phaseb_cuda_amp_readiness", "status": "PASS",
            "evidence_kind": "actual_cuda_l4_probe", "dataset": dataset, "phase_label": phase,
            "frozen_contract_id": CONTRACT, "teacher_precision": p.PRECISION, "student_precision": p.PRECISION,
            "runtime": {"device": "cuda:0", "gpu": "NVIDIA L4", "torch_cuda": "schema-fixture", "cuda_available": True},
            "config_id": "b" * 64,
            "sampling": {"seed": 42, "epoch": 0, "min_batches_per_split": 3, "train_epoch_seed": 42,
                         "same_gpu_tensor_for_all_roles": True, "batch_size": 2,
                         "effective_batch_size": 4, "num_workers": 0},
            "source_refs": {str(r): {"sha256": "c" * 64, "model_digest": "d" * 64,
                                      "test_fixture": False} for r in p.RATIOS},
            "role_rows": rows, "optimizer_steps": 0, "model_file_writes": 0}


class PrecisionGuardSchemaTests(unittest.TestCase):
    def validate(self, receipt):
        return p.validate_dataset_receipt(receipt, frozen_contract_id=CONTRACT, phase_label="source")

    def test_cpu_guard_fails_before_builders_and_dataset_access(self):
        teacher, student, train_data, val_data = Mock(), Mock(), Mock(), Mock()
        native = SimpleNamespace(**{name: Mock() for name in
            ("DataLoader", "kd_loss", "seed_everything", "rng_state", "restore_rng")})
        with patch.object(torch.cuda, "is_available", return_value=False):
            with self.assertRaises(p.PrecisionProbeError) as caught:
                p.probe_dataset_amp("cub200", config(), train_data, val_data, teacher, student, native,
                                    frozen_contract_id=CONTRACT, phase_label="source")
        self.assertEqual(caught.exception.failure_kind, "cuda_unavailable")
        teacher.assert_not_called()
        student.assert_not_called()
        native.DataLoader.assert_not_called()
        native.rng_state.assert_not_called()

    def test_non_l4_gpu_and_explicit_cpu_are_rejected(self):
        for name in ("NVIDIA L40", "NVIDIA A100-SXM4-40GB", "Tesla T4"):
            with self.subTest(name=name), patch.object(torch.cuda, "is_available", return_value=True), \
                    patch.object(torch.cuda, "get_device_name", return_value=name):
                with self.assertRaises(p.PrecisionProbeError) as caught:
                    p.require_l4_cuda()
                self.assertEqual(caught.exception.failure_kind, "gpu_mismatch")
        with self.assertRaises(p.PrecisionProbeError):
            p.require_l4_cuda("cpu")

    def test_request_rejects_amp_off_small_sampling_bad_seed_and_phase(self):
        native = SimpleNamespace(**{name: lambda *a, **k: None for name in
            ("DataLoader", "kd_loss", "seed_everything", "rng_state", "restore_rng")})
        base = dict(dataset="cub200", config=config(), native_train_module=native,
                    frozen_contract_id=CONTRACT, phase_label="source", min_batches=3, seed=42, epoch=0)
        for change in ({"config": {**config(), "amp": False}}, {"min_batches": 2}, {"seed": 99},
                       {"phase_label": "unknown"}, {"frozen_contract_id": "missing"},
                       {"config": {**config(), "effective_batch_size": 3}}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                p._validate_request(**{**base, **change})

    def test_native_loader_seed_epoch_shuffle_and_validation_order(self):
        class NativeLike(TensorDataset):
            def set_epoch(self, epoch, seed):
                self.epoch_call = (epoch, seed)
        dataset = NativeLike(torch.arange(12), torch.arange(12), torch.arange(12))
        seed_calls = []
        native = SimpleNamespace(DataLoader=DataLoader, seed_everything=seed_calls.append)
        with patch.object(torch.cuda, "is_available", return_value=False), warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="'pin_memory' argument is set as true")
            first = p._loader(dataset, "train", config(), native, 42, 2)
            second = p._loader(dataset, "train", config(), native, 42, 2)
            # DataLoader consumes a base-seed draw before RandomSampler; compare
            # two Native-equivalent loaders instead of assuming a raw randperm.
            self.assertEqual([ids.tolist() for _, _, ids in first], [ids.tolist() for _, _, ids in second])
            val = p._loader(dataset, "validation", config(), native, 42, 2)
            self.assertEqual([int(i) for _, _, ids in val for i in ids], list(range(12)))
        self.assertEqual(dataset.epoch_call, (2, 42))
        self.assertEqual(seed_calls, [42 + 2*100003, 42 + 2*100003])
        self.assertEqual(first.batch_size, config()["batch_size"])
        self.assertEqual(first.num_workers, config()["num_workers"])
        self.assertFalse(first.drop_last)

    def test_module_contains_no_step_or_file_write_calls(self):
        tree = ast.parse((PROJECT / "phaseb" / "precision.py").read_text(encoding="utf8"))
        forbidden = {"step", "save", "write_text", "write_bytes", "checkpoint_write", "json_write", "open"}
        found = [node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id
                 for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, (ast.Attribute, ast.Name))
                 and (node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id) in forbidden]
        self.assertEqual(found, [])

    def test_synthetic_schema_full_coverage_accepts_only_all_datasets(self):
        receipts = [synthetic_schema_receipt(d) for d in p.DATASETS]
        result = p.validate_full_coverage(receipts, frozen_contract_id=CONTRACT, phase_label="source")
        self.assertEqual(len(result["coverage"]), 3)
        self.assertEqual(len(result["role_rows"]), 3*4*2*3*3)
        self.assertEqual(result["optimizer_steps"], 0)
        for bad in (receipts[:2], [receipts[0], receipts[0], receipts[2]]):
            with self.assertRaises(ValueError):
                p.validate_full_coverage(bad, frozen_contract_id=CONTRACT, phase_label="source")

    def test_synthetic_schema_phase_and_contract_cannot_mix(self):
        receipt = synthetic_schema_receipt()
        for field, value in (("phase_label", "recovered"), ("frozen_contract_id", "e"*64),
                             ("teacher_precision", "fp32"), ("status", "FAIL")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.validate({**receipt, field: value})

    def test_synthetic_schema_rejects_missing_duplicate_roles_and_source_refs(self):
        receipt = synthetic_schema_receipt()
        for mutation in ("missing", "duplicate", "source", "fixture"):
            bad = deepcopy(receipt)
            if mutation == "missing":
                bad["role_rows"].pop()
            elif mutation == "duplicate":
                bad["role_rows"].append(deepcopy(bad["role_rows"][0]))
            elif mutation == "source":
                del bad["source_refs"]["0.7"]
            else:
                bad["source_refs"]["0.7"]["test_fixture"] = True
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                self.validate(bad)

    def test_synthetic_schema_boolean_ratio_and_batch_index_are_rejected(self):
        for field in ("ratio", "batch_index"):
            bad = synthetic_schema_receipt()
            bad["role_rows"][0][field] = False
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.validate(bad)

    def test_synthetic_schema_rejects_nonfinite_forward_loss_gradient_and_steps(self):
        for key, value in (("finite_logits", False), ("finite_loss", False), ("finite_gradients", False),
                           ("loss", float("nan")), ("optimizer_steps", 1), ("scale", .5)):
            bad = synthetic_schema_receipt()
            bad["role_rows"][0][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate(bad)

    def test_synthetic_schema_normal_scaler_backoff_is_distinct_and_bounded(self):
        receipt = synthetic_schema_receipt()
        row = receipt["role_rows"][0]
        first = {"attempt": 1, "scale_before": 65536.0, "scale_after": 32768.0,
                 "finite_gradients": False, "gradient_tensors": 2, "nonfinite_gradient_tensors": 1,
                 "nonfinite_gradient_values": 4, "first_nonfinite_parameter": "head.weight"}
        final = {**row["scale_attempts"][0], "attempt": 2,
                 "scale_before": 32768.0, "scale_after": 32768.0}
        row.update(scale_attempts=[first, final], first_overflow=deepcopy(first), overflow_count=1, scale=32768.0)
        self.assertTrue(self.validate(receipt))
        for field, value in (("scale_after", 65536.0), ("scale_before", 131072.0)):
            bad = deepcopy(receipt)
            bad["role_rows"][0]["scale_attempts"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.validate(bad)

    def test_synthetic_schema_rejects_image_stream_and_frozen_teacher_changes(self):
        bad = synthetic_schema_receipt()
        bad["role_rows"][2]["image_ids"] = ["different-image"]
        with self.assertRaises(ValueError):
            self.validate(bad)
        bad = synthetic_schema_receipt()
        bad["role_rows"][1]["teacher_requires_grad"] = True
        with self.assertRaises(ValueError):
            self.validate(bad)


if __name__ == "__main__":
    unittest.main()
