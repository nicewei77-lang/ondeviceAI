"""Synthetic CLI/dispatch guards only; no CUDA, Drive, model read, or training."""
import contextlib
import io
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

from phaseb import cli
from phaseb.ownership import JobKey


class CliTests(unittest.TestCase):
    def test_data_root_mapping_rejects_extra_keys_and_signed_urls(self):
        roots = {d: str(Path.cwd()) for d in cli.DATASETS}
        self.assertEqual(set(cli.data_roots(roots)), set(cli.DATASETS))
        with self.assertRaisesRegex(ValueError, 'exactly'):
            cli.data_roots({**roots, 'SAS': 'secret'})
        for invalid in ('https://blob.example/container?sig=SECRET', '/content/images?sig=SECRET',
                        '/content/images#token', 'relative/images', '/content/../images'):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                cli.data_roots({**roots, 'cub200': invalid}, require_directories=False)

    def test_parser_rejects_invalid_slot_and_missing_explicit_confirmation(self):
        for args in (
            ['worker', '--work-dir', 'unused', '--slot', 'C'],
            ['acknowledge-runtime-readiness', '--work-dir', 'unused', '--slot', 'A', '--active-sessions', '2'],
        ):
            with self.subTest(args=args), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as seen:
                cli.parser().parse_args(args)
            self.assertEqual(seen.exception.code, 2)

    def test_manual_readiness_rejects_three_sessions_and_non_coordinator_without_reading(self):
        with mock.patch.object(cli, '_execution') as execution:
            for slot, count, confirm in (('A', 3, True), ('A', 1, True), ('B', 2, True), ('A', 2, False)):
                with self.subTest(slot=slot, count=count, confirm=confirm), self.assertRaises(ValueError):
                    cli.acknowledge_runtime_readiness('unused', slot, count, {}, {}, confirm)
            execution.assert_not_called()

    def test_colab_url_rejects_query_credentials_and_other_hosts(self):
        good = 'https://colab.research.google.com/drive/notebook_A-123'
        self.assertEqual(cli._colab_url(good), good)
        for invalid in (good + '?token=secret', good + '#scrollTo=123',
                        'https://evil.example/drive/notebook',
                        'https://user:password@colab.research.google.com/drive/notebook'):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                cli._colab_url(invalid)

    def test_freeze_reuses_existing_source_pins_via_pipeline(self):
        engine = SimpleNamespace(prepare_contract=mock.Mock(return_value={'state': 'prepared'}))
        with mock.patch.object(cli, '_pipeline', return_value=engine):
            self.assertEqual(cli.freeze_source('work'), {'state': 'prepared'})
        engine.prepare_contract.assert_called_once_with('work')

    def test_runtime_registration_requires_full_local_preflight(self):
        roots = {d: str(Path.cwd()) for d in cli.DATASETS}
        engine = mock.Mock()
        with mock.patch.object(cli, 'read', return_value=roots), \
                mock.patch.object(cli, 'verify_local_preflight', side_effect=ValueError('missing full-image preflight')), \
                mock.patch.object(cli, '_pipeline', return_value=engine):
            with self.assertRaisesRegex(ValueError, 'full-image preflight'):
                cli.register_runtime('work', 'A', 'data_roots.json')
        engine.register_runtime.assert_not_called()

    def test_unknown_job_and_wrong_slot_never_call_pipeline_run(self):
        job = JobKey('cub200', 'recovery', 0, 10)
        engine = SimpleNamespace(jobs=lambda: [job], complete=mock.Mock(return_value=False), run_job=mock.Mock())
        execution = {'assignment': {'jobs': [{'job_id': job.job_id, 'slot': 'B'}]}}
        with mock.patch.object(cli, '_execution', return_value=(engine, {}, execution, {})):
            for job_id in ('unknown', job.job_id):
                with self.subTest(job_id=job_id), self.assertRaises(ValueError):
                    cli.run_job('work', 'A', job_id)
        engine.run_job.assert_not_called()

    def test_missing_contract_fails_closed_before_run(self):
        engine = SimpleNamespace(load_contract=mock.Mock(side_effect=FileNotFoundError('missing frozen contract')),
                                 run_job=mock.Mock())
        with mock.patch.object(cli, '_pipeline', return_value=engine), mock.patch.object(cli, 'output_root', return_value=Path.cwd()):
            with self.assertRaises(FileNotFoundError):
                cli.run_job('unused', 'A', 'all__aggregate__rnone__snone')
        engine.run_job.assert_not_called()

    def _worker_engine(self, *, ready=None, failure=None):
        jobs = [JobKey('all', 'aggregate', None, None),
                JobKey('cub200', 'recovery', 0, 10),
                JobKey('cub200', 'recovery', 30, 10),
                JobKey('flowers102', 'recovery', 0, 10)]
        finished = {jobs[0].job_id}
        executed = []
        def run(work, slot, job):
            if failure:
                raise failure
            executed.append(job.job_id)
            finished.add(job.job_id)
        engine = SimpleNamespace(jobs=lambda: jobs,
            complete=lambda work, assignment, job: job.job_id in finished,
            ready=mock.Mock(side_effect=ready or (lambda work, assignment, job: job != jobs[2])),
            run_job=mock.Mock(side_effect=run))
        execution = {'assignment': {'jobs': [{'job_id': job.job_id, 'slot': 'A' if i < 3 else 'B'} for i, job in enumerate(jobs)]}}
        return jobs, engine, execution, executed

    def test_worker_runs_only_own_incomplete_ready_jobs_then_yields_without_retry(self):
        jobs, engine, execution, executed = self._worker_engine()
        with mock.patch.object(cli, '_execution', return_value=(engine, {}, execution, {})):
            result = cli.worker('work', 'A')
        self.assertEqual(executed, [jobs[1].job_id])
        self.assertEqual(result['state'], 'yielded_pending_dependencies')
        self.assertEqual(result['pending_jobs'], [jobs[2].job_id])
        self.assertFalse(result['automatic_retry'])
        self.assertLessEqual(engine.ready.call_count, 3)

    def test_worker_max_jobs_bounds_dispatch(self):
        jobs, engine, execution, executed = self._worker_engine(ready=lambda *args: True)
        with mock.patch.object(cli, '_execution', return_value=(engine, {}, execution, {})):
            result = cli.worker('work', 'A', max_jobs=1)
        self.assertEqual(executed, [jobs[1].job_id])
        self.assertEqual(result['state'], 'yielded_max_jobs')
        with self.assertRaises(ValueError):
            cli.worker('unused', 'A', max_jobs=0)

    def test_worker_never_retries_pipeline_failure(self):
        _, engine, execution, _ = self._worker_engine(failure=RuntimeError('precision gate failed'))
        with mock.patch.object(cli, '_execution', return_value=(engine, {}, execution, {})), self.assertRaisesRegex(RuntimeError, 'precision gate failed'):
            cli.worker('work', 'A')
        self.assertEqual(engine.run_job.call_count, 1)

    def test_worker_requires_actual_completion_receipt_after_pipeline_returns(self):
        _, engine, execution, _ = self._worker_engine()
        engine.run_job = mock.Mock(return_value={'state': 'complete'})
        with mock.patch.object(cli, '_execution', return_value=(engine, {}, execution, {})), self.assertRaisesRegex(ValueError, 'validated completion receipt'):
            cli.worker('work', 'A')
        self.assertEqual(engine.run_job.call_count, 1)

    def test_readiness_records_only_explicit_manual_confirmation(self):
        runs = cli.ROOT / 'codex_ws/runs/cli_tests'
        runs.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=runs) as temporary:
            control = Path(temporary)
            for slot in ('A', 'B'):
                (control / ('runtime_' + slot + '.json')).write_text('{"fixture":true}', encoding='utf8')
            engine = SimpleNamespace(controls=lambda work: control)
            registrations = {slot: {'runtime_id': 'runtime-' + slot, 'runtime': {'gpu': 'fixture only'},
                                   'data_roots': {d: '/content/fixture/' + d for d in cli.DATASETS}} for slot in ('A', 'B')}
            arguments = ('unused', 'A', 2, {'A': 'runtime-A', 'B': 'runtime-B'},
                         {slot: 'https://colab.research.google.com/drive/fixture_' + slot for slot in ('A', 'B')}, True)
            with mock.patch.object(cli, '_execution', return_value=(engine, {'contract_id': 'contract', 'code_id': 'code'},
                                                                     {'assignment_id': 'assignment'}, registrations)):
                record = cli.acknowledge_runtime_readiness(*arguments)
                self.assertEqual(cli.acknowledge_runtime_readiness(*arguments), record)
            self.assertEqual(record['evidence_kind'], 'explicit_user_manual_Colab_UI_confirmation')
            self.assertEqual(record['assignment_id'], 'assignment')
            self.assertEqual(set(record['slots']), {'A', 'B'})
            self.assertFalse(record['CUDA_AMP_verified'])
            self.assertFalse(record['training_success_established'])
            self.assertNotIn('owner_token', str(record))


if __name__ == '__main__':
    unittest.main()
