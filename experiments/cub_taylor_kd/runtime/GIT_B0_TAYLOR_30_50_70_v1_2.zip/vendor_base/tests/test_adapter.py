"""CPU-only random-fixture tests for the strict Native/tckd adapter.

Run with ``python -m unittest discover -s tests -p test_adapter.py -v`` from the
new project. Set PHASEB_TCKD_ROOT and PHASEB_B1_ROOT when the existing projects
are not siblings. These checks do not validate pretrained accuracy or CUDA AMP.
"""

from copy import deepcopy
import hashlib
import importlib
import importlib.util
import os
from pathlib import Path
import sys
import tempfile
import unittest

import torch


PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))
from phaseb.adapter import load_native_source, native_to_dense_spec, strict_restore_compact


def package(name, path):
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path / "__init__.py",
                                                     submodule_search_locations=[str(path)])
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return name


TCKD_ROOT = Path(os.environ.get("PHASEB_TCKD_ROOT", PROJECT.parent / "Teacher_Compression_KD"))
B1_ROOT = Path(os.environ.get("PHASEB_B1_ROOT", PROJECT.parent / "Teacher_Size_KD_SmallGap_B1"))
TCKD = package("adapter_test_tckd", TCKD_ROOT / "tckd")
NATIVE = package("adapter_test_native", B1_ROOT / "vendor" / "official" / "nskd")
compression_models = importlib.import_module(TCKD + ".models")
compression_pruning = importlib.import_module(TCKD + ".pruning")
native_models = importlib.import_module(NATIVE + ".models")
native_io = importlib.import_module(NATIVE + ".io")


class AdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        torch.manual_seed(143)
        cls.native = native_models.build_test_teacher(num_classes=3).eval()
        cls.classes = [{"label": i, "name": f"class_{i}"} for i in range(3)]
        cls.manifest = {"dataset": "fixture", "num_classes": 3, "classes": cls.classes,
                        "train": [], "val": [], "test": []}
        cls.contract = {"schema_version": 1, "config": {"dataset": "fixture", "num_classes": 3},
                        "job": "fixture/teacher_base", "split_id": native_io.identity(cls.manifest),
                        "seed": 143, "source": {"fixture": True}, "code_id": "fixture-code"}
        cls.saved = {"model_state": deepcopy(cls.native.state_dict()),
                     "model_spec": native_models.model_spec(cls.native), "epoch": 44,
                     "contract": cls.contract,
                     "model_digest": native_io.model_state_identity(cls.native.state_dict())}

    def setUp(self):
        # All ephemeral files are in this new project's codex_ws, not system temp.
        scratch = PROJECT / "codex_ws" / "runs" / "adapter_cpu_fixture"
        scratch.mkdir(parents=True, exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=scratch)
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "best.pt"
        self.write(self.saved)

    def write(self, saved):
        torch.save(saved, self.path)
        self.sha = hashlib.sha256(self.path.read_bytes()).hexdigest()

    def source(self, **updates):
        kwargs = dict(expected_sha256=self.sha, expected_model_digest=self.saved["model_digest"],
                      expected_contract=self.contract, manifest=self.manifest,
                      expected_classes=self.classes, native_io=native_io, allow_test_fixture=True)
        kwargs.update(updates)
        return load_native_source(self.path, **kwargs)

    def branch(self, source, ratio):
        return source.prune(ratio, compression_models=compression_models,
                            compression_pruning=compression_pruning)

    def compact(self, model, spec, provenance):
        return {"model_state": deepcopy(model.state_dict()), "model_spec": spec,
                "model_digest": native_io.model_state_identity(model.state_dict()),
                "adapter_provenance": provenance}

    def restore(self, checkpoint, source, ratio, **updates):
        kwargs = dict(compression_models=compression_models, native_io=native_io,
                      expected_source=source.reference, expected_ratio=ratio,
                      expected_classes=self.classes, allow_test_fixture=True)
        kwargs.update(updates)
        return strict_restore_compact(checkpoint, **kwargs)

    def test_native_base_spec_translation_is_exact(self):
        spec = {"schema_version": 1, "kind": "teacher", "architecture": "dinov3_convnext",
                "teacher_size": "base", "num_classes": 3, "depths": [3, 3, 27, 3],
                "dims": [128, 256, 512, 1024], "upstream_commit": native_models.UPSTREAM_COMMIT,
                "test_fixture": False}
        dense = native_to_dense_spec(spec, num_classes=3)
        self.assertEqual(dense["architecture"], "dinov3_convnext_base")
        self.assertIsNone(dense["pruning_layout"])
        for field, value in [("teacher_size", "small"), ("dims", [96, 192, 384, 768]),
                             ("test_fixture", 0), ("schema_version", True), ("num_classes", True),
                             ("upstream_commit", "other")]:
            with self.subTest(field=field), self.assertRaises(ValueError):
                native_to_dense_spec({**spec, field: value}, num_classes=3)
        with self.assertRaises(ValueError):
            native_to_dense_spec({**spec, "pruning_layout": []}, num_classes=3)

    def test_fixture_requires_explicit_opt_in(self):
        with self.assertRaisesRegex(ValueError, "fixtures"):
            self.source(allow_test_fixture=False)
        source = self.source()
        self.assertTrue(source.reference["test_fixture"])

    def test_canonical_reference_path_survives_local_byte_verification(self):
        canonical = "/content/drive/MyDrive/frozen/main/fixture/teachers/base/best.pt"
        source = self.source(reference_path=canonical)
        self.assertEqual(source.reference["path"], canonical)
        _, _, provenance = self.branch(source, .3)
        self.assertEqual(provenance["source"]["path"], canonical)
        with self.assertRaises(ValueError):
            self.source(reference_path="/content/last.pt")

    def test_zero_branch_preserves_every_tensor_and_cpu_output(self):
        source = self.source()
        model, spec, provenance = self.branch(source, 0)
        self.assertEqual(native_io.model_state_identity(model.state_dict()), self.saved["model_digest"])
        for name, tensor in self.saved["model_state"].items():
            self.assertTrue(torch.equal(model.state_dict()[name], tensor), name)
        sample = torch.randn(2, 3, 32, 32)
        with torch.inference_mode():
            expected, actual = self.native(sample), model.eval()(sample)
        self.assertTrue(torch.equal(actual, expected))
        checkpoint = self.compact(model, spec, provenance)
        restored = self.restore(checkpoint, source, 0).eval()
        with torch.inference_mode():
            self.assertTrue(torch.equal(restored(sample), expected))

    def test_all_ratios_physically_reduce_and_strictly_restore(self):
        source = self.source()
        dense_count = sum(p.numel() for p in self.native.parameters())
        sample = torch.randn(1, 3, 32, 32)
        for ratio in (0, .3, .5, .7):
            with self.subTest(ratio=ratio):
                model, spec, provenance = self.branch(source, ratio)
                for entry in spec["pruning_layout"]:
                    block = model.stages[entry["stage"]][entry["block"]]
                    self.assertEqual(block.pwconv1.out_features, entry["hidden"])
                    self.assertEqual(block.pwconv2.in_features, entry["hidden"])
                    self.assertEqual(tuple(block.pwconv1.weight.shape),
                                     (entry["hidden"], entry["original_hidden"] // 4))
                    self.assertFalse(hasattr(block.pwconv1, "weight_mask"))
                    if ratio:
                        self.assertLess(entry["hidden"], entry["original_hidden"])
                if ratio:
                    self.assertLess(sum(p.numel() for p in model.parameters()), dense_count)
                restored = self.restore(self.compact(model, spec, provenance), source, ratio)
                self.assertEqual(native_io.model_state_identity(restored.state_dict()),
                                 native_io.model_state_identity(model.state_dict()))
                with torch.inference_mode():
                    self.assertTrue(torch.equal(model.eval()(sample), restored.eval()(sample)))
                self.assertEqual(provenance["source"], source.reference)
        self.assertEqual(native_io.model_state_identity(source._checkpoint["model_state"]),
                         self.saved["model_digest"])

    def test_independent_branches_reuse_original_source(self):
        source = self.source()
        a, _, _ = self.branch(source, .3)
        a.stages[0][0].pwconv1.weight.data.zero_()
        b, spec, _ = self.branch(source, .7)
        c, spec2, _ = self.branch(self.source(), .7)
        self.assertEqual(spec, spec2)
        self.assertEqual(native_io.model_state_identity(b.state_dict()),
                         native_io.model_state_identity(c.state_dict()))

    def test_source_sha_digest_contract_and_class_guards(self):
        bad_classes = deepcopy(self.classes)
        bad_classes[0]["name"], bad_classes[1]["name"] = bad_classes[1]["name"], bad_classes[0]["name"]
        for kwargs in [{"expected_sha256": "0" * 64}, {"expected_model_digest": "0" * 64},
                       {"expected_contract": {**self.contract, "seed": 999}},
                       {"expected_classes": bad_classes},
                       {"manifest": {**self.manifest, "dataset": "other"}}]:
            with self.subTest(kwargs=list(kwargs)), self.assertRaises(ValueError):
                self.source(**kwargs)
        original = self.path
        self.path = original.with_name("last.pt")
        self.path.write_bytes(original.read_bytes())
        with self.assertRaisesRegex(ValueError, "best.pt"):
            self.source()

    def test_shared_norm_conflict_fails_even_with_updated_digest(self):
        saved = deepcopy(self.saved)
        saved["model_state"]["norms.3.weight"] = saved["model_state"]["norm.weight"].clone() + 1
        saved["model_digest"] = native_io.model_state_identity(saved["model_state"])
        self.write(saved)
        with self.assertRaisesRegex(ValueError, "aliases"):
            self.source(expected_model_digest=saved["model_digest"])

    def test_in_memory_source_mutation_is_detected(self):
        source = self.source()
        source._checkpoint["model_state"]["head.weight"][0, 0] += 1
        with self.assertRaisesRegex(ValueError, "mutated"):
            self.branch(source, .3)

    def test_non_grid_and_boolean_ratios_fail(self):
        source = self.source()
        for ratio in (True, False, -.1, .1, .9, 1, float("nan")):
            with self.subTest(ratio=ratio), self.assertRaises(ValueError):
                self.branch(source, ratio)

    def test_strict_restore_guards_provenance_keys_shapes_dtype_digest(self):
        source = self.source()
        model, spec, provenance = self.branch(source, .5)
        checkpoint = self.compact(model, spec, provenance)
        for mutation in ("source", "ratio", "classes", "layout", "missing", "shape", "dtype", "digest"):
            bad = deepcopy(checkpoint)
            if mutation == "source":
                bad["adapter_provenance"]["source"]["sha256"] = "0" * 64
            elif mutation == "ratio":
                bad["adapter_provenance"]["ratio"] = .3
            elif mutation == "classes":
                bad["adapter_provenance"]["classes"][0]["name"] = "reordered"
            elif mutation == "layout":
                bad["model_spec"]["pruning_layout"][0]["hidden"] -= 1
            elif mutation == "missing":
                del bad["model_state"]["head.bias"]
            elif mutation == "shape":
                bad["model_state"]["head.weight"] = bad["model_state"]["head.weight"][:2]
            elif mutation == "dtype":
                bad["model_state"]["head.weight"] = bad["model_state"]["head.weight"].half()
            else:
                bad["model_digest"] = "0" * 64
            if mutation in {"missing", "shape", "dtype"}:
                bad["model_digest"] = native_io.model_state_identity(bad["model_state"])
            with self.subTest(mutation=mutation), self.assertRaises((ValueError, RuntimeError)):
                self.restore(bad, source, .5)

    def test_native_fit_nested_provenance_and_recovered_state_supported(self):
        source = self.source()
        model, spec, provenance = self.branch(source, .3)
        # A recovery optimizer may change parameters; current digest is separate.
        model.head.bias.data.add_(.2)
        checkpoint = self.compact(model, spec, provenance)
        del checkpoint["adapter_provenance"]
        checkpoint["contract"] = {"source": {"adapter_provenance": provenance}}
        restored = self.restore(checkpoint, source, .3)
        self.assertEqual(native_io.model_state_identity(restored.state_dict()), checkpoint["model_digest"])
        with self.assertRaisesRegex(ValueError, "fixtures"):
            self.restore(checkpoint, source, .3, allow_test_fixture=False)


if __name__ == "__main__":
    unittest.main()
