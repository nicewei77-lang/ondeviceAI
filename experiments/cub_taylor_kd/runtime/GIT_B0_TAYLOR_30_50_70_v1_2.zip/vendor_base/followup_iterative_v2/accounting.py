"""Canonical recovery wall time, with incomplete attempts preserved as HOLD."""
from datetime import datetime, timezone
from pathlib import Path
import time
import uuid
from .common import atomic_json, read

def now():
    return datetime.now(timezone.utc).isoformat()

class Attempt:
    def __init__(self, directory, profile, *, deferred=False):
        self.directory = Path(directory)
        self.profile = profile
        self.deferred = deferred
    def __enter__(self):
        if not self.deferred:
            self.start()
        return self
    def start(self):
        if hasattr(self,'started'):
            raise ValueError('Recovery attempt timer cannot restart')
        self.started = time.perf_counter_ns()
        self.path = self.directory / 'attempts' / (uuid.uuid4().hex+'.json')
        self.value = {'schema':'iterative.recovery_cost.v1','segment_id':self.path.stem,
                      'start_utc':now(),'end_utc':None,'elapsed_ns':None,'profile':self.profile,'state':'running'}
        atomic_json(self.path,self.value)
    def __exit__(self, kind, error, traceback):
        if not hasattr(self,'started'):
            return
        self.value.update(end_utc=now(),elapsed_ns=time.perf_counter_ns()-self.started,
                          state='complete' if kind is None else 'interrupted', error_type=None if kind is None else kind.__name__)
        atomic_json(self.path,self.value)

def recovery_cost(directory):
    rows = [read(p) for p in sorted((Path(directory)/'attempts').glob('*.json'))]
    ids = [r['segment_id'] for r in rows]
    complete = bool(rows) and len(ids)==len(set(ids)) and all(r['end_utc'] and type(r['elapsed_ns']) is int and r['elapsed_ns']>=0 for r in rows)
    profiles = [r['profile'] for r in rows]
    comparable = bool(profiles) and all({k:v for k,v in p.items() if k!='gpu_uuid'}=={k:v for k,v in profiles[0].items() if k!='gpu_uuid'} for p in profiles)
    intervals = sorted((r['start_utc'],r['end_utc']) for r in rows if r['end_utc'])
    if any(intervals[i][1] > intervals[i+1][0] for i in range(len(intervals)-1)):
        complete = False
    return {'complete':complete and comparable,'recovery_allocated_wall_ms':(sum(r['elapsed_ns'] for r in rows)+500000)//1000000 if complete and comparable else None,
            'profile':profiles[0] if profiles else None,'attempts':rows,
            'scope':'All recorded recovery attempts; train/validation/surgery/reset/commit/verification wall, excludes source preparation and final completion receipt'}
