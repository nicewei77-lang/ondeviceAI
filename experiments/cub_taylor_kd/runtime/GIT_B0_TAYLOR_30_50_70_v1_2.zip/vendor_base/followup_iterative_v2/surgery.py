"""Physical surgery with original-channel composition and deterministic L1 ties."""
from copy import deepcopy
import torch
from torch import nn
from .common import identity

def blocks(model):
    for stage, bank in enumerate(model.stages):
        for block, layer in enumerate(bank):
            if not isinstance(layer.pwconv1, nn.Linear) or not isinstance(layer.pwconv2, nn.Linear):
                raise TypeError('Expected ConvNeXt expanded MLP Linear pair')
            yield stage, block, layer

def dense_layout(model):
    result = []
    for stage, block, layer in blocks(model):
        first, second = layer.pwconv1, layer.pwconv2
        hidden = first.out_features
        if hidden != 4 * first.in_features or second.in_features != hidden or second.out_features != first.in_features:
            raise ValueError('Factory must return original dense ConvNeXt')
        result.append(dict(stage=stage, block=block, original_hidden=hidden, hidden=hidden,
                           retained_indices=list(range(hidden))))
    if not result:
        raise ValueError('Empty ConvNeXt blocks')
    return result

def validate_layout(model, layout):
    bank = list(blocks(model))
    if len(layout) != len(bank):
        raise ValueError('Layout must cover every block exactly once')
    for (stage, block, layer), row in zip(bank, layout):
        if set(row) != {'stage', 'block', 'original_hidden', 'hidden', 'retained_indices'}:
            raise ValueError('Unexpected layout schema')
        indices = row['retained_indices']
        if (type(row['stage']) is not int or type(row['block']) is not int or
            type(row['hidden']) is not int or type(row['original_hidden']) is not int or
            (row['stage'], row['block']) != (stage, block) or
            row['original_hidden'] != 4 * layer.pwconv1.in_features or
            not indices or any(type(i) is not int for i in indices) or
            indices != sorted(set(indices)) or indices[0] < 0 or indices[-1] >= row['original_hidden'] or
            len(indices) != row['hidden'] or layer.pwconv1.out_features != row['hidden'] or
            layer.pwconv2.in_features != row['hidden']):
            raise ValueError('Invalid original-index layout/physical width')

def _replace(layer, positions):
    first, second = layer.pwconv1, layer.pwconv2
    if positions == list(range(first.out_features)):
        return
    index = torch.tensor(positions, device=first.weight.device, dtype=torch.long)
    a = nn.Linear(first.in_features, len(positions), bias=first.bias is not None,
                  device=first.weight.device, dtype=first.weight.dtype)
    b = nn.Linear(len(positions), second.out_features, bias=second.bias is not None,
                  device=second.weight.device, dtype=second.weight.dtype)
    with torch.no_grad():
        a.weight.copy_(first.weight.index_select(0, index))
        b.weight.copy_(second.weight.index_select(1, index))
        if first.bias is not None:
            a.bias.copy_(first.bias.index_select(0, index))
        if second.bias is not None:
            b.bias.copy_(second.bias)
    for original, replacement in ((first, a), (second, b)):
        replacement.train(original.training)
        for old, new in zip(original.parameters(), replacement.parameters()):
            new.requires_grad_(old.requires_grad)
    layer.pwconv1, layer.pwconv2 = a, b

def prune_stage(model, layout, recipe, stage,*,audit=None):
    validate_layout(model, layout)
    result = deepcopy(layout)
    for (_, _, layer), row in zip(blocks(model), result):
        target = recipe.width(row['original_hidden'], stage)
        if target > row['hidden']:
            raise ValueError('A pruning stage cannot increase width')
        if target == row['hidden']:
            continue  # D0 and later OS boundaries are exact physical no-ops.
        scores = layer.pwconv1.weight.detach().float().abs().sum(dim=1)
        if not bool(torch.isfinite(scores).all()):
            raise FloatingPointError('Nonfinite channel importance')
        # Current physical order is original-index order, so stable ties implement
        # lowest ORIGINAL channel first, including after earlier surgeries.
        positions = torch.argsort(scores, descending=True, stable=True)[:target].sort().values.tolist()
        original = [row['retained_indices'][i] for i in positions]
        if audit is not None:
            audit.append({'stage':row['stage'],'block':row['block'],'original_hidden':row['original_hidden'],
                'retained_before':list(row['retained_indices']),'target_hidden':target,
                'L1_FP32':scores.cpu().tolist(),'retained_after':original,'bias_in_importance':False})
        _replace(layer, positions)
        row.update(hidden=target, retained_indices=original)
    validate_layout(model, result)
    model._tckd_pruning_layout = deepcopy(result)
    return result

def restore(dense_factory, state, layout, *, digest, state_identity):
    if state_identity(state) != digest:
        raise ValueError('Checkpoint tensor digest changed')
    model = dense_factory()
    original = dense_layout(model)
    if len(layout) != len(original):
        raise ValueError('Restore layout does not cover source')
    for (_, _, layer), row, base in zip(blocks(model), layout, original):
        if (row.get('stage'), row.get('block'), row.get('original_hidden')) != (base['stage'], base['block'], base['original_hidden']):
            raise ValueError('Restore original model changed')
        indices = row.get('retained_indices', [])
        if (not indices or any(type(i) is not int for i in indices) or indices != sorted(set(indices)) or
            indices[0] < 0 or indices[-1] >= base['hidden'] or row.get('hidden') != len(indices)):
            raise ValueError('Restore indices invalid')
        _replace(layer, indices)
    validate_layout(model, layout)
    expected = model.state_dict()
    if set(expected) != set(state) or any(expected[n].shape != state[n].shape or expected[n].dtype != state[n].dtype for n in expected):
        raise ValueError('Strict restore state keys/shapes/dtypes differ')
    # Official ConvNeXt registers the last norm under two aliases.
    for suffix in ('weight', 'bias'):
        a, b = f'norm.{suffix}', f'norms.3.{suffix}'
        if a in state and b in state and not torch.equal(state[a], state[b]):
            raise ValueError('Conflicting norm aliases')
    model.load_state_dict(state, strict=True)
    model._tckd_pruning_layout = deepcopy(layout)
    return model

def assert_stage_widths(model, layout, recipe, stage):
    validate_layout(model, layout)
    if any(row['hidden'] != recipe.width(row['original_hidden'], stage) for row in layout):
        raise ValueError('Stage/final width differs from the original-width target')
    return identity(layout)
