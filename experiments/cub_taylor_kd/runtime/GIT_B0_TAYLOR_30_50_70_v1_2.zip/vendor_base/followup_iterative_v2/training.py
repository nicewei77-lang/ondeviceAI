"""Matched global-budget CE recovery with committed epoch/boundary transactions.

Native Student fit is reused unchanged elsewhere. This new Teacher loop records
the intentional stage reset policy instead of mutating the frozen Native loop.
"""
from dataclasses import asdict
from pathlib import Path
import io
import hashlib
import time
import sys
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from .common import atomic_json, identity, load_commit, save_commit, sha,has_commit,save_best,model_bytes,immutable_json
from .model_store import configure,release,release_after_fit
from .policy import choose_best
from .surgery import dense_layout, prune_stage, restore, assert_stage_widths

def parameter_manifest(model, optimizer):
    named = {id(p): (name, p) for name, p in model.named_parameters()}
    seen, result = set(), []
    for group in optimizer.param_groups:
        rows = []
        for p in group['params']:
            if id(p) not in named or id(p) in seen:
                raise ValueError('Optimizer contains stale/duplicate Parameter')
            seen.add(id(p))
            name, _ = named[id(p)]
            rows.append({'name': name, 'shape': list(p.shape), 'dtype': str(p.dtype)})
        result.append({'name': group['name'], 'parameters': rows})
    if seen != set(named):
        raise ValueError('Optimizer does not cover every current Parameter')
    return result

def fresh_optimizer(model, config, device):
    head = list(model.head.parameters())
    heads = {id(p) for p in head}
    groups = [{'params': [p for p in model.parameters() if id(p) not in heads],
               'name': 'backbone', 'base_lr': 1e-5, 'lr': 1e-5},
              {'params': head, 'name': 'head', 'base_lr': 1e-4, 'lr': 1e-4}]
    for p in model.parameters():
        p.requires_grad_(True)
    optimizer = torch.optim.AdamW(groups, weight_decay=config['teacher_weight_decay'])
    scaler = torch.amp.GradScaler('cuda', enabled=bool(config.get('amp', True)) and str(device).startswith('cuda'))
    return optimizer, scaler, parameter_manifest(model, optimizer)

def _best_load(directory, best, recipe, dense_factory, native_io):
    if best is None or not recipe.eligible(best['epoch']):
        raise ValueError('No eligible final-quarter Teacher')
    name = best['file']
    if Path(name).name != name or not name.startswith('best_'):
        raise ValueError('Invalid best checkpoint path')
    raw = model_bytes(directory,best)
    if hashlib.sha256(raw).hexdigest() != best['sha256']:
        raise ValueError('Selected Teacher raw bytes changed')
    saved = torch.load(io.BytesIO(raw), map_location='cpu', weights_only=True)
    if (saved['contract_id'] != recipe.contract_id or saved['recipe'] != asdict(recipe) or
        saved['epoch'] != best['epoch'] or saved['model_digest'] != best['model_digest'] or
        saved['eligibility'] != 'final_quarter' or saved['stage'] != 3):
        raise ValueError('Teacher selection/checkpoint contract differs')
    model = restore(dense_factory, saved['model_state'], saved['layout'],
                    digest=saved['model_digest'], state_identity=native_io.model_state_identity)
    assert_stage_widths(model, saved['layout'], recipe, 3)
    return model, saved

def load_selection_data(directory, recipe, dense_factory, native_io):
    configure(directory,recipe,native_io,dense_factory)
    try:
        from .model_store import get_store
        current=get_store(directory).pointer()
        if current is None:raise ValueError('Teacher has no committed state')
        pointer=current['active']
        if pointer['contract_id']!=recipe.contract_id or pointer['next_epoch']!=recipe.budget or pointer['kind']!='epoch':raise ValueError('Teacher recovery is incomplete or recipe changed')
        best=pointer['best']
        selected=_best_load(directory,best,recipe,dense_factory,native_io)
        history=__import__('json').loads((Path(directory)/'history.json').read_text(encoding='utf8'))
        if len(history)!=recipe.budget:raise ValueError('Completed Teacher history is incomplete')
        summary={'history':history,'best':best,'commit':pointer}
        return selected,pointer,summary
    finally:release(directory)

def load_selected(directory,recipe,dense_factory,native_io):
    selected,pointer,_=load_selection_data(directory,recipe,dense_factory,native_io)
    return selected,pointer

@release_after_fit
def fit_teacher(dense_factory, train_dataset, val_dataset, run_dir, recipe, config,
                native_io, native_train, *, lease=None, device='cuda', stop_after_epoch=None,
                fault=None, on_recovery_start=None):
    """Resume only a fully committed transaction; no in-memory partial-epoch resume.

    fault is an explicit CPU-fixture crash injector and is forbidden in research.
    The orchestrator supplies verified source/CUDA evidence and a live job lease.
    """
    if not recipe.fixture and (lease is None or not str(device).startswith('cuda') or fault is not None):
        raise ValueError('Research recovery requires a live lease and actual CUDA')
    if recipe.fixture and str(device) != 'cpu':
        raise ValueError('Fixtures use CPU, never experimental CUDA evidence')
    directory = Path(run_dir)
    if lease is not None:
        lease.assert_output_path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    if on_recovery_start:on_recovery_start()
    store=configure(directory,recipe,native_io,dense_factory,lease)
    resuming=has_commit(directory)
    native_io.seed_everything(recipe.seed)
    environment = native_io.environment_record()
    runtime = {'device_type': str(device).split(':')[0],
               'python_major_minor': list(sys.version_info[:2]),
               'versions': {name:environment['versions'][name] for name in ('torch','torchvision','numpy','Pillow')},
               'torch_cuda': environment['torch_cuda'],
               'amp_enabled': bool(config.get('amp',True)) and str(device).startswith('cuda'),
               'gpu': torch.cuda.get_device_name(device) if str(device).startswith('cuda') else None}
    execution = {'recipe': asdict(recipe), 'config': config, 'runtime': runtime,
                 'head_warmup_epochs': 0, 'optimizer_policy': 'fresh_each_of_four_boundaries',
                 'scaler_policy': 'fresh_each_of_four_boundaries', 'best_policy': 'final_quarter_OA_CE_earliest',
                 'checkpoint_policy':'per_job_3resume_3best_7anchors_v2_1'}
    model = dense_factory().to(device)
    layout = dense_layout(model)
    history, applied, events, best = [], [], [], None
    next_epoch, stage, optimizer, scaler = 0, -1, None, None
    if resuming:
        saved, _ = load_commit(directory)
        if saved['execution'] != execution or saved['contract_id'] != recipe.contract_id:
            raise ValueError('Resume source/code/protocol/runtime/recipe changed')
        next_epoch, stage = saved['next_epoch'], saved['stage']
        if type(next_epoch) is not int or not 0 <= next_epoch <= recipe.budget:
            raise ValueError('Invalid committed global epoch')
        expected_stage = recipe.stage(next_epoch if saved['kind'] == 'boundary' else next_epoch - 1)
        if stage != expected_stage or saved['applied_boundaries'] != list(range(stage + 1)):
            raise ValueError('Committed stage/boundary ledger differs')
        if (saved['kind'] not in ('boundary', 'epoch') or
            (saved['kind'] == 'boundary' and not recipe.stage_start(next_epoch)) or
            len(saved['history']) != next_epoch):
            raise ValueError('Incomplete epoch/boundary transaction')
        model = restore(dense_factory, saved['model_state'], saved['layout'],
                        digest=saved['model_digest'], state_identity=native_io.model_state_identity).to(device)
        layout = saved['layout']
        assert_stage_widths(model, layout, recipe, stage)
        optimizer, scaler, manifest = fresh_optimizer(model, config, device)
        if manifest != saved['parameter_manifest']:
            raise ValueError('Optimizer parameter membership changed')
        optimizer.load_state_dict(saved['optimizer_state'])
        scaler.load_state_dict(saved['scaler_state'])
        parameter_manifest(model, optimizer)
        history, applied, events, best = saved['history'], saved['applied_boundaries'], saved['boundary_events'], saved['best']
        if len(events) != len(applied) or [e['boundary_id'] for e in events] != applied:
            raise ValueError('Boundary reset event ledger differs')
        native_io.restore_rng(saved['rng_state'])
        if best is not None:
            del_best, _ = _best_load(directory, best, recipe, dense_factory, native_io)
            del del_best
            native_io.restore_rng(saved['rng_state'])
    batch = config['batch_size']
    effective = config['effective_batch_size']
    if type(batch) is not int or type(effective) is not int or batch < 1 or effective < batch or effective % batch:
        raise ValueError('Invalid effective batch size')
    accumulation = effective // batch
    amp = bool(config.get('amp', True)) and str(device).startswith('cuda')

    def active():
        if lease is not None:
            lease.assert_active()

    def commit(kind, e):
        active()
        if any(p.dtype!=torch.float32 for p in model.parameters()):
            raise ValueError('Storage/precision contract requires FP32 master parameters')
        for state in optimizer.state.values():
            for name in ('exp_avg','exp_avg_sq'):
                if name in state and state[name].dtype!=torch.float32:
                    raise ValueError('Storage contract requires FP32 Adam moments')
        payload = {'schema': 'iterative.teacher.v1', 'kind': kind, 'next_epoch': e,
                   'stage': stage, 'contract_id': recipe.contract_id, 'execution': execution,
                   'model_state': model.state_dict(), 'model_digest': native_io.model_state_identity(model.state_dict()),
                   'layout': layout, 'applied_boundaries': applied, 'boundary_events': events,
                   'optimizer_state': optimizer.state_dict(), 'scaler_state': scaler.state_dict(),
                   'parameter_manifest': parameter_manifest(model, optimizer), 'rng_state': native_io.rng_state(),
                   'best': best, 'history': history}
        pointer=save_commit(directory, payload, tag=f'{e:03d}_{kind}')
        byte_limit=(4 if kind=='boundary' else 12)*sum(p.numel() for p in model.parameters())+8*1024**2
        if pointer['bytes']>byte_limit:
            raise ValueError('Actual serialized checkpoint exceeds declared storage forecast; HOLD')
        return pointer

    atomic_json(directory / 'environment.json', environment)
    atomic_json(directory / 'contract.json', {'contract_id': recipe.contract_id, **execution})
    try:
        for epoch in range(next_epoch, recipe.budget):
            active()
            stage = recipe.stage(epoch)
            if stage not in applied:
                if not recipe.stage_start(epoch) or applied != list(range(stage)):
                    raise ValueError('Boundary execution out of order')
                native_io.seed_everything(recipe.epoch_seed(epoch))
                before = native_io.model_state_identity(model.state_dict())
                def anchor(position,model_stage):
                    payload={'schema':'iterative.stage_anchor.v2','contract_id':recipe.contract_id,'recipe':asdict(recipe),
                        'stage':model_stage,'anchor_j':stage+1,'code_stage_index':stage,'global_epoch':epoch,
                        'position':position,'model_state':model.state_dict(),'model_digest':native_io.model_state_identity(model.state_dict()),'layout':layout}
                    return store.anchor(f'anchor_{position}_{stage}.pt',payload)
                pre_anchor=anchor('pre',stage-1) if stage else {'source_id':recipe.source_id,'model_digest':before}
                audit=[]
                layout = prune_stage(model, layout, recipe, stage,audit=audit)
                assert_stage_widths(model, layout, recipe, stage)
                optimizer, scaler, manifest = fresh_optimizer(model, config, device)
                post_anchor=anchor('post',stage)
                audit_payload={'anchor_j':stage+1,'code_stage_index':stage,'global_epoch':epoch,
                    'pre_anchor':pre_anchor,'post_anchor':post_anchor,'L1_records':audit,
                    'optimizer_reset_is_not_part_of_model_only_digest':True}
                audit_path=directory/f'BOUNDARY_{stage:02d}_AUDIT.json'
                # Replayed anchors retain their original bytes; mathematical
                # L1/layout/digests must still agree even if provider metadata changes.
                if audit_path.exists():
                    prior=__import__('json').loads(audit_path.read_text(encoding='utf8'))
                    if prior['L1_records']!=audit or prior['pre_anchor']['model_digest']!=pre_anchor['model_digest'] or prior['post_anchor']['model_digest']!=post_anchor['model_digest']:
                        raise ValueError('Boundary replay audit differs')
                else:immutable_json(audit_path,audit_payload)
                applied.append(stage)
                events.append({'boundary_id': stage, 'global_epoch': epoch,
                               'pre_digest': before, 'post_digest': native_io.model_state_identity(model.state_dict()),
                               'layout_id': identity(layout), 'reset_optimizer': True, 'reset_scaler': True,
                               'parameter_manifest_id': identity(manifest), 'optimizer_state_entries_after_reset': len(optimizer.state)})
                if fault:
                    fault('before_boundary_commit', epoch)
                commit('boundary', epoch)
                if fault:
                    fault('after_boundary_commit', epoch)
            native_io.seed_everything(recipe.epoch_seed(epoch))
            if hasattr(train_dataset, 'set_epoch'):
                train_dataset.set_epoch(epoch, recipe.seed)
            generator = torch.Generator().manual_seed(recipe.epoch_seed(epoch))
            loader = DataLoader(train_dataset, batch_size=batch, shuffle=True, generator=generator,
                                num_workers=config.get('num_workers', 0), pin_memory=str(device).startswith('cuda'), drop_last=False)
            if len(loader) == 0:
                raise ValueError('Empty training set')
            factor = recipe.learning_factor(epoch, config.get('warmup_epochs', 5))
            for group in optimizer.param_groups:
                group['lr'] = group['base_lr'] * factor
            parameter_manifest(model, optimizer)
            model.train()
            optimizer.zero_grad(set_to_none=True)
            started = time.perf_counter()
            if str(device).startswith('cuda'):
                torch.cuda.reset_peak_memory_stats()
            samples = correct = group_samples = attempted = applied_steps = skipped = 0
            loss_sum = 0.0
            for index, (images, labels, _) in enumerate(loader):
                images, labels = images.to(device), labels.to(device)
                with torch.autocast(device_type=str(device).split(':')[0], enabled=amp):
                    output = model(images)
                    loss = F.cross_entropy(output.float(), labels)
                if not bool(torch.isfinite(output).all()) or not bool(torch.isfinite(loss)):
                    raise FloatingPointError(f'Nonfinite forward/loss at global epoch{epoch + 1} batch{index + 1}')
                count = labels.numel()
                scaler.scale(loss * count).backward()
                group_samples += count
                if (index + 1) % accumulation == 0 or index + 1 == len(loader):
                    scaler.unscale_(optimizer)
                    for p in model.parameters():
                        if p.grad is not None:
                            p.grad.div_(group_samples)
                    finite = all(bool(torch.isfinite(p.grad).all()) for p in model.parameters() if p.grad is not None)
                    if not finite and not amp:
                        raise FloatingPointError('Nonfinite unscaled FP32 gradients')
                    attempted += 1
                    scaler.step(optimizer)
                    scaler.update()
                    applied_steps += int(finite)
                    skipped += int(not finite)
                    optimizer.zero_grad(set_to_none=True)
                    group_samples = 0
                samples += count
                correct += int((output.argmax(1) == labels).sum())
                loss_sum += float(loss.detach()) * count
            if str(device).startswith('cuda'):
                torch.cuda.synchronize()
            training_seconds = time.perf_counter() - started
            val_started = time.perf_counter()
            logits, labels, _ = native_train.predict(model, val_dataset, batch, config.get('num_workers', 0), device)
            if not bool(torch.isfinite(logits).all()):
                raise FloatingPointError('Nonfinite validation logits')
            accuracy = 100 * int((logits.argmax(1) == labels).sum()) / len(labels)
            val_loss = float(F.cross_entropy(logits.float(), labels))
            histogram = torch.bincount(logits.argmax(1), minlength=config['num_classes']).tolist()
            row = {'epoch': epoch, 'completed_epochs': epoch + 1, 'stage': stage,
                   'epoch_seed': recipe.epoch_seed(epoch), 'learning_factor': factor,
                   'learning_rates': {g['name']: g['lr'] for g in optimizer.param_groups},
                   'train_samples': samples, 'train_loss': loss_sum / samples,
                   'train_accuracy_pct': 100 * correct / samples, 'val_accuracy_pct': accuracy,
                   'val_loss': val_loss, 'val_prediction_histogram': histogram,
                   'max_predicted_class_fraction': max(histogram) / len(labels), 'eligible': recipe.eligible(epoch),
                   'attempted_optimizer_steps': attempted, 'applied_optimizer_steps': applied_steps,
                   'skipped_optimizer_steps': skipped, 'scaler_scale': scaler.get_scale(),
                   'train_seconds': training_seconds, 'validation_seconds': time.perf_counter() - val_started,
                   'epoch_seconds_excluding_commit_io': time.perf_counter() - started,
                   'peak_gpu_memory_bytes': torch.cuda.max_memory_allocated() if str(device).startswith('cuda') else 0,
                   'parameters': sum(p.numel() for p in model.parameters()), 'layout_id': identity(layout)}
            history.append(row)
            candidate = {'epoch': epoch, 'accuracy_pct': accuracy, 'loss': val_loss}
            if recipe.eligible(epoch) and choose_best(best, candidate):
                saved = {'schema': 'iterative.selected_teacher.v1', 'recipe': asdict(recipe),
                         'contract_id': recipe.contract_id, 'stage': stage, 'epoch': epoch,
                         'eligibility': 'final_quarter', 'model_state': model.state_dict(),
                         'model_digest': native_io.model_state_identity(model.state_dict()), 'layout': layout}
                best = {**candidate,**save_best(directory,saved),'model_digest':saved['model_digest']}
            io_started = time.perf_counter()
            pointer = commit('epoch', epoch + 1)
            atomic_json(directory / 'history.json', history)
            atomic_json(directory / 'status.json', {'state': 'complete' if epoch + 1 == recipe.budget else 'running',
                        'completed_epochs': epoch + 1, 'planned_epochs': recipe.budget, 'stage': stage,
                        'applied_boundaries': applied, 'commit': pointer,
                        'latest_commit_io_seconds': time.perf_counter() - io_started})
            print(f'{recipe.dataset} {recipe.arm} r{recipe.target_percent} B{recipe.budget} {epoch + 1}/{recipe.budget} val={accuracy:.3f}', flush=True)
            if fault:
                fault('after_epoch_commit', epoch)
            if stop_after_epoch is not None and epoch + 1 >= stop_after_epoch:
                break
        atomic_json(directory/'history.json',history)
        atomic_json(directory/'status.json',{'state':'complete' if len(history)==recipe.budget else 'paused_at_epoch_boundary',
            'completed_epochs':len(history),'planned_epochs':recipe.budget,'stage':stage,'commit':store.pointer()['active']})
        return {'state': 'complete' if len(history) == recipe.budget else 'paused_at_epoch_boundary',
                'completed_epochs': len(history), 'best': best, 'boundary_resets': len(applied), 'history': history}
    except BaseException as error:
        atomic_json(directory / 'ERROR.json', {'state': 'interrupted' if isinstance(error, KeyboardInterrupt) else 'failed',
                    'error_type': type(error).__name__, 'message': str(error),
                    'resume_from': 'COMMITTED.json only; uncommitted in-memory state is discarded'})
        raise
