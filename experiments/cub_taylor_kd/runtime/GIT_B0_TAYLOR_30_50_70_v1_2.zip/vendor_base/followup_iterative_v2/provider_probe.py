"""Actual provider protocol probe with a tiny CPU IO fixture, no research training."""
from dataclasses import asdict
import torch
from torch import nn
from phaseb.native import module
from .common import identity,atomic_json
from .policy import Recipe
from .surgery import dense_layout
from .training import fresh_optimizer
from .model_store import ModelStore,DriveBackend,MODELS

class Block(nn.Module):
    def __init__(self):
        super().__init__();self.pwconv1=nn.Linear(4,16);self.pwconv2=nn.Linear(16,4)
    def forward(self,x):return x+self.pwconv2(torch.nn.functional.gelu(self.pwconv1(x)))
class IOModel(nn.Module):
    def __init__(self):
        super().__init__();self.stages=nn.ModuleList([nn.Sequential(Block())]);self.head=nn.Linear(4,3)
    def forward(self,x):return self.head(self.stages[0](x))

def run_probe(contract,lease):
    native=module('cub200','io');previous=native.rng_state()
    try:
        recipe=Recipe('fixture','D0',0,20,20261013,identity('provider_IO_fixture_not_a_Teacher'),contract['protocol_id'],contract['code_id'],True)
        def factory():
            torch.manual_seed(42);return IOModel()
        backend=DriveBackend(lease.output_dir,recipe.contract_id,lease)
        store=ModelStore(lease.output_dir,recipe,native,factory,lease,backend=backend)
        cfg={'teacher_weight_decay':.01,'amp':False}
        model=factory();layout=dense_layout(model);optimizer,scaler,manifest=fresh_optimizer(model,cfg,'cpu')
        execution={'recipe':asdict(recipe),'runtime':{'amp_enabled':False},'IO_fixture_only':True}
        best=None
        def payload(e,kind,stage):
            return {'schema':'provider.IO_fixture_only.v2','kind':kind,'next_epoch':e,'stage':stage,
                'contract_id':recipe.contract_id,'execution':execution,'model_state':model.state_dict(),
                'model_digest':native.model_state_identity(model.state_dict()),'layout':layout,
                'applied_boundaries':list(range(stage+1)),'history':[{'IO_fixture_only':True} for _ in range(e)],
                'optimizer_state':optimizer.state_dict(),'scaler_state':scaler.state_dict(),
                'parameter_manifest':manifest,'rng_state':native.rng_state(),'best':best}
        for epoch in range(20):
            stage=recipe.stage(epoch)
            if recipe.stage_start(epoch):
                for position in (('pre','post') if stage else ('post',)):
                    value={'schema':'provider.model_only_IO_anchor.v2','contract_id':recipe.contract_id,'recipe':asdict(recipe),
                        'model_state':model.state_dict(),'model_digest':native.model_state_identity(model.state_dict()),'layout':layout,
                        'stage':stage if position=='post' else stage-1,'anchor_j':stage+1,'code_stage_index':stage,
                        'global_epoch':epoch,'position':position}
                    store.anchor(f'anchor_{position}_{stage}.pt',value)
                store.commit(payload(epoch,'boundary',stage))
            if recipe.eligible(epoch):
                value={'schema':'provider.model_only_IO_best.v2','contract_id':recipe.contract_id,'recipe':asdict(recipe),
                    'model_state':model.state_dict(),'model_digest':native.model_state_identity(model.state_dict()),'layout':layout,
                    'stage':3,'epoch':epoch,'eligibility':'final_quarter'}
                best={**store.save_best(value),'epoch':epoch}
            store.commit(payload(epoch+1,'epoch',stage))
        accounting=store.accounting();files=accounting['files']
        if len(files)!=13 or set(files)!=MODELS:raise ValueError('Provider fixture did not exercise exactly3R3B7anchors')
        observed=sum(int(r['provider_quota_bytes']) for r in files.values()) if all(r.get('provider_quota_bytes') is not None for r in files.values()) else None
        current=sum(r['bytes'] for r in files.values())
        if observed is not None and observed>current:
            raise ValueError('PROVIDER_ACCOUNTING_HOLD: quotaBytesUsed exceeds current head/anchor bytes')
        result={'state':'complete','kind':'storage_probe','frozen_contract_id':contract['contract_id'],
            'evidence':'actual_official_Drive_API_small_IO_fixture','provider_protocol_verified':True,
            'provider_current_file_bytes':current,'provider_quota_bytes_observed':observed,
            'provider_accounting_complete':observed is not None,'file_count':len(files),'files':files,
            'optimizer_steps':0,'research_model_updates':0,'research_accuracy_metrics_produced':False,
            'scope':'Small provider fixture verifies fixed IDs/checksums/pointer protocol; large checkpoint accounting remains checked at actual writes',
            'PC_model_downloads':0,'delete_API_calls':0,'provider_revision_delete_calls':0}
        atomic_json(lease.output_dir/'PROVIDER_PROBE.json',result)
        return result
    finally:native.restore_rng(previous)
