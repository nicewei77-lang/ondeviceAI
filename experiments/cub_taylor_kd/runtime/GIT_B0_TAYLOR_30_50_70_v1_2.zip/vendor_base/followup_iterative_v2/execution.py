"""Frozen source, protocol and SINGLE-runtime ownership for namespace v2."""
from pathlib import Path
import hashlib
import os
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from phaseb.native import module, config, parent
from phaseb.ownership import freeze_assignment, validate_assignment, OwnershipGuard, current_runtime_id
from phaseb.pipeline import source_ids
from .common import ROOT, PARENT, read, sha, identity, immutable_json, verify_parent, atomic_json
from .graph import all_jobs, partition

WORK_NAME = 'TeacherCompressionKD_Iterative_Single_v2'

def output_root(work):
    path = Path(work).expanduser().resolve()
    if path.name!='results' or path.parent.name!=WORK_NAME or path.is_relative_to(PARENT):
        raise ValueError('Use the separate iterative project/results root')
    return path

def controls(work):
    return output_root(work).parent/'control'

def code_manifest():
    manifest = read(ROOT/'FROZEN_SOURCE.json')
    if identity(manifest['sha256']) != manifest['code_id']:
        raise ValueError('New code manifest identity changed')
    for name,wanted in manifest['sha256'].items():
        path=ROOT/name
        if not path.resolve().is_relative_to(ROOT.resolve()) or sha(path)!=wanted:
            raise ValueError('New frozen source changed: '+name)
    verify_parent()
    return manifest

def load_contract(work):
    contract=read(controls(work)/'contract.json')
    if identity({k:v for k,v in contract.items() if k!='contract_id'})!=contract['contract_id']:
        raise ValueError('Iterative contract identity changed')
    manifest=code_manifest()
    if contract['code_id']!=manifest['code_id'] or contract['protocol_id']!=sha(ROOT/'assets/PROTOCOL_DRAFT.md'):
        raise ValueError('Code/protocol differs from immutable contract')
    return contract

def freeze(work):
    """Freeze reviewed design bytes; this does not assert actual CUDA readiness."""
    work=output_root(work);manifest=code_manifest();review=read(ROOT/'assets/DESIGN_FREEZE.json')
    protocol=sha(ROOT/'assets/PROTOCOL_DRAFT.md')
    if (review.get('state')!='DESIGN_FROZEN_IMPLEMENTATION_AND_PROVIDER_GATES_PENDING' or review.get('namespace')!='teamnative_iterative_single_v2' or
        review['operational_addendum']['sha256']!=protocol or
        review['scientific_protocol']['sha256']!=sha(ROOT/'assets/SCIENTIFIC_PROTOCOL_V03.md') or
        review['independent_design_review']['state']!='NO_REMAINING_DESIGN_P1_IN_REVIEWED_SCOPE'):
        raise ValueError('Protocol/code independent review not frozen; PREPARATION_ONLY')
    pins=read(ROOT/'assets/source_pins.json')
    for d in ('cub200','flowers102','aircraft'):
        if config(d)['teacher_seed']!=20261013:
            raise ValueError('Graph Teacher seed differs from exact Native source recipe')
    payload={'namespace':'teamnative_iterative_single_v2','protocol_id':protocol,'code_id':manifest['code_id'],
             'selector_state':'FROZEN_REVIEWED','review':review,'source_pins':pins,
             'student_epochs':60,'pruning_runtimes':1,'max_sessions':2,'additional_purchases':0,
             'storage_policy':'per_job_3resume_3best_7anchors_v2_1','PC_large_checkpoint_downloads':False,
             'parent_code_id':manifest['parent_code_id'],'Native_config_ids':{d:identity(config(d)) for d in pins['datasets']}}
    contract={**payload,'contract_id':identity(payload)}
    immutable_json(controls(work)/'contract.json',contract)
    return {'state':'protocol_frozen_actual_source_CUDA_pending','contract_id':contract['contract_id'],'training_calls':0}

def prepare_data(work, inputs, cache='/content/itkd_v2_raw_cache'):
    work=output_root(work);code_manifest()
    if os.name!='posix':
        raise ValueError('Actual data preparation is restricted to local /content in Colab')
    inputs,cache,receipts=Path(inputs).resolve(),Path(cache).resolve(),Path('/content/itkd_v2_data_preflight/results')
    pins=read(PARENT/'configs/readonly_inputs.json')['datasets']
    for path in (cache,receipts):
        if not path.is_relative_to(Path('/content')) or path==Path('/content') or path.is_relative_to(Path('/content/drive')):
            raise ValueError('Local cache/preflight must stay outside Drive')
        for forbidden in [inputs,PARENT.resolve(),work]+[Path(p['native_results']).resolve() for p in pins.values()]:
            if path.is_relative_to(forbidden) or forbidden.is_relative_to(path):
                raise ValueError('Preparation output overlaps a protected input/result')
    roots={}
    for dataset,pin in pins.items():
        subprocess.run([sys.executable,'-B','-u',str(PARENT/'vendor/native_parent/tools/prepare_data.py'),
            '--dataset',dataset,'--inputs',str(inputs),'--cache-root',str(cache),'--work-dir',str(receipts),
            '--native-results',pin['native_results']],check=True,cwd=PARENT)
        receipt=read(receipts/'data'/dataset/'B1_DATA_RECEIPT.json')
        if receipt.get('split_id')!=pin['split_id'] or receipt.get('full_image_preflight_complete') is not True or receipt.get('exact_native_manifest_parity') is not True:
            raise ValueError('Full-image Native data parity failed')
        roots[dataset]=receipt['data_root']
    immutable_json(receipts/'data_roots.json',roots)
    return {'state':'full_local_image_preflight_complete','data_roots_file':str(receipts/'data_roots.json'),'training_calls':0}

def verify_data(roots):
    from phaseb.pipeline import context
    for dataset in ('cub200','flowers102','aircraft'):
        value=roots[dataset]
        if '://' in value or any(c in value for c in '?&#') or not Path(value).is_dir():
            raise ValueError('Expected existing plain dataset filesystem path')
        receipt=read(Path('/content/itkd_v2_data_preflight/results/data')/dataset/'B1_DATA_RECEIPT.json')
        pin=read(PARENT/'configs/readonly_inputs.json')['datasets'][dataset]
        if (Path(receipt['data_root']).resolve()!=Path(value).resolve() or receipt['split_id']!=pin['split_id'] or
            receipt.get('full_image_preflight_complete') is not True or receipt.get('exact_native_manifest_parity') is not True):
            raise ValueError('Current runtime data preflight differs')
        context(dataset,{},roots)

def registration_capacity(work,slot,contract,existing_registration,*,pilot_only=False):
    from .storage import live_quota,required_remaining,validate_committed_progress
    assignment=None
    if existing_registration is not None and (controls(work)/'execution.json').exists():
        current,a,r,_=execution(work,slot)
        if current!=contract or r!=existing_registration:
            raise ValueError('Resume registration differs from immutable execution binding')
        validate_committed_progress(work,a,contract)
        assignment=a
    # Existing immutable progress is validated BEFORE it reduces the forecast.
    requirement=required_remaining(work,assignment,full_workflow=not pilot_only)
    try:
        return live_quota(requirement)
    except Exception as error:
        atomic_json(controls(work)/f'STORAGE_GATE_{slot}_HOLD.json',{'state':'STORAGE_CAPACITY_PENDING_OR_HOLD',
            'error_type':type(error).__name__,'automatic_retry':False,'training_started':False,
            'forecast_scope':'remaining_validated_assignment' if assignment else 'fresh_full_or_pilot',
            'required_bytes':requirement})
        raise

def register(work,slot,roots_file,*,pilot_only=False):
    if slot!='A':
        raise ValueError('v2 permits exactly one pruning runtime, slot A')
    contract=load_contract(work);roots=read(roots_file);verify_data(roots)
    parent()
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    runtime=current_training_runtime()
    for pin in read(PARENT/'configs/readonly_inputs.json')['datasets'].values():
        validate_runtime_match(pin['baseline_execution_runtime'],runtime)
    path=controls(work)/f'runtime_{slot}.json'
    if path.exists():
        previous=read(path)
        if previous['runtime_id']!=current_runtime_id() or previous['contract_id']!=contract['contract_id'] or previous['data_roots']!=roots or previous['runtime']!=runtime or previous['workflow_mode']!=('pilot_only' if pilot_only else 'full'):
            raise ValueError('No implicit runtime transfer/re-registration')
        registration_capacity(work,slot,contract,previous,pilot_only=pilot_only)
        return {k:v for k,v in previous.items() if k!='owner_token'}
    quota=registration_capacity(work,slot,contract,None,pilot_only=pilot_only)
    record={'state':'registered','slot':slot,'runtime_id':current_runtime_id(),'owner_token':uuid.uuid4().hex,
            'contract_id':contract['contract_id'],'data_roots':roots,'runtime':runtime,
            'registered_at_utc':datetime.now(timezone.utc).isoformat(),
            'workflow_mode':'pilot_only' if pilot_only else 'full','initial_storage_gate':quota}
    immutable_json(path,record)
    return {k:v for k,v in record.items() if k!='owner_token'}

def bind(work,slot):
    contract=load_contract(work);control=controls(work)
    if slot!='A' or read(control/'runtime_A.json')['runtime_id']!=current_runtime_id():
        raise ValueError('Only actual registered A may bind once')
    if (control/'execution.json').exists():
        raise ValueError('Assignment already frozen; inspect instead of rebinding')
    owners={};receipts=[{'path':str(control/'contract.json'),'sha256':sha(control/'contract.json')}]
    for s in ('A',):
        path=control/f'runtime_{s}.json';r=read(path)
        if r['state']!='registered' or r['contract_id']!=contract['contract_id']:
            raise ValueError('Runtime registration differs')
        owners[s]={'runtime_id':r['runtime_id'],'owner_token':r['owner_token']}
        receipts.append({'path':str(path),'sha256':sha(path)})
    readonly=[p['native_results'] for p in read(PARENT/'configs/readonly_inputs.json')['datasets'].values()]
    readonly.append(str(output_root(work).parent.parent/'TeacherCompressionKD_TeamNative_Base_v1'))
    readonly.append(str(output_root(work).parent.parent/'TeacherCompressionKD_Iterative_Matched_v1'))
    assignment=freeze_assignment(all_jobs(),partition(),frozen_contract_id=contract['contract_id'],source_ids=source_ids(contract),
        output_root=output_root(work),slot_owners=owners,source_receipts=receipts,readonly_roots=readonly,local_lock_root='/content/itkd_v2_local_locks')
    immutable_json(control/'execution.json',{'assignment':assignment,'contract_id':contract['contract_id'],'code_id':contract['code_id']})
    return {'state':'bound_actual_source_CUDA_pending','assignment_id':assignment['assignment_id']}

def execution(work,slot):
    if slot!='A':raise ValueError('v2 has no slot B')
    contract=load_contract(work);control=controls(work);e=read(control/'execution.json');a=e['assignment']
    if e['contract_id']!=contract['contract_id'] or e['code_id']!=contract['code_id']:
        raise ValueError('Execution binding changed')
    validate_assignment(a,expected_contract_id=contract['contract_id'],expected_source_ids=source_ids(contract),expected_jobs=all_jobs(),expected_assignment_id=a['assignment_id'])
    if a['output_root']!=output_root(work).as_posix():
        raise ValueError('Wrong output root')
    if a.get('slots')!=['A'] or set(a.get('slot_owners',{}))!={'A'} or any(row['slot']!='A' for row in a['jobs']):
        raise ValueError('Single-runtime assignment contains an unapproved second owner')
    r=read(control/f'runtime_{slot}.json')
    if r['runtime_id']!=current_runtime_id() or r['contract_id']!=contract['contract_id']:
        raise ValueError('Wrong runtime or contract')
    parent()
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    live=current_training_runtime()
    validate_runtime_match(r['runtime'],live)
    for pin in read(PARENT/'configs/readonly_inputs.json')['datasets'].values():
        validate_runtime_match(pin['baseline_execution_runtime'],live)
    verify_data(r['data_roots'])
    guard=OwnershipGuard(a,slot,expected_contract_id=contract['contract_id'],expected_source_ids=source_ids(contract),
        expected_jobs=all_jobs(),expected_assignment_id=a['assignment_id'],local_lock_root=a['local_lock_root'],owner_token=r['owner_token'])
    return contract,a,r,guard

def job_dir(work,assignment,job):
    slot=partition()[job]
    path=output_root(work)/assignment['assignment_id']/f'slot_{slot}'/'jobs'/job.job_id
    if path.resolve()!=path:
        raise ValueError('Redirected job directory')
    return path

def completion(work,assignment,job):
    path=job_dir(work,assignment,job);owner_path=path/'.owner.json'
    if not owner_path.exists():
        return None
    owner=read(owner_path);slot=partition()[job];binding=assignment['slot_owners'][slot]
    source_sha=hashlib.sha256(__import__('json').dumps(assignment['source_ids'],sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    expected={'schema':'phaseb.ownership.v1','generation':1,'assignment_id':assignment['assignment_id'],
              'frozen_contract_id':assignment['frozen_contract_id'],'source_ids_sha256':source_sha,
              'job_id':job.job_id,'slot':slot,'runtime_id':binding['runtime_id'],'owner_token_sha256':binding['owner_token_sha256']}
    if any(owner.get(k)!=v for k,v in expected.items()):
        raise ValueError('Completed producer owner/source identity differs')
    if owner['state']!='complete':
        return None
    marker=read(path/'COMPLETE.json')
    if marker!=owner['completion_receipt'] or marker.get('frozen_contract_id')!=assignment['frozen_contract_id']:
        raise ValueError('Completed producer marker differs')
    return marker
