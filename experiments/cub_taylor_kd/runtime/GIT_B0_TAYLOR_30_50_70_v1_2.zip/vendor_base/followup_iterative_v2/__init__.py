"""Preparation-only matched one-shot/iterative Teacher experiment."""

VERSION = '0.2.0'
NAMESPACE = 'teamnative_iterative_single_v2'
