"""Single START notebook and portable v2 package; no runtime allocation."""
import ast,json,sys,zipfile
from pathlib import Path
import nbformat
from .common import ROOT,PARENT,identity,sha,atomic_json,verify_parent

PARENT_ZIP_SHA='8e6feabc22a9b827be61906ff522fcc294693bcfbd7d41efe90d7bb2d626124f'
V1_ZIP_SHA='5459d9f343a0c704789266c6ca18e7655a5447cc6d41ad442abeac6e65b6a6af'

def notebook(zip_sha):
    cells=[nbformat.v4.new_markdown_cell('''# 단일 runtime iterative pruning v2

이 노트북 하나만 사용합니다. 다른 프로젝트 세션1개는 그대로 두고 pruning L4는1개만 사용합니다. 계정 전체 최대2개입니다. 기존 v1 시작 노트북을 함께 실행하지 않습니다.

첫 변수 START_FULL_WORKFLOW=True와 모두 실행으로 시작합니다. 최초 Google 인증 후 quota/provider probe/새 CUDA 수치검토 전에는 Teacher·Student 본학습을 하지 않습니다. 모델과 전체 logits는 Drive에 두고 Colab에서 평가하며 PC에는 작은 분석 요약만 전달합니다. 새 GPU 시작은 패키지 검토 뒤 조율합니다.'''),
        nbformat.v4.new_code_cell("""START_FULL_WORKFLOW=False
PILOT_ONLY=False
assert START_FULL_WORKFLOW is True, '실제 단일 workflow 시작을 조율한 뒤 True로 변경하세요'
"""),
        nbformat.v4.new_markdown_cell('## Drive 연결과 고정 패키지 확인'),
        nbformat.v4.new_code_cell(f'''from pathlib import Path, PurePosixPath
from google.colab import drive, auth
import os, sys, json, hashlib, stat, tempfile, zipfile, subprocess
if not os.path.ismount('/content/drive'):
    drive.mount('/content/drive',timeout_ms=900000)
BASE=Path('/content/drive/MyDrive/온디바이스AI')
PROJECT=BASE/'TeacherCompressionKD_Iterative_Single_v2'
WORK=PROJECT/'results'
PACKAGE=PROJECT/'packages/ITERATIVE_SINGLE_v2.zip'
assert hashlib.sha256(PACKAGE.read_bytes()).hexdigest()=='{zip_sha}', 'ZIP SHA 불일치'
CODE=Path(tempfile.mkdtemp(prefix='itkd_single_v2_',dir='/content'))
with zipfile.ZipFile(PACKAGE) as archive:
    assert archive.testzip() is None
    for item in archive.infolist():
        path=PurePosixPath(item.filename)
        assert not path.is_absolute() and '..' not in path.parts and chr(92) not in item.filename
        assert not stat.S_ISLNK(item.external_attr>>16)
    archive.extractall(CODE)
ENV={{**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf8'}}
def run(*args):
    subprocess.run([sys.executable,'-B','-u','-m','followup_iterative_v2.cli',*map(str,args)],cwd=CODE,env=ENV,check=True)
run('plan')'''),
        nbformat.v4.new_markdown_cell('''## 단일 순차 workflow

일반 Colab 인증은 Google 화면에서 직접 처리합니다. 인증정보를 채팅이나 파일에 저장하지 않습니다. 실제 Drive quota를 확인하고, tiny provider probe와 새 source/stage CUDA 검사(update0)를 수행한 후 상위의 실제 결과 검토 파일을 최대2시간 기다립니다. 이후 고정 판정표에 따라 P1/P2/P3/Test/export를 순차 수행합니다. 다른 slot 대기나 새 연구 승인 요청은 없습니다.

완료 후 Drive 저장·작은 분석 묶음까지 확인하고 자기 runtime만 공식 API로 반환 요청합니다. 실제 반환 확인 전에는 RELEASE_CONFIRMED라고 쓰지 않습니다.'''),
        nbformat.v4.new_code_cell('''auth.authenticate_user()
arguments=['autorun','--work-dir',WORK,'--inputs',BASE/'TeacherSizeKD_NoPruning/inputs',
           '--start-full-workflow','--review-timeout','7200']
if PILOT_ONLY:arguments.append('--pilot-only')
run(*arguments)''')]
    for c in cells:
        if c.cell_type=='code':ast.parse(c.source)
    nb=nbformat.v4.new_notebook(cells=cells,metadata={'colab':{'name':'00_START_SINGLE_RUNTIME_v2.ipynb','provenance':[]},
        'kernelspec':{'display_name':'Python 3','name':'python3'},'language_info':{'name':'python'},'accelerator':'GPU'})
    nbformat.validate(nb);return nb

def cpu_notebook():
    return nbformat.v4.new_notebook(cells=[nbformat.v4.new_markdown_cell('# 로컬 CPU fixture 검증\\n실제 pretrained/CUDA/Drive 실행 증거가 아닙니다. Teacher_Compression_KD_TeamNative 경로에서 실행합니다.'),
        nbformat.v4.new_code_cell('''from pathlib import Path
import os, sys, subprocess
ROOT=Path(os.environ.get('ITKD_PARENT_ROOT','.')).resolve()
assert (ROOT/'followup_iterative_v2').is_dir()
PYTHON=os.environ.get('ITKD_TEST_PYTHON',sys.executable)
command=[PYTHON,'-B','-X','utf8','-m','unittest','discover','-s','followup_iterative_v2/tests','-v']
print('실제 interpreter:',PYTHON)
print('검증 명령:',command)
result=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
print(result.stdout)
assert result.returncode==0
print('CPU_FIXTURE_PASS_ONLY')''')],metadata={'kernelspec':{'display_name':'Python 3','name':'python3'},'language_info':{'name':'python'}})

def main():
    parent_id=verify_parent();original=PARENT/'colab_packages/PHASEB_TEAMNATIVE_RUNNER_v1.zip'
    if sha(original)!=PARENT_ZIP_SHA:raise ValueError('Original parent ZIP changed')
    historical=PARENT/'followup_iterative_v1/colab_packages/ITERATIVE_MATCHED_v1.zip'
    if historical.exists() and sha(historical)!=V1_ZIP_SHA:raise ValueError('Preserved v1 ZIP changed')
    paths=[p for p in ROOT.rglob('*') if p.is_file() and not set(p.relative_to(ROOT).parts)&{'colab_packages','reports','codex_ws','__pycache__'}
        and p.suffix in ('.py','.md','.json') and p.name!='FROZEN_SOURCE.json']
    for p in paths:
        if p.suffix=='.py':ast.parse(p.read_text(encoding='utf8'),filename=str(p))
    hashes={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}
    manifest={'schema':'iterative.single_v2.source.v1','code_id':identity(hashes),'sha256':hashes,'parent_code_id':parent_id,
        'parent_ZIP_sha256':PARENT_ZIP_SHA,'preserved_v1_ZIP_sha256':V1_ZIP_SHA,'mode':'PREPARATION_ONLY_ACTUAL_GATES_PENDING'}
    atomic_json(ROOT/'FROZEN_SOURCE.json',manifest)
    out=ROOT/'colab_packages';out.mkdir(exist_ok=True);target=out/'ITERATIVE_SINGLE_v2.zip'
    with zipfile.ZipFile(original) as source,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
        for info in source.infolist():archive.writestr(info,source.read(info.filename))
        for p in paths+[ROOT/'FROZEN_SOURCE.json']:archive.write(p,'followup_iterative_v2/'+p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:raise ValueError('ZIP CRC failed')
    digest=sha(target);notebooks=[]
    for name,nb in [('00_START_SINGLE_RUNTIME_v2.ipynb',notebook(digest)),('00_ITERATIVE_CPU_FIXTURE_CHECK.ipynb',cpu_notebook())]:
        path=out/name;nbformat.write(nb,path);nbformat.validate(nbformat.read(path,as_version=4));notebooks.append({'file':name,'sha256':sha(path)})
    delivery={'state':'BUILT_SINGLE_RUNTIME_ACTUAL_PROVIDER_CUDA_PENDING','code_id':manifest['code_id'],'ZIP':target.name,
        'ZIP_sha256':digest,'ZIP_bytes':target.stat().st_size,'new_source_files':len(hashes),'notebooks':notebooks,
        'pruning_runtimes':1,'ZIP_CRC':True,'Python_AST':True,'nbformat':True,'python':sys.executable,
        'actual_provider_probe':False,'actual_source_CUDA':False,'actual_GPU_training':False,'PC_model_downloads':0,
        'preserved_v1_ZIP_sha256':V1_ZIP_SHA}
    atomic_json(out/'DELIVERY.json',delivery);print(json.dumps(delivery,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
