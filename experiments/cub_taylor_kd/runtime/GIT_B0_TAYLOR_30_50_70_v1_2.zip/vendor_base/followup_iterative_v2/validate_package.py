"""Extracted-package acceptance with inspectable UTF-8 commands and CPU logs."""
from datetime import datetime,timezone
from pathlib import Path
import ast
import json
import os
import subprocess
import sys
import tempfile
import uuid
import zipfile
import nbformat
from .common import ROOT,PARENT,read,sha,atomic_json,verify_parent

def main():
    delivery=read(ROOT/'colab_packages/DELIVERY.json')
    archive=ROOT/'colab_packages'/delivery['ZIP']
    if sha(archive)!=delivery['ZIP_sha256']:
        raise ValueError('Delivered ZIP hash differs')
    stage=PARENT/'codex_ws/runs'/('iterative_acceptance_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:8])
    extracted=stage/'extracted';extracted.mkdir(parents=True)
    with zipfile.ZipFile(archive) as package:
        if package.testzip() is not None:raise ValueError('ZIP CRC failed')
        names=package.namelist()
        if len(names)!=len(set(names)):raise ValueError('Duplicate ZIP entry')
        for name in names:
            p=Path(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name:raise ValueError('Unsafe ZIP path')
        package.extractall(extracted)
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1','PYTHONIOENCODING':'utf8'}
    commands=[]
    def run(arguments,name):
        cmd=[sys.executable,'-B','-X','utf8',*arguments]
        completed=subprocess.run(cmd,cwd=extracted,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf8')
        log=stage/(name+'.log');log.write_text(completed.stdout,encoding='utf8')
        commands.append({'command':cmd,'cwd':str(extracted),'exit_code':completed.returncode,'log':str(log),'log_sha256':sha(log)})
        if completed.returncode:raise RuntimeError(f'{name} failed; see {log}')
        return completed.stdout
    run(['-m','unittest','discover','-s','followup_iterative_v2/tests','-v'],'CPU_TESTS')
    plan=json.loads(run(['-m','followup_iterative_v2.cli','plan'],'PLAN_ONLY'))
    if plan['P1']['teacher']!=6 or plan['P1']['student_full60']!=6 or plan['training_calls']!=0:
        raise ValueError('Plan-only count/gate mismatch')
    run(['-m','followup_iterative_v2.cli','--help'],'CLI_HELP')
    notebooks=[]
    for row in delivery['notebooks']:
        path=ROOT/'colab_packages'/row['file']
        if sha(path)!=row['sha256']:raise ValueError('Notebook bytes differ')
        nb=nbformat.read(path,as_version=4);nbformat.validate(nb)
        for cell in nb.cells:
            if cell.cell_type=='code':ast.parse(cell.source)
        notebooks.append({'file':row['file'],'sha256':row['sha256'],'schema_AST':True,
                          'actual_Colab_execution':False})
    # A CPU-only notebook is executed with a task-local kernel specification.
    # No global Jupyter configuration, credentials, runtimes or libraries change.
    cpu_path=ROOT/'colab_packages/00_ITERATIVE_CPU_FIXTURE_CHECK.ipynb'
    cpu=nbformat.read(cpu_path,as_version=4);cpu_state='NOT_EXECUTED';cpu_gap=None
    try:
        from nbclient import NotebookClient
        import ipykernel
        from jupyter_client import KernelManager
        from jupyter_client.kernelspec import KernelSpecManager
        kernels=stage/'kernels';kernel_dir=kernels/'itkd_cpu';kernel_dir.mkdir(parents=True)
        atomic_json(kernel_dir/'kernel.json',{'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],
                    'display_name':'Task-local iterative CPU','language':'python'})
        manager=KernelManager(kernel_name='itkd_cpu',kernel_spec_manager=KernelSpecManager(kernel_dirs=[str(kernels)]))
        client=NotebookClient(cpu,km=manager,timeout=300)
        client.execute(cwd=str(extracted),env={**env,'ITKD_PARENT_ROOT':str(extracted),'ITKD_TEST_PYTHON':sys.executable})
        executed=stage/'CPU_FIXTURE_EXECUTED.ipynb';nbformat.write(cpu,executed);nbformat.validate(cpu)
        output='\n'.join(''.join(o.get('text','')) for c in cpu.cells if c.cell_type=='code' for o in c.get('outputs',[]) if o.output_type=='stream')
        if 'CPU_FIXTURE_PASS_ONLY' not in output:raise ValueError('Executed CPU notebook PASS marker missing')
        (stage/'CPU_NOTEBOOK_OUTPUT.log').write_text(output,encoding='utf8');cpu_state='EXECUTED_CPU_PASS_TEXT_OUTPUT_INSPECTED'
    except ImportError as error:
        cpu_gap=f'Missing local notebook execution dependency: {getattr(error,"name",None) or type(error).__name__}; exact CPU subprocess tests passed; no installation performed'
    result={'state':'EXTRACTED_CPU_PACKAGE_ACCEPTANCE_PASS','verified_at_utc':datetime.now(timezone.utc).isoformat(),
            'python':sys.executable,'python_version':sys.version,'code_id':delivery['code_id'],
            'ZIP_sha256':delivery['ZIP_sha256'],'ZIP_bytes':archive.stat().st_size,'ZIP_CRC':True,
            'new_source_manifest_verified':True,'original_parent_code_preserved':verify_parent(),
            'commands':commands,'notebooks':notebooks,'CPU_notebook':cpu_state,'CPU_notebook_gap':cpu_gap,
            'stage':str(stage),'plan':plan,'actual_pretrained_source_new_stage_check':False,
            'actual_new_CUDA':False,'actual_Colab_training':False,'actual_Drive_quota':'NOT_OBSERVED_STORAGE_CAPACITY_PENDING'}
    reports=ROOT/'reports';reports.mkdir(exist_ok=True)
    atomic_json(reports/'PACKAGE_ACCEPTANCE.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('commands','plan','notebooks')},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
