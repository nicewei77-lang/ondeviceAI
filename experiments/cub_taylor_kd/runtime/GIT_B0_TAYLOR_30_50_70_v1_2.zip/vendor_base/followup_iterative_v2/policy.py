"""Global-budget schedule independent of pruning stage and checkpoint selection."""
from dataclasses import asdict, dataclass
from fractions import Fraction
import math
from .common import identity

@dataclass(frozen=True)
class Recipe:
    dataset: str
    arm: str
    target_percent: int
    budget: int
    seed: int
    source_id: str
    protocol_id: str
    code_id: str
    fixture: bool = False

    def __post_init__(self):
        if self.arm not in ('D0', 'OS', 'IT') or self.dataset not in ('cub200', 'flowers102', 'aircraft', 'fixture'):
            raise ValueError('Unknown arm/dataset')
        if type(self.target_percent) is not int or self.target_percent not in (0, 30, 50, 70):
            raise ValueError('Invalid final target')
        if (self.arm == 'D0') != (self.target_percent == 0):
            raise ValueError('Only D0 has zero target')
        if type(self.budget) is not int or self.budget not in (20, 40):
            raise ValueError('Budget must be independently planned20 or planned40')
        if type(self.seed) is not int or self.seed < 0 or type(self.fixture) is not bool:
            raise ValueError('Invalid seed/fixture flag')
        if (self.dataset == 'fixture') != self.fixture:
            raise ValueError('Fixture must use its explicit separate dataset')
        for digest in (self.source_id, self.protocol_id, self.code_id):
            if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
                raise ValueError('Recipe requires SHA-256 identities')

    @property
    def contract_id(self):
        return identity(asdict(self))

    def stage(self, epoch):
        if type(epoch) is not int or not 0 <= epoch < self.budget:
            raise ValueError('Epoch outside planned budget')
        return epoch // (self.budget // 4)

    def stage_start(self, epoch):
        return epoch % (self.budget // 4) == 0

    def eligible(self, epoch):
        return self.stage(epoch) == 3

    def width(self, original_hidden, stage):
        if type(original_hidden) is not int or original_hidden < 1 or type(stage) is not int or not 0 <= stage < 4:
            raise ValueError('Invalid width/stage')
        step = 0 if self.arm == 'D0' else (4 if self.arm == 'OS' else stage + 1)
        value = Fraction(original_hidden * (400 - self.target_percent * step), 400)
        return -(-value.numerator // value.denominator)

    def learning_factor(self, epoch, warmup=5):
        self.stage(epoch)
        warmup = min(warmup, self.budget)
        if warmup < 1:
            raise ValueError('Warmup must be positive')
        return min(1.0, (epoch + 1) / warmup) * 0.5 * (1 + math.cos(math.pi * epoch / self.budget))

    def epoch_seed(self, epoch):
        self.stage(epoch)
        return self.seed + epoch * 100003

def choose_best(previous, candidate):
    """Accuracy max; CE min; earliest global epoch on exact ties."""
    for key in ('accuracy_pct', 'loss'):
        if not math.isfinite(candidate[key]):
            raise FloatingPointError('Nonfinite validation metric')
    score = lambda x: (-x['accuracy_pct'], x['loss'], x['epoch'])
    return previous is None or score(candidate) < score(previous)
