"""Content identities, immutable records and atomic checkpoint commit pointers."""
from __future__ import annotations
import hashlib
import io
import json
import os
from pathlib import Path
import uuid
import time
import torch

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent

def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False).encode('utf8')).hexdigest()

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        with temporary.open('w', encoding='utf8', newline='\n') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, path)
                break
            except PermissionError as error:
                if getattr(error,'winerror',None) not in (5,32,33) or attempt==5:
                    raise
                time.sleep(.05*(attempt+1))
    finally:
        temporary.unlink(missing_ok=True)

def immutable_json(path, value):
    path = Path(path)
    if path.exists():
        if read(path) != value:
            raise ValueError('Immutable record differs: ' + str(path))
        return
    atomic_json(path, value)  # Caller must hold the single assigned writer lease.

def has_commit(directory):
    from .model_store import get_store
    return get_store(directory).pointer() is not None


def save_commit(directory, payload, *, tag):
    """Verified fixed-head update, then pointer commit; no epoch blob creation."""
    from .model_store import get_store
    if not payload.get('execution',{}).get('recipe',{}).get('fixture',False):
        from .local_disk import record
        record(directory,'before_Teacher_checkpoint_commit')
    return get_store(directory).commit(payload)


def load_commit(directory):
    from .model_store import get_store
    payload,ref=get_store(directory).load()
    for key in ('kind','next_epoch','contract_id','model_digest','stage'):
        if payload[key]!=ref[key]:raise ValueError('Bounded checkpoint pointer/payload differ')
    return payload,ref


def save_best(directory,payload):
    from .model_store import get_store
    return get_store(directory).save_best(payload)


def model_bytes(directory,reference):
    from .model_store import get_store
    return get_store(directory).read_ref(reference)


def verify_parent():
    frozen = read(PARENT / 'FROZEN_SOURCE.json') if (PARENT / 'FROZEN_SOURCE.json').is_file() else read(PARENT / 'colab_packages/RUNNER_FROZEN_SOURCE.json')
    if frozen['code_id'] != '082f46e63640d338d91e9bcf62734610b65243b08ef45e663191afcce36841a4':
        raise ValueError('Unexpected frozen parent')
    for name, wanted in frozen['sha256'].items():
        if sha(PARENT / name) != wanted:
            raise ValueError('Frozen parent modified: ' + name)
    return frozen['code_id']
