"""Validation-only decisions. Draft policy is not a research activation approval."""
import math
from pathlib import Path
from .common import identity, read, sha, immutable_json

PENDING = {'PENDING', 'PENDING_FULL60', 'NOT_ACTIVATED', 'RUNNING'}
VALID = {'VALID', 'complete'}
COLLAPSE = 'NOT_RUN_TEACHER_COLLAPSE'

def preserved(control, method):
    return method['oa'] - control['oa'] >= -1.0 and method['hard'] - control['hard'] >= -2.0

def budget_assessment(control, os_row, it_row):
    rows = [control, os_row, it_row]
    if control is not None and control.get('state', 'VALID') not in VALID | PENDING:
        return {'state': 'INVALID_CONTROL_HOLD', 'eligible': None}
    if any(r is not None and r.get('state', 'VALID') not in VALID | PENDING | {COLLAPSE} for r in rows[1:]):
        return {'state': 'ERROR_HOLD', 'eligible': None}
    if control is None or control.get('state', 'VALID') in PENDING or control.get('completed_epochs', 60) < 60:
        return {'state': 'PENDING_FULL60', 'eligible': None}
    for row in rows:
        if row is not None and row.get('state', 'VALID') in VALID:
            if not all(type(row.get(k)) in (int, float) and math.isfinite(row[k]) and 0 <= row[k] <= 100 for k in ('oa', 'hard')):
                return {'state': 'INVALID_CONTROL_HOLD' if row is control else 'ERROR_HOLD', 'eligible': None}
    if any(r is not None and r.get('state') == COLLAPSE for r in rows[1:]):
        return {'state': 'ASSESSED', 'eligible': False, 'paired_viable': False, 'reason': 'Teacher class collapse'}
    if any(r is None or r.get('state', 'VALID') in PENDING or r.get('completed_epochs', 60) < 60 for r in rows[1:]):
        return {'state': 'PENDING_FULL60', 'eligible': None}
    passes = {'OS': preserved(control, os_row), 'IT': preserved(control, it_row)}
    return {'state': 'ASSESSED', 'eligible': any(passes.values()), 'paired_viable': True, 'passes': passes}

def choose_budget(dataset, e20, e40, target, *, fallback_used=False):
    for value in (e20, e40):
        if value in ('ERROR_HOLD', 'INVALID_CONTROL_HOLD'):
            return value
        if value not in (True, False, None):
            raise ValueError('Eligibility must be bool/None or explicit HOLD')
    if e20 is None:
        return 'PENDING_B20'
    if dataset in ('cub', 'cub200') and e40 is None:
        return 'PENDING_CUB_FACTORIAL_B40'
    if e20:
        return 'SELECT_B20'
    if e40 is None:
        return 'PENDING_B40'
    if e40:
        return 'SELECT_B40'
    if target == 70 and not fallback_used:
        return 'ACTIVATE_SHARED_R50_B20'
    return 'PRESERVATION_NOT_FOUND'

def teacher_collapsed(selected, classes):
    return selected['oa'] <= max(5.0, 200 / classes) and selected['max_predicted_class_fraction'] >= 0.99

def validation_record(path, expected, *, root):
    """Whitelist one exact validation artifact and its SHA, never a user glob."""
    path, root = Path(path).resolve(), Path(root).resolve()
    if not path.is_relative_to(root) or path.name != 'VALIDATION.json' or any('test' in part.lower() for part in path.relative_to(root).parts):
        raise ValueError('Selector accepts only whitelisted VALIDATION.json paths')
    if sha(path) != expected['sha256']:
        raise ValueError('Validation artifact SHA changed')
    record = read(path)
    required = {'split', 'dataset', 'arm', 'budget', 'target_percent', 'seed', 'state', 'completed_epochs',
                'oa', 'hard', 'teacher', 'student', 'split_id', 'hard_id', 'initial_id', 'baseline', 'protocol_id', 'code_id'}
    if set(record) != required or record['split'] != 'validation' or record['state'] != 'complete' or record['completed_epochs'] != 60:
        raise ValueError('Only full60 validation evidence is admissible')
    for key, value in expected['identity'].items():
        if record.get(key) != value:
            raise ValueError('Validation record identity differs: ' + key)
    return record

def final_recommendation(records, recovery_costs):
    if set(records) != {'D0', 'OS', 'IT'} or any(set(records[a]) != {42, 43, 44} for a in records):
        raise ValueError('Final selection requires all three arms and all three seeds')
    for arm in records:
        for row in records[arm].values():
            if not all(type(row.get(k)) in (int,float) and math.isfinite(row[k]) and 0<=row[k]<=100 for k in ('oa','hard')):
                raise ValueError('ERROR_HOLD: final validation metrics missing/nonfinite/out of range')
    passes, differences = {}, {}
    for arm in ('OS', 'IT'):
        diff = {k: sum(records[arm][s][k] - records['D0'][s][k] for s in (42, 43, 44)) / 3 for k in ('oa', 'hard')}
        differences[arm] = diff
        passes[arm] = diff['oa'] >= -1.0 and diff['hard'] >= -2.0
    candidates = [a for a in ('OS', 'IT') if passes[a]]
    if len(candidates)==1:
        recommendation = candidates[0]
    elif len(candidates)==2:
        costs = {a:recovery_costs.get(a) for a in candidates}
        valid = all(isinstance(c,dict) and c.get('complete') is True and
                    type(c.get('recovery_allocated_wall_ms')) is int and c['recovery_allocated_wall_ms']>=0 for c in costs.values())
        profiles = [{k:v for k,v in c.get('profile',{}).items() if k!='gpu_uuid'} for c in costs.values()] if valid else []
        if not valid or profiles[0]!=profiles[1]:
            recommendation = 'RECOMMENDATION_HOLD_COST_INCOMPLETE'
        else:
            os_ms,it_ms = (costs[a]['recovery_allocated_wall_ms'] for a in ('OS','IT'))
            tolerance = max(1000, math.ceil(.01*min(os_ms,it_ms)))
            if abs(os_ms-it_ms)>tolerance:
                recommendation = 'OS' if os_ms<it_ms else 'IT'
            else:
                recommendation = min(candidates,key=lambda a:(-sum(records[a][s]['hard'] for s in records[a])/3,
                    -sum(records[a][s]['oa'] for s in records[a])/3,0 if a=='OS' else 1))
    else:
        recommendation = 'D0'
    return {'recommendation': recommendation, 'paired_mean_differences_pp': differences,
            'preserved': passes, 'Test_conditions': ['D0', 'OS', 'IT'], 'Test_used_for_selection': False}

def freeze_test_lock(path, payload, *, lease):
    lease.assert_output_path(path)
    if payload.get('split') != 'validation' or payload.get('selector_state') != 'FROZEN_REVIEWED':
        raise ValueError('Unreviewed/non-validation selector cannot authorize Test')
    if set(payload.get('arms', {})) != {'D0', 'OS', 'IT'}:
        raise ValueError('Lock must contain all predeclared arms')
    for arm, seeds in payload['arms'].items():
        if set(seeds) != {'42', '43', '44'}:
            raise ValueError('Lock requires complete three-seed comparison')
        for seed, row in seeds.items():
            if row['completed_epochs'] != 60 or row['validation']['split'] != 'validation':
                raise ValueError('Incomplete/incorrect lock evidence')
            for name in ('teacher', 'student', 'validation', 'baseline'):
                if not row[name].get('sha256'):
                    raise ValueError('Lock artifact SHA missing')
    lock = {**payload, 'lock_id': identity(payload)}
    immutable_json(path, lock)
    return lock

def require_test_lock(lock, *, expected_id, actual_artifacts):
    payload = {k: v for k, v in lock.items() if k != 'lock_id'}
    if lock.get('lock_id') != expected_id or identity(payload) != expected_id or lock.get('selector_state') != 'FROZEN_REVIEWED':
        raise ValueError('Test selection lock changed/unreviewed')
    for arm in ('D0', 'OS', 'IT'):
        for seed in ('42', '43', '44'):
            frozen = lock['arms'][arm][seed]
            current = actual_artifacts[arm][seed]
            for key in ('teacher', 'student', 'validation', 'baseline'):
                if frozen[key] != current[key]:
                    raise ValueError('Actual Test consumer differs from frozen selection')
    return True
