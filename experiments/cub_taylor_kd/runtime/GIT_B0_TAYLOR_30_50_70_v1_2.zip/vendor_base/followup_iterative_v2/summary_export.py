"""Small evidence-only analysis export; model/optimizer/logit payloads stay in Drive."""
from pathlib import Path
import json
import zipfile
from .common import read,sha,identity,atomic_json

MAX_ANALYSIS_BYTES=128*1024**2
NAMES={'history.json','status.json','contract.json','COMPLETE.json','EVALUATION_COMPLETE.json',
       'VALIDATION.json','TEST_SUMMARY.json','RECOVERY_COST.json','profile.json','ERROR.json',
       'RECOVERED_CUDA_GATE.json','SOURCE_STAGE_CUDA_GATE.json','STORAGE_CAPACITY_GATE.json',
       'LOCAL_DISK_GATE.json','BUDGET_REVIEW.json','FINAL_SELECTION_LOCK.json','SOURCE_GATE_READY.json',
       'ACTUAL_CUDA_REVIEW.json','execution.json','LOCAL_DISK_START.json','LOCAL_CACHE_INVENTORY.json',
       'REMOTE_MODEL_SEALS.json','VALIDATION_METRICS.json','LOCAL_DISK_LATEST.json','LOCAL_DISK_SAMPLES.jsonl',
       'STORAGE_ACCOUNTING.json','PROVIDER_PROBE.json'}

def selected_files(root,*,excluded_root=None):
    root=Path(root).resolve();excluded=Path(excluded_root).resolve() if excluded_root else None
    result=[]
    for p in root.rglob('*'):
        if not p.is_file() or p.is_symlink():continue
        resolved=p.resolve()
        if not resolved.is_relative_to(root):raise ValueError('Analysis export escapes experiment root')
        if excluded and resolved.is_relative_to(excluded):continue
        if p.suffix=='.csv' or p.name in NAMES or (p.suffix=='.json' and p.name.startswith(('BOUNDARY_','TRANSACTION_'))):
            if p.suffix in ('.pt','.pth','.safetensors','.onnx','.zip'):
                raise ValueError('Large model/logit payload is forbidden in PC analysis export')
            result.append(p)
    return sorted(result)

def export_bundle(root,output,*,metadata,excluded_root=None,max_bytes=MAX_ANALYSIS_BYTES):
    root,output=Path(root).resolve(),Path(output).resolve()
    files=selected_files(root,excluded_root=excluded_root)
    import csv
    def check(value):
        if isinstance(value,dict):
            for key,part in value.items():
                if key in ('model_state','optimizer_state','scaler_state','rng_state') or (key=='logits' and isinstance(part,(list,dict))):
                    raise ValueError('Forbidden tensor/state payload in PC evidence export')
                check(part)
        elif isinstance(value,list):
            for part in value:check(part)
    for path in files:
        if path.suffix=='.json':check(read(path))
        elif path.suffix=='.csv':
            with path.open(encoding='utf8',newline='') as stream:header=next(csv.reader(stream),[])
            if header!=['image_id','label','prediction','CE','entropy','correct','is_hard']:
                raise ValueError('Only label/prediction/CE summary CSV is allowed; no full logits')
    total=sum(p.stat().st_size for p in files)
    if total>max_bytes:
        raise ValueError('ANALYSIS_EXPORT_HOLD: evidence exceeds128MiB; no model download fallback')
    manifest={'schema':'iterative.small_analysis.v2','metadata':metadata,
              'model_checkpoint_files_included':0,'optimizer_files_included':0,'raw_logit_tensor_files_included':0,
              'uncompressed_limit_bytes':max_bytes,'source_bytes':total,
              'files':[{'path':p.relative_to(root).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in files]}
    encoded=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf8')
    if total+len(encoded)>max_bytes:raise ValueError('Analysis manifest exceeds total export cap')
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary=output.with_suffix('.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as archive:
        for p in files:archive.write(p,p.relative_to(root).as_posix())
        archive.writestr('ANALYSIS_MANIFEST.json',encoded)
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:raise ValueError('Analysis ZIP CRC failed')
        if sum(i.file_size for i in archive.infolist())>max_bytes:raise ValueError('Analysis ZIP extracted size cap exceeded')
    if temporary.stat().st_size>max_bytes:raise ValueError('Analysis ZIP download cap exceeded')
    temporary.replace(output)
    return {'schema':'iterative.small_analysis.v2','path':str(output),'sha256':sha(output),'bytes':output.stat().st_size,
            'uncompressed_bytes':total+len(encoded),'file_count':len(files),'large_checkpoints_included':False,
            'raw_logits_included':False,'manifest_id':identity(manifest)}

def run_export(work,assignment,contract,lease):
    from .execution import output_root
    experiment=output_root(work).parent
    record=export_bundle(experiment,lease.output_dir/'ANALYSIS_BUNDLE.zip',excluded_root=lease.output_dir,
          metadata={'namespace':contract['namespace'],'contract_id':contract['contract_id'],
                    'code_id':contract['code_id'],'assignment_id':assignment['assignment_id'],
                    'scope':'Colab-computed metrics/history/per-sample predictions and hashes; no PC model execution'})
    atomic_json(lease.output_dir/'ANALYSIS_BUNDLE.json',record)
    return {'state':'complete','kind':'analysis_export','frozen_contract_id':contract['contract_id'],'bundle':record}
