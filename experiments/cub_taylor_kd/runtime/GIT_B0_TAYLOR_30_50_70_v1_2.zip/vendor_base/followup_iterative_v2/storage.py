"""Append-only disk estimate and authenticated Google Drive storageQuota gate."""
from dataclasses import replace
from datetime import datetime,timezone
import math
from pathlib import Path
from .common import ROOT,PARENT,read,identity
from .graph import ARMS,SEEDS,TARGETS,teacher,student,active_jobs,decision
from .policy import Recipe

MIB=1024**2
GIB=1024**3

def parameters(dataset,recipe,stage):
    pins=read(ROOT/'assets/source_pins.json')['datasets'][dataset]
    dense=next(b['parameters'] for b in pins['branches'] if b['ratio']==0.)
    spec=pins['base_reference']['model_spec']
    return dense+sum(depth*(recipe.width(4*dim,stage)-4*dim)*(2*dim+1) for depth,dim in zip(spec['depths'],spec['dims']))

def teacher_bytes(dataset,arm,budget,target):
    recipe=Recipe(dataset,arm,0 if arm=='D0' else target,budget,20261013,'a'*64,'b'*64,'c'*64)
    sizes=[parameters(dataset,recipe,stage) for stage in range(4)]
    resume_heads=3*(12*sizes[0]+8*MIB)
    best_heads=3*(4*sizes[-1]+8*MIB)
    anchors=sum(4*p+8*MIB for p in sizes)+sum(4*p+8*MIB for p in sizes[:3])
    return {'parameters_by_stage':sizes,'resume_heads_bytes':resume_heads,'best_heads_bytes':best_heads,
            'stage_anchor_bytes':anchors,'single_upload_spare_bytes':12*sizes[0]+8*MIB,
            'total_bytes':resume_heads+best_heads+anchors}


def estimate(jobs):
    teachers=[];students=[]
    for job in sorted(jobs):
        if job.stage.startswith('t_'):
            _,arm,b=job.stage.split('_');teachers.append({'job_id':job.job_id,**teacher_bytes(job.dataset,arm.upper(),int(b[1:]),job.ratio)})
        elif job.stage.startswith('s_'):
            students.append(job.job_id)
    raw=sum(t['total_bytes'] for t in teachers)+len(students)*128*MIB+3*256*MIB+max((t['single_upload_spare_bytes'] for t in teachers),default=0)
    needed=math.ceil(raw*1.10)+5*GIB
    return {'estimated_bytes':raw,'required_free_bytes_with_headroom':needed,'required_free_GiB':needed/GIB,
            'teacher_jobs':teachers,'student_jobs':students,'Student_storage_reserve_per_job_bytes':128*MIB,
            'headroom':'10 percent plus5GiB; unbounded repeated failures not predicted',
            'dtype_assumption':'FP32 model/master, Adam first and second moments FP32; actual tensor schema checked during runtime commits',
            'retention':'per_Teacher_3resume_3best_7anchors_no_delete_API','is_measured_checkpoint_size':False}

def plans():
    base={decision('cub200',20,30).job_id:{'state':'complete','kind':'validation_decision','dataset':'cub200','target_percent':30,'action':'SELECT_B20'}}
    for d,r in (('flowers102',70),('aircraft',30)):
        base[decision(d,20,r).job_id]={'state':'complete','kind':'validation_decision','dataset':d,'target_percent':r,'action':'SELECT_B20'}
    default=estimate(active_jobs(base,expand=True,main=True))
    for d,r in (('flowers102',70),('aircraft',30)):
        base[decision(d,20,r).job_id]['action']='ACTIVATE_B40'
        base[decision(d,40,r).job_id]={'state':'complete','kind':'validation_decision','dataset':d,'target_percent':r,
                                     'action':'ACTIVATE_SHARED_R50_B20' if d=='flowers102' else 'SELECT_B40'}
    base[decision('flowers102',20,50).job_id]={'state':'complete','kind':'validation_decision','dataset':'flowers102','target_percent':50,'action':'ACTIVATE_B40'}
    base[decision('flowers102',40,50).job_id]={'state':'complete','kind':'validation_decision','dataset':'flowers102','target_percent':50,'action':'SELECT_B40'}
    return {'pilot':estimate(active_jobs({})),'default_full':default,'maximum_full':estimate(active_jobs(base,expand=True,main=True))}

def required_remaining(work=None,assignment=None,*,full_workflow=True):
    plan=plans()['maximum_full' if full_workflow else 'pilot']
    if assignment is None:
        return plan['required_free_bytes_with_headroom']
    from .execution import job_dir
    from .graph import all_jobs
    jobs={j.job_id:j for j in all_jobs()}
    raw=0
    from .model_store import metadata_accounting
    from .pipeline import recipe_for
    contract=read(Path(work).parent/'control/contract.json')
    for row in plan['teacher_jobs']:
        job=jobs[row['job_id']];directory=job_dir(work,assignment,job)
        allocated=0
        if directory.exists():
            accounting=metadata_accounting(directory,recipe_for(contract,job))
            allocated=sum(r['bytes'] for r in accounting['files'].values())
            if allocated<0 or allocated>row['total_bytes']:raise ValueError('Owned model accounting exceeds schema bound')
        raw+=max(0,row['total_bytes']-allocated)
    raw+=max((t['single_upload_spare_bytes'] for t in plan['teacher_jobs']),default=0)
    completed_students=0
    for job in jobs.values():
        marker=job_dir(work,assignment,job)/'COMPLETE.json'
        if job.stage.startswith('s_') and marker.exists():
            record=read(marker)
            completed_students+=int(record.get('kind')=='student' and record.get('result_state')=='complete' and record.get('completed_epochs')==60)
    raw+=max(0,len(plan['student_jobs'])-completed_students)*128*MIB+3*256*MIB
    return math.ceil(raw*1.10)+5*GIB

def validate_committed_progress(work,assignment,contract):
    """Cold-process metadata-only binding proof before remaining-capacity credit."""
    from dataclasses import asdict
    from .execution import job_dir,completion,controls
    from .graph import all_jobs,partition
    from .pipeline import recipe_for
    from .model_store import metadata_accounting
    from phaseb.native import config
    for job in all_jobs():
        complete=completion(work,assignment,job)
        if not job.stage.startswith('t_'):continue
        directory=job_dir(work,assignment,job)
        if not directory.exists():
            if complete is not None:raise ValueError('Completed Teacher directory is absent')
            continue
        recipe=recipe_for(contract,job);record=metadata_accounting(directory,recipe);pointer=record['pointer']
        if pointer is None:
            if complete is not None:raise ValueError('Completed Teacher has no committed pointer')
            continue
        current=pointer['active'];e=current['next_epoch']
        if current['contract_id']!=recipe.contract_id or type(e) is not int or not 0<=e<=recipe.budget or current['kind'] not in ('epoch','boundary'):
            raise ValueError('Persisted committed epoch/contract differs')
        stage=recipe.stage(e if current['kind']=='boundary' else e-1)
        runtime=read(controls(work)/f'runtime_{partition()[job]}.json')['runtime']
        execution={'recipe':asdict(recipe),'config':config(job.dataset),'runtime':runtime,'head_warmup_epochs':0,
            'optimizer_policy':'fresh_each_of_four_boundaries','scaler_policy':'fresh_each_of_four_boundaries',
            'best_policy':'final_quarter_OA_CE_earliest','checkpoint_policy':'per_job_3resume_3best_7anchors_v2_1'}
        if current['stage']!=stage or current['applied_boundaries']!=list(range(stage+1)) or current['execution_id']!=identity(execution):
            raise ValueError('Persisted stage/runtime/recipe binding differs')
        if complete is not None and (complete.get('commit')!=current or complete.get('completed_epochs')!=recipe.budget or e!=recipe.budget):
            raise ValueError('Completed Teacher pointer/budget differs')
    return True


def evaluate_quota(about,folder,required_bytes):
    if folder.get('ownedByMe') is not True or folder.get('mimeType')!='application/vnd.google-apps.folder':
        raise ValueError('Quota principal must own the exact intended MyDrive project folder')
    quota=about.get('storageQuota',{})
    if not str(quota.get('usage','')).isdigit():
        raise ValueError('Authoritative Drive total usage is unavailable')
    limit=quota.get('limit')
    if limit is not None and not str(limit).isdigit():
        raise ValueError('Drive quota limit is invalid')
    free=None if limit is None else max(0,int(limit)-int(quota['usage']))
    if free is not None and free<required_bytes:
        raise ValueError(f'STORAGE_HOLD: Drive free{free} bytes below declared v2 bounded-schema requirement{required_bytes}; no deletion/purchase fallback')
    principal=about.get('user',{}).get('permissionId')
    if not principal:
        raise ValueError('Quota principal identity is missing')
    return {'state':'PASS','evidence':'authenticated_Google_Drive_about_storageQuota','checked_at_utc':datetime.now(timezone.utc).isoformat(),
            'project_folder_id':folder['id'],'principal_id_sha256':identity(principal),'quota':quota,
            'free_bytes':free,'unlimited_limit_omitted':limit is None,'required_bytes':required_bytes,
            'scope':'API reports account or organization-pooled total-service quota; account type is not inferred; no reservation against concurrent unrelated writes',
            'official_reference':'https://developers.google.com/workspace/drive/api/reference/rest/v3/about'}

def live_quota(required_bytes):
    import google.auth
    from googleapiclient.discovery import build
    mapping=read(ROOT/'assets/DRIVE_DESTINATION.json')
    credentials,_=google.auth.default()  # User's normal Colab authentication, never persisted here.
    service=build('drive','v3',credentials=credentials,cache_discovery=False)
    about=service.about().get(fields='storageQuota,user(permissionId)').execute()
    folder=service.files().get(fileId=mapping['project_folder_id'],fields='id,mimeType,ownedByMe').execute()
    return evaluate_quota(about,folder,required_bytes)
