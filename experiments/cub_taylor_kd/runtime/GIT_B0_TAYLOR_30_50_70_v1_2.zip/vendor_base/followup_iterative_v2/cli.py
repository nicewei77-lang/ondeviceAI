"""Public single-runtime CLI entrypoint; v1 remains unchanged."""
from .single_cli import *

if __name__ == "__main__":
    main()
