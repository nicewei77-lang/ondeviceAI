"""All possible jobs are pinned; activation is a validation-driven subset."""
from collections import Counter
from phaseb.ownership import JobKey

TARGETS = {'cub200': (30,), 'flowers102': (70,50), 'aircraft': (30,)}
ARMS = ('D0','OS','IT')
SEEDS = (42,43,44)

def teacher(dataset, arm, budget, ratio):
    return JobKey(dataset, f't_{arm.lower()}_b{budget}', 0 if arm=='D0' else ratio, 20261013)

def student(dataset, arm, budget, ratio, seed):
    return JobKey(dataset, f's_{arm.lower()}_b{budget}', 0 if arm=='D0' else ratio, seed)

def decision(dataset, budget, ratio):
    return JobKey(dataset, f'decide_b{budget}', ratio, 0)

def select(dataset):
    return JobKey(dataset, 'select', 0, 0)

def all_jobs():
    jobs = {JobKey('all','aggregate',None,None), JobKey('all','activate_p2',0,0),
            JobKey('all','activate_p3',0,0), JobKey('all','close_workflow',0,0), JobKey('all','source_review',0,0),
            JobKey('all','release_a',0,0), JobKey('all','analysis_export',0,0),JobKey('all','storage_probe',0,0)}
    for dataset, targets in TARGETS.items():
        for budget in (20,40):
            for target in targets:
                for arm in ARMS:
                    jobs.add(teacher(dataset,arm,budget,target))
                    jobs.update(student(dataset,arm,budget,target,s) for s in SEEDS)
                if dataset!='cub200' or budget==20:
                    jobs.add(decision(dataset,budget,target))
        jobs.add(select(dataset))
        jobs.add(JobKey(dataset,'finalizer',None,None))
    return sorted(jobs)

def partition():
    """One pruning runtime owns every job; data-loader workers are unchanged."""
    return {job:'A' for job in all_jobs()}

def triplet(dataset,budget,ratio,seeds=(42,)):
    return {teacher(dataset,a,budget,ratio) for a in ARMS} | {student(dataset,a,budget,ratio,s) for a in ARMS for s in seeds}

def active_jobs(receipts, *, expand=False, main=False):
    """Only immutable completed decision receipts can activate later jobs."""
    active = {JobKey('all','aggregate',None,None),JobKey('all','storage_probe',0,0)} | triplet('cub200',20,30) | triplet('cub200',40,30)
    active.add(decision('cub200',20,30))
    if expand:
        for dataset,ratio in (('flowers102',70),('aircraft',30)):
            active.update(triplet(dataset,20,ratio));active.add(decision(dataset,20,ratio))
    grid={j.job_id:j for j in all_jobs()}
    pending={k:v for k,v in receipts.items() if v and v.get('state')=='complete' and v.get('kind')=='validation_decision'}
    for job_id,record in pending.items():
        key=grid.get(job_id)
        if key is None or not key.stage.startswith('decide_') or record.get('dataset')!=key.dataset or record.get('target_percent')!=key.ratio:
            raise ValueError('Decision payload does not bind its exact job identity')
        action=record.get('action')
        if action=='ACTIVATE_B40' and key.stage!='decide_b20':
            raise ValueError('Only B20 decision can activate B40')
        if action=='ACTIVATE_SHARED_R50_B20' and (key.dataset!='flowers102' or key.ratio!=70 or key.stage!='decide_b40'):
            raise ValueError('Only the completed Flowers70 B40 chain can activate fallback')
        if action=='SELECT_B40' and key.dataset!='cub200' and key.stage!='decide_b40':
            raise ValueError('B40 cannot be selected before its diagnosis')
    while pending:
        progressed=False
        for job_id in sorted(list(pending)):
            if grid[job_id] not in active:
                continue
            record=pending.pop(job_id);progressed=True
            dataset,ratio,action=record['dataset'],record['target_percent'],record['action']
            if action=='ACTIVATE_B40':
                active.update(triplet(dataset,40,ratio));active.add(decision(dataset,40,ratio))
            elif action=='ACTIVATE_SHARED_R50_B20':
                active.update(triplet(dataset,20,50));active.add(decision(dataset,20,50))
            elif action in ('SELECT_B20','SELECT_B40'):
                if main:
                    budget=int(action[-2:]);active.update(triplet(dataset,budget,ratio,SEEDS))
                    active.add(select(dataset));active.add(JobKey(dataset,'finalizer',None,None))
            elif action!='PRESERVATION_NOT_FOUND':
                raise ValueError('Unrecognized/nonterminal activation decision')
        if not progressed:
            raise ValueError('Decision chain is not reachable from approved activations')
    if not active.issubset(set(all_jobs())):
        raise ValueError('Activation escaped frozen possible graph')
    return active

def counts(jobs):
    jobs = list(jobs)
    teachers = [j for j in jobs if j.stage.startswith('t_')]
    students = [j for j in jobs if j.stage.startswith('s_')]
    return {'teacher':len(teachers),'student_full60':len(students),
            'teacher_epochs':sum(int(j.stage.rsplit('b',1)[1]) for j in teachers),
            'student_epochs':60*len(students), 'slot_counts':dict(Counter(partition()[j] for j in jobs))}
