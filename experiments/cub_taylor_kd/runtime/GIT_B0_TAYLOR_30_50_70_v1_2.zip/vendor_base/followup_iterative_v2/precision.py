"""New stage-aware actual CUDA gate, reusing the frozen zero-step probe kernel."""
from copy import deepcopy
import gc
import torch
from phaseb import precision as kernel
from .common import identity

def probe_candidate(dataset, config, train_data, val_data, teacher_builder, student_builder,
                    native_train, *, reference, candidate, contract_id, epoch=0, min_batches=3):
    if min_batches < 3 or type(min_batches) is not int:
        raise ValueError('At least three actual batches per split are required')
    # The hardware guard precedes builders/loaders and cannot produce CPU PASS.
    device, runtime = kernel.require_l4_cuda('cuda')
    if reference.get('test_fixture') is not False or not reference.get('model_digest') or not reference.get('sha256'):
        raise ValueError('A verified real source/checkpoint reference is required')
    previous = native_train.rng_state()
    teacher = student = None
    rows = []
    try:
        teacher = kernel._prepare_model(teacher_builder(), device)
        student = kernel._prepare_model(student_builder(), device)
        teacher_optimizer = torch.optim.AdamW(teacher.parameters(), lr=0.)
        student_optimizer = torch.optim.AdamW(student.parameters(), lr=0.)
        teacher_scaler = torch.amp.GradScaler('cuda')
        student_scaler = torch.amp.GradScaler('cuda')
        for split, data in (('train', train_data), ('validation', val_data)):
            loader = kernel._loader(data, split, config, native_train, 42, epoch)
            if len(loader) < min_batches:
                raise ValueError('Actual dataset has insufficient batches')
            for batch_index, (images, labels, ids) in enumerate(loader):
                if batch_index >= min_batches:
                    break
                ids = kernel._ids(ids)
                if images.dtype != torch.float32 or images.shape[0] != len(ids):
                    raise ValueError('Actual Native image batch differs')
                images, labels = images.to(device), labels.to(device)
                def row(role):
                    value = kernel._row(dataset, candidate['target_percent']/100, 'iterative_stage', split, batch_index, ids, role, images)
                    value['candidate'] = deepcopy(candidate)
                    return value
                value = row('teacher_recovery')
                rows.append(kernel._backward(teacher, images, labels, None, value, teacher_optimizer,
                                             teacher_scaler, native_train, config, device))
                teacher.eval().requires_grad_(False)
                value = row('teacher_frozen')
                with torch.no_grad(), torch.autocast('cuda', dtype=torch.float16):
                    logits = teacher(images).float()
                kernel._finite_logits(logits, value, config['num_classes'])
                value.update(status='PASS')
                rows.append(value)
                value = row('student_kd')
                rows.append(kernel._backward(student, images, labels, logits, value, student_optimizer,
                                             student_scaler, native_train, config, device))
        receipt = {'schema': 'iterative.cuda.v1', 'state': 'PASS', 'evidence_kind': 'actual_cuda_l4_stage_probe',
                   'contract_id': contract_id, 'dataset': dataset, 'candidate': candidate,
                   'reference': reference, 'runtime': runtime, 'config_id': identity(config), 'rows': rows,
                   'optimizer_steps': 0, 'model_file_writes': 0, 'min_batches_per_split': min_batches,
                   'scope': 'Sampled actual images; single-microbatch AMP output/loss/unscaled-gradient checks; no full-epoch claim'}
        require_candidate(receipt, contract_id=contract_id, candidate=candidate, reference=reference)
        return receipt
    finally:
        native_train.restore_rng(previous)
        del teacher, student
        gc.collect()
        torch.cuda.empty_cache()

def require_candidate(receipt, *, contract_id, candidate, reference):
    if (receipt.get('schema') != 'iterative.cuda.v1' or receipt.get('state') != 'PASS' or
        receipt.get('evidence_kind') != 'actual_cuda_l4_stage_probe' or receipt.get('contract_id') != contract_id or
        receipt.get('candidate') != candidate or receipt.get('reference') != reference or
        receipt.get('optimizer_steps') != 0 or receipt.get('model_file_writes') != 0 or
        receipt.get('runtime', {}).get('gpu') != 'NVIDIA L4'):
        raise ValueError('New actual stage/recovered CUDA evidence missing or changed')
    rows = receipt.get('rows', [])
    expected = {(s, b, role) for s in ('train','validation') for b in range(3)
                for role in ('teacher_recovery','teacher_frozen','student_kd')}
    actual = {(r['split'], r['batch_index'], r['role']) for r in rows}
    if not expected.issubset(actual) or len(actual) != len(rows):
        raise ValueError('Missing/duplicate actual CUDA probe roles')
    for row in rows:
        if row['candidate'] != candidate or row['status'] != 'PASS' or row['finite_logits'] is not True:
            raise ValueError('CUDA row failed')
        if row['role'] != 'teacher_frozen' and (row['finite_loss'] is not True or row['finite_gradients'] is not True):
            raise ValueError('CUDA loss/gradient gate failed')
    return True
