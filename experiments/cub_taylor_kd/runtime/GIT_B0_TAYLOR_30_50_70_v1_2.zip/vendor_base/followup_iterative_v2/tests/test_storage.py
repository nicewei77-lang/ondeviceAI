import unittest
from followup_iterative_v2.storage import plans,evaluate_quota,parameters
from followup_iterative_v2.common import ROOT,read
from followup_iterative_v2.policy import Recipe

class StorageTests(unittest.TestCase):
    def test_parameter_counts_match_actual_source_branches(self):
        for d,pin in read(ROOT/'assets/source_pins.json')['datasets'].items():
            for branch in pin['branches']:
                percent=round(branch['ratio']*100)
                r=Recipe(d,'D0' if percent==0 else 'OS',percent,20,20261013,'a'*64,'b'*64,'c'*64)
                self.assertEqual(parameters(d,r,3),branch['parameters'])

    def test_capacity_unknown_and_shortfall_hold(self):
        folder={'id':'project','ownedByMe':True,'mimeType':'application/vnd.google-apps.folder'}
        with self.assertRaises(ValueError):evaluate_quota({},folder,100)
        with self.assertRaisesRegex(ValueError,'STORAGE_HOLD'):
            evaluate_quota({'storageQuota':{'limit':'1000','usage':'950'},'user':{'permissionId':'example'}},folder,100)
        result=evaluate_quota({'storageQuota':{'limit':'1000','usage':'900'},'user':{'permissionId':'example'}},folder,100)
        self.assertEqual(result['free_bytes'],100)
        unlimited=evaluate_quota({'storageQuota':{'usage':'900'},'user':{'permissionId':'example'}},folder,100)
        self.assertTrue(unlimited['unlimited_limit_omitted'])
        with self.assertRaises(ValueError):evaluate_quota({'storageQuota':{'usage':'900'},'user':{'permissionId':'example'}},{**folder,'ownedByMe':False},100)

    def test_forecast_phases(self):
        rows=plans()
        self.assertLess(rows['pilot']['estimated_bytes'],rows['default_full']['estimated_bytes'])
        self.assertLess(rows['default_full']['estimated_bytes'],rows['maximum_full']['estimated_bytes'])
        self.assertEqual(len(rows['maximum_full']['teacher_jobs']),22)
        self.assertEqual(len(rows['maximum_full']['student_jobs']),40)

if __name__=='__main__':unittest.main()
