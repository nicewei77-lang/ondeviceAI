"""Independent review reproductions: fresh B-job drift and resume quota double count."""
import contextlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from followup_iterative_v2 import single_cli as cli,pipeline,execution,storage
from followup_iterative_v2.common import ROOT,atomic_json
from phaseb.ownership import JobKey

class RegressionTests(unittest.TestCase):
    def temp(self):
        root=ROOT.parent/'codex_ws/runs/iterative_fixture';root.mkdir(parents=True,exist_ok=True)
        return tempfile.TemporaryDirectory(dir=root)

    def test_single_A_fresh_second_job_runtime_drift_is_rejected(self):
        with self.temp() as tmp:
            root=Path(tmp);jobs=[JobKey('cub200','t_d0_b20',0,20261013),JobKey('cub200','t_it_b20',30,20261013)]
            values={j.job_id:None for j in jobs};values[JobKey('all','close_workflow',0,0).job_id]=None
            contract={'contract_id':'a'*64};assignment={'assignment_id':'b'*64,'local_lock_root':str(root),'frozen_contract_id':'a'*64}
            registration={'slot':'A','data_roots':{},'workflow_mode':'pilot_only','initial_storage_gate':{'principal_id_sha256':'p'}}
            drift=False;checks=[];bodies=[]
            class Lease:
                def __init__(self,key):self.key=key;self.output_dir=root/key.job_id;self.output_dir.mkdir(exist_ok=True)
                def assert_active(self):pass
                def complete(self,result):values[self.key.job_id]=result
            class Guard:
                @contextlib.contextmanager
                def claim(self,key):yield Lease(key)
            guard=Guard()
            def live(*args):
                checks.append('live')
                if drift:raise ValueError('live torchvision differs from registered Native baseline')
                return contract,assignment,registration,guard
            def body(*args):
                nonlocal drift
                bodies.append('model-access');drift=True
                return {'state':'complete','kind':'teacher','frozen_contract_id':'a'*64}
            with (patch.object(cli,'execution',side_effect=live),patch.object(execution,'execution',side_effect=live),
                  patch.object(cli,'require_source_review'),patch.object(cli,'receipts',side_effect=lambda *a:dict(values)),
                  patch.object(cli,'activation',return_value=set(jobs)),patch.object(cli,'partition',return_value={j:'A' for j in jobs}),
                  patch.object(cli,'automatic_coordinator'),patch('followup_iterative_v2.local_disk.snapshot',return_value={'state':'CPU_FIXTURE_ONLY'}),
                  patch.object(cli,'budget_review',return_value={}),patch.object(pipeline,'ready',return_value=True),
                  patch.object(pipeline,'recover',side_effect=body),patch.object(storage,'live_quota',return_value={'principal_id_sha256':'p'}),
                  patch.object(storage,'required_remaining',return_value=1)):
                with self.assertRaisesRegex(ValueError,'live torchvision'):
                    cli.worker(root,'A',start_training=True)
            self.assertEqual(len(bodies),1)
            self.assertEqual(len(checks),3)  # Initial worker, fresh job1, rejected fresh job2.

    def test_register_fresh_full_vs_bound_resume_remaining(self):
        with self.temp() as tmp:
            work=Path(tmp)/'TeacherCompressionKD_Iterative_Single_v2/results'
            contract={'contract_id':'a'*64};registration={'state':'registered'};assignment={'assignment_id':'b'*64}
            full=614_288_000_000;remaining=565_684_000_000;free=589_986_000_000;events=[]
            def forecast(work_arg=None,a=None,**kw):
                events.append('remaining' if a is not None else 'full')
                return remaining if a is not None else full
            def quota(required):
                events.append('quota')
                if required>free:raise ValueError('STORAGE_HOLD')
                return {'state':'PASS','required_bytes':required}
            with (patch.object(storage,'required_remaining',side_effect=forecast),patch.object(storage,'live_quota',side_effect=quota),
                  patch.object(storage,'validate_committed_progress',side_effect=lambda *a:events.append('committed_chain')),
                  patch.object(execution,'controls',return_value=work.parent/'control'),
                  patch.object(execution,'execution',side_effect=lambda *a:(events.append('binding') or contract,assignment,registration,None))):
                with self.assertRaisesRegex(ValueError,'STORAGE_HOLD'):
                    execution.registration_capacity(work,'A',contract,None)
                self.assertEqual(events,['full','quota'])
                events.clear();atomic_json(execution.controls(work)/'execution.json',{'fixture':True})
                result=execution.registration_capacity(work,'A',contract,registration)
                self.assertEqual(result['required_bytes'],remaining)
                self.assertEqual(events,['binding','committed_chain','remaining','quota'])

if __name__=='__main__':unittest.main()
