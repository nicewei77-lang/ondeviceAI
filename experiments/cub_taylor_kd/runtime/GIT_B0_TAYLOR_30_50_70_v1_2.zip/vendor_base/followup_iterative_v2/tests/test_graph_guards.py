from pathlib import Path
import itertools
import unittest
from followup_iterative_v2.graph import active_jobs,counts,decision
from followup_iterative_v2.common import ROOT,read
from followup_iterative_v2.policy import Recipe
from followup_iterative_v2.selection import validation_record
from followup_iterative_v2.precision import probe_candidate

def dec(dataset,ratio,action):
    return {'state':'complete','kind':'validation_decision','dataset':dataset,'target_percent':ratio,'action':action}

class GraphTests(unittest.TestCase):
    def test_permutation_chain(self):
        rows=[(decision('flowers102',20,70).job_id,dec('flowers102',70,'ACTIVATE_B40')),
              (decision('flowers102',40,70).job_id,dec('flowers102',70,'ACTIVATE_SHARED_R50_B20')),
              (decision('flowers102',20,50).job_id,dec('flowers102',50,'SELECT_B20'))]
        expected=None
        for order in itertools.permutations(rows):
            actual=active_jobs(dict(order),expand=True,main=True)
            if expected is None:expected=actual
            self.assertEqual(actual,expected)
        bad=dict(rows);bad[rows[0][0]]={**rows[0][1],'target_percent':50}
        with self.assertRaises(ValueError):active_jobs(bad,expand=True)
        with self.assertRaises(ValueError):active_jobs({rows[1][0]:rows[1][1]},expand=True)

    def test_activation_counts_all_branches(self):
        base={decision('cub200',20,30).job_id:dec('cub200',30,'SELECT_B20')}
        def state(other40=False,fallback=False):
            records=dict(base)
            for dataset,target in [('flowers102',70),('aircraft',30)]:
                records[decision(dataset,20,target).job_id]=dec(dataset,target,'ACTIVATE_B40' if other40 else 'SELECT_B20')
                if other40:
                    action='ACTIVATE_SHARED_R50_B20' if fallback and dataset=='flowers102' else 'SELECT_B40'
                    records[decision(dataset,40,target).job_id]=dec(dataset,target,action)
            if fallback:
                records[decision('flowers102',20,50).job_id]=dec('flowers102',50,'ACTIVATE_B40')
                records[decision('flowers102',40,50).job_id]=dec('flowers102',50,'SELECT_B40')
            return counts(active_jobs(records,expand=True,main=True))
        cases=read(ROOT/'assets/REVIEW_CASES.json')['allocation_expectations']
        for actual,expected in zip([counts(active_jobs({})),state(),state(True),state(True,True)],cases):
            self.assertEqual(actual['teacher'],expected['new_teacher'])
            self.assertEqual(actual['student_full60'],expected['full60_student'])
            self.assertEqual(actual['teacher_epochs'],expected['teacher_epochs'])
            self.assertEqual(actual['student_epochs'],expected['student_epochs'])

    def test_independent_width_table(self):
        for c in read(ROOT/'assets/REVIEW_CASES.json')['target_width_examples']:
            r=Recipe('fixture','D0' if c['percent']==0 else 'IT',c['percent'],20,42,'a'*64,'b'*64,'c'*64,True)
            self.assertEqual([r.width(c['H'],j) for j in range(4)],c['widths'])

    def test_test_path_rejected_before_read(self):
        with self.assertRaises(ValueError):
            validation_record(Path('test')/'VALIDATION.json',{'sha256':'a'*64,'identity':{}},root=Path('.'))

    def test_CPU_cannot_produce_new_CUDA_gate(self):
        def forbidden():raise AssertionError('Builder must not be called on CPU')
        with self.assertRaises(RuntimeError):
            probe_candidate('cub200',{},None,None,forbidden,forbidden,None,reference={},candidate={},contract_id='a'*64)

if __name__=='__main__':unittest.main()
