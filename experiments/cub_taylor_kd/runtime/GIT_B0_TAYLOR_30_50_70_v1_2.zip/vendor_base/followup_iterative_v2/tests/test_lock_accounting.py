from pathlib import Path
import tempfile
import unittest
from followup_iterative_v2.common import ROOT,identity,atomic_json
from followup_iterative_v2.selection import freeze_test_lock,require_test_lock
from followup_iterative_v2.accounting import recovery_cost

class Lease:
    def __init__(self,root):self.root=Path(root).resolve()
    def assert_output_path(self,path):
        if not Path(path).resolve().is_relative_to(self.root):raise ValueError('outside lease')

class LockTests(unittest.TestCase):
    def _temp(self):
        root=ROOT.parent/'codex_ws/runs/iterative_fixture';root.mkdir(parents=True,exist_ok=True)
        return tempfile.TemporaryDirectory(dir=root)

    def test_lock_complete_and_changed_consumer(self):
        with self._temp() as tmp:
            root=Path(tmp);arms={a:{str(s):{'completed_epochs':60,'teacher':{'sha256':'a'*64},
                'student':{'sha256':'b'*64},'validation':{'sha256':'c'*64,'split':'validation'},
                'baseline':{'sha256':'d'*64}} for s in (42,43,44)} for a in ('D0','OS','IT')}
            payload={'selector_state':'FROZEN_REVIEWED','split':'validation','arms':arms}
            lock=freeze_test_lock(root/'FINAL_SELECTION_LOCK.json',payload,lease=Lease(root))
            self.assertTrue(require_test_lock(lock,expected_id=lock['lock_id'],actual_artifacts=arms))
            import copy
            changed=copy.deepcopy(arms);changed['OS']['42']['student']['sha256']='e'*64
            with self.assertRaises(ValueError):require_test_lock(lock,expected_id=lock['lock_id'],actual_artifacts=changed)
            with self.assertRaises(ValueError):freeze_test_lock(root/'FINAL_SELECTION_LOCK.json',{**payload,'split':'test'},lease=Lease(root))
            missing=copy.deepcopy(payload);missing['arms']['IT'].pop('44')
            with self.assertRaises(ValueError):freeze_test_lock(root/'OTHER.json',missing,lease=Lease(root))

    def test_incomplete_attempt_is_not_zero(self):
        with self._temp() as tmp:
            root=Path(tmp);base={'schema':'iterative.recovery_cost.v1','segment_id':'1','start_utc':'2026-01-01T00:00:00',
                'end_utc':None,'elapsed_ns':None,'profile':{'gpu':'L4','gpu_uuid':'one'},'state':'running'}
            atomic_json(root/'attempts/1.json',base)
            self.assertFalse(recovery_cost(root)['complete'])
            self.assertIsNone(recovery_cost(root)['recovery_allocated_wall_ms'])
            atomic_json(root/'attempts/1.json',{**base,'end_utc':'2026-01-01T00:00:01','elapsed_ns':1500000})
            self.assertEqual(recovery_cost(root)['recovery_allocated_wall_ms'],2)
            atomic_json(root/'attempts/2.json',{**base,'segment_id':'2','start_utc':'2026-01-01T00:00:00.5',
                 'end_utc':'2026-01-01T00:00:02','elapsed_ns':1500000})
            self.assertFalse(recovery_cost(root)['complete'])

if __name__=='__main__':unittest.main()
