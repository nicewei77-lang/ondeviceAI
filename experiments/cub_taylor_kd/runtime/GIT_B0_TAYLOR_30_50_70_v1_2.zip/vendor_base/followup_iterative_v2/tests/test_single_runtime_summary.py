import contextlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from followup_iterative_v2.common import ROOT,atomic_json
from followup_iterative_v2 import single_cli,pipeline
from followup_iterative_v2.graph import all_jobs,partition
from followup_iterative_v2.summary_export import export_bundle

class SingleRuntimeTests(unittest.TestCase):
    def temp(self):
        root=ROOT.parent/'codex_ws/runs/iterative_v2_fixture';root.mkdir(parents=True,exist_ok=True)
        return tempfile.TemporaryDirectory(dir=root)
    def test_one_owner_full_DAG_and_export_before_release(self):
        with self.temp() as tmp:
            root=Path(tmp);records={j.job_id:None for j in all_jobs()};sequence=[]
            assignment={'assignment_id':'b'*64,'local_lock_root':str(root)};contract={'contract_id':'a'*64}
            registration={'workflow_mode':'full'}
            class Lease:
                def __init__(self,key):self.key=key;self.output_dir=root/key.job_id;self.output_dir.mkdir(exist_ok=True)
                def complete(self,value):records[self.key.job_id]=value
            class Guard:
                @contextlib.contextmanager
                def claim(self,key):yield Lease(key)
            guard=Guard()
            def completion(work,a,key):return records[key.job_id]
            def execute(work,a,c,r,g,key,values,**kw):
                sequence.append(key.stage)
                value={'state':'complete','frozen_contract_id':'a'*64,'kind':key.stage}
                if key.stage.startswith('decide_'):
                    action='SELECT_B20'
                    if key.dataset=='flowers102' and key.ratio==70:
                        action='ACTIVATE_B40' if key.stage=='decide_b20' else 'ACTIVATE_SHARED_R50_B20'
                    value.update(kind='validation_decision',dataset=key.dataset,target_percent=key.ratio,action=action)
                records[key.job_id]=value
                return value
            def release(*args):
                sequence.append('release')
                self.assertTrue(any(v and v.get('kind')=='closed' for v in records.values()))
                self.assertIn('analysis_export',sequence)
                return {'state':'fixture_release_requested','actual_runtime_released':False}
            with (patch.object(single_cli,'execution',return_value=(contract,assignment,registration,guard)),
                  patch.object(single_cli,'receipts',side_effect=lambda *a:dict(records)),
                  patch.object(single_cli,'completion',side_effect=completion),patch.object(pipeline,'completion',side_effect=completion),
                  patch.object(single_cli,'require_source_review'),patch.object(single_cli,'budget_review',return_value={}),
                  patch.object(pipeline,'run_job',side_effect=execute),patch.object(single_cli,'release_runtime',side_effect=release)):
                with contextlib.redirect_stdout(io.StringIO()):
                    result=single_cli.worker(root,start_training=True,auto_release=True,full_workflow=True)
            self.assertEqual(set(partition().values()),{'A'})
            self.assertEqual(result['state'],'fixture_release_requested')
            self.assertEqual(sequence.count('release'),1)
            self.assertLess(sequence.index('analysis_export'),sequence.index('release'))
            self.assertTrue(any(v and v.get('target_percent')==50 and v.get('action')=='SELECT_B20' for v in records.values()))
    def test_second_slot_and_missing_source_review_hold(self):
        with self.assertRaises(ValueError):single_cli.worker('/unused','B',start_training=True)
        with self.assertRaises(ValueError):single_cli.worker('/unused',start_training=False)

class SummaryTests(unittest.TestCase):
    temp=SingleRuntimeTests.temp
    def test_export_excludes_models_and_full_logits(self):
        with self.temp() as tmp:
            root=Path(tmp);output=root/'export/bundle.zip'
            atomic_json(root/'job/history.json',[{'epoch':1,'loss':1.}])
            (root/'job/model.pt').write_bytes(b'checkpoint must never be exported')
            (root/'job/logits.pt').write_bytes(b'full logits must never be exported')
            (root/'job/VALIDATION.csv').write_text('image_id,label,prediction,CE,entropy,correct,is_hard\n1,0,0,0.1,0.2,1,0\n',encoding='utf8')
            info=export_bundle(root,output,excluded_root=output.parent,metadata={'fixture':True})
            with zipfile.ZipFile(output) as archive:self.assertTrue(all(not n.endswith('.pt') for n in archive.namelist()))
            self.assertFalse(info['large_checkpoints_included'])
            atomic_json(root/'job/VALIDATION_METRICS.json',{'logits':[[1.,2.]]})
            with self.assertRaises(ValueError):export_bundle(root,output,excluded_root=output.parent,metadata={'fixture':True})

if __name__=='__main__':unittest.main()
