from pathlib import Path
import unittest
from followup_iterative_v2.common import read
from followup_iterative_v2.selection import budget_assessment, choose_budget, final_recommendation, teacher_collapsed

class SelectionTests(unittest.TestCase):
    def test_independent_cases(self):
        cases = read(Path(__file__).parents[1] / 'assets/REVIEW_CASES.json')
        for case in cases['metric_cases']:
            control, os_row, it_row = case['d0'], case['os'], case['it']
            if case.get('viable') is False:
                it_row = {'state': 'NOT_RUN_TEACHER_COLLAPSE'}
            result = budget_assessment(control, os_row, it_row)
            self.assertEqual(result['eligible'], case['expected_eligible'], case['id'])
            if 'expected_state' in case:
                self.assertEqual(result['state'], case['expected_state'], case['id'])
        for case in cases['branch_cases']:
            self.assertEqual(choose_budget(case.get('dataset','aircraft'),case['e20'],case['e40'],case['target'],
                                         fallback_used=case.get('fallback_used',False)), case['expected'], case['id'])

    def test_three_seed_recommendation(self):
        records = {a: {s: {'oa': 75., 'hard': 60.} for s in (42,43,44)} for a in ('D0','OS','IT')}
        costs = {a:{'complete':True,'recovery_allocated_wall_ms':ms,'profile':{'gpu':'L4'}} for a,ms in [('OS',100000),('IT',120000)]}
        result = final_recommendation(records, costs)
        self.assertEqual(result['recommendation'], 'OS')
        records['OS'][42]['hard'] = 50.
        self.assertEqual(final_recommendation(records, costs)['recommendation'], 'IT')
        records['IT'][42]['oa'] = 65.
        self.assertEqual(final_recommendation(records, costs)['recommendation'], 'D0')

    def test_v03_additional_cases(self):
        cases = read(Path(__file__).parents[1] / 'assets/REVIEW_CASES.json')
        for c in cases['additional_branch_cases']:
            if 'e20' in c:
                self.assertEqual(choose_budget('flowers102',c['e20'],c['e40'],c['target'],fallback_used=c['fallback_used']),c['expected'])
            elif 'selected' in c:
                self.assertEqual(teacher_collapsed(c['selected'],c['num_classes']),c['expected_resource_skip'])
            else:
                records = {a:{s:{'oa':c.get('oa_'+a.lower(),75.),'hard':c.get('hard_'+a.lower(),60.)} for s in (42,43,44)} for a in ('OS','IT')}
                records['D0'] = {s:{'oa':75.,'hard':60.} for s in (42,43,44)}
                costs = {a:{'complete':c.get('cost_complete',True),'recovery_allocated_wall_ms':c.get('cost_'+a.lower()),'profile':{'gpu':'L4'}} for a in ('OS','IT')}
                self.assertEqual(final_recommendation(records,costs)['recommendation'],c['expected'],c['id'])

    def test_final_nonfinite_is_hold_not_performance_fallback(self):
        records={a:{s:{'oa':75.,'hard':60.} for s in (42,43,44)} for a in ('D0','OS','IT')}
        records['IT'][44]['oa']=float('nan')
        with self.assertRaisesRegex(ValueError,'ERROR_HOLD'):
            final_recommendation(records,{})

if __name__ == '__main__':
    unittest.main()
