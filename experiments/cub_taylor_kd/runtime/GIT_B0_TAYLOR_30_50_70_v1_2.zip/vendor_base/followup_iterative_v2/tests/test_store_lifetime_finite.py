import copy,gc,weakref
import unittest
import torch
from followup_iterative_v2.model_store import configure,release,_STORES
from followup_iterative_v2.tests.test_bounded_store import BoundedStoreTests
from followup_iterative_v2.tests.test_kernel import factory

class StoreSafetyTests(unittest.TestCase):
    temp=BoundedStoreTests.temp
    setup_store=BoundedStoreTests.setup_store
    payload=BoundedStoreTests.payload
    def test_nonfinite_resume_state_never_commits(self):
        for case in ('optimizer_nan','scaler_nan','scale_zero','rng_dtype','stale_optimizer_id'):
            with self.subTest(case=case),self.temp() as tmp:
                r,native,store=self.setup_store(tmp);store.commit(self.payload(r,native,0,'boundary'))
                before=copy.deepcopy(store.pointer());value=self.payload(r,native,1,'epoch')
                if case in ('optimizer_nan','stale_optimizer_id'):
                    pid=value['optimizer_state']['param_groups'][0]['params'][0]
                    shape=value['parameter_manifest'][0]['parameters'][0]['shape']
                    state={'step':torch.tensor(1.),'exp_avg':torch.zeros(shape),'exp_avg_sq':torch.zeros(shape)}
                    if case=='optimizer_nan':state['exp_avg'].flatten()[0]=float('nan')
                    value['optimizer_state']['state'][pid if case=='optimizer_nan' else 999999]=state
                elif case in ('scaler_nan','scale_zero'):
                    value['execution']['runtime']['amp_enabled']=True
                    value['scaler_state']={'scale':float('nan') if case=='scaler_nan' else 0.,'growth_factor':2.,
                        'backoff_factor':.5,'growth_interval':2000,'_growth_tracker':0}
                else:value['rng_state']['torch']=torch.zeros(4)
                with self.assertRaises(ValueError):store.commit(value)
                self.assertEqual(store.pointer(),before)
    def test_context_releases_source_closure(self):
        class Owner:
            def build(self):return factory()
        refs=[]
        with self.temp() as tmp:
            r,native,_=self.setup_store(tmp)
            for i in range(22):
                owner=Owner();refs.append(weakref.ref(owner))
                configure(tmp,r,native,owner.build)
                self.assertEqual(len(_STORES),1)
                release(tmp);del owner;gc.collect()
                self.assertEqual(len(_STORES),0)
            self.assertTrue(all(ref() is None for ref in refs))

    def test_metadata_reader_survives_empty_global_cache(self):
        from followup_iterative_v2.model_store import metadata_accounting
        with self.temp() as tmp:
            r,native,store=self.setup_store(tmp);store.commit(self.payload(r,native,0,'boundary'))
            configure(tmp,r,native,factory)
            before=metadata_accounting(tmp,r)
            release(tmp);self.assertEqual(_STORES,{})
            after=metadata_accounting(tmp,r)
            self.assertEqual(before,after)

if __name__=='__main__':unittest.main()
