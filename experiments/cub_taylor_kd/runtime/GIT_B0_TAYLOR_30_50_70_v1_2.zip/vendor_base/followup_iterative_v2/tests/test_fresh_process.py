from pathlib import Path
import json,os,subprocess,sys,tempfile,unittest
from followup_iterative_v2.common import ROOT

class FreshProcessTests(unittest.TestCase):
    def test_register_remaining_worker_resume_without_cache(self):
        scratch=ROOT.parent.parent/'codex_ws/runs';scratch.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='v2_fresh_',dir=scratch) as tmp:
            work=Path(tmp)/'TeacherCompressionKD_Iterative_Single_v2/results'
            script=ROOT/'tests/fresh_resume_process.py'
            outputs=[]
            for mode in ('prepare','resume'):
                command=[sys.executable,'-B','-X','utf8',str(script),mode,str(work)]
                run=subprocess.run(command,cwd=ROOT.parent,env={**os.environ,'PYTHONPATH':str(ROOT.parent),'PYTHONDONTWRITEBYTECODE':'1'},
                    stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf8',timeout=240)
                self.assertEqual(run.returncode,0,run.stdout)
                outputs.append(json.loads(run.stdout.strip().splitlines()[-1]))
            self.assertEqual(outputs[0]['prepared_epochs'],3)
            self.assertEqual(outputs[1]['resumed_epochs'],20)
            self.assertEqual(outputs[1]['global_cache'],0)
            self.assertEqual(outputs[1]['remaining_before'],outputs[1]['remaining_after'])

if __name__=='__main__':unittest.main()
