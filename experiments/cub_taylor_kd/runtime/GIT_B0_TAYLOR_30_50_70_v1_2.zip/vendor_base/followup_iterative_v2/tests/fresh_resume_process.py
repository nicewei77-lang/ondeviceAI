"""Subprocess CPU integration fixture; hardware/provider boundaries are mocked."""
from dataclasses import asdict,replace
from datetime import datetime,timezone
import json,math,sys
from pathlib import Path
from unittest.mock import patch
from phaseb.ownership import JobKey,freeze_assignment,OwnershipGuard,current_runtime_id
from phaseb.native import parent,module
from followup_iterative_v2 import execution,storage,pipeline,single_cli
from followup_iterative_v2.common import atomic_json,read,sha,load_commit
from followup_iterative_v2.model_store import configure,release,_STORES
from followup_iterative_v2.training import fit_teacher
from followup_iterative_v2.tests.test_kernel import factory,recipe,Data,CONFIG

mode=sys.argv[1];work=Path(sys.argv[2]).resolve()
allowed=Path(__file__).resolve().parents[3]/'codex_ws/runs'
assert work.is_relative_to(allowed) and any(p.startswith('v2_fresh_') for p in work.parts),'Fixture write path must remain in its new scratch directory'
assert not _STORES,'Fresh process must start without a model-store cache'
r=replace(recipe(),seed=20261013);native=module('cub200','io');train=module('cub200','train')
job=JobKey('fixture','t_it_b20',70,20261013);control=work.parent/'control'
def runtime():
    env=native.environment_record()
    return {'device_type':'cpu','amp_enabled':False,'python_major_minor':list(sys.version_info[:2]),
        'versions':{k:env['versions'][k] for k in ('torch','torchvision','numpy','Pillow')},'torch_cuda':env['torch_cuda'],'gpu':None}
contract={'contract_id':r.contract_id,'code_id':r.code_id,'fixture_recipe':asdict(r),'fixture_only':True}
if mode=='prepare':
    atomic_json(control/'contract.json',contract)
    registration={'state':'registered','slot':'A','runtime_id':current_runtime_id(),'owner_token':'fixture-only-nonce',
        'contract_id':r.contract_id,'data_roots':{},'runtime':runtime(),'workflow_mode':'pilot_only',
        'registered_at_utc':datetime.now(timezone.utc).isoformat(),'initial_storage_gate':{'principal_id_sha256':'fixture-account'}}
    atomic_json(control/'runtime_A.json',registration);atomic_json(control/'data_roots.json',{})
    assignment=freeze_assignment([job],{job:'A'},frozen_contract_id=r.contract_id,source_ids={'fixture':r.source_id},
        output_root=work,slot_owners={'A':{'runtime_id':registration['runtime_id'],'owner_token':registration['owner_token']}},
        source_receipts=[{'path':str(control/'contract.json'),'sha256':sha(control/'contract.json')},
                         {'path':str(control/'runtime_A.json'),'sha256':sha(control/'runtime_A.json')}],
        local_lock_root=work.parent/'locks')
    atomic_json(control/'execution.json',{'assignment':assignment})
else:
    registration=read(control/'runtime_A.json');assignment=read(control/'execution.json')['assignment']
    assert registration['runtime_id']==current_runtime_id(),'Fixture runtime must be the same real OS boot'

def binding(*args):
    guard=OwnershipGuard(assignment,'A',expected_contract_id=r.contract_id,expected_source_ids={'fixture':r.source_id},
        expected_jobs=[job],expected_assignment_id=assignment['assignment_id'],local_lock_root=assignment['local_lock_root'],owner_token=registration['owner_token'])
    return contract,assignment,registration,guard

directory=work/assignment['assignment_id']/'slot_A/jobs'/job.job_id
if mode=='prepare':
    with binding()[3].claim(job) as lease:
        fit_teacher(factory,Data(),Data(),directory,r,CONFIG,native,train,lease=lease,device='cpu',stop_after_epoch=3)
    assert not _STORES
    print(json.dumps({'fixture_only':True,'prepared_epochs':3,'global_cache':len(_STORES)}))
    sys.exit(0)

parent()
import b1kd.runtime as native_runtime
full_raw=128*1024**2+3*256*1024**2+32*1024**2
full=math.ceil(full_raw*1.10)+5*1024**3
forecast={'teacher_jobs':[{'job_id':job.job_id,'total_bytes':128*1024**2,'single_upload_spare_bytes':32*1024**2}],
    'student_jobs':[],'required_free_bytes_with_headroom':full}
events=[];closed=False
def quota(required):
    events.append(['quota',required])
    if required>full-1000:raise ValueError('Fixture free capacity needs persisted-allocation credit')
    return {'state':'PASS','principal_id_sha256':'fixture-account','required_bytes':required}
def values(*args):
    return {job.job_id:execution.completion(work,assignment,job),JobKey('all','close_workflow',0,0).job_id:{'state':'complete'} if closed else None}
def auto(*args):
    global closed
    if execution.completion(work,assignment,job):closed=True
def recover(*args):
    lease=args[-1]
    result=fit_teacher(factory,Data(),Data(),directory,r,CONFIG,native,train,lease=lease,device='cpu')
    assert result['completed_epochs']==20
    configure(directory,r,native,factory)
    try:payload,pointer=load_commit(directory)
    finally:release(directory)
    return {'state':'complete','kind':'teacher','frozen_contract_id':r.contract_id,'completed_epochs':20,
            'commit':pointer,'model_digest':payload['model_digest'],'fixture_only':True}

with (patch.object(execution,'load_contract',return_value=contract),patch.object(execution,'verify_data'),
      patch.object(native_runtime,'current_training_runtime',side_effect=runtime),patch.object(native_runtime,'validate_runtime_match'),
      patch.object(execution,'execution',side_effect=binding),patch.object(execution,'partition',return_value={job:'A'}),
      patch('followup_iterative_v2.graph.all_jobs',return_value=[job]),patch('followup_iterative_v2.graph.partition',return_value={job:'A'}),
      patch.object(pipeline,'recipe_for',return_value=r),patch('phaseb.native.config',return_value=CONFIG),
      patch.object(storage,'plans',return_value={'pilot':forecast,'maximum_full':forecast}),patch.object(storage,'live_quota',side_effect=quota)):
    before=storage.required_remaining(work,assignment,full_workflow=False)
    execution.register(work,'A',control/'data_roots.json',pilot_only=True)
    assert not _STORES,'Registration/metadata-only validation must not leave a factory cache'
    after=storage.required_remaining(work,assignment,full_workflow=False)
    assert before==after<full,'Cache-free persisted allocation must produce equal remaining forecast'
    with (patch.object(single_cli,'execution',side_effect=binding),patch.object(single_cli,'require_source_review'),
          patch.object(single_cli,'receipts',side_effect=values),patch.object(single_cli,'activation',return_value={job}),
          patch.object(single_cli,'automatic_coordinator',side_effect=auto),patch.object(single_cli,'budget_review',return_value={}),
          patch.object(pipeline,'ready',return_value=True),patch.object(pipeline,'recover',side_effect=recover),
          patch('followup_iterative_v2.local_disk.snapshot',return_value={'state':'CPU_FIXTURE_ONLY'})):
        result=single_cli.worker(work,start_training=True)
assert not _STORES
print(json.dumps({'fixture_only':True,'state':result['state'],'resumed_epochs':20,'global_cache':len(_STORES),
    'remaining_before':before,'remaining_after':after,'events':events,'actual_GPU':False}))
