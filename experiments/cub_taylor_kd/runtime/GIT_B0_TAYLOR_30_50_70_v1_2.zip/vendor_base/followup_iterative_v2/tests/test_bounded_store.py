"""New storage protocol CPU simulations, not pretrained/provider/GPU evidence."""
from dataclasses import asdict
from pathlib import Path
import tempfile
import unittest
from followup_iterative_v2.common import ROOT
from followup_iterative_v2.model_store import ModelStore,LocalFixtureBackend,RESUME,BEST,ANCHORS,digest
from followup_iterative_v2.surgery import dense_layout
from followup_iterative_v2.tests.test_kernel import factory,recipe,CONFIG
from followup_iterative_v2.training import fresh_optimizer
from phaseb.native import module

class BoundedStoreTests(unittest.TestCase):
    def temp(self):
        root=ROOT.parent/'codex_ws/runs/iterative_v2_fixture';root.mkdir(parents=True,exist_ok=True)
        return tempfile.TemporaryDirectory(dir=root)
    def setup_store(self,path,budget=20):
        r=recipe('D0',0,budget);native=module('cub200','io');store=ModelStore(path,r,native,factory)
        return r,native,store
    def payload(self,r,native,e,kind,best=None):
        model=factory();stage=r.stage(e if kind=='boundary' else e-1)
        optimizer,scaler,manifest=fresh_optimizer(model,CONFIG,'cpu')
        return {'kind':kind,'next_epoch':e,'stage':stage,'contract_id':r.contract_id,
            'model_state':model.state_dict(),'model_digest':native.model_state_identity(model.state_dict()),
            'layout':dense_layout(model),'history':[{'storage_simulation_only':True} for _ in range(e)],
            'applied_boundaries':list(range(stage+1)),'best':best,'execution':{'recipe':asdict(r),'IO_fixture_only':True,'runtime':{'amp_enabled':False}},
            'optimizer_state':optimizer.state_dict(),'scaler_state':scaler.state_dict(),'parameter_manifest':manifest,'rng_state':native.rng_state()}
    def test_fixed_heads_and_pinsets(self):
        with self.temp() as tmp:
            r,native,store=self.setup_store(tmp,40);store.commit(self.payload(r,native,0,'boundary'))
            best=None
            for epoch in range(40):
                if epoch and r.stage_start(epoch):store.commit(self.payload(r,native,epoch,'boundary',best))
                before=store.pointer()
                oldrefs=[ref for ref in (before['active'],before.get('prior')) if ref]
                oldbytes={ref['file']:store.backend.get(ref['file']) for ref in oldrefs}
                if r.eligible(epoch):
                    value=self.payload(r,native,epoch,'boundary',best)
                    value.update(epoch=epoch,stage=3,eligibility='final_quarter',recipe=asdict(r))
                    value.pop('kind');value.pop('execution')
                    for key in ('optimizer_state','scaler_state','rng_state','parameter_manifest','history','applied_boundaries','best'):value.pop(key,None)
                    best={**store.save_best(value),'epoch':epoch}
                store.commit(self.payload(r,native,epoch+1,'epoch',best))
                for name,raw in oldbytes.items():self.assertEqual(store.backend.get(name),raw)
            files={p.name for p in Path(tmp).glob('*.pt')}
            self.assertEqual(files,set(RESUME+BEST))
            self.assertEqual(store.load()[0]['next_epoch'],40)
            with self.assertRaises(ValueError):store.commit(self.payload(r,native,40,'epoch',best))
    def test_faults_preserve_committed_state(self):
        for point in ('before_candidate_upload','after_candidate_upload','after_candidate_verify','before_pointer_commit','after_pointer_commit'):
            with self.subTest(point=point),self.temp() as tmp:
                r,native,store=self.setup_store(tmp);store.commit(self.payload(r,native,0,'boundary'))
                before=store.pointer();protected={x['file']:store.backend.get(x['file']) for x in (before['active'],before.get('prior')) if x}
                def fault(event):
                    if event==point:raise RuntimeError('simulated storage interruption')
                store.fault=fault
                with self.assertRaises(RuntimeError):store.commit(self.payload(r,native,1,'epoch'))
                store.fault=None
                self.assertEqual(store.load()[0]['next_epoch'],1 if point=='after_pointer_commit' else 0)
                for name,raw in protected.items():self.assertEqual(store.backend.get(name),raw)
    def test_immutable_anchor_and_index_guard(self):
        with self.temp() as tmp:
            r,native,store=self.setup_store(tmp)
            value=self.payload(r,native,0,'boundary')
            for key in ('optimizer_state','scaler_state','rng_state','parameter_manifest','history','applied_boundaries','best','execution','kind'):value.pop(key,None)
            value.update(position='post',anchor_j=1,code_stage_index=0,global_epoch=0,recipe=asdict(r))
            first=store.anchor('anchor_post_0.pt',value);second=store.anchor('anchor_post_0.pt',value)
            self.assertEqual(first['sha256'],second['sha256'])
            with self.assertRaises(ValueError):store.anchor('anchor_post_0.pt',{**value,'anchor_j':2})
            bad={**value,'model_digest':'a'*64}
            with self.assertRaises(ValueError):store.anchor('anchor_post_0.pt',bad)

    def test_anchor_replay_repairs_ledger_without_rewriting_blob(self):
        with self.temp() as tmp:
            r,native,store=self.setup_store(tmp)
            value=self.payload(r,native,0,'boundary')
            for key in ('optimizer_state','scaler_state','rng_state','parameter_manifest','history','applied_boundaries','best','execution','kind'):value.pop(key,None)
            value.update(position='post',anchor_j=1,code_stage_index=0,global_epoch=0,recipe=asdict(r))
            def fault(event):
                if event=='after_candidate_verify':raise RuntimeError('interrupted before anchor ledger')
            store.fault=fault
            with self.assertRaises(RuntimeError):store.anchor('anchor_post_0.pt',value)
            raw=store.backend.get('anchor_post_0.pt');self.assertIsNone(store.backend.get('ANCHORS.json'))
            store.fault=None;store.anchor('anchor_post_0.pt',value)
            import json
            self.assertIn('anchor_post_0.pt',json.loads(store.backend.get('ANCHORS.json')))
            self.assertEqual(store.backend.get('anchor_post_0.pt'),raw)

if __name__=='__main__':unittest.main()
