"""Small random CPU fixtures; never pretrained/CUDA/accuracy evidence."""
from dataclasses import replace
from pathlib import Path
import contextlib
import io
import tempfile
import unittest
from unittest.mock import patch
import torch
from torch import nn
from torch.utils.data import Dataset
from followup_iterative_v2.common import identity, load_commit
from followup_iterative_v2.policy import Recipe, choose_best
from followup_iterative_v2.surgery import dense_layout, prune_stage, restore, assert_stage_widths
from followup_iterative_v2.training import fit_teacher, load_selected, parameter_manifest, fresh_optimizer
from phaseb.native import module
from followup_iterative_v2.model_store import configure,release

torch.set_num_threads(1)

class Block(nn.Module):
    def __init__(self):
        super().__init__()
        self.pwconv1 = nn.Linear(4, 16)
        self.pwconv2 = nn.Linear(16, 4)
    def forward(self, x):
        return x + self.pwconv2(torch.nn.functional.gelu(self.pwconv1(x)))

class Fixture(nn.Module):
    def __init__(self):
        super().__init__()
        self.stages = nn.ModuleList([nn.Sequential(Block(), Block())])
        self.head = nn.Linear(4, 3)
    def forward(self, x):
        for stage in self.stages:
            x = stage(x)
        return self.head(x)

class Data(Dataset):
    def __init__(self):
        g = torch.Generator().manual_seed(5)
        self.images = torch.randn(7, 4, generator=g)
        self.epochs = []
    def set_epoch(self, e, seed):
        self.epochs.append((e, seed))
    def __len__(self):
        return len(self.images)
    def __getitem__(self, i):
        return self.images[i], i % 3, i

def factory():
    torch.manual_seed(42)
    return Fixture()

def recipe(arm='IT', ratio=70, budget=20):
    return Recipe('fixture', arm, ratio, budget, 42, 'a'*64, 'b'*64, 'c'*64, fixture=True)

CONFIG = {'batch_size': 3, 'effective_batch_size': 6, 'num_workers': 0, 'teacher_weight_decay': .01,
          'amp': False, 'warmup_epochs': 5, 'num_classes': 3}

def read_commit(path,r=None):
    configure(path,r or recipe(),module('cub200','io'),factory)
    try:return load_commit(path)
    finally:release(path)

class KernelTests(unittest.TestCase):
    def test_zero_update_all_ratios(self):
        digest = module('cub200', 'io').model_state_identity
        for ratio in (30, 50, 70):
            os_model, it_model = factory(), factory()
            os_layout, it_layout = dense_layout(os_model), dense_layout(it_model)
            for stage in range(4):
                os_layout = prune_stage(os_model, os_layout, recipe('OS', ratio), stage)
                it_layout = prune_stage(it_model, it_layout, recipe('IT', ratio), stage)
            self.assertEqual(os_layout, it_layout)
            self.assertEqual(digest(os_model.state_dict()), digest(it_model.state_dict()))
            x = torch.zeros(2, 4)
            self.assertTrue(torch.equal(os_model(x), it_model(x)))

    def test_d0_noop(self):
        model = factory(); params = [id(p) for p in model.parameters()]
        layout = dense_layout(model)
        for stage in range(4):
            layout = prune_stage(model, layout, recipe('D0', 0), stage)
        self.assertEqual(params, [id(p) for p in model.parameters()])

    def test_ties_and_composition(self):
        model = factory()
        for stage in model.stages:
            for block in stage:
                block.pwconv1.weight.data.fill_(1)
        layout = dense_layout(model)
        for stage in range(4):
            layout = prune_stage(model, layout, recipe(), stage)
            self.assertEqual(layout[0]['retained_indices'], list(range(recipe().width(16, stage))))

    def test_bad_layout_and_nonfinite(self):
        model = factory(); layout = dense_layout(model)
        layout[0]['retained_indices'][1] = 0
        with self.assertRaises(ValueError):
            prune_stage(model, layout, recipe(), 0)
        model = factory(); layout = dense_layout(model)
        model.stages[0][0].pwconv1.weight.data[0, 0] = float('nan')
        with self.assertRaises(FloatingPointError):
            prune_stage(model, layout, recipe(), 0)

    def test_global_lr_rng_and_widths(self):
        for budget in (20, 40):
            r = recipe(budget=budget)
            self.assertEqual([e for e in range(budget) if r.stage_start(e)], [j*budget//4 for j in range(4)])
            self.assertEqual(r.epoch_seed(budget//4), 42 + budget//4*100003)
            self.assertNotEqual(r.learning_factor(budget//4), r.learning_factor(0))
            self.assertEqual(r.width(4096, 3), 1229)
            self.assertEqual([e for e in range(budget) if r.eligible(e)], list(range(3*budget//4, budget)))

    def test_selection_tie(self):
        best = {'accuracy_pct': 50., 'loss': 1., 'epoch': 15}
        self.assertFalse(choose_best(best, {**best, 'epoch': 16}))
        self.assertTrue(choose_best(best, {**best, 'loss': .9, 'epoch': 16}))

    def test_stale_optimizer(self):
        model = factory(); optimizer, _, _ = fresh_optimizer(model, CONFIG, 'cpu')
        prune_stage(model, dense_layout(model), recipe(), 0)
        with self.assertRaises(ValueError):
            parameter_manifest(model, optimizer)

    def _fit(self, path, r=None, **kw):
        with contextlib.redirect_stdout(io.StringIO()):
            return fit_teacher(factory, Data(), Data(), path, r or recipe(), CONFIG,
                               module('cub200', 'io'), module('cub200', 'train'), device='cpu', **kw)

    def test_resume_midstage_and_boundaries(self):
        scratch = Path(__file__).resolve().parents[2] / 'codex_ws/runs/iterative_fixture'
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            root = Path(tmp)
            full = self._fit(root/'full')
            expected, _ = read_commit(root/'full')
            for label, point, at in [('mid', 'after_epoch_commit', 2), ('before', 'before_boundary_commit', 5),
                                     ('after', 'after_boundary_commit', 5)]:
                def fault(kind, epoch):
                    if kind == point and epoch == at:
                        raise KeyboardInterrupt('fixture crash')
                with self.assertRaises(KeyboardInterrupt):
                    self._fit(root/label, fault=fault)
                result = self._fit(root/label)
                saved, _ = read_commit(root/label)
                self.assertEqual(saved['model_digest'], expected['model_digest'])
                self.assertEqual(saved['boundary_events'], expected['boundary_events'])
                self.assertEqual(result['boundary_resets'], 4)
                self.assertEqual([r['epoch_seed'] for r in result['history']], [42+e*100003 for e in range(20)])
                self.assertTrue(all(row['attempted_optimizer_steps'] == row['applied_optimizer_steps'] == 2 for row in result['history']))
            self.assertEqual(full['completed_epochs'], 20)
            self.assertGreaterEqual(full['best']['epoch'], 15)
            load_selected(root/'full', recipe(), factory, module('cub200', 'io'))
            with self.assertRaises(ValueError):
                self._fit(root/'full', r=replace(recipe(), budget=40))

    def test_strict_restore_changed_digest(self):
        model = factory(); layout = prune_stage(model, dense_layout(model), recipe(), 0)
        with self.assertRaises(ValueError):
            restore(factory, model.state_dict(), layout, digest='0'*64, state_identity=module('cub200', 'io').model_state_identity)

    def test_resume_rejects_single_library_drift(self):
        scratch=Path(__file__).resolve().parents[2]/'codex_ws/runs/iterative_fixture'
        scratch.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(dir=scratch) as tmp:
            self._fit(tmp,stop_after_epoch=1)
            native_io=module('cub200','io')
            environment=native_io.environment_record()
            environment['versions']={**environment['versions'],'torchvision':'INDEPENDENT_SIMULATED_RUNTIME_DRIFT'}
            with patch.object(native_io,'environment_record',return_value=environment):
                with self.assertRaisesRegex(ValueError,'runtime/recipe changed'):
                    self._fit(tmp)

if __name__ == '__main__':
    unittest.main()
