"""Guarded new job bodies; the frozen one-shot pipeline is never written."""
from dataclasses import asdict
import gc
import hashlib
import io as binary_io
from pathlib import Path
import statistics
import torch
from phaseb.native import module, config, legacy
from phaseb.pipeline import context, initial_student, verify_training_complete
from phaseb.sources import load_source
from phaseb.ownership import JobKey
from .common import ROOT, PARENT, read, identity, sha, atomic_json, immutable_json, load_commit
from .execution import completion, job_dir
from .policy import Recipe
from .surgery import dense_layout, prune_stage, restore, assert_stage_widths
from .training import fit_teacher, load_selected,load_selection_data
from .precision import probe_candidate, require_candidate
from .accounting import Attempt, recovery_cost
from .selection import (teacher_collapsed, budget_assessment, choose_budget, validation_record,
                        final_recommendation, freeze_test_lock, require_test_lock)
from .graph import ARMS, SEEDS, TARGETS, teacher, student, decision, select

def sample_csv(path,payload,hard_ids):
    """Colab-derived per-sample evidence, sufficient for CPU accuracy/CE checks."""
    import csv
    logits=payload['logits'].double();labels=payload['labels'].long()
    ce=torch.nn.functional.cross_entropy(logits,labels,reduction='none').tolist()
    logp=torch.nn.functional.log_softmax(logits,dim=1)
    entropy=(-(logp.exp()*logp).sum(dim=1)).tolist()
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf8',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['image_id','label','prediction','CE','entropy','correct','is_hard'])
        for iid,label,pred,loss,ent in zip(payload['image_ids'],labels.tolist(),logits.argmax(1).tolist(),ce,entropy):
            writer.writerow([iid,label,pred,loss,ent,int(label==pred),int(label in hard_ids)])

def recipe_for(contract,job):
    _,arm,budget=job.stage.split('_')
    return Recipe(job.dataset,arm.upper(),job.ratio,int(budget[1:]),config(job.dataset)['teacher_seed'],
                  identity(contract['source_pins']['datasets'][job.dataset]['source_reference']),contract['protocol_id'],contract['code_id'])

def dense_source(dataset,contract):
    source=load_source(dataset,contract)
    def factory():
        return source.prune(0.,compression_models=legacy('models'),compression_pruning=legacy('pruning'))[0]
    return source,factory

def source_candidate(recipe,stage,layout):
    return {'arm':recipe.arm,'budget':recipe.budget,'target_percent':recipe.target_percent,
            'stage':stage,'global_epoch':stage*recipe.budget//4,'layout_id':identity(layout)}

def source_gate(work,assignment,contract,roots,lease):
    receipts=[]
    for dataset,targets in TARGETS.items():
        source,factory=dense_source(dataset,contract)
        _,_,sets=context(dataset,contract,roots)
        for budget in (20,40):
            for target in targets:
                for arm in ARMS:
                    if arm=='D0' and target!=targets[0]:
                        continue
                    key=teacher(dataset,arm,budget,target);recipe=recipe_for(contract,key)
                    for stage in range(4):
                        model=factory();layout=dense_layout(model)
                        for j in range(stage+1):
                            layout=prune_stage(model,layout,recipe,j)
                        digest=module(dataset,'io').model_state_identity(model.state_dict())
                        # Strict source/stage reconstruction before the real CUDA probe.
                        rebuilt=restore(factory,model.state_dict(),layout,digest=digest,state_identity=module(dataset,'io').model_state_identity)
                        assert_stage_widths(rebuilt,layout,recipe,stage)
                        del rebuilt,model
                        def builder(recipe=recipe,stage=stage):
                            value=factory();current=dense_layout(value)
                            for j in range(stage+1):
                                current=prune_stage(value,current,recipe,j)
                            return value
                        candidate=source_candidate(recipe,stage,layout)
                        receipt=probe_candidate(dataset,config(dataset),sets['train'],sets['val'],builder,
                            lambda:initial_student(dataset,42,contract)[0],module(dataset,'train'),
                            reference=source.reference,candidate=candidate,contract_id=contract['contract_id'],epoch=candidate['global_epoch'])
                        lease.assert_active();receipts.append(receipt)
                        atomic_json(lease.output_dir/f'{dataset}_{arm}_r{key.ratio}_b{budget}_stage{stage}.json',receipt)
                        print('SOURCE_STAGE_CUDA_PASS',dataset,arm,key.ratio,budget,stage,flush=True)
        del source,factory;gc.collect()
    result={'state':'complete','kind':'source_stage_cuda_gate','frozen_contract_id':contract['contract_id'],
            'evidence_kind':'actual_cuda_l4_stage_probe','optimizer_steps':0,'candidates':receipts,
            'source_refs':{d:contract['source_pins']['datasets'][d]['source_reference'] for d in TARGETS}}
    atomic_json(lease.output_dir/'SOURCE_STAGE_CUDA_GATE.json',result)
    return result

def require_source_gate(work,assignment,contract,recipe):
    job=JobKey('all','aggregate',None,None)
    record=completion(work,assignment,job)
    if not record or record['kind']!='source_stage_cuda_gate' or record['evidence_kind']!='actual_cuda_l4_stage_probe':
        raise ValueError('New actual source/stage CUDA gate is pending')
    reference=contract['source_pins']['datasets'][recipe.dataset]['source_reference']
    for stage in range(4):
        matches=[r for r in record['candidates'] if r['dataset']==recipe.dataset and
                 r['candidate']['arm']==recipe.arm and r['candidate']['budget']==recipe.budget and
                 r['candidate']['target_percent']==recipe.target_percent and r['candidate']['stage']==stage]
        if len(matches)!=1:
            raise ValueError('Source gate stage coverage differs')
        require_candidate(matches[0],contract_id=contract['contract_id'],candidate=matches[0]['candidate'],reference=reference)

def selected_teacher(work,assignment,contract,key,*,require_complete=True,source_bundle=None):
    record=completion(work,assignment,key) if require_complete else None
    if require_complete and not record:
        raise ValueError('Teacher producer not complete')
    recipe=recipe_for(contract,key);source,factory=source_bundle or dense_source(key.dataset,contract)
    (model,saved),pointer,payload=load_selection_data(job_dir(work,assignment,key),recipe,factory,module(key.dataset,'io'))
    best=payload['best']
    ref={'path':str(job_dir(work,assignment,key)/best['file']),'file_id':best.get('file_id'),'bytes':best['bytes'],'sha256':best['sha256'],
         'model_digest':saved['model_digest'],'contract_id':recipe.contract_id,'epoch':saved['epoch'],
         'layout_id':identity(saved['layout']),'test_fixture':False,'source':source.reference}
    if record and (record.get('teacher')!=ref or record.get('completed_epochs')!=recipe.budget or record.get('commit')!=pointer):
        raise ValueError('Teacher completion/selected checkpoint differs')
    return model,ref,saved,payload,recipe

def recover(work,assignment,contract,roots,lease):
    key=lease.key;recipe=recipe_for(contract,key);require_source_gate(work,assignment,contract,recipe)
    source,factory=dense_source(key.dataset,contract);_,_,sets=context(key.dataset,contract,roots)
    props=torch.cuda.get_device_properties(0)
    from b1kd.runtime import current_training_runtime
    profile={'gpu':torch.cuda.get_device_name(0),'gpu_uuid':str(getattr(props,'uuid','unavailable')),
             'precision':'native_amp_fp32_master','schema':'iterative.recovery_cost.v1',
             'runtime':current_training_runtime()}
    with Attempt(lease.output_dir,profile,deferred=True) as attempt:
        result=fit_teacher(factory,sets['train'],sets['val'],lease.output_dir,recipe,config(key.dataset),
                           module(key.dataset,'io'),module(key.dataset,'train'),lease=lease,device='cuda',on_recovery_start=attempt.start)
        if result['state']!='complete':
            raise ValueError('Teacher budget is incomplete')
        model,ref,saved,payload,_=selected_teacher(work,assignment,contract,key,require_complete=False,source_bundle=(source,factory))
        selected=payload['history'][ref['epoch']]
        collapsed=teacher_collapsed({'oa':selected['val_accuracy_pct'],
                   'max_predicted_class_fraction':selected['max_predicted_class_fraction']},config(key.dataset)['num_classes'])
        candidate=source_candidate(recipe,3,saved['layout']);candidate['phase']='recovered'
        def rebuilt():
            return restore(factory,saved['model_state'],saved['layout'],digest=saved['model_digest'],state_identity=module(key.dataset,'io').model_state_identity)
        gate=probe_candidate(key.dataset,config(key.dataset),sets['train'],sets['val'],rebuilt,
              lambda:initial_student(key.dataset,42,contract)[0],module(key.dataset,'train'),reference=ref,
              candidate=candidate,contract_id=contract['contract_id'],epoch=3*recipe.budget//4)
        atomic_json(lease.output_dir/'RECOVERED_CUDA_GATE.json',gate)
        profile_model=legacy('pruning').profile_model(model.cuda(),224,'cuda')
        atomic_json(lease.output_dir/'profile.json',profile_model)
        from .remote_seal import seal
        pointer=payload['commit']
        atomic_json(lease.output_dir/'REMOTE_MODEL_SEALS.json',{'best':seal(ref['path'],work=work,expected_sha256=ref['sha256'],file_id=ref['file_id'],expected_bytes=ref['bytes']),
            'last':seal(lease.output_dir/pointer['file'],work=work,expected_sha256=pointer['sha256'],file_id=pointer['file_id'],expected_bytes=pointer['bytes']),
            'Colab_strict_restore_verified':True,'PC_model_downloads':0})
        del model;gc.collect();torch.cuda.empty_cache()
    cost=recovery_cost(lease.output_dir)
    atomic_json(lease.output_dir/'RECOVERY_COST.json',cost)
    return {'state':'complete','kind':'teacher','frozen_contract_id':contract['contract_id'],
            'completed_epochs':recipe.budget,'teacher':ref,'commit':payload['commit'],
            'teacher_collapsed':collapsed,'selected_validation':selected,'last_two_eligible_diagnostic':payload['history'][-2:],
            'recovered_gate_sha256':sha(lease.output_dir/'RECOVERED_CUDA_GATE.json'),'cost':cost}

def student_contract(contract,key,tref):
    pin=read(PARENT/'configs/readonly_inputs.json')['datasets'][key.dataset]
    return {'schema':'iterative.student.v1','frozen_contract_id':contract['contract_id'],
            'job':f'{key.dataset}/student_{key.stage}_r{key.ratio:02d}','seed':key.seed,'config':config(key.dataset),
            'source':{'teacher':tref,'initial':pin['initializations'][str(key.seed)],'baseline':pin['baselines'][str(key.seed)]},
            'split_id':pin['split_id'],'Hard_set':pin['hard_set'],'phaseb_code_id':contract['code_id']}

def native_baseline(dataset,seed,split,manifest):
    pin=read(PARENT/'configs/readonly_inputs.json')['datasets'][dataset]
    source=pin['baseline_saved_predictions'][split][str(seed)]
    raw=Path(source['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=source['sha256']:
        raise ValueError('Read-only Native baseline prediction bytes changed')
    payload=torch.load(binary_io.BytesIO(raw),map_location='cpu',weights_only=True)
    if (payload['checkpoint']!=pin['baselines'][str(seed)] or payload['split']!=split or
        payload['image_ids']!=[r['image_id'] for r in manifest[split]] or
        payload['labels'].tolist()!=[r['label'] for r in manifest[split]]):
        raise ValueError('Baseline checkpoint/order/labels differ')
    return payload,{'sha256':source['sha256'],'path':source['path'],'checkpoint':pin['baselines'][str(seed)]}

def distill(work,assignment,contract,roots,lease):
    key=lease.key;_,arm,budget=key.stage.split('_');tkey=teacher(key.dataset,arm.upper(),int(budget[1:]),key.ratio)
    tr=completion(work,assignment,tkey)
    if tr is None:
        raise ValueError('Teacher incomplete')
    if tr['teacher_collapsed']:
        return {'state':'complete','kind':'student','frozen_contract_id':contract['contract_id'],
                'result_state':'NOT_RUN_TEACHER_COLLAPSE','completed_epochs':0,'teacher':tr['teacher']}
    teacher_model,tref,_,_,_=selected_teacher(work,assignment,contract,tkey)
    gate_path=job_dir(work,assignment,tkey)/'RECOVERED_CUDA_GATE.json'
    if sha(gate_path)!=tr['recovered_gate_sha256']:
        raise ValueError('Recovered gate changed')
    gate=read(gate_path);require_candidate(gate,contract_id=contract['contract_id'],candidate=gate['candidate'],reference=tref)
    model,spec=initial_student(key.dataset,key.seed,contract)
    expected=student_contract(contract,key,tref)
    pin,manifest,sets=context(key.dataset,contract,roots)
    module(key.dataset,'train').fit(model,sets['train'],sets['val'],lease.output_dir,60,key.seed,config(key.dataset),expected,spec,teacher=teacher_model)
    best=verify_training_complete(lease.output_dir,60,expected,spec)
    sref={'path':str(lease.output_dir/'best.pt'),'sha256':sha(lease.output_dir/'best.pt'),
          'model_digest':best['model_digest'],'contract_id':identity(best['contract']),'epoch':best['epoch'],'model_spec':best['model_spec']}
    model=module(key.dataset,'models').build_from_spec(spec);model.load_state_dict(best['model_state'],strict=True);model.cuda()
    logits,labels,ids=module(key.dataset,'train').predict(model,sets['val'],config(key.dataset)['batch_size'],config(key.dataset)['num_workers'],'cuda')
    if ids!=[r['image_id'] for r in manifest['val']] or labels.tolist()!=[r['label'] for r in manifest['val']]:
        raise ValueError('Validation order/labels changed')
    values=module(key.dataset,'metrics').classification_metrics(logits,labels,config(key.dataset)['num_classes'],pin['hard_set']['class_ids'])
    payload={'logits':logits,'labels':labels,'image_ids':ids,'checkpoint':sref,'teacher':tref,'split':'validation'}
    module(key.dataset,'io').checkpoint_write(lease.output_dir/'VALIDATION_PREDICTIONS.pt',payload)
    sample_csv(lease.output_dir/'VALIDATION.csv',payload,pin['hard_set']['class_ids'])
    atomic_json(lease.output_dir/'VALIDATION_METRICS.json',{'split':'validation','student':sref,'teacher':tref,**values})
    from .remote_seal import seal
    atomic_json(lease.output_dir/'REMOTE_MODEL_SEALS.json',{'best':seal(sref['path'],work=work,expected_sha256=sref['sha256']),
        'last':seal(lease.output_dir/'last.pt',work=work,expected_sha256=sha(lease.output_dir/'last.pt')),
        'Colab_strict_restore_verified':True,'PC_model_downloads':0})
    _,baseline=native_baseline(key.dataset,key.seed,'val',manifest)
    record={'split':'validation','dataset':key.dataset,'arm':arm.upper(),'budget':int(budget[1:]),'target_percent':key.ratio,
            'seed':key.seed,'state':'complete','completed_epochs':60,'oa':values['accuracy_pct'],'hard':values['hard_accuracy_pct'],
            'teacher':tref,'student':sref,'split_id':pin['split_id'],'hard_id':pin['hard_set']['identity'],
            'initial_id':pin['initializations'][str(key.seed)]['model_digest'],'baseline':baseline,
            'protocol_id':contract['protocol_id'],'code_id':contract['code_id']}
    atomic_json(lease.output_dir/'VALIDATION.json',record)
    del model,teacher_model;gc.collect();torch.cuda.empty_cache()
    return {'state':'complete','kind':'student','frozen_contract_id':contract['contract_id'],'result_state':'complete',
            'completed_epochs':60,'teacher':tref,'student':sref,'validation_sha256':sha(lease.output_dir/'VALIDATION.json')}

def validation_for(work,assignment,contract,key):
    result=completion(work,assignment,key)
    if not result:
        return None
    if result['result_state']=='NOT_RUN_TEACHER_COLLAPSE':
        return {'state':'NOT_RUN_TEACHER_COLLAPSE'}
    path=job_dir(work,assignment,key)/'VALIDATION.json'
    _,arm,budget=key.stage.split('_')
    expected={'sha256':result['validation_sha256'],'identity':{'dataset':key.dataset,'seed':key.seed,
              'arm':arm.upper(),'budget':int(budget[1:]),'target_percent':key.ratio,
              'protocol_id':contract['protocol_id'],'code_id':contract['code_id']}}
    record=validation_record(path,expected,root=job_dir(work,assignment,key))
    if record['teacher']!=result['teacher'] or record['student']!=result['student']:
        raise ValueError('Validation receipt differs from trained models')
    # Actual checkpoint consumption is always hash + load from those SAME bytes.
    raw=Path(result['student']['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=result['student']['sha256']:
        raise ValueError('Student selected bytes changed')
    saved=torch.load(binary_io.BytesIO(raw),map_location='cpu',weights_only=True)
    if (saved['contract']!=student_contract(contract,key,result['teacher']) or
        module(key.dataset,'io').model_state_identity(saved['model_state'])!=result['student']['model_digest']):
        raise ValueError('Student checkpoint contract/tensors differ')
    return record

def decision_body(work,assignment,contract,key):
    dataset,target=key.dataset,key.ratio
    def assessment(budget):
        rows=[validation_for(work,assignment,contract,student(dataset,a,budget,target,42)) for a in ARMS]
        result=budget_assessment(*rows)
        if result['state'] in ('ERROR_HOLD','INVALID_CONTROL_HOLD'):
            return result['state'],result
        return result['eligible'],result
    e20,r20=assessment(20);e40,r40=(None,{'state':'NOT_ACTIVATED'})
    if dataset=='cub200' or key.stage=='decide_b40':
        e40,r40=assessment(40)
    action=choose_budget(dataset,e20,e40,target,fallback_used=target==50)
    if action=='PENDING_B40' and key.stage=='decide_b20':
        action='ACTIVATE_B40'
    if action.startswith('PENDING') or action.endswith('HOLD'):
        raise ValueError('Decision must remain pending/hold: '+action)
    return {'state':'complete','kind':'validation_decision','frozen_contract_id':contract['contract_id'],
            'dataset':dataset,'target_percent':target,'action':action,'assessment20':r20,'assessment40':r40,
            'Test_reads':0,'full60_only':True}

def selected_decision(receipts,dataset):
    rows=[r for r in receipts.values() if r and r.get('kind')=='validation_decision' and r['dataset']==dataset and r['action'].startswith('SELECT_')]
    if len(rows)!=1:
        raise ValueError('Expected one immutable selected budget/ratio')
    row=rows[0]
    return int(row['action'][-2:]),row['target_percent']

def selection_body(work,assignment,contract,roots,lease,receipts):
    dataset=lease.key.dataset;budget,target=selected_decision(receipts,dataset)
    records={a:{s:validation_for(work,assignment,contract,student(dataset,a,budget,target,s)) for s in SEEDS} for a in ARMS}
    costs={a:completion(work,assignment,teacher(dataset,a,budget,target))['cost'] for a in ('OS','IT')}
    recommendation=final_recommendation(records,costs)
    arms={}
    for arm in ARMS:
        arms[arm]={}
        for seed,row in records[arm].items():
            path=job_dir(work,assignment,student(dataset,arm,budget,target,seed))/'VALIDATION.json'
            arms[arm][str(seed)]={'completed_epochs':60,'teacher':row['teacher'],'student':row['student'],
                'validation':{'path':str(path),'sha256':sha(path),'split':'validation'},'baseline':row['baseline'],
                'split_id':row['split_id'],'hard_id':row['hard_id'],'initial_id':row['initial_id']}
    payload={'schema':'iterative.test_lock.v1','split':'validation','selector_state':contract['selector_state'],
             'dataset':dataset,'budget':budget,'target_percent':target,'arms':arms,
             'protocol_id':contract['protocol_id'],'code_id':contract['code_id'],'frozen_contract_id':contract['contract_id'],
             'recommendation':recommendation,'Test_used_for_selection':False}
    lock=freeze_test_lock(lease.output_dir/'FINAL_SELECTION_LOCK.json',payload,lease=lease)
    return {'state':'complete','kind':'selection','frozen_contract_id':contract['contract_id'],'lock_id':lock['lock_id'],
            'lock_sha256':sha(lease.output_dir/'FINAL_SELECTION_LOCK.json'),'recommendation':recommendation}

def finalizer(work,assignment,contract,roots,lease,receipts):
    dataset=lease.key.dataset;selection=completion(work,assignment,select(dataset))
    lock_path=job_dir(work,assignment,select(dataset))/'FINAL_SELECTION_LOCK.json'
    if not selection or sha(lock_path)!=selection['lock_sha256']:
        raise ValueError('Actual immutable Test lock is missing/changed')
    lock=read(lock_path);budget,target=selected_decision(receipts,dataset)
    actual={}
    for arm in ARMS:
        actual[arm]={}
        # Revalidate every selected Teacher/Student against the exact frozen lock.
        tm,tref,_,_,_=selected_teacher(work,assignment,contract,teacher(dataset,arm,budget,target));del tm
        for seed in SEEDS:
            key=student(dataset,arm,budget,target,seed);row=validation_for(work,assignment,contract,key)
            vp=job_dir(work,assignment,key)/'VALIDATION.json'
            actual[arm][str(seed)]={'teacher':tref,'student':row['student'],
                'validation':{'path':str(vp),'sha256':sha(vp),'split':'validation'},'baseline':row['baseline']}
    require_test_lock(lock,expected_id=selection['lock_id'],actual_artifacts=actual)
    # Test ImageDataset is constructed only AFTER every frozen consumer matches.
    pin,manifest,sets=context(dataset,contract,roots,test=True)
    native_io=module(dataset,'io');cfg=config(dataset);rows=[]
    def evaluate(name,ref,builder,seed=None):
        destination=lease.output_dir/'evaluation'/'test'/name
        path=destination.with_suffix('.pt')
        if path.exists():
            payload=native_io.checkpoint_read(path)
        else:
            model=builder().cuda()
            with torch.autocast('cuda',enabled=False):
                logits,labels,ids=module(dataset,'train').predict(model,sets['test'],cfg['batch_size'],cfg['num_workers'],'cuda')
            payload={'logits':logits,'labels':labels,'image_ids':ids,'checkpoint':ref,
                     'split':'test','lock_id':lock['lock_id']}
            native_io.checkpoint_write(path,payload)
            del model;gc.collect();torch.cuda.empty_cache()
        if (payload['checkpoint']!=ref or payload['split']!='test' or payload['lock_id']!=lock['lock_id'] or
            payload['image_ids']!=[r['image_id'] for r in manifest['test']] or payload['labels'].tolist()!=[r['label'] for r in manifest['test']]):
            raise ValueError('Cached Test inference checkpoint/lock/order differs')
        metrics=module(dataset,'metrics').classification_metrics(payload['logits'],payload['labels'],cfg['num_classes'],pin['hard_set']['class_ids'])
        atomic_json(destination.with_suffix('.json'),{'condition':name,'seed':seed,'checkpoint':ref,
                    'lock_id':lock['lock_id'],'split':'test',**metrics})
        sample_csv(destination.with_suffix('.csv'),payload,pin['hard_set']['class_ids'])
        return {'condition':name,'seed':seed,**metrics}
    for arm in ARMS:
        tk=teacher(dataset,arm,budget,target);ref=actual[arm]['42']['teacher']
        rows.append(evaluate('teacher_'+arm,ref,lambda tk=tk:selected_teacher(work,assignment,contract,tk)[0]))
        for seed in SEEDS:
            ref=actual[arm][str(seed)]['student']
            def builder(ref=ref):
                raw=Path(ref['path']).read_bytes()
                if hashlib.sha256(raw).hexdigest()!=ref['sha256']:
                    raise ValueError('Student raw SHA changed after selection freeze')
                saved=torch.load(binary_io.BytesIO(raw),map_location='cpu',weights_only=True)
                if module(dataset,'io').model_state_identity(saved['model_state'])!=ref['model_digest']:
                    raise ValueError('Student selected tensors changed')
                model=module(dataset,'models').build_from_spec(ref['model_spec']);model.load_state_dict(saved['model_state'],strict=True)
                return model
            rows.append(evaluate(f'student_{arm}_seed{seed}',ref,builder,seed))
    for seed in SEEDS:
        payload,ref=native_baseline(dataset,seed,'test',manifest)
        sample_csv(lease.output_dir/'evaluation/test'/f'baseline_seed{seed}.csv',payload,pin['hard_set']['class_ids'])
        values=module(dataset,'metrics').classification_metrics(payload['logits'],payload['labels'],cfg['num_classes'],pin['hard_set']['class_ids'])
        rows.append({'condition':'baseline','seed':seed,'read_only_source':ref,**values})
    paired=[];groups={}
    for arm in ARMS:
        values=[r for r in rows if r['condition'].startswith('student_'+arm+'_')]
        groups[arm]={k:{'mean':statistics.mean(r[k] for r in values),'sample_sd':statistics.stdev(r[k] for r in values),'n':3}
                     for k in ('accuracy_pct','hard_accuracy_pct')}
        for seed in SEEDS:
            value=next(r for r in values if r['seed']==seed);baseline=next(r for r in rows if r['condition']=='baseline' and r['seed']==seed)
            paired.append({'arm':arm,'seed':seed,'OA_KD_gain_pp':value['accuracy_pct']-baseline['accuracy_pct'],
                           'Hard_KD_gain_pp':value['hard_accuracy_pct']-baseline['hard_accuracy_pct']})
    atomic_json(lease.output_dir/'TEST_SUMMARY.json',{'rows':rows,'groups':groups,'paired_baseline_gains':paired,
        'lock_id':lock['lock_id'],'frozen_recommendation':lock['recommendation'],'Test_used_for_selection':False,
        'scope':'Exploratory follow-up after prior Test observation; three Student seeds conditional on one Teacher source/split; not an independent new holdout'})
    return {'state':'complete','kind':'finalizer','dataset':dataset,'frozen_contract_id':contract['contract_id'],
            'lock_id':lock['lock_id'],'Teacher_rows':3,'Student_rows':9,'read_only_baselines':3,
            'Test_used_for_selection':False,'summary_sha256':sha(lease.output_dir/'TEST_SUMMARY.json')}

def ready(work,assignment,contract,key,receipts):
    done=lambda j:completion(work,assignment,j) is not None
    if key.dataset=='all' and key.stage=='aggregate':return done(JobKey('all','storage_probe',0,0))
    if key.dataset=='all':
        return True
    if key.stage.startswith('t_'):
        return done(JobKey('all','aggregate',None,None))
    if key.stage.startswith('s_'):
        _,arm,budget=key.stage.split('_')
        return done(teacher(key.dataset,arm.upper(),int(budget[1:]),key.ratio))
    if key.stage.startswith('decide_'):
        budgets=(20,40) if key.dataset=='cub200' else (int(key.stage.rsplit('b',1)[1]),)
        return all(done(student(key.dataset,a,b,key.ratio,42)) for a in ARMS for b in budgets)
    if key.stage in ('select','finalizer'):
        if key.stage=='finalizer':
            return done(select(key.dataset))
        try:
            budget,target=selected_decision(receipts,key.dataset)
        except ValueError:
            return False
        return all(done(student(key.dataset,a,budget,target,s)) for a in ARMS for s in SEEDS)
    raise ValueError('Unknown new job stage')

def run_job(work,assignment,contract,registration,guard,key,receipts,*,budget_record=None):
    # Every slot and every fresh job revalidates LIVE libraries before any model
    # or optimizer access. A guard retained by worker() is not runtime evidence.
    from .execution import execution as live_execution
    current_contract,current_assignment,current_registration,current_guard=live_execution(work,registration['slot'])
    if (current_contract!=contract or current_assignment!=assignment or current_registration!=registration):
        raise ValueError('Next-job immutable binding differs from worker context')
    guard=current_guard
    roots=registration['data_roots']
    if not ready(work,assignment,contract,key,receipts):
        raise ValueError('Job dependencies are not complete')
    with guard.claim(key) as lease:
        lease.assert_active()
        from .local_disk import snapshot
        atomic_json(lease.output_dir/'LOCAL_DISK_GATE.json',snapshot())
        from .storage import live_quota,required_remaining
        try:
            quota=live_quota(required_remaining(work,assignment,full_workflow=registration['workflow_mode']=='full'))
        except Exception as error:
            atomic_json(lease.output_dir/'STORAGE_GATE_HOLD.json',{'state':'STORAGE_CAPACITY_PENDING_OR_HOLD',
                'error_type':type(error).__name__,'automatic_retry':False,'this_job_training_started':False})
            raise
        if quota['principal_id_sha256']!=registration['initial_storage_gate']['principal_id_sha256']:
            raise ValueError('Storage quota principal changed after runtime registration')
        atomic_json(lease.output_dir/'STORAGE_CAPACITY_GATE.json',quota)
        if budget_record is not None:
            atomic_json(lease.output_dir/'BUDGET_REVIEW.json',budget_record)
        if key.stage=='storage_probe':
            from .provider_probe import run_probe
            result=run_probe(contract,lease)
        elif key.stage=='analysis_export':
            from .summary_export import run_export
            result=run_export(work,assignment,contract,lease)
        elif key.dataset=='all':
            result=source_gate(work,assignment,contract,roots,lease)
        elif key.stage.startswith('t_'):
            result=recover(work,assignment,contract,roots,lease)
        elif key.stage.startswith('s_'):
            result=distill(work,assignment,contract,roots,lease)
        elif key.stage.startswith('decide_'):
            result=decision_body(work,assignment,contract,key)
        elif key.stage=='select':
            result=selection_body(work,assignment,contract,roots,lease,receipts)
        elif key.stage=='finalizer':
            result=finalizer(work,assignment,contract,roots,lease,receipts)
        else:
            raise ValueError('Unsupported iterative job')
        atomic_json(lease.output_dir/'COMPLETE.json',result)
        lease.assert_active();lease.complete(result)
    return result
