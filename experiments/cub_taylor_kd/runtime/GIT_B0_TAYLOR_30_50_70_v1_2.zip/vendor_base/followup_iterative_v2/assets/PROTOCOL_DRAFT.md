# 단일 런타임과 균형 저장 운영 부록 v2.1

상태: 구현 및 독립 검토 전, 실제 GPU 시작 보류.
기존 task 01a172c5-8a62-7691-918f-0bfc05c640ff를 계속 사용한다.

## 사용자 지시와 적용 범위

2026-10-26 04:20:33 UTC에 사용자는 다른 작업의 Colab 세션 1개를 사용 중이라고 확인했다.
04:22:11 UTC에는 pruning을 1개 런타임으로 조정하고 PC에 대형 checkpoint를 내려받지 말라고 요청했다.
04:24:19 UTC에는 Drive가 충분하므로 Drive에만 남긴다면 기존 큰 보존 방식도 괜찮으며 적합한 pruning 실증이 핵심이라고 설명했다.

따라서 이번 최소 변경은 단일 A 런타임의 순차 실행과 Colab 내 평가, 작은 분석 요약 전송이다.
04:33:16 UTC에 사용자는 권고한 균형 저장과 단일 세션 수정을 명시적으로 수락했다.
따라서 과학적 Teacher 학습 kernel과 Native Student60은 재사용하되, 새 실험의 epoch별 별도 영구 blob 생성은 없앤다.
기존 파일을 삭제하는 정리나 압축 변경은 하지 않는다. 전 job에 걸친 복잡한 공용 저장 pool은 만들지 않는다.
신규 namespace는 teamnative_iterative_single_v2로 구분하며 v1/Native/B1/완료된 pruning 원본은 변경하지 않는다.

## 과학 계약

v0.3의 source, ordered split, 초기화, baseline, Native Hard, D0/OS/IT 정의와 K4를 그대로 유지한다.
원래 H 기준 ceil target, original-index 합성, FP32 row-L1, global epoch/RNG/LR, 동일 stage reset, final-quarter Teacher best 규칙을 유지한다.
B20/40, Student full60 기반 validation 결정표, Flowers 한 번의 r70→r50 fallback, 최종 Test lock도 유지한다.
원문 protocol SHA는 a48c696c1f9e4008d22603863200a8531977da8be4d6e572414ca1e5b3c5b8bb이다.
검증된 v1 code는 aa0bb28584a5221d9a6b0aac626f8159899055f70cbd5b6d9d56ad830fca0039다.
저장량 최적화는 과학 조건이나 현재 source/weights를 바꾸는 근거가 아니다.

## 단일 소유권과 실행

pruning은 A 런타임 하나만 등록하고 모든 활성 job을 순차 처리한다.
runtime_B 등록/배정/receipt/lease 대기가 없어야 한다. 같은 GPU에 여러 학습을 겹치지 않는다.
다른 프로젝트 세션 1개에 접속하거나 입력하거나 해제하지 않는다. 계정 전체 동시 한도 2개를 유지한다.
각 job 직전 live full runtime fingerprint와 원본 Native 조건을 다시 확인한다.
job nonce/attempt/assignment/source/contract/commit의 binding과 자동 owner steal 거부를 유지한다.
중단 후 마지막 atomic committed epoch 또는 boundary를 재개하고 이미 완료한 surgery/reset을 반복하지 않는다.
runtime 교체를 묵시적으로 같은 writer로 간주하지 않는다. 교체 필요 시 이전 writer와 결과를 보존하는 명시적 handoff가 필요하다.
원래 v1 A/B 시작 노트북은 이번 단일-runtime 실행에 사용하지 않는다.

## 검증과 분석 위치

원본 source SHA, 실제 strict restore, stage/recovered Teacher CUDA finite 및 모델 평가는 Colab에서 수행한다.
상위 또는 사용자 PC로 model_state, optimizer/scaler checkpoint나 전체 raw logits를 다운로드하지 않는다.
Colab에서 OA/Hard/CE, confusion counts, 필요한 예측 요약과 paired 평균/SD를 계산하고 작은 JSON/CSV/summary와 hash 원장을 저장한다.
분석용 bundle은 명시적 whitelist와 크기 확인을 사용한다. checkpoint 확장자/모델 tensor/전체 logits를 포함하지 않는다.
요약 크기 초과 시 모델을 넣거나 핵심 행을 조용히 버리지 않고 indexed small parts 또는 HOLD로 처리한다.
모든 모델, epoch 기록, layout와 detailed evidence는 Drive에 남길 수 있다. PC에서는 필요한 요약만 선택적으로 읽는다.
원격 저장은 파일 metadata의 size/checksum 등 작은 증거로 확인하고 확인하지 못한 범위는 구분한다.

## 균형 저장과 원자적 재개

각 Teacher job은 고정 resume head 3개(active/prior/candidate)와 best head 3개를 사용한다.
이는 신규 실험의 상태 파일에만 적용하며 기존 파일의 삭제 또는 덮어쓰기 승인이 아니다.
current와 prior commit이 참조하는 resume/best head는 candidate 작성 중 보호한다.
candidate의 전체 bytes/SHA/strict restore/recipe/owner 검증이 끝난 뒤 COMMITTED pointer를 바꾼다.
실패 시 검증된 직전 active commit을 유지한다. resume와 boundary의 epoch/stage/reset 의미를 바꾸지 않는다.
모든 epoch의 작은 metrics/history와 transaction/layout/선정/hash 원장은 보존한다.
별도 영구 epoch model snapshot은 만들지 않는다.

필수 stage 상태는 4개의 post-surgery/reset model-only anchor와 stage2~4 이전의 3개 pre-surgery model-only anchor로 한정한다.
stage1의 pre 상태는 이미 보존한 원본 source를 참조한다. anchor로 L1 ranking과 실제 slicing을 Colab에서 감사할 수 있다.
완료 Teacher의 selected best와 final last는 현재 검증된 head를 seal해 재사용하며 추가 모델 복사를 요구하지 않는다.
Student는 원래 Native 수치 학습/선택 규칙을 유지하고 best/last와 작은 예측 요약만 보존한다.

Drive에서 동일 blob의 head를 갱신하는 경우 같은 file ID를 사용하며 원장에 ID/revision/SHA를 묶는다.
filesystem rename이 provider에서 독립 blob/Trash를 생성한다고 가정하거나 생성하지 않는다고 가정하지 않는다. 실제 accounting을 확인한다.
직접 Drive API를 사용하면 계정 인증은 Colab 안에서만 처리하고 원본 namespace 밖에는 쓰지 않는다.
기존 revision 삭제, 영구 삭제, Trash 비우기 API는 호출하지 않는다. 오래된 provider revisions는 영구 복구 가능하다고 보장하지 않는다.
필수 anchor와 최종 선택본은 별도 immutable 참조로 보존해 provider revision 자동 정리에 의존하지 않는다.
본 구현의 remote readback/atomicity/accounting을 실제로 확인하기 전 공간 감소를 실측 PASS로 표현하지 않는다.

## 저장량과 시간

이전 v1 append-only의 추가 여유 공간 추정은 P1 193.285GiB, 기본 307.672GiB, 최대 분기 614.288GiB였으며 v2 예산으로 그대로 쓰지 않는다.
v2 예산은 고정 head 수, stage anchors, Student/평가, 단일 upload의 peak와 여유분으로 새로 계산한다.
실제 quota가 충분하다는 사용자 진술과 인증 Drive API의 actual quota PASS를 구분한다.
PC에는 대형 모델 저장이 필요하지 않으며 코드/요약/원장에 대한 작은 작업 공간만 필요하다.
Colab local data/cache/staging/FUSE cache를 Drive 영구 저장량과 분리해 추정하고 실제 free/peak를 기록한다.
단일 L4에서 pilot 6–8, 기본 22–28, 최대 분기 32–38 GPU시간은 기존 처리량 기반 추정이며 이제 wall time도 같은 규모로 늘어난다.
setup/I/O/검토 대기/재시도 때문에 초과할 수 있다. 8/40시간은 검토 기록 기준이며 강제 시간 상한이 아니다.

## 시작과 완료 gate

새로운 단일 START notebook의 코드/패키지/CPU/독립 delta 검토를 먼저 통과한다.
최초 Colab 로그인/Drive 인증 후 실제 quota, source와 CUDA gate를 수행한다. 과거 v1 PASS로 대체하지 않는다.
새 SOURCE_GATE_READY가 생기면 같은 code/contract/원장에 묶인 actual review 후에만 본학습을 진행한다.
상위 대화가 실제 새 run 증거부터 30분 직접 Drive 확인을 담당한다. 별도 자동화나 중복 예약을 만들지 않는다.
모든 활성 job의 완료/저장/해시/receipt를 확인한 뒤 자기 런타임만 공식 unassign으로 해제 요청한다.
RELEASE_REQUESTED와 실제 반환 확인을 구분한다. Drive 파일은 삭제하지 않는다.

## 최소 회귀 검증

- A 한 개로 P1 및 full adaptive graph가 순차 완료되며 B record 없이 deadlock이 없어야 한다.
- 단일 writer/잘못된 slot/새 job runtime drift/중복 완료 marker를 거부한다.
- epoch 중간과 boundary 전후 pause/crash/resume, stage exactly-once와 strict restore를 검증한다.
- source review 전 본학습0, 최종 lock 전 Test0, closure 전 release 거부를 검증한다.
- 후보 저장/검증/pointer flip 전후 fault에서 active/prior와 참조 중 best가 보존되며 epoch 수만큼 blob 수가 증가하지 않는지 검증한다.
- 중간 head 재사용, stage anchors, final seal 및 remote SHA/revision accounting을 검증한다.
- analysis export는 크기 제한과 whitelist를 검사하며 checkpoint/tensor/logits를 포함하지 않는다.
- 새 code/ZIP/notebook SHA와 CPU/CLI/추출 검증을 고정하고 이전 v1 검증과 새 v2 검증을 구분한다.

이 부록은 신규 단일-runtime 구현의 검토 기준이며 실제 quota/CUDA/학습 완료 영수증이 아니다.
