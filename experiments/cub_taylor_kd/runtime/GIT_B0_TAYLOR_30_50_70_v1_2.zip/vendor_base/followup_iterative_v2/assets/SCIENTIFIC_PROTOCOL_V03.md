# Iterative pruning 후속 실험 프로토콜 초안 v0.3

상태: REVIEW_REQUIRED, PREPARATION_ONLY, GPU launch 금지.
기존 작업 01a172c5-8a62-7691-918f-0bfc05c640ff 안의 새 실험 namespace를 사용한다. 기존 55개 작업, Native, B1 및 원본 가중치와 설정은 수정하지 않는다.
새 namespace 제안: teamnative_iterative_matched_v1.
사용자가 A와 B 기존 런타임을 직접 해제했다고 2026-10-26 02:32:57 UTC에 확인했다. 이 확인을 재질문하지 않는다.
Chrome URL 안전성 종료는 해결됐다고 간주하지 않으며, 우회 또는 반복 승인 요청을 하지 않는다.

## 1. 원안과 근거의 구분

원안은 Library plan.md, library_file_id libfile_0bde2e5c1b9081918934cdfaedcb9c64, file_id file_00000000afb88206b2e38d988b1b278a, 2026-09-30 업로드, 11,689 bytes, 전체 410줄이다. 실제 Library read로 전체를 읽었다.
로컬의 교수님_피드백_반영_5인_프로젝트_계획.md는 별도 후속 문서이며 원안과 동일 파일이라고 부르지 않는다.

| 항목 | 원안 plan.md | 완료된 현행 one-shot 및 이번 후속 |
|---|---|---|
| 출발점 | pretrained → pruning → 동일 fine-tuning | 완료 Team Native Base의 45-epoch 예산 내 validation-best를 공통 출발점으로 사용한다. best가 마지막 epoch라는 뜻은 아니다. |
| pruning | L1 expanded-MLP hidden channel, residual dimension 보존 | 같은 대상을 유지한다. 36개 block의 실제 두 Linear tensor를 줄인다. |
| 비율 | 0/30/50/70%, 70% 붕괴 시 조정 가능 | MLP hidden 제거율이며 전체 Params/MACs 감소율이 아니다. 후속 비교에서는 방법 간 최종 폭을 정확히 맞춘다. |
| 복원 예산과 LR | 동일 조건을 요구하지만 20 epoch나 구체 LR는 없음 | 기존 실행은 CE20, backbone1e-5/head1e-4였다. 후속 20/40 비교는 새로 명시하는 정책이다. |
| Hard | validation Soft Confusion Top-20 pairs를 0% Teacher에서 한 번 선정 | 현재 frozen Native Base Hard IDs를 그대로 유지한다. 원안의 soft-pair 방식과 동일하다고 주장하지 않는다. |
| 데이터 | CUB 중심 | 현행 Team CUB ordered split, Flowers/Aircraft official split 및 pad/crop 입력을 고정한다. |
| KD 계수 표기 | alpha*CE+(1-alpha)*KD | 현재 코드는 (1-alpha)*CE+alpha*KD다. alpha=0.5에서는 값이 같으며 후속에서도 0.5로 고정한다. |
| 배포 | Student INT8 PTQ와 Android 측정 포함 | 이번 pruning 방법 비교에서는 수행하지 않는다. 원래 후속 배포 질문을 폐기한 것은 아니다. |

현재 완료 one-shot의 57개 Test 평가행 검산 결과는 이미 관측한 이전 실험이다. 다음 표는 동기와 보고용이며 실행 selector의 입력에서 제외한다.

| dataset | 이전 validation 사전 선택 ratio | Student Test OA/Hard 평균 | 같은 0% 대비 OA/Hard pp |
|---|---:|---:|---:|
| CUB | 30% | 72.794 / 55.080 | +0.351 / +1.008 |
| Flowers | 70% | 88.838 / 84.962 | -1.675 / -2.061 |
| Aircraft | 30% | 69.627 / 52.402 | +1.080 / +1.902 |

Flowers70은 Test에서 허용폭 밖이었다. 이 결과로 이전 validation 선택을 바꾸지 않는다. 후속 연구는 이전 Test를 본 뒤의 탐색적 후속임을 공개하고, 같은 Test를 완전히 새로운 독립 holdout처럼 표현하지 않는다.

## 2. 질문과 비교대상

Q1: 같은 최종 hidden 폭, 같은 복원 epoch 및 데이터 노출에서 반복적인 L1 ranking 재계산과 pruning 시점이 Student 품질을 바꾸는가?
Q2: 20에서 보존 목표를 못 맞출 때 40-epoch 복원 정책이 도움이 되는가?
Q2의 budget 변화에는 사전 지정한 global cosine와 stage 노출 및 checkpoint 선택 기회 변화가 포함된다. 순수 epoch 하나의 인과효과라고 부르지 않는다.

각 budget B에서 세 arm을 둔다.

1. D0: 0% dense matched control.
2. OS: one-shot pruning + matched stage resets.
3. IT: iterative pruning + matched stage resets.

OS는 일반 uninterrupted AdamW one-shot과 동일하다고 부르지 않는다. 이전 one-shot20 결과는 역사적 reference만 사용하며 새 matched control로 재사용하지 않는다.
Teacher recovery는 CE-only로 유지한다. dense-output KD recovery, DKD, Student 구조 변경, INT8을 동시에 추가하지 않는다.
원래 Native no-KD baseline은 초기값, split, stream, recipe, Hard 및 평가 참조가 정확히 연결될 때만 읽기 전용으로 재사용한다. Native Base KD 또는 이전 recovery-r00 KD를 새 D0로 대체하지 않는다.

## 3. 반드시 고정할 source와 입력

각 dataset의 동일 Native Base validation-best path, raw SHA256, model digest, source contract, selected epoch, original model_spec을 세 arm과 두 budget의 공통 Tsrc로 고정한다.
recovered r00를 IT의 출발점으로 쓰지 않는다.
Native split과 ordered IDs/labels, metadata, input view, train epoch/sample RNG, Student seed42/43/44 원래 initialization digest, read-only baseline, Native Base Hard IDs를 고정한다.
Teacher seed는 dataset의 현행 Native teacher seed를 유지한다.
Student는 MobileNetV3-Large, T4, alpha0.5, planned60, Native AMP/GradScaler와 전체-budget validation-best 선택을 유지한다.
새 code/protocol/source manifest identity와 현재 학습 원본의 identity는 별도로 기록한다. source model이 크다고 다른 weight로 대체하거나 size cap을 우회하지 않는다. 실제 Colab의 원본 filesystem에서 SHA와 strict restore를 검증한다.
SAS bearer URL, 인증 토큰 또는 서명 URL은 영구 manifest, OneDrive, source, 로그에 저장하지 않는다. 지속 원장에는 file ID, metadata, SHA만 둔다.

## 4. 네 stage의 정확한 pruning

K=4, j=1..4, 원래 block hidden H, 최종 제거율 r에 대해 목표 폭은 h_j=ceil(H*(1-r*j/4))다.
Decimal 또는 정확한 유리수 계산으로 경계를 처리한다. 마지막 폭은 OS와 IT 모두 ceil(H*(1-r))다.
현재 폭에 (1-r/4)를 반복 곱하지 않는다.
IT는 각 경계에서 현재 FP32 pwconv1.weight row-L1을 다시 계산한다. bias는 importance에 넣지 않는다.
동률은 낮은 original channel index를 우선하고 남은 original indices는 원래 순서로 정렬한다.
현재 retained-index 배열의 부분집합을 선택해 original indices를 합성한다.
pwconv1의 row와 bias, pwconv2의 같은 column을 함께 줄인다. pwconv2 output bias, residual width, depthwise, normalization, layer scale과 class head 폭은 보존한다.
OS는 첫 stage에서 최종 r을 한 번 적용한다. 이후 경계는 물리적 no-op이다. D0의 모든 pruning 경계도 no-op이다. no-op은 weight 재초기화 또는 다시 ranking한다는 뜻이 아니다.
nonfinite importance, 중복/범위 밖 index, 증가한 폭 또는 최종 폭 불일치는 오류로 중단한다.
legacy tckd의 이미 compact인 모델 거부를 우회해 같은 함수를 반복 호출하지 않는다. 새 surgery helper와 strict adapter로 원래 index 합성을 명시한다.
fresh dense 구조 + 저장된 original-index layout + strict state load로 중간/최종 모델을 복원할 수 있어야 한다.
학습 업데이트가 없는 4-stage IT와 OS의 최종 layout/weights/output 동일성은 필수 invariant다.

## 5. global epoch, LR, optimizer 및 best 선택

B=20의 stage 시작은 global e=0/5/10/15, B=40은 0/10/20/30이다.
stage마다 Native fit을 epochs=B/4로 호출하는 구현은 허용하지 않는다.
전역 e=0..B-1로 Native의 seed+e*100003, dataset.set_epoch(e,seed), DataLoader generator 및 global LR를 계산한다.
LR은 기존 Native warmup/cosine family를 B 전체에 한 번 적용한다. stage마다 warmup/cosine을 다시 시작하지 않는다. head warm-up은 0이다.

세 arm 모두 첫 stage 시작 및 이후 세 경계에서 fresh AdamW와 fresh GradScaler를 정확히 한 번 만든다.
base LR, weight decay, parameter groups, trainability, AMP policy는 세 arm에서 같다.
IT의 surgery 뒤 optimizer가 현재 Parameter만 참조하는지 검증한다. 낡은 Parameter 또는 Adam moments를 묵시적으로 재사용하지 않는다.
이번 버전은 moments slicing 방법이 아니라 모든 arm의 공통 reset 정책이다. moments 보존 변형은 별도 후속 factor다.

다음 stage는 직전 stage의 last fully completed state에서 이어간다. 중간 validation-best로 되감지 않는다.
Teacher best 후보는 최종 target 폭에 도달한 마지막 quarter, 즉 e=15..19 또는 e=30..39다. OS와 D0도 동일 window만 후보로 한다.
OA 최대, 동률이면 CE 최소, 완전 동률이면 earliest global epoch를 선택한다.
이전 폭의 best 또는 전체-history best를 새 KD Teacher로 잘못 연결하면 거부한다.
Student best는 기존 Native의 전체 planned60 규칙을 그대로 쓴다.

## 6. stage transaction과 resume

완료한 epoch의 gradient accumulation과 optimizer/scaler update, validation, checkpoint/hash 저장을 마친 뒤에만 경계를 넘는다.
checkpoint에는 next global epoch, 현재 stage, 적용한 boundary ID 목록, original-index layout, pre/post digest, optimizer/scaler/RNG, group의 parameter names/shapes/dtypes, selection eligibility와 best 상태, 전체 history를 저장한다.
stage 중간 resume는 해당 마지막 완료 epoch의 optimizer/scaler/RNG를 복원하며 다시 reset하지 않는다.
경계 직전 checkpoint에서 재개하면 결정론적인 surgery/reset을 한 번 적용한다. 이미 경계가 적용된 checkpoint에서는 다시 적용하지 않는다.
중간 epoch나 미완료 transaction을 완료로 선언하지 않는다. 실패 시 마지막 atomic committed epoch에서 이어간다.
source/layout/contract/runtime/recipe/hash 변경을 묵인해 resume하지 않는다.
planned20 last.pt를 planned40으로 바꿔 이어붙이지 않는다. B20/B40는 각각 별도 immutable 실행 계약과 경로다.

## 7. 최소 진단과 단계별 확장

P0: 새 실제 source/stage/strict-restore/CUDA finite gate를 optimizer update0으로 실행한다. 기존 216-record gate나 CPU fixture를 새 IT gate로 대체하지 않는다.

P1 최소 진단은 CUB r30에서 D0/OS/IT × B20/40이다.
- Teacher 6회, recovery epoch 합180.
- 각 조건 Student seed42 planned60 완료 6회, Student epoch 합360.
- validation만 수집하고 Test 호출0.
- CUB를 먼저 택한 이유는 기존 연구의 우선 dataset과 비교적 짧은 실제 처리량이며, 새 Test 유불리로 dataset을 고르지 않는다.

P2는 Flowers r70, Aircraft r30에서 우선 B20의 D0/OS/IT를 실행한다.
각 dataset에서 B20이 아래 budget eligibility를 못 맞출 때만 B40의 세 arm을 추가한다.
따라서 40을 생략한 dataset에 대해 20이 최적이라거나 더 긴 예산이 이득 없다고 주장하지 않는다. validation 보존 목표를 20에서 충족했다는 제한된 판단이다.

P3는 각 dataset에서 선택된 B와 동일 final ratio의 D0/OS/IT를 Student42/43/44로 완성한다.
pilot의 seed42 run은 immutable Teacher/contract/full60/init/stream/runtime이 정확히 같을 때만 재사용한다.
추가 seed43/44는 총18회다. pilot seed42가 budget 선택에 사용됐음을 보고하며, 3seed SD를 독립 budget/Teacher seed 검증이나 비열등성 증명으로 부르지 않는다.
12-epoch pause를 full60 완료나 보존 판정으로 쓰지 않는다. 이 v0.3의 수치 선택은 full60만 사용한다.

## 8. validation decision table

보존 margin과 budget 선택은 새 validation의 Student full60 checkpoint에서 계산한다. 아래 Teacher resource screen만 별도의 Teacher validation 판정이다.
control과 모든 참조/수치가 유효해야 한다. 완료로 선언한 run의 필수 artifact 손상/누락, shape/contract/precision mismatch 또는 nonfinite는 ERROR_HOLD다. performance fallback으로 숨기지 않는다.
아직 activate하지 않았거나 완료하지 않은 required run은 PENDING이며 오류나 ineligible 값으로 바꾸지 않는다. 의도적 NOT_RUN_TEACHER_COLLAPSE는 미완료 Student 오류가 아니라 사전에 정의한 resource skip이다.
D0 자체가 numerical/contract invalid이거나 아래 class-collapse이면 INVALID_CONTROL_HOLD다.

Teacher class-collapse resource screen은 eligible-window OA/CE/earliest 규칙으로 먼저 고정한 selected Teacher checkpoint의 동일 validation에서
  valOA <= max(5.0, 2*100/num_classes)
  AND max_predicted_class_fraction >= 0.99
일 때만 적용한다. val confusion/prediction histogram은 이미 수행한 validation forward에서 기록한다.
selected Teacher가 정상이면 마지막 두 epoch만 붕괴했어도 이 guard로 제외하지 않는다. 마지막 두 epoch 상태는 trajectory 진단으로 따로 보존하며 eligibility나 Student 활성화를 바꾸지 않는다.
이 screen은 Student 성능을 예측한 증명이 아니라 명백히 붕괴한 Teacher에 대한 자원 guard다.
해당 arm은 Student를 임의 full60로 세지 않고 NOT_RUN_TEACHER_COLLAPSE로 남긴다. 실제 source/AMP 오류와 구분한다.

각 budget B에서 D0_B의 같은 Student seed42와 paired 비교한다.
PASS(method,B) = OA_method-OA_D0 >= -1.0pp AND Hard_method-Hard_D0 >= -2.0pp.
이것은 pilot 보존 목표이지 통계적 비열등성이 아니다.
PAIRED_VIABLE(B)는 D0가 유효하고 OS/IT 두 Teacher에 class-collapse가 없음을 뜻한다.
ELIGIBLE(B) = PAIRED_VIABLE(B) AND (PASS(OS,B) OR PASS(IT,B)).

다음 표는 위에서 아래 순서로 적용하는 배타적인 decision tree다. fallback_used는 추가 ratio 변경을 금지하며 현재 target50의 성공을 무효화하지 않는다.

| 조건 | 행동 |
|---|---|
| required control/contract/numerics invalid | ERROR/INVALID_CONTROL_HOLD, Test0, 원인 보고 |
| 현재 target의 B20 required run/artifact가 pending | PENDING_B20, 완료/의도적 skip 상태를 먼저 확인 |
| CUB의 required B40 factorial 진단이 pending | PENDING_CUB_FACTORIAL_B40, 두 budget 진단 완료 후 선택 |
| ELIGIBLE20 true | B20 선택, fallback 사용 여부와 무관하게 두 방법 모두 P3에 포함 |
| ELIGIBLE20 false, B40 미평가 또는 pending | B40 활성화/대기, ineligible이나 오류로 치환하지 않음 |
| ELIGIBLE20 false, ELIGIBLE40 true | B40 선택, fallback 사용 여부와 무관하게 두 방법 모두 P3에 포함 |
| 현재 target의 두 budget 모두 평가했고 둘 다 ineligible, target70이고 fallback 미사용 | 두 방법 모두 target50, fallback_used=true로 한 번 변경, D0_B는 재사용, target50의 E20/E40는 새 상태로 평가 |
| 현재 target의 두 budget 모두 평가했고 둘 다 ineligible, target30/50이거나 fallback 이미 사용 | PRESERVATION_NOT_FOUND, 해당 dataset의 비싼 main activation 보류, 실패와 비용 기록, Test0 |

CUB는 최초 factorial 진단이라 두 budget 모두 완료한 뒤 선택한다.
Flowers fallback은 최대 한 번 r70→r50이고 IT/OS에 같은 final ratio를 적용한다. r70 실패를 지우지 않고 adaptive fallback으로 표기한다.
budget20에서 Teacher collapse가 있으면 budget40도 진단한 뒤 결정한다. budget 확대 효과와 ratio 효과를 혼동하지 않는다.

P3 전체3seed validation에서 보존 여부는 paired OA/Hard 차이 평균의 위 AND margin으로 다시 판정한다.
P3 후에는 이 버전에서 ratio/budget을 또 튜닝하지 않는다. 둘 다 보존 실패이면 추천은 D0이고 두 압축 arm의 실패를 보고한다.
둘 중 하나만 보존하면 그것을 추천한다. 둘 다 보존하면 아래 canonical recovery cost가 작은 arm을 추천하고, 비용 동률이면 Val Hard, Val OA, 마지막 완전동률이면 OS 순으로 결정한다.
추천과 별개로 D0/OS/IT 세 조건은 사전 등록한 비교 대상으로 모두 final Test에 포함한다. Test 수치로 추천을 뒤집지 않는다.

추천용 canonical field는 recovery_allocated_wall_ms다. 이는 GPU kernel 시간이 아니라 해당 recovery job이 GPU를 할당받아 실제 처리한 구간의 wall time이다.
각 attempt에서 source raw SHA/strict restore와 공통 dataset 준비가 끝나 첫 stage surgery/reset 직전에 perf_counter_ns를 시작하고, 모든 4stage의 train/validation, ranking/surgery/reset, checkpoint/history/status/hash/Drive I/O 및 최종 best/last gate가 완료된 시점까지 측정한다. 최종 completion receipt 자체를 쓰는 시간은 제외한다.
resume attempt의 checkpoint 읽기/restore/검증 비용은 recovery 함수 진입부터 포함한다. 같은 job의 중단/실패 attempt와 재시도 구간도 모두 합친다. queue/dependency 대기, 공통 환경 설치, dense45/source 검증 및 Student KD 비용은 제외하고 별도 보고한다.
완전한 attempt ledger의 각 elapsed_ns를 합친 뒤 (sum_ns+500000)//1000000으로 정수 ms를 한 번 산출한다. 모든 attempt의 시작/종료와 중복 없는 segment identity가 있어야 하며 crash로 종료 시각이 없으면 불완전 비용이다.
OS/IT의 GPU model, runtime precision/profile 및 계측 schema는 같아야 한다. GPU UUID는 기록하되 동일 물리 GPU를 강제하지 않는다. 두 runtime의 성능 변동과 Drive I/O 잡음을 포함한 관측 비용이며 순수 방법의 계산 복잡도 증거로 해석하지 않는다.
시간 차이가 max(1000ms, ceil(0.01*min(cost_OS,cost_IT))) 이하이면 비용 동률로 처리한다. 이 범위를 넘으면 작은 값을 선택한다. 비용이 동률일 때만 full3seed validation Hard 평균, OA 평균, OS 순으로 판정한다.
두 방법 모두 보존하지만 비용이 누락/불완전/비교 불가능하면 RECOMMENDATION_HOLD_COST_INCOMPLETE다. 0으로 대체하거나 accuracy tie-break로 건너뛰지 않는다. budget/ratio 및 D0/OS/IT 비교 집합은 바꾸지 않으며 Test lock에는 추천 보류 사유를 명시할 수 있다. Test를 본 뒤 비용 정의나 추천 규칙을 바꾸지 않는다.

## 9. 실행 수와 시간 예산

모든 단계가 활성화되는 경우의 새 실행 수다. skipped/failed/paused는 별도로 기록한다.

| 분기 | 새 Teacher | full60 Student |
|---|---:|---:|
| 최소 CUB 진단 | 6 | 6 |
| 타 dataset B20 진단과 세 dataset P3까지, B40 추가 없음 | 총12 | 총30 |
| Flowers/Aircraft 모두 B40 추가 | 총18 | 총36 |
| Flowers r50의 B20/B40 fallback까지 모두 추가 | 최대22 | 최대40 |

Teacher recovery epoch 합은 기본300, 두 추가dataset B40까지540, fallback 두 budget까지660이다.
Student epoch 합은 기본1800, 최대2400이다. 숫자는 동시 최대/평균을 섞지 않고 실제 activation manifest로 다시 센다.

완료된 동일 L4 실행의 관측 범위로 Student60 1회는 CUB 약24~26분, Flowers8~10분, Aircraft60~63분이었다. Teacher20은 CUB18~22분, Flowers5~10분, Aircraft20~25분 수준이었다.
새 IT는 초기 stage에서 더 넓은 Teacher를 학습하며 reset/checkpoint I/O도 있어 기존 시간과 같지 않다.
최소 CUB 진단은 약6~8 allocated GPU-hours, 두 L4에서 약3~4시간을 예상한다.
주 경로 전체는 약22~28 GPU-hours, 두 L4에서 대략12~16시간을 예상한다.
B40와 fallback이 모두 활성화되면 약32~38 GPU-hours, 대략18~22시간까지 늘 수 있다.
이는 측정 전 조건부 추정이며 구매 가격이나 보장 ETA가 아니다. 단일 L4만 가능하면 wall time이 늘어난다.
pilot8 및 전체40 GPU-hours에서 다음 job 시작 전 예산 검토를 기록한다. 원래 source45 공통 비용, 실제 recovery/mask/추가진단/KD/inference/I/O/idle 비용을 분리한다.
추가 결제/업그레이드/제3 runtime을 자동 수행하지 않는다.

## 10. precision과 모델 검증

초기 정책은 Teacher training AMP, KD Teacher AMP, Student AMP+GradScaler, eval FP32이며 완료된 Native recipe와 같은 종류다.
B1 overflow만으로 ConvNeXt FP32가 필수라고 주장하지 않는다.
실제 L4의 source, 각 중간/최종 폭, recovered Teacher에서 output/loss/unscaled gradients 유한성 및 skipped optimizer steps를 검사한다.
scaled gradient의 정상 GradScaler backoff와 실제 output/loss nonfinite를 구분하고 기록한다.
실패하면 특정 arm만 FP32/clamp/resume하지 않는다. ERROR_HOLD 후 모든 arm에 일관된 별도 precision 계약을 만들고 원래 source/초기값부터 재실행해야 한다.
checkpoint strict restore, model/raw digest, optimizer parameter membership, stage layout, best eligibility와 final ratio gate가 통과해야 Student를 활성화한다.

## 11. Test 보호와 원장

selector는 validation artifact whitelist만 읽는다. Test path/logits/metrics를 읽는 코드를 selector에서 거부한다.
Student들의 final ratio, method, B, source/Teacher/Student/baseline/Hard/split/validation SHA, code/protocol identity를 FINAL_SELECTION_LOCK에 고정한다.
Test는 lock이 완성되고 실제 weights와 일치한 뒤 final 평가에서만 읽는다. lock 변경 뒤 같은 Test를 튜닝해 재평가하지 않는다.
보고서는 dataset별 OA/Hard, 같은 seed IT-OS와 각 D0 대비 차이, 평균 및 표본SD, 실패/skip와 실제 비용을 모두 남긴다.
동일 epochs/data exposure 비교와 동일 compute 비교를 구분한다. 단계별 폭/Params/MACs, samples, attempted/applied/skipped optimizer steps, wall/I/O scope, peak memory를 기록한다.

## 12. 두 slot, Drive 저장, PC 독립성

기존 phaseb의 source/assignment/owner nonce/attempt/receipt 단일-writer guard를 재사용하되 새 job graph identity를 쓴다.
소유권 변경/중복 writer/완료 marker 불일치/expired lease는 자동 steal하지 않고 HOLD한다.
P1 activation, dataset budget/fallback decision, P3 activation, final Test lock은 각각 단일 coordinator가 한 번만 쓴다.
같은 GPU에 여러 training job을 적재하지 않는다. 동시에 최대 두 runtime이다.
Drive에 매 epoch checkpoint/status, 각 경계/layout/decision, 30분 progress review를 남긴다. 사용자 PC가 꺼져도 Colab 학습과 Drive 상태 저장은 계속될 수 있어야 한다.
이미 운영 중인 cloud 측 Drive 읽기 관측을 30분 단위로 유지한다. PC가 켜져야만 동작하는 local monitor로 대체하거나 중복 감시 작업을 새로 만들지 않는다.
ready dependency 대기는 정상 job orchestration으로만 한정하고, 무제한 keepalive나 서비스 제한 회피는 하지 않는다.

모든 배정 작업과 flush/hash/receipt 검증 후 GPU가 더 필요 없으면 official google.colab.runtime.unassign() 호출을 지원할 수 있다.
공식 source: https://raw.githubusercontent.com/googlecolab/colabtools/main/google/colab/runtime.py (2026-10-26 확인).
자기 runtime 내부에서만 공식 함수를 사용한다. 외부에서 내부 endpoint/credential을 재구현하지 않는다.
호출 전 RELEASE_REQUESTED를 저장하며, 실제 할당 반환 확인 없이 RELEASE_CONFIRMED라고 쓰지 않는다. 호출 실패 시 상태를 남기고 반복 요청/우회하지 않는다.
현 Chrome 안전 차단 때문에 새 runtime 연결과 최초 notebook 시작은 여전히 별도 실행 경로의 차단이다. 준비 완료와 실제 launch/첫 epoch를 구분한다.

## 13. 구현 및 freeze 전 acceptance

- 소스/원안/현재실행 보존 SHA와 policy 차이 문서를 남긴다.
- global LR/RNG가 stage 안에서 reset되지 않는 fixture를 B20/B40 모두 검증한다.
- stage 경계 optimizer/scaler reset 수, stale parameter 제거, mid-stage 및 boundary resume 등가성을 검증한다.
- r0 no-op, OS/IT zero-update 동일성, global original-index 합성, 정확한 최종 폭과 strict restore를 검증한다.
- Teacher best eligibility/tie/이전폭 best 거부, changed source/model/receipt 거부를 검증한다.
- budget/fallback/invalid-control decision table과 job activation counts, single writer 및 final Test lock 누수 guard를 검증한다.
- 기존 sourceCUDA PASS를 새 IT 실제 gate로 대체하지 않는다. 로컬 fixture와 실제 pretrained/CUDA 실행 증거를 분리한다.
- CLI/노트북/ZIP의 syntax/schema/CRC/source hash, 추출 후 CPU fixture와 plan-only 실행을 확인한다.
- 실제 CUDA gate 후에만 P1을 시작하고 첫 완료 epoch 및 checkpoint/raw SHA를 보고한다.

이 초안은 아직 독립 재검토와 구현/실제 gate를 통과하지 않았으며 launch 허가증이 아니다.

## 14. 선행 근거와 이번 검증의 범위

Li 등의 [Pruning Filters for Efficient ConvNets](https://arxiv.org/abs/1608.08710)는 filter와 연결 feature map을 물리적으로 제거하는 structured pruning의 선행 예다. 이번 대상은 ConvNeXt expanded MLP hidden이므로 그 논문의 architecture나 정확도 수치를 그대로 재현한다고 부르지 않는다.
Zhu와 Gupta의 [To prune, or not to prune](https://arxiv.org/abs/1710.01878)는 gradual pruning의 선행 근거다. sparse weight를 다루는 원래 방법과 달리 이 실험은 4stage linear cumulative structured slicing이며, 동일 구현이나 우월성의 증거가 아니다.
Liu 등의 [Rethinking the Value of Network Pruning](https://arxiv.org/abs/1810.05270)는 pruning 비교에서 학습 조건과 baseline을 신중히 맞춰야 함을 뒷받침한다. 이번 실험은 pretrained Teacher의 KD 적합성을 비교하며 scratch 학습 우열을 새로 검증하지 않는다.
세 원문 abstract와 서지정보를 2026-10-26 확인했다. K4, linear schedule, matched resets 및 final-quarter window는 이번 사전 명세이며 문헌이 최적이라고 보장한 설정이 아니다. 이번 IT가 OS보다 낫다는 결과는 아직 없다.

