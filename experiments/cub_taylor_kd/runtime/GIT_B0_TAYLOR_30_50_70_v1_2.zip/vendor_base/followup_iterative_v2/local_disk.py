"""Observed Colab local disk gate; Drive quota and opaque FUSE cache stay separate."""
from pathlib import Path
from datetime import datetime,timezone
import shutil

GIB=1024**3
MIN_FREE_BYTES=8*GIB

def snapshot(path='/content',*,minimum_free=MIN_FREE_BYTES):
    path=Path(path).resolve()
    usage=shutil.disk_usage(path)
    if usage.free<minimum_free:
        raise ValueError(f'COLAB_LOCAL_DISK_HOLD: free{usage.free} below reserve{minimum_free}')
    return {'state':'PASS','observed_at_utc':datetime.now(timezone.utc).isoformat(),'path':str(path),
            'total_bytes':usage.total,'used_bytes':usage.used,'free_bytes':usage.free,'minimum_free_bytes':minimum_free,
            'scope':'Observed local filesystem free space; not Drive quota or a measured peak',
            'FUSE_writeback_cache_bytes':'not_separately_measured_or_bounded'}

def inventory(root):
    root=Path(root).resolve()
    if not root.is_dir():return {'path':str(root),'state':'not_present','bytes':0}
    files=[p for p in root.rglob('*') if p.is_file() and not p.is_symlink()]
    return {'path':str(root),'state':'observed','bytes':sum(p.stat().st_size for p in files),'files':len(files)}

def record(directory,event):
    from .common import atomic_json
    import json
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    value={**snapshot(),'event':event}
    atomic_json(directory/'LOCAL_DISK_LATEST.json',value)
    with (directory/'LOCAL_DISK_SAMPLES.jsonl').open('a',encoding='utf8') as stream:
        stream.write(json.dumps(value,ensure_ascii=False)+'\n')
    return value
