"""Single pruning runtime orchestration. No second slot, allocator or browser API."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import time
from phaseb.ownership import JobKey,_process_lock
from .common import ROOT,read,sha,identity,atomic_json
from .execution import output_root,controls,code_manifest,freeze,prepare_data,register,bind,execution,job_dir,completion
from .graph import all_jobs,partition,active_jobs,counts
from .local_disk import snapshot,inventory
from . import pipeline


def receipts(work,assignment):
    return {j.job_id:completion(work,assignment,j) for j in all_jobs()}

def activation(work,assignment,values):
    expand=values.get(JobKey('all','activate_p2',0,0).job_id) is not None
    main=values.get(JobKey('all','activate_p3',0,0).job_id) is not None
    active=active_jobs(values,expand=expand,main=main)
    if values.get(JobKey('all','analysis_export',0,0).job_id):active.add(JobKey('all','analysis_export',0,0))
    return active

def require_source_review(work,assignment,contract):
    result=completion(work,assignment,JobKey('all','source_review',0,0))
    source=completion(work,assignment,JobKey('all','aggregate',None,None))
    if not result or not source or result['source_gate_identity']!=identity(source) or result['code_id']!=contract['code_id']:
        raise ValueError('Actual new source/stage gate must be reviewed before START_TRAINING')

def coordinator(work,slot,kind,review_file=None):
    contract,a,r,guard=execution(work,slot)
    if slot!='A':
        raise ValueError('Only registered A coordinates immutable activations/closure')
    key=JobKey('all',kind,0,0)
    if completion(work,a,key):
        return completion(work,a,key)
    values=receipts(work,a)
    active=activation(work,a,values)
    if kind=='source_review':
        source=values[JobKey('all','aggregate',None,None).job_id]
        review=read(review_file)
        if (not source or review.get('state')!='ACTUAL_CUDA_REVIEW_PASS' or
            review.get('source_gate_identity')!=identity(source) or review.get('contract_id')!=contract['contract_id'] or
            review.get('code_id')!=contract['code_id'] or not review.get('review_evidence')):
            raise ValueError('Actual CUDA review does not match this new source/stage evidence')
        sessions=review.get('global_sessions',{})
        if (type(sessions.get('active_count')) is not int or not 0<=sessions['active_count']<=2 or
            not sessions.get('observed_at_utc') or not sessions.get('evidence') or
            sessions.get('includes_other_projects') is not True):
            raise ValueError('GLOBAL_SESSION_OCCUPANCY_PENDING: current whole-account session evidence is required')
        if review.get('pruning_runtime_count')!=1:
            raise ValueError('v2 actual review must bind exactly one pruning runtime')
        payload={'state':'complete','kind':'source_review','frozen_contract_id':contract['contract_id'],
                 'code_id':contract['code_id'],'source_gate_identity':identity(source),'review':review}
    elif kind in ('activate_p2','activate_p3'):
        require_source_review(work,a,contract)
        decisions={k:v for k,v in values.items() if v and v.get('kind')=='validation_decision'}
        if not decisions or (kind=='activate_p2' and not any(v['dataset']=='cub200' for v in decisions.values())):
            raise ValueError('Required pilot validation decision is still pending')
        if kind=='activate_p3':
            terminal={v['dataset'] for v in decisions.values() if v['action'].startswith('SELECT_') or v['action']=='PRESERVATION_NOT_FOUND'}
            if terminal!={'cub200','flowers102','aircraft'}:
                raise ValueError('Every dataset needs a terminal pilot decision before P3')
        review=read(review_file) if review_file else {'state':'VALIDATION_REVIEW_PASS',
            'decision_identities':{k:identity(v) for k,v in decisions.items()},'continue_within_existing_budget':True,
            'review_evidence':'Frozen v0.3 automatic decision table; validated full60 marker chain',
            'review_mode':'automatic_predeclared_full_workflow','budget_review':budget_review(work,a)}
        if (review.get('state')!='VALIDATION_REVIEW_PASS' or review.get('decision_identities')!={k:identity(v) for k,v in decisions.items()} or
            review.get('continue_within_existing_budget') is not True or not review.get('review_evidence')):
            raise ValueError('Pilot/budget review must bind all current immutable decisions')
        if values[JobKey('all','close_workflow',0,0).job_id]:
            raise ValueError('Closed workflow cannot activate new work')
        payload={'state':'complete','kind':kind,'frozen_contract_id':contract['contract_id'],'review':review}
    elif kind=='close_workflow':
        pending=[j.job_id for j in active if values[j.job_id] is None]
        if pending:
            raise ValueError('Cannot close with activated pending jobs: '+','.join(pending))
        payload={'state':'complete','kind':'closed','frozen_contract_id':contract['contract_id'],
                 'active_job_ids':sorted(j.job_id for j in active),
                 'completion_identities':{j.job_id:identity(values[j.job_id]) for j in active},
                 'no_more_jobs_in_this_bound_workflow':True}
    else:
        raise ValueError('Unknown coordinator action')
    with guard.claim(key) as lease:
        atomic_json(lease.output_dir/'COMPLETE.json',payload);lease.complete(payload)
    return payload

def budget_review(work,assignment):
    """Recorded before each next job. Thresholds require review, not new approval.

    This estimate counts the single pruning runtime's wall including idle;
    it excludes allocation/setup before registration and is not the canonical
    per-method recovery cost used for recommendations.
    """
    now=datetime.now(timezone.utc)
    rows=[]
    for slot in ('A',):
        r=read(controls(work)/f'runtime_{slot}.json')
        started=datetime.fromisoformat(r['registered_at_utc'])
        rows.append({'slot':slot,'runtime_id':r['runtime_id'],'wall_seconds_since_registration':max(0.,(now-started).total_seconds())})
    hours=sum(r['wall_seconds_since_registration'] for r in rows)/3600
    return {'reviewed_at_utc':now.isoformat(),'registered_allocated_wall_hours':hours,'slots':rows,'pruning_runtime_count':1,'other_workflows_touched':False,
            'pilot8h_review_due':hours>=8,'workflow40h_review_due':hours>=40,
            'decision':'CONTINUE_FROZEN_WORKFLOW_WITH_ONE_PRUNING_RUNTIME_NO_ADDITIONAL_PURCHASE',
            'automatic_review':True,'scope':'Registration-to-now wall estimate, not total billing or per-method GPU kernel time'}

def automatic_coordinator(work,slot,full_workflow):
    if slot!='A':
        return
    contract,a,r,guard=execution(work,slot);values=receipts(work,a)
    cub=[v for v in values.values() if v and v.get('kind')=='validation_decision' and v['dataset']=='cub200']
    if not cub:
        return
    if full_workflow and not values.get(JobKey('all','activate_p2',0,0).job_id):
        coordinator(work,slot,'activate_p2')
        values=receipts(work,a)
    decisions=[v for v in values.values() if v and v.get('kind')=='validation_decision']
    terminal={v['dataset'] for v in decisions if v['action'].startswith('SELECT_') or v['action']=='PRESERVATION_NOT_FOUND'}
    if full_workflow and terminal=={'cub200','flowers102','aircraft'} and not values.get(JobKey('all','activate_p3',0,0).job_id):
        coordinator(work,slot,'activate_p3')
        values=receipts(work,a)
    active=activation(work,a,values)
    if all(values[j.job_id] is not None for j in active) and (not full_workflow or terminal=={'cub200','flowers102','aircraft'}):
        export_key=JobKey('all','analysis_export',0,0)
        if not values.get(export_key.job_id):
            pipeline.run_job(work,a,contract,r,guard,export_key,values,budget_record=budget_review(work,a))
        coordinator(work,slot,'close_workflow')

def release_runtime(work,slot):
    contract,a,r,guard=execution(work,slot);values=receipts(work,a)
    closed=values.get(JobKey('all','close_workflow',0,0).job_id)
    if not closed or not closed['no_more_jobs_in_this_bound_workflow']:
        raise ValueError('Workflow closure and all saved activated jobs are required before release')
    active=activation(work,a,values)
    if sorted(j.job_id for j in active)!=closed['active_job_ids'] or any(values[j.job_id] is None or identity(values[j.job_id])!=closed['completion_identities'][j.job_id] for j in active):
        raise ValueError('Saved completion set changed after workflow closure')
    key=JobKey('all','release_'+slot.lower(),0,0)
    path=job_dir(work,a,key)
    if (path/'RELEASE_REQUESTED.json').exists():
        raise ValueError('Release was already requested; no automatic retry or success inference')
    with guard.claim(key) as lease:
        record={'state':'RELEASE_REQUESTED','slot':slot,'runtime_id':r['runtime_id'],
                'assignment_id':a['assignment_id'],'all_saved_completion_identities':closed['completion_identities'],
                'requested_at_utc':datetime.now(timezone.utc).isoformat(),'RELEASE_CONFIRMED':False,
                'official_api':'google.colab.runtime.unassign','Drive_files_deleted':False}
        atomic_json(lease.output_dir/'RELEASE_REQUESTED.json',record)
        if read(lease.output_dir/'RELEASE_REQUESTED.json')!=record:
            raise ValueError('Release intent Drive readback failed')
        try:
            from google.colab import runtime
            runtime.unassign()  # Official API, self runtime only. No internal endpoint reconstruction.
        except Exception as error:
            atomic_json(lease.output_dir/'RELEASE_FAILED.json',{'error_type':type(error).__name__,'message':str(error),
                        'RELEASE_CONFIRMED':False,'automatic_retry':False})
            raise
        result={'state':'complete','kind':'release_request_sent','frozen_contract_id':contract['contract_id'],
                'RELEASE_CONFIRMED':False,'independent_allocation_return_confirmation_required':True}
        atomic_json(lease.output_dir/'COMPLETE.json',result);lease.complete(result)
    return result

def plan(work=None):
    from .storage import plans
    manifest=code_manifest();storage=plans()
    result={'state':'PREPARATION_ONLY','namespace':'teamnative_iterative_single_v2','code_id':manifest['code_id'],
        'pruning_runtimes':1,'single_owner':'A','max_global_sessions':2,'user_reported_other_runtime_count':1,
        'other_project_runtime_actions':0,'actual_new_GPU_allocations':0,'actual_followup_training':0,
        'training_calls':0,
        'potential_jobs':len(all_jobs()),'P1':counts(active_jobs({})),
        'storage_policy':'per_job_3resume_3best_7anchors_v2_1','storage_capacity_state':'ACTUAL_QUOTA_NOT_OBSERVED',
        'storage_estimates':{k:{'required_free_bytes':v['required_free_bytes_with_headroom'],'required_free_GiB':v['required_free_GiB']} for k,v in storage.items()},
        'PC_model_optimizer_full_logit_downloads':False,'analysis_export_cap_bytes':128*1024**2,
        'actual_CUDA_verified':False,'source_stage_candidates':88,
        'monitoring':'Parent owns direct Drive observations after real start; no active scheduled automation is claimed',
        'time_scope':'One pruning GPU: GPU-hours approximately wall-hours plus preparation/idle; not divided by two'}
    if work and (controls(work)/'execution.json').exists():
        assignment=read(controls(work)/'execution.json')['assignment'];values=receipts(work,assignment)
        active=activation(work,assignment,values)
        result['pending_jobs']=[j.job_id for j in sorted(active) if values[j.job_id] is None]
    return result

def worker(work,slot='A',*,start_training=False,auto_release=False,full_workflow=False):
    if slot!='A':raise ValueError('v2 permits only the single pruning owner A')
    if start_training is not True:raise ValueError('Actual new source/stage CUDA review is required')
    contract,assignment,registration,guard=execution(work,'A');require_source_review(work,assignment,contract)
    if registration['workflow_mode']!=('full' if full_workflow else 'pilot_only'):
        raise ValueError('Worker scope differs from registered contract')
    lock=Path(assignment['local_lock_root'])/assignment['assignment_id']/'worker_A.lock'
    with _process_lock(lock):
        while True:
            automatic_coordinator(work,'A',full_workflow)
            values=receipts(work,assignment);active=activation(work,assignment,values)
            if values.get(JobKey('all','close_workflow',0,0).job_id):
                if auto_release:return release_runtime(work,'A')
                return {'state':'workflow_closed_saved','pending_jobs':[],'pruning_runtimes':1,'runtime_released':False}
            pending=[j for j in sorted(active) if values[j.job_id] is None]
            ready=[j for j in pending if pipeline.ready(work,assignment,contract,j,values)]
            if not ready:
                raise ValueError('SINGLE_RUNTIME_DAG_HOLD: unresolved dependencies='+','.join(j.job_id for j in pending))
            key=ready[0]
            print(__import__('json').dumps({'state':'starting','owner':'A','job_id':key.job_id}),flush=True)
            pipeline.run_job(work,assignment,contract,registration,guard,key,values,budget_record=budget_review(work,assignment))
            print(__import__('json').dumps({'state':'completed','owner':'A','job_id':key.job_id}),flush=True)

def autorun(work,inputs,*,start_full_workflow=False,review_timeout=7200,pilot_only=False):
    if start_full_workflow is not True or not 1<=review_timeout<=7200:
        raise ValueError('Explicit START_FULL_WORKFLOW and finite evidence review wait are required')
    work=output_root(work)
    with _process_lock(Path('/content/itkd_v2_autorun_locks/owner_A.lock')):
        freeze(work)
        atomic_json(controls(work)/'LOCAL_DISK_START.json',snapshot())
        prepared=prepare_data(work,inputs)
        atomic_json(controls(work)/'LOCAL_CACHE_INVENTORY.json',{'observed_after_prepare':True,
            'data_cache':inventory('/content/itkd_v2_raw_cache'),'code':inventory(ROOT.parent),
            'local_disk':snapshot(),'FUSE_writeback_cache_bytes':'not_separately_measured'})
        register(work,'A',prepared['data_roots_file'],pilot_only=pilot_only)
        if not (controls(work)/'execution.json').exists():bind(work,'A')
        contract,assignment,registration,guard=execution(work,'A')
        probe=JobKey('all','storage_probe',0,0)
        if completion(work,assignment,probe) is None:pipeline.run_job(work,assignment,contract,registration,guard,probe,receipts(work,assignment))
        source_key=JobKey('all','aggregate',None,None)
        source=completion(work,assignment,source_key) or pipeline.run_job(work,assignment,contract,registration,guard,source_key,receipts(work,assignment))
        atomic_json(controls(work)/'SOURCE_GATE_READY.json',{'state':'ACTUAL_SOURCE_STAGE_CUDA_READY_FOR_REVIEW',
            'namespace':contract['namespace'],'source_gate_identity':identity(source),'contract_id':contract['contract_id'],
            'code_id':contract['code_id'],'gate_path':str(job_dir(work,assignment,source_key)/'COMPLETE.json'),
            'optimizer_steps':0,'training_started':False,'pruning_runtime_count':1,
            'other_project_runtime_actions':0,'new_research_approval_required':False})
        review_path=controls(work)/'ACTUAL_CUDA_REVIEW.json';started=time.monotonic()
        while not review_path.is_file():
            elapsed=time.monotonic()-started
            if elapsed>=review_timeout:
                atomic_json(controls(work)/'REVIEW_WAIT.json',{'state':'ACTUAL_EVIDENCE_REVIEW_TIMEOUT',
                    'elapsed_seconds':elapsed,'training_started':False,'automatic_retry':False})
                raise TimeoutError('Actual new source/stage evidence review remains pending')
            time.sleep(min(15,review_timeout-elapsed))
        coordinator(work,'A','source_review',review_path)
        return worker(work,'A',start_training=True,auto_release=True,full_workflow=not pilot_only)

def main():
    parser=argparse.ArgumentParser(description='Single pruning runtime v2; Drive-only checkpoints, small PC summaries')
    parser.add_argument('command',choices=['plan','freeze','prepare-data','register','bind','source-gate',
        'review-source-gate','activate-p2','activate-p3','close-workflow','worker','release-runtime','autorun'])
    parser.add_argument('--work-dir');parser.add_argument('--inputs');parser.add_argument('--data-roots-file');parser.add_argument('--review-file')
    parser.add_argument('--start-training',action='store_true');parser.add_argument('--start-full-workflow',action='store_true')
    parser.add_argument('--full-workflow',action='store_true');parser.add_argument('--pilot-only',action='store_true')
    parser.add_argument('--auto-release',action='store_true');parser.add_argument('--review-timeout',type=int,default=7200)
    args=parser.parse_args()
    if args.command=='plan':result=plan(args.work_dir)
    else:
        if not args.work_dir:parser.error('--work-dir is required')
        if args.command=='freeze':result=freeze(args.work_dir)
        elif args.command=='prepare-data':result=prepare_data(args.work_dir,args.inputs)
        elif args.command=='register':result=register(args.work_dir,'A',args.data_roots_file,pilot_only=args.pilot_only)
        elif args.command=='bind':result=bind(args.work_dir,'A')
        elif args.command=='autorun':result=autorun(args.work_dir,args.inputs,start_full_workflow=args.start_full_workflow,
                  review_timeout=args.review_timeout,pilot_only=args.pilot_only)
        elif args.command=='worker':result=worker(args.work_dir,start_training=args.start_training,
                  auto_release=args.auto_release,full_workflow=args.full_workflow)
        elif args.command=='release-runtime':result=release_runtime(args.work_dir,'A')
        elif args.command=='source-gate':
            c,a,r,g=execution(args.work_dir,'A');key=JobKey('all','aggregate',None,None)
            record=completion(args.work_dir,a,key) or pipeline.run_job(args.work_dir,a,c,r,g,key,receipts(args.work_dir,a))
            result={'state':record['state'],'source_gate_identity':identity(record),'contract_id':c['contract_id'],
                    'code_id':c['code_id'],'optimizer_steps':0,'training_started':False}
        else:
            kind={'review-source-gate':'source_review','activate-p2':'activate_p2','activate-p3':'activate_p3','close-workflow':'close_workflow'}[args.command]
            if kind=='source_review' and not args.review_file:parser.error('--review-file is required')
            result=coordinator(args.work_dir,'A',kind,args.review_file)
    print(__import__('json').dumps(result,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
