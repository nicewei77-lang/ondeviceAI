"""Per-job bounded model store; production uses official Drive content updates.

Exactly three resume names, three best names, and seven immutable boundary
anchors are permitted. No delete/Trash API exists. A live job lease authorizes
updates only in this new namespace. Old results and v1 are never store roots.
"""
from dataclasses import asdict
import hashlib
import io
import json
import math
from functools import wraps
from pathlib import Path
import torch
from .common import ROOT,identity,atomic_json,read
from .surgery import restore,assert_stage_widths

RESUME=tuple(f'resume_head_{i}.pt' for i in range(3))
BEST=tuple(f'best_head_{i}.pt' for i in range(3))
ANCHORS=tuple([f'anchor_post_{i}.pt' for i in range(4)]+[f'anchor_pre_{i}.pt' for i in range(1,4)])
MODELS=set(RESUME+BEST+ANCHORS)
CONTROL={'COMMITTED.json','ANCHORS.json','MODEL_FILES.json'}
_STORES={}

def digest(data):return hashlib.sha256(data).hexdigest()

def provider_errors(function):
    @wraps(function)
    def wrapped(*args,**kwargs):
        try:return function(*args,**kwargs)
        except Exception as error:
            if type(error).__module__.startswith(('google','httplib2','urllib','requests')):
                status=getattr(getattr(error,'resp',None),'status',None)
                raise RuntimeError(f'DRIVE_STORAGE_PROVIDER_HOLD: {type(error).__name__}, status={status}; no automatic auth retry') from None
            raise
    return wrapped

def encode(value):
    stream=io.BytesIO();torch.save(value,stream);return stream.getvalue()

class LocalFixtureBackend:
    """CPU-fixture stand-in, fixed filenames in a fresh task-local test directory."""
    def __init__(self,directory,contract_id,lease=None):
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.contract_id=contract_id
    def get(self,name,expected_id=None):
        if expected_id and expected_id!='fixture:'+name:raise ValueError('Fixture model file ID changed')
        path=self.directory/name
        return path.read_bytes() if path.exists() else None
    def put(self,name,data):
        if name not in MODELS|CONTROL:raise ValueError('Unknown fixture store name')
        path=self.directory/name;temporary=path.with_suffix('.tmp')
        temporary.write_bytes(data);temporary.replace(path)
        return {'file':name,'file_id':'fixture:'+name,'sha256':digest(data),'bytes':len(data),
                'provider_sha256':None,'provider_quota_bytes':None,'fixture':True}
    def describe(self,name,data):
        return {'file':name,'file_id':'fixture:'+name,'sha256':digest(data),'bytes':len(data),
                'provider_sha256':None,'provider_quota_bytes':None,'fixture':True}
    def file_metadata(self,name):
        path=self.directory/name
        if not path.is_file():raise ValueError('Fixture object metadata missing')
        return {'file_id':'fixture:'+name,'bytes':path.stat().st_size,'provider_sha256':None}

class DriveBackend:
    def __init__(self,directory,contract_id,lease=None):
        import google.auth
        from googleapiclient.discovery import build
        self.directory=Path(directory).resolve();self.contract_id=contract_id;self.lease=lease
        parents=[p for p in self.directory.parents if p.name=='TeacherCompressionKD_Iterative_Single_v2']
        if len(parents)!=1:raise ValueError('Drive model store must be inside the new v2 project')
        self.project=parents[0];self.parent_id=read(ROOT/'assets/DRIVE_DESTINATION.json')['project_folder_id']
        credentials,_=google.auth.default()
        self.service=build('drive','v3',credentials=credentials,cache_discovery=False)
        self.ids={};self.folder_id=self._folder()
    def _query(self,parent,name):
        escaped=name.replace('\\','\\\\').replace("'","\\'")
        result=self.service.files().list(q=f"'{parent}' in parents and name = '{escaped}' and trashed = false",
            fields='files(id,name,mimeType,parents,appProperties),nextPageToken',pageSize=100).execute()
        if result.get('nextPageToken') or len(result.get('files',[]))>1:raise ValueError('Ambiguous new model store path')
        return result.get('files',[])
    def _folder(self):
        parent=self.parent_id
        for name in self.directory.relative_to(self.project).parts:
            rows=self._query(parent,name)
            if len(rows)!=1 or rows[0]['mimeType']!='application/vnd.google-apps.folder':
                raise ValueError('New job folder is not yet visible through official Drive API')
            parent=rows[0]['id']
        return parent
    def _find(self,name):
        if name not in MODELS|CONTROL:raise ValueError('Unknown model-store object')
        rows=self._query(self.folder_id,name)
        if not rows:return None
        row=rows[0];tags=row.get('appProperties',{})
        if (tags.get('itkd_namespace')!='teamnative_iterative_single_v2' or
            tags.get('itkd_contract')!=self.contract_id or tags.get('itkd_object')!=name):
            raise ValueError('Refuse to adopt/update an existing unowned object')
        return row['id']
    def _metadata(self,file_id):
        return self.service.files().get(fileId=file_id,
            fields='id,name,size,sha256Checksum,md5Checksum,quotaBytesUsed,version,parents,appProperties').execute()
    @provider_errors
    def file_metadata(self,name):
        file_id=self._find(name)
        if file_id is None:raise ValueError('Owned model metadata missing')
        value=self._metadata(file_id)
        return {'file_id':file_id,'bytes':int(value['size']),'provider_sha256':value.get('sha256Checksum'),
                'provider_quota_bytes':value.get('quotaBytesUsed'),'provider_version':value.get('version')}
    @provider_errors
    def get(self,name,expected_id=None):
        from googleapiclient.http import MediaIoBaseDownload
        file_id=self._find(name)
        if file_id is None:return None
        if expected_id and file_id!=expected_id:raise ValueError('Bound model file ID changed')
        metadata=self._metadata(file_id)
        cap=2*1024**3 if name in MODELS else 1024**2
        if int(metadata.get('size',-1))<0 or int(metadata['size'])>cap:raise ValueError('Unexpected model-store object size')
        stream=io.BytesIO();download=MediaIoBaseDownload(stream,self.service.files().get_media(fileId=file_id),chunksize=8*1024**2)
        done=False
        while not done:_,done=download.next_chunk(num_retries=0)
        return stream.getvalue()
    def describe(self,name,data):
        file_id=self._find(name)
        if file_id is None:raise ValueError('Model metadata is unavailable')
        metadata=self._metadata(file_id)
        if int(metadata['size'])!=len(data):raise ValueError('Model metadata size changed')
        expected=digest(data)
        if metadata.get('sha256Checksum') and metadata['sha256Checksum']!=expected:raise ValueError('Provider model checksum changed')
        return {'file':name,'file_id':file_id,'sha256':expected,'bytes':len(data),
                'provider_sha256':metadata.get('sha256Checksum'),'provider_quota_bytes':metadata.get('quotaBytesUsed'),
                'provider_version':metadata.get('version'),'fixture':False}
    @provider_errors
    def put(self,name,data):
        from googleapiclient.http import MediaIoBaseUpload
        if self.lease is None:raise ValueError('Read-only completed model store cannot write')
        self.lease.assert_output_path(self.directory/name)
        if name not in MODELS|CONTROL:raise ValueError('Unknown model-store object')
        existing=self._find(name)
        media=MediaIoBaseUpload(io.BytesIO(data),mimetype='application/octet-stream',chunksize=8*1024**2,resumable=True)
        if existing:
            # Same file ID; do not rename a large FUSE file or create per-epoch blobs.
            request=self.service.files().update(fileId=existing,media_body=media,keepRevisionForever=False,fields='id')
        else:
            request=self.service.files().create(body={'name':name,'parents':[self.folder_id],
                'mimeType':'application/octet-stream','appProperties':{'itkd_namespace':'teamnative_iterative_single_v2',
                'itkd_contract':self.contract_id,'itkd_object':name}},media_body=media,fields='id')
        response=None
        while response is None:_,response=request.next_chunk(num_retries=0)
        if existing and response['id']!=existing:raise ValueError('Drive update changed the fixed file ID')
        metadata=self._metadata(response['id'])
        if int(metadata['size'])!=len(data):raise ValueError('Drive readback metadata size mismatch')
        expected=digest(data)
        if metadata.get('sha256Checksum') and metadata['sha256Checksum']!=expected:
            raise ValueError('Provider model SHA differs')
        # Prefer server SHA; only an unavailable checksum needs a full Colab-only
        # readback. No model payload is sent to the PC or a connector.
        verification='provider_SHA256_and_size'
        if not metadata.get('sha256Checksum'):
            observed=self.get(name)
            if observed is None or digest(observed)!=expected:raise ValueError('Drive raw readback differs')
            verification='Colab_API_raw_readback_SHA256_and_size'
        return {'file':name,'file_id':response['id'],'sha256':expected,'bytes':len(data),
                'provider_sha256':metadata.get('sha256Checksum'),'provider_quota_bytes':metadata.get('quotaBytesUsed'),
                'provider_version':metadata.get('version'),'remote_verification':verification,'fixture':False}

class ModelStore:
    def __init__(self,directory,recipe,native_io,dense_factory,lease=None,*,backend=None,fault=None):
        self.directory=Path(directory);self.recipe=recipe;self.native_io=native_io
        self.factory=dense_factory;self.lease=lease;self.fault=fault;self.pending_best=None
        if backend is not None and not recipe.fixture:raise ValueError('Custom test backend is forbidden for research')
        self.backend=backend or (LocalFixtureBackend(directory,recipe.contract_id) if recipe.fixture else DriveBackend(directory,recipe.contract_id,lease))
    def _event(self,name):
        if self.fault:
            if not self.recipe.fixture:raise ValueError('Fault injection is fixture-only')
            self.fault(name)
    def pointer(self):
        raw=self.backend.get('COMMITTED.json')
        if raw is None:return None
        value=json.loads(raw)
        if value.get('schema')!='iterative.bounded_commit.v2' or value['contract_id']!=self.recipe.contract_id:
            raise ValueError('Bounded pointer recipe/source identity differs')
        refs=[value.get('active'),value.get('prior')]
        if not refs[0] or any(r and (r['file'] not in RESUME or r['contract_id']!=self.recipe.contract_id) for r in refs):
            raise ValueError('Bounded resume pointer references an invalid head')
        if refs[1] and refs[0]['file']==refs[1]['file']:raise ValueError('Active/prior head alias')
        return value
    def _verify(self,raw):
        value=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
        if value['contract_id']!=self.recipe.contract_id:
            raise ValueError('Stored checkpoint source/recipe changed')
        if self.native_io.model_state_identity(value['model_state'])!=value['model_digest']:
            raise ValueError('Stored checkpoint tensor digest differs')
        def finite(item):
            if isinstance(item,torch.Tensor):
                if item.is_floating_point() and not bool(torch.isfinite(item).all()):raise ValueError('Nonfinite checkpoint tensor/state')
            elif isinstance(item,float):
                if not math.isfinite(item):raise ValueError('Nonfinite checkpoint scalar/state')
            elif isinstance(item,dict):
                for part in item.values():finite(part)
            elif isinstance(item,(list,tuple)):
                for part in item:finite(part)
        finite(value)
        if value.get('kind') in ('epoch','boundary'):
            required={'optimizer_state','scaler_state','rng_state','parameter_manifest','execution','history','applied_boundaries'}
            if not required.issubset(value):raise ValueError('Resume checkpoint state schema is incomplete')
            if value['execution']['recipe']!=asdict(self.recipe):raise ValueError('Resume recipe differs')
            optimizer=value['optimizer_state'];groups=optimizer.get('param_groups');states=optimizer.get('state')
            manifest=value['parameter_manifest']
            if not isinstance(groups,list) or not isinstance(states,dict) or len(groups)!=len(manifest):raise ValueError('Optimizer group schema differs')
            shapes={};ids=[]
            for group,record in zip(groups,manifest):
                if group['name']!=record['name'] or len(group['params'])!=len(record['parameters']):raise ValueError('Optimizer parameter membership differs')
                for pid,param in zip(group['params'],record['parameters']):
                    ids.append(pid);shapes[pid]=param['shape']
            if len(ids)!=len(set(ids)) or not set(states).issubset(ids):raise ValueError('Optimizer has stale/duplicate parameter IDs')
            for pid,state in states.items():
                if not {'step','exp_avg','exp_avg_sq'}.issubset(state):raise ValueError('Incomplete Adam state')
                if not isinstance(state['step'],torch.Tensor) or state['step'].numel()!=1 or float(state['step'])<0:raise ValueError('Invalid Adam step state')
                for name in ('exp_avg','exp_avg_sq'):
                    tensor=state[name]
                    if not isinstance(tensor,torch.Tensor) or list(tensor.shape)!=shapes[pid] or tensor.dtype!=torch.float32:
                        raise ValueError('Adam moment shape/dtype differs')
            scaler=value['scaler_state'];amp=value['execution'].get('runtime',{}).get('amp_enabled',False)
            if amp:
                if (not {'scale','growth_factor','backoff_factor','growth_interval','_growth_tracker'}.issubset(scaler) or
                    scaler['scale']<=0 or scaler['growth_factor']<=1 or not 0<scaler['backoff_factor']<1 or
                    type(scaler['growth_interval']) is not int or scaler['growth_interval']<=0 or
                    type(scaler['_growth_tracker']) is not int or scaler['_growth_tracker']<0):raise ValueError('Invalid AMP scaler state')
            elif scaler!={}:raise ValueError('Disabled AMP checkpoint contains scaler state')
            rng=value['rng_state']
            if (set(rng)!={'python','numpy','torch','cuda'} or not isinstance(rng['torch'],torch.Tensor) or
                rng['torch'].dtype!=torch.uint8 or rng['torch'].ndim!=1 or not rng['torch'].numel() or
                not isinstance(rng['cuda'],list) or any(not isinstance(t,torch.Tensor) or t.dtype!=torch.uint8 or t.ndim!=1 for t in rng['cuda'])):
                raise ValueError('Invalid RNG state schema')
        previous=self.native_io.rng_state()
        try:
            model=restore(self.factory,value['model_state'],value['layout'],digest=value['model_digest'],state_identity=self.native_io.model_state_identity)
            assert_stage_widths(model,value['layout'],self.recipe,value['stage'])
            if value.get('kind') in ('epoch','boundary'):
                actual={name:{'name':name,'shape':list(p.shape),'dtype':str(p.dtype)} for name,p in model.named_parameters()}
                entries=[p for group in value['parameter_manifest'] for p in group['parameters']]
                if len(entries)!=len(actual) or {p['name']:p for p in entries}!=actual:raise ValueError('Stored optimizer parameter names/shapes differ from model')
                self.native_io.restore_rng(value['rng_state'])  # Semantic RNG validation, restored below.
            del model
        finally:self.native_io.restore_rng(previous)
        return value
    def read_ref(self,ref):
        if ref['file'] not in MODELS:raise ValueError('Invalid bounded model reference')
        raw=self.backend.get(ref['file'],expected_id=ref.get('file_id'))
        if raw is None or digest(raw)!=ref['sha256'] or len(raw)!=ref['bytes']:
            raise ValueError('Referenced model raw bytes changed')
        return raw
    def load(self):
        pointer=self.pointer()
        if pointer is None:raise FileNotFoundError('No committed bounded resume head')
        ref=pointer['active'];raw=self.read_ref(ref)
        return self._verify(raw),ref
    def _write(self,name,value):
        raw=encode(value);self._verify(raw)
        factor=12 if name in RESUME else 4
        limit=factor*sum(t.numel() for t in value['model_state'].values())+8*1024**2
        if len(raw)>limit:raise ValueError('Serialized model exceeds the declared schema budget')
        self._event('before_candidate_upload')
        ref=self.backend.put(name,raw)
        self._event('after_candidate_upload')
        if ref['sha256']!=digest(raw) or ref['bytes']!=len(raw):raise ValueError('Candidate verification receipt differs')
        record={**ref,'contract_id':self.recipe.contract_id,'model_digest':value['model_digest'],
                'stage':value['stage'],'kind':value.get('kind','model_only'),'next_epoch':value.get('next_epoch')}
        if 'execution' in value:
            record['execution_id']=identity(value['execution']);record['applied_boundaries']=value['applied_boundaries']
        self._register(record)
        self._event('after_candidate_verify')
        return record
    def _register(self,ref):
        raw=self.backend.get('MODEL_FILES.json')
        ledger={'schema':'iterative.model_files.v2','contract_id':self.recipe.contract_id,'files':{}} if raw is None else json.loads(raw)
        if ledger['contract_id']!=self.recipe.contract_id:raise ValueError('Model accounting source identity changed')
        ledger['files'][ref['file']]=ref
        self.backend.put('MODEL_FILES.json',json.dumps(ledger,sort_keys=True,ensure_ascii=False).encode('utf8'))
        atomic_json(self.directory/'STORAGE_ACCOUNTING.json',{'schema':'iterative.storage_accounting.v2',
            'contract_id':self.recipe.contract_id,'files':ledger['files'],
            'logical_current_file_bytes':sum(r['bytes'] for r in ledger['files'].values()),
            'actual_provider_revision_accounting_complete':all(r.get('provider_quota_bytes') is not None for r in ledger['files'].values()),
            'scope':'Current owned model objects; historical provider revisions require actual accounting gate'})
    def accounting(self):
        raw=self.backend.get('MODEL_FILES.json')
        if raw is None:return {'contract_id':self.recipe.contract_id,'files':{}}
        record=json.loads(raw)
        if record['contract_id']!=self.recipe.contract_id or not set(record['files']).issubset(MODELS):
            raise ValueError('Model accounting contains an invalid object/contract')
        return record
    def commit(self,payload):
        old=self.pointer();protected=set()
        e=payload['next_epoch'];kind=payload['kind']
        if type(e) is not int or not 0<=e<=self.recipe.budget or kind not in ('boundary','epoch'):
            raise ValueError('Invalid bounded epoch/boundary transition')
        expected_stage=self.recipe.stage(e if kind=='boundary' else e-1)
        if payload['stage']!=expected_stage or len(payload['history'])!=e or payload['applied_boundaries']!=list(range(expected_stage+1)):
            raise ValueError('Bounded commit stage/history/ledger differs')
        if old is None:
            valid=kind=='boundary' and e==0
        else:
            prior=old['active'];previous=prior['next_epoch']
            if previous>=self.recipe.budget:valid=False
            elif kind=='boundary':valid=prior['kind']=='epoch' and e==previous and self.recipe.stage_start(e) and expected_stage==prior['stage']+1
            else:valid=e==previous+1 and expected_stage==prior['stage']
        if not valid:raise ValueError('Duplicate/out-of-order bounded commit')
        if old:protected={r['file'] for r in (old['active'],old.get('prior')) if r}
        candidates=[n for n in RESUME if n not in protected]
        if not candidates:raise ValueError('No unreferenced resume candidate head')
        ref=self._write(candidates[0],payload);ref['best']=payload.get('best')
        pointer={'schema':'iterative.bounded_commit.v2','contract_id':self.recipe.contract_id,
                 'sequence':0 if old is None else old['sequence']+1,'active':ref,'prior':None if old is None else old['active']}
        self._event('before_pointer_commit')
        encoded=json.dumps(pointer,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf8')
        self.backend.put('COMMITTED.json',encoded)
        self._event('after_pointer_commit')
        if self.pointer()!=pointer:raise ValueError('Bounded pointer readback differs')
        self.pending_best=None
        atomic_json(self.directory/f'TRANSACTION_{pointer["sequence"]:04d}.json',{'schema':'iterative.transaction.v2',
            'sequence':pointer['sequence'],'kind':payload['kind'],'next_epoch':payload['next_epoch'],
            'active':ref,'prior':pointer['prior'],'candidate_verified_before_pointer':True})
        return ref
    def save_best(self,value):
        if {'optimizer_state','scaler_state','rng_state'}&set(value):raise ValueError('Best head must be model-only')
        pointer=self.pointer();protected=set()
        if (not pointer or value.get('epoch')!=pointer['active']['next_epoch'] or value.get('stage')!=3 or
            value.get('eligibility')!='final_quarter' or not self.recipe.eligible(value['epoch'])):
            raise ValueError('Best head is not eligible for the next uncommitted final-quarter epoch')
        if pointer:
            for resume in (pointer['active'],pointer.get('prior')):
                if resume and resume.get('best'):protected.add(resume['best']['file'])
        if self.pending_best:protected.add(self.pending_best['file'])
        free=[n for n in BEST if n not in protected]
        if not free:raise ValueError('All best heads are pinned by committed/pending state')
        ref=self._write(free[0],value);self.pending_best=ref
        return ref
    def anchor(self,name,value):
        if name not in ANCHORS:raise ValueError('Invalid immutable stage anchor')
        if {'optimizer_state','scaler_state','rng_state'}&set(value):raise ValueError('Stage anchor must be model-only')
        j=value['anchor_j'];index=value['code_stage_index']
        expected_layout_stage=index if value['position']=='post' else index-1
        if (j!=index+1 or value['global_epoch']!=index*self.recipe.budget//4 or
            value['stage']!=expected_layout_stage or
            (value['position']=='pre' and j not in (2,3,4)) or
            (value['position']=='post' and j not in (1,2,3,4))):
            raise ValueError('Stage anchor j/index/global epoch convention differs')
        current=self.backend.get(name)
        if current is not None:
            stored=self._verify(current)
            keys=('contract_id','model_digest','stage','anchor_j','code_stage_index','global_epoch','position','layout')
            if any(stored.get(k)!=value.get(k) for k in keys):raise ValueError('Immutable stage anchor differs on replay')
            ref={**self.backend.describe(name,current),'contract_id':self.recipe.contract_id,
                 'model_digest':stored['model_digest'],'stage':stored['stage'],'kind':'model_only','next_epoch':None}
            self._register(ref)
        else:ref=self._write(name,value)
        raw=self.backend.get('ANCHORS.json');ledger={} if raw is None else json.loads(raw)
        if name in ledger and ledger[name]['sha256']!=ref['sha256']:raise ValueError('Immutable anchor ledger changed')
        ledger[name]=ref
        self.backend.put('ANCHORS.json',json.dumps(ledger,sort_keys=True,ensure_ascii=False).encode('utf8'))
        return ref

def metadata_accounting(directory,recipe):
    """Cold-process small ledger reader: no factory/cache/model download required."""
    backend=LocalFixtureBackend(directory,recipe.contract_id) if recipe.fixture else DriveBackend(directory,recipe.contract_id)
    try:
        raw=backend.get('MODEL_FILES.json');pointer_raw=backend.get('COMMITTED.json')
        if raw is None:
            if pointer_raw is not None:raise ValueError('Committed pointer has no owned model ledger')
            return {'contract_id':recipe.contract_id,'files':{},'pointer':None}
        ledger=json.loads(raw)
        if ledger.get('contract_id')!=recipe.contract_id or not isinstance(ledger.get('files'),dict) or not set(ledger['files']).issubset(MODELS):
            raise ValueError('Owned persisted model ledger differs')
        pointer=None if pointer_raw is None else json.loads(pointer_raw)
        pinned={}
        if pointer is not None:
            if pointer.get('schema')!='iterative.bounded_commit.v2' or pointer['contract_id']!=recipe.contract_id:raise ValueError('Persisted pointer binding differs')
            for ref in (pointer.get('active'),pointer.get('prior')):
                if ref:
                    pinned[ref['file']]=ref
                    if ref.get('best'):pinned[ref['best']['file']]=ref['best']
        files={}
        for name,record in ledger['files'].items():
            if record.get('file')!=name or record.get('contract_id')!=recipe.contract_id or not record.get('file_id'):
                raise ValueError('Persisted ledger object identity differs')
            meta=backend.file_metadata(name)
            if meta['file_id']!=record['file_id'] or meta['bytes']<0:raise ValueError('Owned object ID/size differs')
            if name in pinned:
                ref=pinned[name]
                if meta['file_id']!=ref['file_id'] or meta['bytes']!=ref['bytes'] or (meta.get('provider_sha256') and meta['provider_sha256']!=ref['sha256']):
                    raise ValueError('Pinned object metadata differs from committed state')
            files[name]={**record,'bytes':meta['bytes'],'observed_provider_sha256':meta.get('provider_sha256')}
        if not set(pinned).issubset(files):raise ValueError('Pinned model absent from owned ledger')
        return {'contract_id':recipe.contract_id,'files':files,'pointer':pointer,'scope':'Small persisted ledger and provider metadata; active payload strict verification occurs on resume'}
    finally:
        if hasattr(backend,'service') and hasattr(backend.service,'close'):backend.service.close()

def configure(directory,recipe,native_io,dense_factory,lease=None,*,backend=None,fault=None):
    key=str(Path(directory).resolve())
    for other in list(_STORES):release(other)
    store=ModelStore(directory,recipe,native_io,dense_factory,lease,backend=backend,fault=fault)
    _STORES[key]=store
    return store

def get_store(directory):
    key=str(Path(directory).resolve())
    if key not in _STORES:raise ValueError('Model store context is required; no implicit old-checkpoint adapter')
    return _STORES[key]

def release(directory):
    store=_STORES.pop(str(Path(directory).resolve()),None)
    if store is not None:
        store.factory=None;store.lease=None
        if hasattr(store.backend,'lease'):store.backend.lease=None
        if hasattr(store.backend,'service') and hasattr(store.backend.service,'close'):store.backend.service.close()

def release_after_fit(function):
    @wraps(function)
    def wrapped(dense_factory,train_dataset,val_dataset,run_dir,*args,**kwargs):
        try:return function(dense_factory,train_dataset,val_dataset,run_dir,*args,**kwargs)
        finally:release(run_dir)
    return wrapped
