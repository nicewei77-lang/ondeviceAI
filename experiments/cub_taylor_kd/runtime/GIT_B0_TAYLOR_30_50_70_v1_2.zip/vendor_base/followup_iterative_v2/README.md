# 단일 runtime과 균형 저장 — iterative 후속 v2

pruning은 L4 runtime 하나에서 모든 job을 순차 실행한다. 사용자가 확인한 다른 프로젝트 세션1개에는 접속·입력·해제하지 않으며 계정 전체 최대2개를 유지한다. v1 시작 노트북과 결과는 이 실행에 사용하거나 수정하지 않는다.

과학 조건은 검토된 v0.3 그대로다. 같은 Native Base source, split, Student 초기값, D0/OS/IT, K4, global epoch/RNG/LR, 같은 optimizer·scaler reset, final-quarter Teacher 선택, Student Native planned60, validation 결정표와 Test lock을 유지한다. 운영 변경은 assets/PROTOCOL_DRAFT.md v2.1과 설계 freeze 영수증에 고정한다.

## 저장과 재개

Teacher job마다 resume head3개와 best head3개를 고정한다. active/prior commit이 참조하는 파일에는 candidate를 쓰지 않는다. Colab에서 전체 직렬화 bytes·SHA·tensor/optimizer/scaler/RNG·strict restore를 검증하고 공식 Drive API의 같은 file ID를 갱신한다. 서버 SHA가 있으면 size/SHA를 확인하고, 없으면 Colab 안에서만 실제 bytes를 읽어 검증한다. 그 뒤 COMMITTED pointer를 바꾼다. 새 epoch별 영구 모델 blob은 만들지 않는다. 기존 파일 삭제·Trash 비우기·revision 삭제 API는 없다.

필수 모델 감사본은 post-surgery/reset anchor4개와 stage2~4 직전의 pre-surgery anchor3개다. 최초 pre는 원래 dense source를 참조한다. anchor에는 model-only 상태만 넣고 optimizer reset과 model digest를 구분한다. epoch별 작은 history, L1 scores/layout, transaction과 hash 기록은 보존한다. 최종 best/last는 검증된 현재 head를 그대로 seal한다.

Student는 고정 Native60 수치 학습과 best/last를 유지한다. 실제 provider revision/accounting과 FUSE 동작은 실측 전 PASS라고 부르지 않는다. 작은 실제 provider probe와 각 큰 파일의 checksum/size 영수증을 별도로 남긴다. tiny probe는 실제 Teacher 학습이나 Accuracy 결과가 아니다.

모든 job 전 현재 Python·Torch·torchvision·numpy·Pillow·CUDA·AMP·GPU fingerprint를 등록 기록과 Native 기준에 대조한다. runtime 교체는 자동 owner transfer로 처리하지 않는다. 이전 writer·checkpoint를 보존하는 명시적 handoff가 필요하다.

## PC에는 무엇을 받는가

모델·optimizer/scaler checkpoint와 전체 logits는 Drive에 두고 Colab에서 평가한다. Colab이 OA/Hard/CE, confusion, label·prediction·CE·entropy CSV, paired 평균·표본SD와 strict restore/hash 영수증을 만든다. PC 분석 export는 JSON/CSV whitelist와128MiB의 압축 전·후 cap을 사용한다. checkpoint 확장자나 tensor/raw-logits payload를 포함하지 않는다. 크기 초과는 HOLD이며 핵심 행을 조용히 버리거나 모델 다운로드로 대체하지 않는다.

원격 모델 증거는 Colab의 공식 Drive API checksum/size 영수증이다. 상위 Drive connector가 checksum 필드를 노출하지 않는 경우, 상위에서 모델 원문을 독립 검증한 것으로 주장하지 않는다. 모델을 PC로 내려받아 보완하지 않는다.

## 자원 계획과 관측 범위

| 경로 | 추가 Drive 여유 공간 계획 |
|---|---:|
| CUB 최초 P1 |43.5935GiB|
| 기본 전체 경로 |78.8205GiB|
| 최대 분기 |130.1690GiB|

고정3R3B7anchor, Student/평가, 단일 upload spare,10%와5GiB 여유를 더한 스키마 계산이다. 실제 quota나 provider 저장량 실측이 아니다. 사용자가 Drive가 충분하다고 말한 사실과 인증된 actual quota PASS는 구분한다. quota API 오류·불명·부족은 HOLD한다.

Colab에서는 local data/cache·코드·임시 파일과 FUSE writeback cache를 Drive 영구 저장량과 구분한다. 시작/각 job/Teacher commit의 실제 free 관측과 data cache inventory를 남기고 local free8GiB guard를 사용한다. 이 guard는 전체 peak의 증명이 아니다. FUSE cache의 별도 크기와 실제 peak는 미실측으로 남기며 관측된 최소 free/최대 used만 해석한다.

PC의 모델 필요 공간은0이다. 코드 ZIP은 수MB, 분석 묶음은 실제 생성 크기만큼이며128MiB 이하로 제한한다. 현재 아직 새 실험이 없어 실제 요약 크기는 없다.

단일 L4의 pilot6–8, 기본22–28, 최대32–38 GPU-hours는 과거 처리량 기반 추정이며 wall time도 같은 규모다. 새 Drive API I/O·준비·검토·재시도 비용은 실측 전이므로 초과할 수 있다.8/40시간은 자동 검토 기록 기준이며 강제 중단 상한이 아니다.

## 시작

Drive의 온디바이스AI/TeacherCompressionKD_Iterative_Single_v2/packages에서 `00_START_SINGLE_RUNTIME_v2.ipynb` 하나만 사용한다. 첫 변수 START_FULL_WORKFLOW=True와 모두 실행으로 준비·인증·quota·provider probe·새 source/stage CUDA 검사·실제 검토 대기·순차 학습·Colab 평가·작은 export·종료 요청을 연결한다. 처음 Google 인증만 직접 처리한다. 과거 PASS를 새 실제 gate로 대체하지 않는다. 실제 source review 전 본학습0이며 기다림은 최대7200초다.

실제 새 run부터 상위 대화가30분 직접 Drive 확인을 담당한다. 별도 활성 예약이 있다고 주장하거나 새 자동화를 만들지 않는다. 모든 활성 작업·분석 export·저장/receipt 검증 후 자기 runtime만 공식 google.colab.runtime.unassign()으로 한 번 반환 요청한다. RELEASE_REQUESTED는 실제 할당 반환 확인과 다르다.

## 로컬 검증

검증 interpreter는 C:/Users/kjiny/Documents/Codex/environments/analysis-py314/Scripts/python.exe다. 프로젝트 Teacher_Compression_KD_TeamNative에서 다음을 실행한다.

```text
python -B -X utf8 -m unittest discover -s followup_iterative_v2/tests -v
python -B -X utf8 -m followup_iterative_v2.build_package
python -B -X utf8 -m followup_iterative_v2.validate_package
```

CPU fixture·mock scheduler·작은 파일 실험은 실제 pretrained Accuracy, authenticated quota, 실제 대형 provider accounting 또는 CUDA 학습 결과가 아니다. 실제 GPU 시작은 패키지·독립 검토와 운영 gate를 확인한 뒤 조율한다.
