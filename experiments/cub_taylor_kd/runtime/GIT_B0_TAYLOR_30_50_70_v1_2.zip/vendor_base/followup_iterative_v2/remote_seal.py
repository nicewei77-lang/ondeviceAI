"""Read-only provider metadata seal. Never download model bytes to the PC."""
from pathlib import Path
import time
from .common import ROOT,read

def verify_metadata(metadata,*,expected_sha256,expected_bytes):
    if int(metadata.get('size',-1))!=expected_bytes:
        raise ValueError('Remote model size differs from Colab-verified bytes')
    supplied=metadata.get('sha256Checksum')
    if supplied and supplied!=expected_sha256:
        raise ValueError('Provider SHA256 differs from Colab model bytes')
    return {'id':metadata['id'],'name':metadata.get('name'),'bytes':int(metadata['size']),
            'provider_sha256':supplied,'provider_md5':metadata.get('md5Checksum'),
            'expected_sha256':expected_sha256,'version':metadata.get('version'),
            'remote_size_verified':True,'remote_raw_SHA256_verified':bool(supplied),
            'scope':'Provider size+SHA256' if supplied else 'Provider size only; provider SHA256 unavailable',
            'PC_checkpoint_downloaded':False}

def seal(path,*,work,expected_sha256,file_id=None,expected_bytes=None):
    from googleapiclient.discovery import build
    import google.auth
    path=Path(path).resolve();project=Path(work).resolve().parent
    if not path.is_relative_to(project):raise ValueError('Remote seal is restricted to the new v2 project')
    relative=path.relative_to(project).parts
    credentials,_=google.auth.default();service=build('drive','v3',credentials=credentials,cache_discovery=False)
    if file_id is not None:
        metadata=service.files().get(fileId=file_id,fields='id,name,size,sha256Checksum,md5Checksum,version').execute()
        return {'path':str(path),**verify_metadata(metadata,expected_sha256=expected_sha256,expected_bytes=expected_bytes)}
    parent=read(ROOT/'assets/DRIVE_DESTINATION.json')['project_folder_id']
    wanted=path.stat().st_size
    for part_index,name in enumerate(relative):
        escaped=name.replace('\\','\\\\').replace("'","\\'")
        query=f"'{parent}' in parents and name = '{escaped}' and trashed = false"
        rows=[]
        for attempt in range(3):
            result=service.files().list(q=query,pageSize=100,
                fields='files(id,name,mimeType,size,sha256Checksum,md5Checksum,version),nextPageToken').execute()
            rows=result.get('files',[])
            if result.get('nextPageToken') or len(rows)>1:raise ValueError('Ambiguous remote model path')
            if rows:break
            if attempt<2:time.sleep(5)  # Bounded visibility wait, not an authentication retry.
        if len(rows)!=1:raise ValueError('Remote model upload metadata remains pending')
        metadata=rows[0]
        if part_index<len(relative)-1:
            if metadata['mimeType']!='application/vnd.google-apps.folder':raise ValueError('Remote parent is not a folder')
            parent=metadata['id']
    return {'path':str(path),**verify_metadata(metadata,expected_sha256=expected_sha256,expected_bytes=wanted)}
