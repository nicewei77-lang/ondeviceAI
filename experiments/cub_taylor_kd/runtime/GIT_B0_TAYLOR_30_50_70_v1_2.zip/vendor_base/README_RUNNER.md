# Team Native Base pruning — guarded runner v1

00 실제 CPU source 검증은3 Base·12 compact 복원·9 초기값·0% 동일성이 통과했다. 이 패키지는 그 결과를 재사용한다. 기존 Native/B1 결과나 구 pruning config는 수정하지 않는다. 새 trainer를 만들지 않고 frozen Native fit/predict와 기존 tckd L1 pruning/복원을 호출한다.

## 지금 실행 순서

1. 00의 요약이 Drive에 저장·확인됐으므로 **00 CPU 런타임을 해제**하고 A/B 두 세션만 유지한다.
2. `01_PRUNING_SLOT_A_v1.ipynb`와 `01_PRUNING_SLOT_B_v1.ipynb`를 각각 **L4**로 연다. 추가 구매는 하지 않는다. L4 할당/기존 Native runtime 조합이 맞지 않으면 중단한다.
3. A에서 source 계약을 고정하고 데이터 준비·runtime 등록까지 실행한다. B에서도 데이터 준비·runtime 등록까지 실행한다. 압축 모델의 학습은 아직 실행하지 않는다.
4. B 등록 완료 뒤 A의 `실행 배정 고정` 셀을 실행한다. 그 다음 실제 A/B 탭 URL·연결 및 동시세션2개를 직접 확인하고 확인 변수만 바꿔 readiness 셀을 실행한다.
5. A의 `RUN_CUDA_PREFLIGHT=True`로 source CUDA 수치검증 셀을 실행한다. optimizer step은0이다. 이 결과를 확인하기 전 `START_TRAINING=False`를 유지한다.
6. 실제 CUDA 결과가 확인된 뒤에만 같은 A/B 노트북의 마지막 worker 셀을 실행한다. 같은 runtime을 유지하고 재준비/재배정 셀을 반복하지 않는다. 이미 완료된 job은 건너뛰며 의존 작업을 기다리면 `yielded_pending_dependencies`로 종료한다. 다른 slot 완료 후 worker 셀만 다시 실행한다.

**브라우저 자동 제어를 사용하지 않는다.** 노트북의 URL·세션 확인은 사용자가 현재 Colab UI를 직접 보고 수행하는 별도 증거다. CPU 검증을 CUDA AMP 성공으로 취급하지 않는다.

## 계약

- CUB/Flowers/Aircraft 완료 Native DINOv3 ConvNeXt Base45 validation-best를 같은 dataset의 모든 ratio 공통 source로 쓴다.
- hidden pruning ratios0/30/50/70%, 모든 ratio에 recovery20(0% 포함), Native Base validation Hard 고정.
- same-seed Native Student 초기화42/43/44, Native input/stream·optimizer·60epoch를 유지한다. baseline은 기존 Native source를 읽기 전용으로 재사용한다. Native Base KD를 recovered-r00 KD로 재사용하지 않는다.
- Teacher KD AMP가 우선 후보이며 실제 source 및 recovered bank의 CUDA output/loss/gradient 검사로 gate한다. AMP 문제가 나면 중단·보고한다. B1 overflow를 근거로 이 실험을 FP32로 자동 전환하지 않는다.
- validation에서 recovered-r00 대비 OA1pp/Hard2pp 평균 목표와 MACs로 추천 ratio를 고정한 후 새 Test를 평가한다. Student3seed 표본 SD는 CI나 비열등성 증명이 아니다.

## 작업 소유권과 재개

55 jobs: source aggregate1, recovery12, recovered-bank aggregate3, Student36, dataset finalizer3. A31/B24로 분리한다. 집계/finalizer는 A만 작성한다. source 계약·assignment·runtime fingerprint·nonce와 source receipt SHA가 같아야 한다. Drive flock/rename이 cross-client atomic하다고 가정하지 않는다.

같은 runtime의 동시 프로세스는 local OS lock으로 막는다. 완료 checkpoint raw SHA·tensor digest·job contract를 소비 시 대조하며, CUDA bank probe가 본 Teacher reference와 실제 KD Teacher가 일치해야 한다. runtime이 새로 할당되거나 boot fingerprint가 바뀌면 자동 소유권 이전을 하지 않고 중단한다. 새 assignment로 몰래 재개하지 않는다.

## 검증 범위

배포 시점의 로컬 CPU fixture·guard·CLI·무결성 regression은 실행했다. 실제3 Base CPU source 검증은 사용자00 실행 결과를 읽어 확인했다. **실제 A/B L4 준비, CUDA AMP probe, recovery 첫 epoch, Student 첫 epoch는 배포 시점에 미실행이다.** 노트북에는 결과를 만들어 넣지 않았다. 사용자 실행 후 생성된 실제 receipt/checkpoint를 별도 확인해야 한다.

환경이 허용되는 Colab에서 노트북을 위에서부터 실행해 검증한다. 코드 ZIP SHA·파일별 source SHA, 기존 Native dependency manifest를 확인한 뒤 실행한다. Runtime/library mismatch는 자동 재설치로 숨기지 않는다. 실행 오류 시 기존 Native/B1 원본을 고치거나 다른 source를 임의 선택하지 않는다.
