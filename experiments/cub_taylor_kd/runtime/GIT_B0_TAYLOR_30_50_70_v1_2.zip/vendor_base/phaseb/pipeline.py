"""Thin orchestration around byte-identical Native fit/predict and legacy L1 surgery."""
from datetime import datetime,timezone
from pathlib import Path
import gc
import hashlib
import io as binary_io
import json
import statistics
import torch

from .adapter import strict_restore_compact
from .contracts import (DATASETS,RATIOS,SEEDS,build_contract,verify_contract,output_root,job_contract,require_precision_receipt)
from .io import identity,read,write,sha,verify_code
from .native import ROOT,module,legacy,config,parent
from .ownership import JobKey,freeze_assignment,OwnershipGuard,current_runtime_id
from .sources import load_source

def jobs():
    rows=[JobKey('all','aggregate',None,None)]
    for d in DATASETS:
        rows.extend(JobKey(d,'recovery',round(r*100),config(d)['teacher_seed']) for r in RATIOS)
        rows.append(JobKey(d,'aggregate',None,None))
        rows.extend(JobKey(d,'student',round(r*100),s) for r in RATIOS for s in SEEDS)
        rows.append(JobKey(d,'finalizer',None,None))
    return rows

def partition():
    result={}
    for job in jobs():
        if job.stage in {'aggregate','finalizer'}:slot='A'
        else:
            d=DATASETS.index(job.dataset);r=(0,30,50,70).index(job.ratio)
            s=0 if job.stage=='recovery' else SEEDS.index(job.seed)
            slot='A' if (d+r+s)%2==0 else 'B'
        result[job]=slot
    return result

def source_ids(contract):return {d:contract['source_pins']['datasets'][d]['source_reference'] for d in DATASETS}
def controls(work):return output_root(work).parent/'control'

def prepare_contract(work):
    work=output_root(work);code=verify_code(ROOT);control=controls(work)
    anchor=read(ROOT/'configs/source_preflight_anchor.json')
    summary=read(work/'preparation/SOURCE_PREFLIGHT_SUMMARY.json')
    if (sha(work/'preparation/source_pins.json')!=anchor['source_pins_SHA256']
        or summary.get('state')!='passed_source_CPU_only'
        or summary.get('code_id')!=anchor['source_preflight_code_id']
        or summary.get('source_contract_id')!=anchor['source_contract_id']):
        raise ValueError('Actual00 source result differs from the verified delivery anchor')
    contract=build_contract(read(ROOT/'configs/policy.json'),read(work/'preparation/source_pins.json'),code)
    path=control/'frozen_contract.json'
    if path.exists() and read(path)!=contract:raise ValueError('Frozen experiment already differs')
    if not path.exists():write(path,contract)
    assignment=freeze_assignment(jobs(),partition(),frozen_contract_id=contract['contract_id'],source_ids=source_ids(contract),
        output_root=work.as_posix(),slot_owners=None,readonly_roots=[v['native_results'] for v in read(ROOT/'configs/readonly_inputs.json')['datasets'].values()],
        source_receipts=[{'path':path.as_posix(),'sha256':sha(path)}])
    target=control/'prepared_assignment.json'
    if target.exists() and read(target)!=assignment:raise ValueError('Prepared assignment differs')
    if not target.exists():write(target,assignment)
    return {'state':'source_contract_frozen_runtime_and_CUDA_gates_pending','contract_id':contract['contract_id'],
            'assignment_id':assignment['assignment_id'],'assignment_state':assignment['state'],'training_calls':0}

def load_contract(work):
    contract=read(controls(work)/'frozen_contract.json');verify_contract(contract,verify_code(ROOT));return contract

def register_runtime(work,slot,data_roots):
    if slot not in ('A','B') or set(data_roots)!=set(DATASETS):raise ValueError('Explicit slot and all data roots required')
    contract=load_contract(work)
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    actual=current_training_runtime()
    for d in DATASETS:validate_runtime_match(read(ROOT/'configs/readonly_inputs.json')['datasets'][d]['baseline_execution_runtime'],actual)
    record={'state':'registered','slot':slot,'runtime_id':current_runtime_id(),'owner_token':__import__('uuid').uuid4().hex,
            'contract_id':contract['contract_id'],'code_id':contract['code_id'],'runtime':actual,'data_roots':data_roots}
    for d in DATASETS:context(d,contract,data_roots)
    path=controls(work)/f'runtime_{slot}.json'
    if path.exists():
        previous=read(path)
        if any(previous[k]!=record[k] for k in record if k!='owner_token'):raise ValueError('Runtime registration changed; no implicit transfer')
        return {k:v for k,v in previous.items() if k!='owner_token'}
    write(path,record)
    return {k:v for k,v in record.items() if k!='owner_token'}

def bind_execution(work):
    work=output_root(work);control=controls(work);contract=load_contract(work)
    if any(work.glob('*/slot_*/jobs/*/.owner.json')):raise ValueError('Execution already began; rebinding forbidden')
    if (control/'execution.json').exists():raise ValueError('Execution assignment already pinned; inspect rather than rebind')
    owners={};receipts=[{'path':(control/'frozen_contract.json').as_posix(),'sha256':sha(control/'frozen_contract.json')}]
    for slot in ('A','B'):
        path=control/f'runtime_{slot}.json';r=read(path)
        if r['state']!='registered' or r['contract_id']!=contract['contract_id'] or r['code_id']!=contract['code_id']:
            raise ValueError('Runtime binding contract changed')
        owners[slot]={'runtime_id':r['runtime_id'],'owner_token':r['owner_token']}
        receipts.append({'path':path.as_posix(),'sha256':sha(path)})
    assignment=freeze_assignment(jobs(),partition(),frozen_contract_id=contract['contract_id'],source_ids=source_ids(contract),
       output_root=work.as_posix(),slot_owners=owners,readonly_roots=[v['native_results'] for v in read(ROOT/'configs/readonly_inputs.json')['datasets'].values()],source_receipts=receipts)
    execution={'state':'bound_actual_CUDA_readiness_pending','contract_id':contract['contract_id'],'code_id':contract['code_id'],
               'assignment_id':assignment['assignment_id'],'assignment':assignment,'preparation_is_training':False}
    write(control/'execution.json',execution);return {k:v for k,v in execution.items() if k!='assignment'}

def context(dataset,contract,data_roots,*,test=False):
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset];manifest=read(ROOT/pin['reference_manifest'])
    if identity(manifest)!=pin['split_id'] or sha(ROOT/pin['reference_manifest'])!=pin['manifest_sha256']:raise ValueError('Reference manifest changed')
    native=Path(pin['native_results'])
    if read(native/'data'/dataset/'splits.json')!=manifest:raise ValueError('Ordered source split changed')
    if identity(read(pin['hard_set']['path']))!=pin['hard_set']['identity']:raise ValueError('Native Hard anchor changed')
    root=Path(data_roots[dataset]).resolve()
    for relative,wanted in manifest['source']['metadata_sha256'].items():
        if sha(root/relative)!=wanted:raise ValueError('Actual dataset metadata changed')
    engine=module(dataset,'data');cfg=config(dataset)
    splits=('test',) if test else ('train','val')
    sets={s:engine.ImageDataset(root,manifest[s],engine.make_transforms(cfg,s=='train'),manifest['preprocessing']['bottom_crop_pixels']) for s in splits}
    return pin,manifest,sets

def job_dir(work,assignment,job):
    matches=[r for r in assignment['jobs'] if r['job_id']==job.job_id]
    if len(matches)!=1:raise ValueError('Unknown dependency job')
    root=output_root(work)/assignment['assignment_id']/('slot_'+matches[0]['slot'])/'jobs'/job.job_id
    if root.resolve()!=root:raise ValueError('Dependency namespace redirected')
    return root

def completion_receipt(work,assignment,job):
    path=job_dir(work,assignment,job)
    if not (path/'.owner.json').exists():return None
    record=read(path/'.owner.json')
    row=next(r for r in assignment['jobs'] if r['job_id']==job.job_id)
    owner=assignment.get('slot_owners',{}).get(row['slot'],{})
    ids_sha=hashlib.sha256(json.dumps(assignment['source_ids'],sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    expected={'schema':'phaseb.ownership.v1','generation':1,'assignment_id':assignment['assignment_id'],
       'frozen_contract_id':assignment['frozen_contract_id'],'source_ids_sha256':ids_sha,'job_id':job.job_id,
       'slot':row['slot'],'runtime_id':owner.get('runtime_id'),'owner_token_sha256':owner.get('owner_token_sha256')}
    if assignment.get('state')!='executable' or not owner or any(record.get(k)!=v for k,v in expected.items()):
        raise ValueError('Dependency permanent ownership/source/contract fields differ')
    if record.get('state')!='complete':return None
    name='precision_gate.json' if job.dataset=='all' else ('bank_gate.json' if job.stage=='aggregate' else ('EVALUATION_COMPLETE.json' if job.stage=='finalizer' else 'COMPLETE.json'))
    if not (path/name).exists() or identity(read(path/name))!=identity(record.get('completion_receipt')):
        raise ValueError('Dependency completion receipt changed')
    result=record['completion_receipt']
    if result.get('frozen_contract_id')!=assignment['frozen_contract_id']:raise ValueError('Completion contract differs')
    if job.stage in ('recovery','student'):
        if result.get('state')!='complete' or result.get('job')!=job.to_dict() or result.get('completed_epochs')!=(20 if job.stage=='recovery' else 60):
            raise ValueError('Training completion job/budget differs')
    return result

def complete(work,assignment,job):
    return completion_receipt(work,assignment,job) is not None

def completed_checkpoint(work,assignment,contract,job):
    result=completion_receipt(work,assignment,job)
    if result is None:raise ValueError('Training dependency is not complete')
    path=job_dir(work,assignment,job)/'best.pt'
    raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    if digest!=result.get('best_raw_sha256'):raise ValueError('Completed checkpoint raw SHA changed')
    saved=torch.load(binary_io.BytesIO(raw),map_location='cpu',weights_only=True)
    native_io=module(job.dataset,'io')
    if (saved.get('model_digest')!=result.get('best_model_digest')
        or native_io.model_state_identity(saved['model_state'])!=saved['model_digest']):
        raise ValueError('Completed checkpoint tensor digest changed')
    budget=20 if job.stage=='recovery' else 60
    if type(saved.get('epoch'))is not int or not 0<=saved['epoch']<budget:raise ValueError('Completed selected epoch outside budget')
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][job.dataset]
    ratio=job.ratio/100
    if job.stage=='recovery':
        provenance=saved.get('contract',{}).get('source',{}).get('adapter_provenance')
        branch=next(b for b in contract['source_pins']['datasets'][job.dataset]['branches'] if b['ratio']==ratio)
        if (not provenance or provenance.get('initial_compact_digest')!=branch['initial_compact_digest']
            or identity(saved['model_spec'])!=branch['model_spec_id']
            or identity(saved['model_spec'].get('pruning_layout'))!=branch['layout_id']):
            raise ValueError('Recovered model differs from actual source surgery layout')
        payload={'adapter_provenance':provenance,'Hard_set':pin['hard_set']}
    elif job.stage=='student':
        gate=recovered_precision_gate(work,assignment,contract)
        teacher_ref=gate['source_refs'][job.dataset][str(ratio)]
        payload={'student_initial':pin['initializations'][str(job.seed)],'Native_baseline':pin['baselines'][str(job.seed)],
                 'teacher':teacher_ref,'Hard_set':pin['hard_set'],'Teacher_precision':contract['policy']['KD_Teacher_precision']}
    else:raise ValueError('No model checkpoint for this job stage')
    expected=job_contract(contract,job.dataset,job.stage,ratio,job.seed,payload)
    if saved.get('contract')!=expected:raise ValueError('Completed checkpoint independent job contract changed')
    return saved,{'path':path.as_posix(),'model_digest':saved['model_digest'],'contract_id':identity(expected),
                  'epoch':saved['epoch'],'model_spec':saved['model_spec'],'raw_sha256':digest,
                  'sha256':digest,'test_fixture':False}

def recovered_precision_gate(work,assignment,contract):
    from .precision import validate_full_coverage
    banks=[]
    for dataset in DATASETS:
        job=JobKey(dataset,'aggregate',None,None)
        receipt=completion_receipt(work,assignment,job)
        if (receipt is None or receipt.get('state')!='passed' or receipt.get('phase')!='recovered'
            or receipt.get('dataset')!=dataset or receipt.get('Teacher_KD_precision')!='AMP'):
            raise ValueError('Recovered-bank completion differs')
        banks.append(receipt['records'][0])
    gate=validate_full_coverage(banks,frozen_contract_id=contract['contract_id'],phase_label='recovered')
    require_precision_receipt(gate,contract,'recovered');return gate

def require_probed_teacher(gate,dataset,ratio,actual_ref):
    if gate.get('source_refs',{}).get(dataset,{}).get(str(ratio))!=actual_ref:
        raise ValueError('Current recovered Teacher differs from the actual CUDA probe source')

def ready(work,assignment,job):
    if job.dataset=='all':return True
    source=JobKey('all','aggregate',None,None)
    if not complete(work,assignment,source):return False
    if job.stage=='recovery':return True
    if job.stage=='aggregate':return all(complete(work,assignment,JobKey(job.dataset,'recovery',round(r*100),config(job.dataset)['teacher_seed'])) for r in RATIOS)
    if not all(complete(work,assignment,JobKey(d,'aggregate',None,None)) for d in DATASETS):return False
    if job.stage=='student':return True
    if job.stage=='finalizer':return all(complete(work,assignment,JobKey(job.dataset,'student',round(r*100),s)) for r in RATIOS for s in SEEDS)
    raise ValueError('Unknown job stage')

def verify_training_complete(folder,epochs,expected_contract,expected_spec=None):
    io=module(expected_contract['config']['dataset'],'io');status=read(folder/'status.json')
    if status['state']!='complete' or status['completed_epochs']!=status['planned_epochs'] or status['planned_epochs']!=epochs:
        raise ValueError('Required complete epoch budget missing')
    best=io.checkpoint_read(folder/'best.pt');last=io.checkpoint_read(folder/'last.pt');history=read(folder/'history.json')
    if (read(folder/'contract.json')!=expected_contract or best['contract']!=expected_contract or last['contract']!=expected_contract
        or last['epoch']!=epochs-1 or last['history']!=history or [h['epoch'] for h in history]!=list(range(1,epochs+1))
        or best['model_spec']!=last['model_spec'] or (expected_spec is not None and best['model_spec']!=expected_spec)):
        raise ValueError('Completed contract/history differs')
    selected=min(history,key=lambda h:(-h['val_accuracy_pct'],h['val_loss'],h['epoch']))
    if best['epoch']!=selected['epoch']-1:raise ValueError('Checkpoint selection is not validation best')
    if (best['val_metrics']!={'accuracy_pct':selected['val_accuracy_pct'],'loss':selected['val_loss']}
        or last['best_accuracy']!=selected['val_accuracy_pct'] or last['best_loss']!=selected['val_loss']):
        raise ValueError('Best metric/selection metadata changed')
    import math
    d=expected_contract['config']['dataset'];pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][d]
    recovery='/recovery_' in expected_contract['job'];execution=last['execution']
    wanted={'epochs':epochs,'seed':expected_contract['seed'],'config':expected_contract['config'],
       'model_spec':best['model_spec'],'max_batches':None,
       'backbone_lr':0.00001 if recovery else None,'head_lr':0.0001 if recovery else None,
       'head_warmup_epochs':0,'runtime':pin['baseline_execution_runtime']}
    if execution!=wanted or not last.get('rng_state') or not last.get('scaler_state') or not last.get('optimizer_state',{}).get('state'):
        raise ValueError('Completed execution/runtime/optimizer resume state differs')
    if any(not math.isfinite(h[k]) for h in history for k in ('train_loss','val_loss','val_accuracy_pct')):
        raise ValueError('Completed history contains nonfinite values')
    for saved in (best,last):
        if io.model_state_identity(saved['model_state'])!=saved['model_digest']:raise ValueError('Completed tensor digest differs')
    return best

def initial_student(dataset,seed,contract):
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset];ref=pin['initializations'][str(seed)]
    actual=contract['source_pins']['datasets'][dataset]['initializations'][str(seed)]
    if sha(ref['path'])!=actual['raw_sha256']:raise ValueError('Actual Native initial bytes changed')
    io=module(dataset,'io');saved=io.checkpoint_read(ref['path'])
    if io.identity(saved['contract'])!=ref['contract_id'] or io.model_state_identity(saved['model_state'])!=ref['model_digest']:
        raise ValueError('Same-seed Native initialization changed')
    model=module(dataset,'models').build_from_spec(saved['model_spec']);model.load_state_dict(saved['model_state'],strict=True)
    return model,saved['model_spec']

def recovery_model(work,assignment,contract,dataset,ratio):
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset]
    job=JobKey(dataset,'recovery',round(ratio*100),config(dataset)['teacher_seed'])
    saved,ref=completed_checkpoint(work,assignment,contract,job)
    model=strict_restore_compact(saved,compression_models=legacy('models'),native_io=module(dataset,'io'),
       expected_source=contract['source_pins']['datasets'][dataset]['source_reference'],expected_ratio=ratio,
       expected_classes=read(ROOT/pin['reference_manifest'])['classes'])
    return model,ref

def run_precision(phase,work,assignment,contract,data_roots,lease):
    from .precision import probe_dataset_amp,validate_full_coverage
    records=[]
    for dataset in DATASETS if phase=='source' else (lease.key.dataset,):
        pin,manifest,sets=context(dataset,contract,data_roots)
        source=load_source(dataset,contract) if phase=='source' else None
        def teacher_builder(ratio):
            if source is not None:
                model,_,_=source.prune(ratio,compression_models=legacy('models'),compression_pruning=legacy('pruning'))
                return model,source.reference
            return recovery_model(work,assignment,contract,dataset,ratio)
        record=probe_dataset_amp(dataset,config(dataset),sets['train'],sets['val'],teacher_builder,
                 lambda seed:initial_student(dataset,seed,contract)[0],module(dataset,'train'),
                 frozen_contract_id=contract['contract_id'],phase_label=phase,min_batches=3)
        records.append(record)
        write(lease.output_dir/(dataset+'_precision.json'),record)
        del source;gc.collect();torch.cuda.empty_cache()
    if phase=='source':
        receipt=validate_full_coverage(records,frozen_contract_id=contract['contract_id'],phase_label=phase)
        write(lease.output_dir/'precision_gate.json',receipt)
    else:
        receipt={'state':'passed','phase':'recovered','dataset':lease.key.dataset,'frozen_contract_id':contract['contract_id'],
                 'Teacher_KD_precision':'AMP','records':records,'scope':'One dataset all4 recovered ratios; sampled actual train/val CUDA finite checks'}
        write(lease.output_dir/'bank_gate.json',receipt)
    return receipt

def run_job(work,slot,job):
    work=output_root(work);contract=load_contract(work);execution=read(controls(work)/'execution.json')
    assignment=execution['assignment'];registration=read(controls(work)/f'runtime_{slot}.json')
    if registration['runtime_id']!=current_runtime_id():raise ValueError('Wrong registered runtime')
    readiness=read(controls(work)/'RUNTIME_READINESS.json')
    if (readiness.get('state')!='passed' or readiness.get('current_URL_and_Colab_connection_verified') is not True
       or type(readiness.get('active_sessions'))is not int or not 1<=readiness['active_sessions']<=2
       or readiness.get('assignment_id')!=execution['assignment_id']):
        raise ValueError('Live runtime/UI/session readiness is not verified; no GPU work allowed')
    from b1kd.runtime import current_training_runtime,validate_runtime_match
    for dataset in DATASETS:validate_runtime_match(read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset]['baseline_execution_runtime'],current_training_runtime())
    if not ready(work,assignment,job):raise ValueError('Dependency gate not complete')
    # Recompute this job's actual dense source identity before claiming its write namespace.
    actual_ids=source_ids(contract)
    if job.dataset in DATASETS:
        source=load_source(job.dataset,contract);actual_ids[job.dataset]=source.reference
    else:source=None
    guard=OwnershipGuard(assignment,slot,expected_contract_id=contract['contract_id'],expected_source_ids=actual_ids,
         expected_jobs=jobs(),expected_assignment_id=execution['assignment_id'],local_lock_root=assignment['local_lock_root'],owner_token=registration['owner_token'])
    with guard.claim(job) as lease:
        lease.assert_active()
        if job.stage=='aggregate':
            result=run_precision('source' if job.dataset=='all' else 'recovered',work,assignment,contract,registration['data_roots'],lease)
        elif job.stage in ('recovery','student'):
            source_gate=read(job_dir(work,assignment,JobKey('all','aggregate',None,None))/'precision_gate.json')
            require_precision_receipt(source_gate,contract,'source')
            pin,manifest,sets=context(job.dataset,contract,registration['data_roots']);ratio=job.ratio/100
            cfg=config(job.dataset)
            if job.stage=='recovery':
                model,spec,prov=source.prune(ratio,compression_models=legacy('models'),compression_pruning=legacy('pruning'))
                payload={'adapter_provenance':prov,'Hard_set':pin['hard_set']}
                expected=job_contract(contract,job.dataset,'recovery',ratio,job.seed,payload)
                module(job.dataset,'train').fit(model,sets['train'],sets['val'],lease.output_dir,20,job.seed,cfg,expected,spec,
                    backbone_lr=contract['policy']['recovery_backbone_lr'],head_lr=contract['policy']['recovery_head_lr'],head_warmup_epochs=0)
                best=verify_training_complete(lease.output_dir,20,expected,spec)
                profiled=strict_restore_compact(best,compression_models=legacy('models'),native_io=module(job.dataset,'io'),
                    expected_source=source.reference,expected_ratio=ratio,expected_classes=manifest['classes'])
                write(lease.output_dir/'profile.json',legacy('pruning').profile_model(profiled,224,'cuda'))
                del profiled
                del model
            else:
                recovered_gate=recovered_precision_gate(work,assignment,contract)
                model,spec=initial_student(job.dataset,job.seed,contract);teacher,tref=recovery_model(work,assignment,contract,job.dataset,ratio)
                require_probed_teacher(recovered_gate,job.dataset,ratio,tref)
                payload={'student_initial':pin['initializations'][str(job.seed)],'Native_baseline':pin['baselines'][str(job.seed)],
                         'teacher':tref,'Hard_set':pin['hard_set'],'Teacher_precision':contract['policy']['KD_Teacher_precision']}
                expected=job_contract(contract,job.dataset,'student',ratio,job.seed,payload)
                module(job.dataset,'train').fit(model,sets['train'],sets['val'],lease.output_dir,60,job.seed,cfg,expected,spec,teacher=teacher)
                best=verify_training_complete(lease.output_dir,60,expected,spec)
                del model,teacher
            result={'state':'complete','job':job.to_dict(),'frozen_contract_id':contract['contract_id'],
                    'best_model_digest':best['model_digest'],'best_raw_sha256':sha(lease.output_dir/'best.pt'),
                    'completed_epochs':20 if job.stage=='recovery' else 60}
            write(lease.output_dir/'COMPLETE.json',result)
        elif job.stage=='finalizer':
            from .evaluation import finalize_dataset
            result=finalize_dataset(work,assignment,contract,registration['data_roots'],lease)
        else:raise ValueError('Unknown stage')
        lease.assert_active();lease.complete(result)
    del source;gc.collect();torch.cuda.empty_cache()
    return result
