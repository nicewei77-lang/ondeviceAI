"""Load the pinned Native engines and existing pruning modules under distinct names."""
from functools import cache
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
PARENT_CODE='224776e72b009d7be9f1f3bc5be0541bfbc754b3488aa4ec3f22a55cb957d474'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

@cache
def parent():
    path=ROOT/'vendor/native_parent'
    sys.path.insert(0,str(path))
    native=importlib.import_module('b1kd.native')
    io=importlib.import_module('b1kd.io')
    if Path(native.ROOT).resolve()!=path.resolve() or io.verify_frozen()['code_id']!=PARENT_CODE:
        raise ValueError('Wrong or changed Native parent dependency')
    manifest=json.loads((ROOT/'DEPENDENCIES.json').read_bytes())
    for name,wanted in manifest['legacy_sha256'].items():
        if sha(ROOT/'vendor/legacy_pruning'/name)!=wanted:raise ValueError('Legacy pruning dependency changed: '+name)
    return native,io

def module(dataset,name):return parent()[0].module(dataset,name)
def config(dataset):return parent()[0].runtime_config(dataset)

@cache
def legacy(name):
    parent()
    package='phaseb_legacy_tckd'
    path=ROOT/'vendor/legacy_pruning/tckd'
    if package not in sys.modules:
        spec=importlib.util.spec_from_file_location(package,path/'__init__.py',submodule_search_locations=[str(path)])
        obj=importlib.util.module_from_spec(spec);sys.modules[package]=obj;spec.loader.exec_module(obj)
    return importlib.import_module(package+'.'+name)
