"""Bounded CUDA/L4 AMP numerical probes; never perform an optimizer step.

This is a readiness sample, not a trainer or a full-epoch success test. Builders
must return disposable caller-owned clones. Train-mode probes can update clone
buffers and gradients, but this module never writes a model/checkpoint/file and
never calls optimizer.step or GradScaler.step. Source and recovered phases have
separate receipts. Native training/data modules, datasets and model factories
are injected, so the existing recipe and actual image preprocessing are reused.

CPU execution is deliberately rejected before any builder/dataset access. The
receipt validator can run on CPU; schema tests alone establish no CUDA evidence.
"""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
import hashlib
import json
import math
from numbers import Real
from typing import Any

import torch


DATASETS = {"cub200": 200, "flowers102": 102, "aircraft": 100}
RATIOS = (0.0, 0.3, 0.5, 0.7)
SPLITS = ("train", "validation")
ROLES = ("teacher_recovery", "teacher_frozen", "student_kd")
PRECISION = "cuda_autocast_float16"
INITIAL_SCALE = 65536.0
MIN_SCALE = 1.0
MAX_RETRIES = 16


class PrecisionProbeError(RuntimeError):
    """Fail-closed probe error with partial rows available as ``receipt``."""

    def __init__(self, message, *, failure_kind="probe_error", row=None, receipt=None):
        super().__init__(message)
        self.failure_kind, self.row, self.receipt = failure_kind, row, receipt


def _identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()


def _sha(value):
    return (isinstance(value, str) and len(value) == 64
            and all(character in "0123456789abcdef" for character in value))


def _phase(phase_label):
    if phase_label not in {"source", "recovered"}:
        raise ValueError("phase_label must explicitly be source or recovered")


def require_l4_cuda(device="cuda"):
    """Reject CPU, unavailable CUDA and every GPU other than NVIDIA L4."""
    resolved = torch.device(device)
    if resolved.type != "cuda" or not torch.cuda.is_available():
        raise PrecisionProbeError("Actual CUDA on NVIDIA L4 is required; no CPU/FP32 fallback",
                                  failure_kind="cuda_unavailable")
    name = " ".join(torch.cuda.get_device_name(resolved).split())
    if name != "NVIDIA L4":
        raise PrecisionProbeError(f"Expected NVIDIA L4, found {name}", failure_kind="gpu_mismatch")
    return resolved, {"device": str(resolved), "gpu": name, "torch": str(torch.__version__),
                      "torch_cuda": torch.version.cuda, "cuda_available": True}


def _validate_request(dataset, config, native_train_module, frozen_contract_id,
                      phase_label, min_batches, seed, epoch):
    _phase(phase_label)
    if not _sha(frozen_contract_id):
        raise ValueError("frozen_contract_id must be a lowercase SHA-256 identity")
    if dataset not in DATASETS or not isinstance(config, Mapping):
        raise ValueError("the exact cub200/flowers102/aircraft Native config is required")
    if (config.get("dataset") != dataset or type(config.get("num_classes")) is not int
            or config["num_classes"] != DATASETS[dataset] or config.get("amp") is not True):
        raise ValueError("dataset/classes or the frozen Native AMP setting differs")
    batch, effective, workers = (config.get("batch_size"), config.get("effective_batch_size"),
                                 config.get("num_workers", 0))
    if (type(batch) is not int or batch < 1 or type(effective) is not int
            or effective < batch or effective % batch or type(workers) is not int or workers < 0):
        raise ValueError("Native batch/effective-batch/worker settings are invalid")
    if type(min_batches) is not int or min_batches < 3:
        raise ValueError("at least three actual train and validation batches are required")
    if type(seed) is not int or seed not in (42, 43, 44) or type(epoch) is not int or epoch < 0:
        raise ValueError("a frozen Student seed 42/43/44 and nonnegative epoch are required")
    temperature, alpha = config.get("temperature"), config.get("kd_alpha")
    if (isinstance(temperature, bool) or not isinstance(temperature, Real)
            or not math.isfinite(temperature) or temperature <= 0
            or isinstance(alpha, bool) or not isinstance(alpha, Real)
            or not math.isfinite(alpha) or not 0 <= alpha <= 1):
        raise ValueError("frozen Native KD temperature/alpha are invalid")
    for name in ("DataLoader", "kd_loss", "seed_everything", "rng_state", "restore_rng"):
        if not callable(getattr(native_train_module, name, None)):
            raise ValueError(f"Native training module must supply {name}")


def _loader(dataset, split, config, train, seed, epoch):
    """Mirror Native fit/predict sampling; no alternative image transform exists."""
    kwargs = dict(batch_size=config["batch_size"], num_workers=config.get("num_workers", 0),
                  pin_memory=True, shuffle=split == "train")
    if split == "train":
        train.seed_everything(seed + epoch * 100003)
        if hasattr(dataset, "set_epoch"):
            dataset.set_epoch(epoch, seed)
        kwargs.update(generator=torch.Generator().manual_seed(seed + epoch * 100003), drop_last=False)
    return train.DataLoader(dataset, **kwargs)


def _ids(value):
    ids = value.tolist() if hasattr(value, "tolist") else list(value)
    if not isinstance(ids, list) or not ids or any(type(i) not in (int, str) for i in ids):
        raise PrecisionProbeError("Actual Native batch image IDs are required", failure_kind="batch_schema")
    return ids


def _row(dataset, ratio, phase_label, split, batch_index, ids, role, images):
    return {"dataset": dataset, "ratio": ratio, "phase_label": phase_label, "split": split,
            "batch_index": batch_index, "image_ids": list(ids), "role": role,
            "teacher_precision": PRECISION, "dtype": {"input": str(images.dtype)},
            "loss": None, "finite_logits": False, "finite_loss": None,
            "finite_gradients": None, "scale": None, "initial_scale": None,
            "scale_attempts": [], "overflow_count": 0, "first_overflow": None,
            "optimizer_steps": 0, "status": "RUNNING"}


def _finite_logits(output, row, classes):
    row["dtype"]["logits"] = str(output.dtype) if isinstance(output, torch.Tensor) else None
    if (not isinstance(output, torch.Tensor) or output.ndim != 2
            or tuple(output.shape) != (len(row["image_ids"]), classes)):
        raise PrecisionProbeError("Unexpected classification logits shape", failure_kind="logit_shape", row=row)
    row["finite_logits"] = bool(torch.isfinite(output).all())
    if not row["finite_logits"]:
        raise PrecisionProbeError("AMP forward produced nonfinite logits; no fallback/clamp/exclusion",
                                  failure_kind="forward_nonfinite", row=row)


def _gradient_summary(model):
    count, bad_tensors, bad_values, first = 0, 0, 0, None
    for name, parameter in model.named_parameters():
        if parameter.grad is None:
            continue
        count += 1
        values = parameter.grad
        finite = torch.isfinite(values)
        if not bool(finite.all()):
            bad_tensors += 1
            bad_values += int((~finite).sum())
            if first is None:
                first = name
    return {"gradient_tensors": count, "nonfinite_gradient_tensors": bad_tensors,
            "nonfinite_gradient_values": bad_values, "first_nonfinite_parameter": first}


def _backward(model, images, labels, teacher_logits, row, optimizer, scaler, train, config, device):
    """Native loss*count / unscale / count; bounded same-batch scaler backoff."""
    model.train().requires_grad_(True)
    cpu_rng, cuda_rng = torch.get_rng_state(), torch.cuda.get_rng_state(device)
    buffers = {name: tensor.detach().clone() for name, tensor in model.named_buffers()}
    row["initial_scale"] = INITIAL_SCALE
    for attempt in range(MAX_RETRIES + 1):
        if attempt:
            torch.set_rng_state(cpu_rng)
            torch.cuda.set_rng_state(cuda_rng, device)
            with torch.no_grad():
                for name, tensor in model.named_buffers():
                    tensor.copy_(buffers[name])
        optimizer.zero_grad(set_to_none=True)
        scale_before = float(scaler.get_scale())
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
            output = model(images)
            _finite_logits(output, row, config["num_classes"])
            loss, ce, kd = train.kd_loss(output.float(), labels, teacher_logits,
                                       config["temperature"], config["kd_alpha"])
        row["dtype"].update(loss=str(loss.dtype), kd_teacher="torch.float32" if teacher_logits is not None else None)
        row["loss"] = float(loss.detach())
        row["ce_loss"], row["kd_loss"] = float(ce), float(kd)
        row["finite_loss"] = all(math.isfinite(row[key]) for key in ("loss", "ce_loss", "kd_loss"))
        if not row["finite_loss"]:
            raise PrecisionProbeError("Unscaled AMP loss is nonfinite; no retry/fallback/clamp/exclusion",
                                      failure_kind="loss_nonfinite", row=row)
        count = labels.numel()
        scaler.scale(loss * count).backward()
        # unscale_ records found_inf for update even though no step is requested.
        scaler.unscale_(optimizer)
        for parameter in model.parameters():
            if parameter.grad is not None:
                parameter.grad.div_(count)
        summary = _gradient_summary(model)
        if not summary["gradient_tensors"]:
            raise PrecisionProbeError("Backward produced no gradients", failure_kind="missing_gradients", row=row)
        finite = summary["nonfinite_gradient_tensors"] == 0
        event = {"attempt": attempt + 1, "scale_before": scale_before,
                 "finite_gradients": finite, **summary}
        row["finite_gradients"] = finite
        if not finite:
            row["overflow_count"] += 1
            if row["first_overflow"] is None:
                row["first_overflow"] = deepcopy(event)
            if scale_before <= MIN_SCALE or attempt == MAX_RETRIES:
                event["scale_after"] = scale_before
                row["scale_attempts"].append(event)
                row["scale"] = scale_before
                raise PrecisionProbeError("Scaled gradients remain nonfinite at the bounded scale/retry limit",
                                          failure_kind="scaled_gradient_overflow_limit", row=row)
        # The public update consumes unscale_'s found_inf and applies normal
        # GradScaler backoff. Neither scaler.step nor optimizer.step is called.
        scaler.update()
        event["scale_after"] = float(scaler.get_scale())
        row["scale_attempts"].append(event)
        row["scale"] = event["scale_after"]
        if not MIN_SCALE <= row["scale"] <= INITIAL_SCALE:
            raise PrecisionProbeError("GradScaler left the frozen 1..65536 scale range",
                                      failure_kind="scale_range", row=row)
        if finite:
            row["status"] = "PASS"
            optimizer.zero_grad(set_to_none=True)
            return row
        if row["scale"] >= scale_before:
            raise PrecisionProbeError("Normal GradScaler backoff did not reduce the scale",
                                      failure_kind="missing_scaler_backoff", row=row)
    raise AssertionError("bounded retry loop exhausted")


def _prepare_model(model, device):
    if not isinstance(model, torch.nn.Module) or not list(model.parameters()):
        raise PrecisionProbeError("Builder must return a disposable model clone", failure_kind="builder_schema")
    if any(t.is_floating_point() and t.dtype != torch.float32
           for t in (*model.parameters(), *model.buffers())):
        raise PrecisionProbeError("Native FP32 master parameters are required for CUDA AMP", failure_kind="parameter_dtype")
    return model.to(device)


def probe_dataset_amp(dataset, config, train_dataset, val_dataset, teacher_builder, student_builder,
                       native_train_module, *, frozen_contract_id, phase_label, min_batches=3,
                       seed=42, epoch=0, device="cuda"):
    """Probe four ratios on >=3 actual batches/split, returning only real L4 evidence.

    teacher_builder(ratio) returns (disposable_model_clone, frozen_source_ref).
    student_builder(seed) returns a disposable initialization clone. All roles
    see the exact same GPU image tensor within a sampled batch. Recovery and KD
    backward use train mode on both splits solely to check numerical readiness;
    validation samples never drive a parameter update. Caller owns runtime locks.
    """
    _validate_request(dataset, config, native_train_module, frozen_contract_id,
                      phase_label, min_batches, seed, epoch)
    device, runtime = require_l4_cuda(device)  # No builder, loader or forward before this gate.
    receipt = {"schema_version": 1, "kind": "phaseb_cuda_amp_readiness", "status": "RUNNING",
               "evidence_kind": "actual_cuda_l4_probe", "dataset": dataset, "phase_label": phase_label,
               "frozen_contract_id": frozen_contract_id, "teacher_precision": PRECISION,
               "student_precision": PRECISION, "runtime": runtime, "config_id": _identity(config),
               "sampling": {"seed": seed, "epoch": epoch, "min_batches_per_split": min_batches,
                            "batch_size": config["batch_size"], "num_workers": config.get("num_workers", 0),
                            "effective_batch_size": config["effective_batch_size"],
                            "gradient_scope": "single microbatch; Native loss*count, unscale, divide count",
                            "train_epoch_seed": seed + epoch * 100003,
                            "same_gpu_tensor_for_all_roles": True},
               "source_refs": {}, "role_rows": [], "optimizer_steps": 0, "model_file_writes": 0}
    previous_rng = native_train_module.rng_state()
    teacher = student = None
    try:
        for ratio in RATIOS:
            teacher, reference = teacher_builder(ratio)
            if (not isinstance(reference, Mapping) or reference.get("test_fixture") is not False
                    or not _sha(reference.get("sha256")) or not _sha(reference.get("model_digest"))):
                raise PrecisionProbeError("Frozen real Teacher source bytes/digest reference is required",
                                          failure_kind="source_reference")
            receipt["source_refs"][str(ratio)] = deepcopy(dict(reference))
            teacher = _prepare_model(teacher, device)
            student = _prepare_model(student_builder(seed), device)
            teacher_optimizer = torch.optim.AdamW(teacher.parameters(), lr=0.0)
            student_optimizer = torch.optim.AdamW(student.parameters(), lr=0.0)
            teacher_scaler, student_scaler = torch.amp.GradScaler("cuda"), torch.amp.GradScaler("cuda")
            if any(float(s.get_scale()) != INITIAL_SCALE for s in (teacher_scaler, student_scaler)):
                raise PrecisionProbeError("Native GradScaler default initial scale changed", failure_kind="initial_scale")
            for split, data in (("train", train_dataset), ("validation", val_dataset)):
                loader = _loader(data, split, config, native_train_module, seed, epoch)
                if len(loader) < min_batches:
                    raise PrecisionProbeError("At least three actual Native batches per split are required",
                                              failure_kind="insufficient_batches")
                for batch_index, (images, labels, ids) in enumerate(loader):
                    if batch_index >= min_batches:
                        break
                    ids = _ids(ids)
                    if (not isinstance(images, torch.Tensor) or images.dtype != torch.float32
                            or images.ndim != 4 or images.shape[0] != len(ids) or images.shape[1] != 3
                            or not isinstance(labels, torch.Tensor) or labels.dtype != torch.int64
                            or tuple(labels.shape) != (len(ids),)):
                        raise PrecisionProbeError("Actual Native RGB float32 images/int64 labels are required",
                                                  failure_kind="batch_schema")
                    if not bool(torch.isfinite(images).all()):
                        raise PrecisionProbeError("Actual Native input contains nonfinite values", failure_kind="input_nonfinite")
                    images, labels = images.to(device), labels.to(device)
                    base = (dataset, ratio, phase_label, split, batch_index, ids)
                    row = _row(*base, "teacher_recovery", images)
                    receipt["role_rows"].append(_backward(teacher, images, labels, None, row,
                                                        teacher_optimizer, teacher_scaler,
                                                        native_train_module, config, device))
                    teacher.eval().requires_grad_(False)
                    teacher.zero_grad(set_to_none=True)
                    row = _row(*base, "teacher_frozen", images)
                    with torch.no_grad(), torch.autocast(device_type="cuda", dtype=torch.float16, enabled=True):
                        raw_logits = teacher(images)
                    _finite_logits(raw_logits, row, config["num_classes"])
                    teacher_logits = raw_logits.float()
                    row["dtype"]["kd_target"] = str(teacher_logits.dtype)
                    row["teacher_requires_grad"] = any(p.requires_grad for p in teacher.parameters())
                    row["status"] = "PASS"
                    receipt["role_rows"].append(row)
                    row = _row(*base, "student_kd", images)
                    receipt["role_rows"].append(_backward(student, images, labels, teacher_logits, row,
                                                        student_optimizer, student_scaler,
                                                        native_train_module, config, device))
                    del raw_logits, teacher_logits
            teacher.zero_grad(set_to_none=True)
            student.zero_grad(set_to_none=True)
            del teacher_optimizer, student_optimizer, teacher_scaler, student_scaler
            teacher = student = None
        torch.cuda.synchronize(device)
        receipt["status"] = "PASS"
        validate_dataset_receipt(receipt, frozen_contract_id=frozen_contract_id, phase_label=phase_label)
        return receipt
    except Exception as error:
        receipt["status"] = "FAIL"
        receipt["failure"] = {"kind": getattr(error, "failure_kind", "probe_error"),
                              "error_type": type(error).__name__, "message": str(error)}
        if getattr(error, "row", None) is not None:
            failed = deepcopy(error.row)
            failed["status"] = "FAIL"
            receipt["role_rows"].append(failed)
        raise PrecisionProbeError(str(error), failure_kind=receipt["failure"]["kind"], receipt=receipt) from error
    finally:
        for model in (teacher, student):
            if model is not None:
                model.zero_grad(set_to_none=True)
        native_train_module.restore_rng(previous_rng)


def validate_dataset_receipt(receipt, *, frozen_contract_id, phase_label):
    """Validate evidence schema/coverage without performing any CUDA operation."""
    _phase(phase_label)
    if (not _sha(frozen_contract_id) or not isinstance(receipt, Mapping)
            or receipt.get("schema_version") != 1 or receipt.get("kind") != "phaseb_cuda_amp_readiness"
            or receipt.get("status") != "PASS" or receipt.get("evidence_kind") != "actual_cuda_l4_probe"
            or receipt.get("frozen_contract_id") != frozen_contract_id
            or receipt.get("phase_label") != phase_label or receipt.get("dataset") not in DATASETS
            or receipt.get("teacher_precision") != PRECISION or receipt.get("student_precision") != PRECISION
            or receipt.get("optimizer_steps") != 0 or receipt.get("model_file_writes") != 0):
        raise ValueError("CUDA AMP receipt identity/phase/precision/no-update evidence differs")
    runtime, sampling = receipt.get("runtime", {}), receipt.get("sampling", {})
    if (runtime.get("gpu") != "NVIDIA L4" or runtime.get("cuda_available") is not True
            or not str(runtime.get("device", "")).startswith("cuda")
            or not runtime.get("torch_cuda") or not _sha(receipt.get("config_id"))):
        raise ValueError("Receipt must identify actual CUDA execution on NVIDIA L4")
    batches = sampling.get("min_batches_per_split")
    if (type(batches) is not int or batches < 3 or sampling.get("seed") not in (42, 43, 44)
            or type(sampling.get("epoch")) is not int or sampling["epoch"] < 0
            or sampling.get("same_gpu_tensor_for_all_roles") is not True
            or sampling.get("train_epoch_seed") != sampling["seed"] + sampling["epoch"] * 100003):
        raise ValueError("Receipt sampling does not preserve the bounded Native image stream")
    references = receipt.get("source_refs", {})
    if set(references) != {str(r) for r in RATIOS}:
        raise ValueError("Receipt must identify all four ratio source references")
    for ref in references.values():
        if (not isinstance(ref, Mapping) or ref.get("test_fixture") is not False
                or not _sha(ref.get("sha256")) or not _sha(ref.get("model_digest"))):
            raise ValueError("Receipt contains an invalid real-source reference")
    expected = {(r, s, b, role) for r in RATIOS for s in SPLITS for b in range(batches) for role in ROLES}
    seen, image_streams = set(), {}
    for row in receipt.get("role_rows", []):
        key = (row.get("ratio"), row.get("split"), row.get("batch_index"), row.get("role"))
        if (type(row.get("ratio")) not in (int, float) or type(row.get("batch_index")) is not int
                or key not in expected or key in seen):
            raise ValueError("Receipt has a missing/duplicate/unexpected role or ratio batch")
        seen.add(key)
        if (row.get("dataset") != receipt["dataset"] or row.get("phase_label") != phase_label
                or row.get("status") != "PASS" or row.get("teacher_precision") != PRECISION
                or row.get("finite_logits") is not True or row.get("optimizer_steps") != 0
                or row.get("dtype", {}).get("input") != "torch.float32"
                or row.get("dtype", {}).get("logits") not in {"torch.float16", "torch.float32"}):
            raise ValueError("Receipt role failed numerical/precision/no-update checks")
        ids = row.get("image_ids")
        if not isinstance(ids, list) or not ids or any(type(i) not in (int, str) for i in ids):
            raise ValueError("Receipt must identify actual sampled images")
        stream_key = (row["split"], row["batch_index"])
        if stream_key in image_streams and image_streams[stream_key] != ids:
            raise ValueError("Ratios/roles did not use the same ordered Native images")
        image_streams[stream_key] = ids
        if row["role"] == "teacher_frozen":
            if (row.get("teacher_requires_grad") is not False or row.get("loss") is not None
                    or row.get("scale") is not None or row["dtype"].get("kd_target") != "torch.float32"):
                raise ValueError("Frozen Teacher eval evidence differs")
            continue
        scale, attempts = row.get("scale"), row.get("scale_attempts")
        if (row.get("finite_loss") is not True or row.get("finite_gradients") is not True
                or isinstance(row.get("loss"), bool) or not isinstance(row.get("loss"), Real)
                or not math.isfinite(row["loss"]) or row["dtype"].get("loss") != "torch.float32"
                or row.get("initial_scale") != INITIAL_SCALE or isinstance(scale, bool)
                or not isinstance(scale, Real) or not MIN_SCALE <= scale <= INITIAL_SCALE
                or not isinstance(attempts, list) or not 1 <= len(attempts) <= MAX_RETRIES + 1
                or attempts[-1].get("finite_gradients") is not True
                or attempts[-1].get("scale_after") != scale):
            raise ValueError("Backward/scaler evidence is missing or nonfinite")
        overflows = [a for a in attempts if a.get("finite_gradients") is False]
        if (row.get("overflow_count") != len(overflows)
                or any(a.get("finite_gradients") is not False for a in attempts[:-1])
                or (not overflows and row.get("first_overflow") is not None)
                or (overflows and not isinstance(row.get("first_overflow"), Mapping))):
            raise ValueError("Normal scaler overflows were not recorded consistently")
        for index, attempt in enumerate(attempts):
            before, after = attempt.get("scale_before"), attempt.get("scale_after")
            if (type(attempt.get("attempt")) is not int or attempt["attempt"] != index + 1
                    or isinstance(before, bool) or not isinstance(before, Real)
                    or isinstance(after, bool) or not isinstance(after, Real)
                    or not MIN_SCALE <= after <= before <= INITIAL_SCALE
                    or type(attempt.get("gradient_tensors")) is not int or attempt["gradient_tensors"] < 1
                    or (attempt.get("finite_gradients") is False and after != before * .5)
                    or (attempt.get("finite_gradients") is False and
                        (not isinstance(attempt.get("nonfinite_gradient_tensors"), int)
                         or attempt["nonfinite_gradient_tensors"] < 1))
                    or (attempt.get("finite_gradients") is True and attempt.get("nonfinite_gradient_tensors") != 0)
                    or (index and before != attempts[index - 1]["scale_after"])):
                raise ValueError("GradScaler attempts do not show normal bounded backoff")
    if seen != expected:
        raise ValueError("Receipt does not cover every ratio/split/batch/role")
    return True


def validate_full_coverage(receipts, *, frozen_contract_id, phase_label):
    """Require three datasets x four ratios for one exact source/recovered phase."""
    _phase(phase_label)
    if not isinstance(receipts, (list, tuple)) or len(receipts) != len(DATASETS):
        raise ValueError("Exactly three dataset AMP receipts are required")
    by_dataset = {}
    for receipt in receipts:
        validate_dataset_receipt(receipt, frozen_contract_id=frozen_contract_id, phase_label=phase_label)
        dataset = receipt["dataset"]
        if dataset in by_dataset:
            raise ValueError("Duplicate dataset precision receipt")
        by_dataset[dataset] = receipt
    if set(by_dataset) != set(DATASETS):
        raise ValueError("Full AMP coverage requires cub200, flowers102, aircraft")
    return {"schema_version": 1, "kind": "phaseb_cuda_amp_full_coverage", "status": "PASS",
            "evidence_kind": "actual_cuda_l4_probe", "frozen_contract_id": frozen_contract_id,
            "phase_label": phase_label, "teacher_precision": PRECISION, "student_precision": PRECISION,
            "coverage": [{"dataset": d, "ratios": list(RATIOS), "splits": list(SPLITS),
                          "roles": list(ROLES), "batches_per_split": by_dataset[d]["sampling"]["min_batches_per_split"],
                          "receipt_id": _identity(by_dataset[d])} for d in DATASETS],
            "source_refs": {d: deepcopy(by_dataset[d]["source_refs"]) for d in DATASETS},
            "role_rows": [deepcopy(row) for d in DATASETS for row in by_dataset[d]["role_rows"]],
            "optimizer_steps": 0, "model_file_writes": 0,
            "scope": "sampled actual Native images; single-microbatch finite AMP forward/loss/backward; no optimizer updates",
            "limits": "Does not establish full-epoch/full-training AMP success, accuracy, recovery completion or Test evaluation"}
