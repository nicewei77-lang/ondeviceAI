"""Explicit preparation and bounded workers for the frozen Native/pruning runner.

Only pipeline.run_job may perform a model operation.  This entry point never
implements a trainer, downloads inputs, guesses a runtime identity, or polls a
browser.  Workers yield when their remaining jobs depend on another slot.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlsplit

from .contracts import DATASETS, output_root
from .io import read, sha, verify_code, write
from .native import ROOT
from .ownership import current_runtime_id, validate_assignment

LOCAL_PREFLIGHT = Path('/content/phaseb_local_preflight/results')
DEFAULT_CACHE = Path('/content/phaseb_raw_cache')
COLAB_PATH = re.compile(r'/drive/[A-Za-z0-9_-]+\Z')


def _pipeline():
    # --help and parser guards require no Torch import or CUDA initialization.
    from . import pipeline
    return pipeline


def _slot(value):
    if value not in ('A', 'B'):
        raise ValueError('Only the frozen slots A and B are allowed')
    return value


def data_roots(value, *, require_directories=True):
    """Accept dataset filesystem paths only; never persist URL/SAS credentials."""
    if not isinstance(value, dict) or set(value) != set(DATASETS):
        raise ValueError('data_roots must contain exactly cub200, flowers102, aircraft')
    result = {}
    for dataset in DATASETS:
        text = value[dataset]
        if (not isinstance(text, str) or not text.strip() or '\x00' in text
                or '://' in text or any(c in text for c in ('?', '#', '&'))):
            raise ValueError('data_roots must contain plain absolute filesystem paths, without URL credentials')
        path = Path(text).expanduser()
        if not path.is_absolute() or '..' in path.parts:
            raise ValueError('data_roots must be absolute, without parent traversal')
        path = path.resolve()
        if require_directories and not path.is_dir():
            raise ValueError('A required local dataset directory is unavailable: ' + dataset)
        result[dataset] = str(path)
    return result


def _colab_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or parsed.netloc != 'colab.research.google.com'
            or not COLAB_PATH.fullmatch(parsed.path) or parsed.query or parsed.fragment
            or parsed.username or parsed.password):
        raise ValueError('Use a canonical https://colab.research.google.com/drive/<id> URL without query or fragment')
    return value


def verify_local_preflight(roots):
    """Require this runtime's completed full-image audit, not a copied root map."""
    roots = data_roots(roots)
    from .native import PARENT_CODE, parent
    parent()
    from b1kd.references import validate_preflight
    pins = read(ROOT / 'configs/readonly_inputs.json')['datasets']
    for dataset in DATASETS:
        folder = LOCAL_PREFLIGHT / 'data' / dataset
        manifest = read(folder / 'splits.json')
        if manifest != read(ROOT / pins[dataset]['reference_manifest']):
            raise ValueError('Local preflight ordered manifest differs from frozen Native inputs')
        validate_preflight(dataset, manifest, read(folder / 'image_audit.json'))
        receipt = read(folder / 'B1_DATA_RECEIPT.json')
        if (receipt.get('dataset') != dataset or receipt.get('split_id') != pins[dataset]['split_id']
                or receipt.get('code_id') != PARENT_CODE or receipt.get('data_root') != roots[dataset]
                or receipt.get('full_image_preflight_complete') is not True
                or receipt.get('exact_native_manifest_parity') is not True
                or Path(receipt['native_results_read_only']).resolve() != Path(pins[dataset]['native_results']).resolve()):
            raise ValueError('Current runtime full-image preflight receipt is missing or incompatible')
        for relative, wanted in manifest['source']['metadata_sha256'].items():
            if sha(Path(roots[dataset]) / relative) != wanted:
                raise ValueError('Actual local dataset metadata changed after full preflight')
    return roots


def _execution(work, slot):
    """Validate frozen binding and the caller before exposing executable work."""
    _slot(slot)
    engine = _pipeline()
    work = output_root(work)
    contract = engine.load_contract(work)
    execution = read(engine.controls(work) / 'execution.json')
    if (execution.get('contract_id') != contract['contract_id']
            or execution.get('code_id') != contract['code_id']):
        raise ValueError('Execution binding differs from the frozen source/code contract')
    assignment = execution['assignment']
    validate_assignment(assignment, expected_contract_id=contract['contract_id'],
                        expected_source_ids=engine.source_ids(contract), expected_jobs=engine.jobs(),
                        expected_assignment_id=execution['assignment_id'])
    if assignment['state'] != 'executable' or assignment['output_root'] != work.as_posix():
        raise ValueError('A complete two-runtime execution binding is required')
    registrations = {}
    for candidate in ('A', 'B'):
        record = read(engine.controls(work) / ('runtime_' + candidate + '.json'))
        owner = assignment['slot_owners'][candidate]
        if (record.get('state') != 'registered' or record.get('slot') != candidate
                or record.get('contract_id') != contract['contract_id']
                or record.get('code_id') != contract['code_id']
                or record.get('runtime_id') != owner['runtime_id']
                or hashlib.sha256(record['owner_token'].encode('utf8')).hexdigest() != owner['owner_token_sha256']):
            raise ValueError('Runtime registration differs from the frozen assignment')
        # Other runtime paths need not exist on this runtime, but must be paths.
        data_roots(record['data_roots'], require_directories=False)
        registrations[candidate] = record
    if registrations[slot]['runtime_id'] != current_runtime_id():
        raise ValueError('This process is not running on the registered slot runtime')
    verify_local_preflight(registrations[slot]['data_roots'])
    for receipt in assignment['source_receipts']:
        if sha(receipt['path']) != receipt['sha256']:
            raise ValueError('A frozen source/runtime receipt changed')
    return engine, contract, execution, registrations


def plan(work):
    """Read metadata only. Missing gates remain pending; no training claim."""
    engine = _pipeline()
    work = output_root(work)
    rows = engine.jobs()
    assignment = engine.partition()
    if len(rows) != 55 or set(assignment) != set(rows):
        raise ValueError('The frozen 55-job plan changed')
    control = engine.controls(work)
    gates = {}
    paths = {'source_pins': work / 'preparation/source_pins.json',
             'source_contract': control / 'frozen_contract.json',
             'slot_A_runtime': control / 'runtime_A.json',
             'slot_B_runtime': control / 'runtime_B.json',
             'execution_binding': control / 'execution.json',
             'manual_runtime_readiness': control / 'RUNTIME_READINESS.json'}
    for name, path in paths.items():
        gates[name] = {'path': str(path), 'state': 'present_unvalidated' if path.is_file() else 'pending'}
    frozen = ROOT / 'FROZEN_SOURCE.json'
    code_id = verify_code(ROOT) if frozen.is_file() else None
    return {'state': 'plan_only', 'training_calls': 0, 'job_count': len(rows),
            'counts': dict(Counter(j.stage for j in rows)),
            'slot_counts': dict(Counter(assignment.values())),
            'code_id': code_id, 'code_gate': 'verified' if code_id else 'pending_package_manifest',
            'maximum_sessions': 2, 'additional_purchases': 0, 'git_push_merge': False,
            'gates': gates, 'CUDA_AMP_verified': False, 'training_ready': False,
            'scope': 'Metadata/file presence only; gate contents and actual CUDA precision are not established by this plan',
            'jobs': [{'job_id': j.job_id, 'slot': assignment[j], **j.to_dict()} for j in rows]}


def freeze_source(work):
    # Reuse 00's actual source_pins; do not re-read/model-allocate its checkpoints.
    engine = _pipeline()
    return engine.prepare_contract(work)


def _local_preparation_paths(cache, inputs, work):
    if os.name != 'posix':
        raise ValueError('Actual data preparation is restricted to a Colab /content runtime')
    content = Path('/content').resolve()
    cache, inputs, work = Path(cache).resolve(), Path(inputs).resolve(), output_root(work)
    preflight = LOCAL_PREFLIGHT.resolve()
    if not inputs.is_dir():
        raise ValueError('Existing approved input archives are unavailable')
    readonly = [Path(v['native_results']).resolve() for v in read(ROOT / 'configs/readonly_inputs.json')['datasets'].values()]
    for destination in (cache, preflight):
        if (not destination.is_relative_to(content) or destination == content
                or destination.is_relative_to(Path('/content/drive'))):
            raise ValueError('Preparation output/cache must use a local /content directory outside Drive')
        for forbidden in readonly + [inputs, ROOT.resolve(), work]:
            if destination.is_relative_to(forbidden) or forbidden.is_relative_to(destination):
                raise ValueError('Preparation output/cache overlaps a read-only source, input, or experiment result')
    if cache.is_relative_to(preflight) or preflight.is_relative_to(cache):
        raise ValueError('Extraction cache and preflight receipts must be separate')
    return cache, inputs, preflight


def prepare_data(work, inputs, cache_root=DEFAULT_CACHE):
    verify_code(ROOT)
    cache, inputs, preflight = _local_preparation_paths(cache_root, inputs, work)
    from .native import parent
    parent()  # Verify the exact existing dependency before invoking its tool.
    pins = read(ROOT / 'configs/readonly_inputs.json')['datasets']
    roots = {}
    for dataset in DATASETS:
        subprocess.run([sys.executable, '-B', '-u', str(ROOT / 'vendor/native_parent/tools/prepare_data.py'),
                        '--dataset', dataset, '--inputs', str(inputs), '--cache-root', str(cache),
                        '--work-dir', str(preflight), '--native-results', pins[dataset]['native_results']],
                       check=True, cwd=ROOT)
        receipt = read(preflight / 'data' / dataset / 'B1_DATA_RECEIPT.json')
        if (receipt.get('dataset') != dataset or receipt.get('split_id') != pins[dataset]['split_id']
                or receipt.get('full_image_preflight_complete') is not True
                or receipt.get('exact_native_manifest_parity') is not True
                or Path(receipt['native_results_read_only']).resolve() != Path(pins[dataset]['native_results']).resolve()):
            raise ValueError('Existing full-data preparation receipt is missing or incompatible')
        roots[dataset] = receipt['data_root']
    roots = data_roots(roots)
    path = preflight / 'data_roots.json'
    if path.exists() and read(path) != roots:
        raise ValueError('Existing local data-root mapping differs; no implicit replacement')
    if not path.exists():
        write(path, roots)
    return {'state': 'full_local_data_preflight_complete', 'data_roots_file': str(path),
            'data_roots': roots, 'training_calls': 0, 'CUDA_AMP_verified': False}


def register_runtime(work, slot, roots_file):
    _slot(slot)
    roots = verify_local_preflight(data_roots(read(roots_file)))
    return _pipeline().register_runtime(work, slot, roots)


def bind_execution(work, slot):
    if _slot(slot) != 'A':
        raise ValueError('Only the registered slot A coordinator may bind execution')
    engine = _pipeline()
    record = read(engine.controls(output_root(work)) / 'runtime_A.json')
    if record.get('runtime_id') != current_runtime_id():
        raise ValueError('Execution binding must run on registered runtime A')
    return engine.bind_execution(work)


def acknowledge_runtime_readiness(work, slot, active_sessions, confirmed_runtime_ids, colab_urls, confirmed):
    if _slot(slot) != 'A' or confirmed is not True:
        raise ValueError('Slot A requires explicit manual current URL/connection confirmation')
    if type(active_sessions) is not int or active_sessions != 2:
        raise ValueError('Exactly the two bound A/B sessions must be confirmed active; maximum is two')
    if set(confirmed_runtime_ids) != {'A', 'B'} or set(colab_urls) != {'A', 'B'}:
        raise ValueError('Manual confirmation must identify both bound runtime slots')
    urls = {candidate: _colab_url(colab_urls[candidate]) for candidate in ('A', 'B')}
    if len(set(urls.values())) != 2:
        raise ValueError('The two runtime slots require distinct Colab notebook URLs')
    engine, contract, execution, registrations = _execution(work, 'A')
    records = {}
    for candidate in ('A', 'B'):
        registration = registrations[candidate]
        if confirmed_runtime_ids[candidate] != registration['runtime_id']:
            raise ValueError('Manually confirmed runtime fingerprint differs from registration: ' + candidate)
        records[candidate] = {'runtime_id': registration['runtime_id'], 'runtime': registration['runtime'],
                              'data_roots': registration['data_roots'], 'colab_url': urls[candidate],
                              'registration_sha256': sha(engine.controls(work) / ('runtime_' + candidate + '.json'))}
    record = {'state': 'passed', 'evidence_kind': 'explicit_user_manual_Colab_UI_confirmation',
              'acknowledged_at_utc': datetime.now(timezone.utc).isoformat(),
              'current_URL_and_Colab_connection_verified': True, 'active_sessions': active_sessions,
              'maximum_sessions': 2, 'additional_purchases': 0, 'git_push_merge': False,
              'assignment_id': execution['assignment_id'], 'contract_id': contract['contract_id'],
              'code_id': contract['code_id'], 'slots': records,
              'CUDA_AMP_verified': False, 'training_success_established': False,
              'scope': 'User manually confirmed the two URLs, connected sessions, runtime IDs and data-root mapping; numerical CUDA gates remain separate'}
    path = engine.controls(work) / 'RUNTIME_READINESS.json'
    if path.exists():
        old = read(path)
        if {k: v for k, v in old.items() if k != 'acknowledged_at_utc'} != {k: v for k, v in record.items() if k != 'acknowledged_at_utc'}:
            raise ValueError('Prior runtime readiness differs; no implicit replacement')
        return old
    write(path, record)
    return record


def run_job(work, slot, job_id):
    engine, _, execution, _ = _execution(work, slot)
    matches = [job for job in engine.jobs() if job.job_id == job_id]
    if len(matches) != 1:
        raise ValueError('Unknown job outside the frozen 55-job grid')
    job = matches[0]
    owner = next(row['slot'] for row in execution['assignment']['jobs'] if row['job_id'] == job_id)
    if owner != slot:
        raise ValueError('Requested job belongs to another runtime slot')
    if engine.complete(work, execution['assignment'], job):
        return {'state': 'already_complete', 'job_id': job_id, 'training_calls': 0}
    return engine.run_job(work, slot, job)


def worker(work, slot, *, max_jobs=None, emit=None):
    """Drain ready jobs in this slot once; yield instead of retrying dependencies."""
    if max_jobs is not None and (type(max_jobs) is not int or max_jobs < 1):
        raise ValueError('max_jobs must be a positive integer')
    engine, _, execution, _ = _execution(work, slot)
    assignment = execution['assignment']
    owned_ids = {row['job_id'] for row in assignment['jobs'] if row['slot'] == slot}
    assigned = [job for job in engine.jobs() if job.job_id in owned_ids]
    completed_now = []
    while True:
        progressed = False
        for job in assigned:
            if engine.complete(work, assignment, job) or not engine.ready(work, assignment, job):
                continue
            if emit:
                emit({'state': 'starting', 'slot': slot, 'job_id': job.job_id})
            engine.run_job(work, slot, job)  # Every source/runtime/precision/lease gate remains in pipeline.
            if not engine.complete(work, assignment, job):
                raise ValueError('Pipeline returned without a validated completion receipt')
            completed_now.append(job.job_id)
            progressed = True
            if emit:
                emit({'state': 'completed', 'slot': slot, 'job_id': job.job_id})
            if max_jobs is not None and len(completed_now) >= max_jobs:
                pending = [j.job_id for j in assigned if not engine.complete(work, assignment, j)]
                return {'state': 'yielded_max_jobs' if pending else 'slot_complete', 'slot': slot,
                        'completed_now': completed_now, 'pending_jobs': pending, 'automatic_retry': False}
        pending = [j.job_id for j in assigned if not engine.complete(work, assignment, j)]
        if not pending or not progressed:
            return {'state': 'slot_complete' if not pending else 'yielded_pending_dependencies', 'slot': slot,
                    'completed_now': completed_now, 'pending_jobs': pending, 'automatic_retry': False,
                    'next_action': 'Inspect the other slot and its gates, then rerun this command after dependency completion' if pending else 'No remaining jobs in this slot'}


def _print(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest='command', required=True)
    for name in ('plan-only', 'freeze-source', 'prepare-data', 'register-runtime', 'bind-execution',
                 'acknowledge-runtime-readiness', 'run-job', 'worker'):
        q = commands.add_parser(name)
        q.add_argument('--work-dir', required=True)
        if name in ('register-runtime', 'bind-execution', 'acknowledge-runtime-readiness', 'run-job', 'worker'):
            q.add_argument('--slot', choices=('A', 'B'), required=True)
        if name == 'prepare-data':
            q.add_argument('--inputs', required=True)
            q.add_argument('--cache-root', default=str(DEFAULT_CACHE))
        elif name == 'register-runtime':
            q.add_argument('--data-roots-file', required=True)
        elif name == 'acknowledge-runtime-readiness':
            q.add_argument('--active-sessions', type=int, required=True)
            q.add_argument('--confirm-current-url-and-colab-connection', action='store_true', required=True)
            for slot in ('a', 'b'):
                q.add_argument('--slot-' + slot + '-runtime-id', required=True)
                q.add_argument('--slot-' + slot + '-colab-url', required=True)
        elif name == 'run-job':
            q.add_argument('--job-id', required=True)
        elif name == 'worker':
            q.add_argument('--max-jobs', type=int)
    return p


def main(argv=None):
    a = parser().parse_args(argv)
    try:
        if a.command == 'plan-only':
            result = plan(a.work_dir)
        elif a.command == 'freeze-source':
            result = freeze_source(a.work_dir)
        elif a.command == 'prepare-data':
            result = prepare_data(a.work_dir, a.inputs, a.cache_root)
        elif a.command == 'register-runtime':
            result = register_runtime(a.work_dir, a.slot, a.data_roots_file)
        elif a.command == 'bind-execution':
            result = bind_execution(a.work_dir, a.slot)
        elif a.command == 'acknowledge-runtime-readiness':
            result = acknowledge_runtime_readiness(a.work_dir, a.slot, a.active_sessions,
                {'A': a.slot_a_runtime_id, 'B': a.slot_b_runtime_id},
                {'A': a.slot_a_colab_url, 'B': a.slot_b_colab_url}, a.confirm_current_url_and_colab_connection)
        elif a.command == 'run-job':
            result = run_job(a.work_dir, a.slot, a.job_id)
        else:
            result = worker(a.work_dir, a.slot, max_jobs=a.max_jobs, emit=_print)
        _print(result)
        return 0
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, subprocess.CalledProcessError) as exc:
        # Do not print argument files or arbitrary mappings containing credentials.
        _print({'state': 'blocked_fail_closed', 'command': a.command,
                'error_type': type(exc).__name__, 'message': str(exc)})
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
