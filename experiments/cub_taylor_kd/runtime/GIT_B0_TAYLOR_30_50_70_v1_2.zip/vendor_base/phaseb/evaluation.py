"""Single-owner validation freeze and new pruning Test evaluation; Native baseline logits reused read-only."""
from pathlib import Path
import csv
import gc
import statistics
import torch
from .io import read,write,sha,identity
from .native import ROOT,module,config
from .contracts import RATIOS,SEEDS
from .ownership import JobKey

def finalize_dataset(work,assignment,contract,data_roots,lease):
    from .pipeline import context,job_dir,recovery_model,completed_checkpoint,recovered_precision_gate,require_probed_teacher
    dataset=lease.key.dataset;pin,manifest,sets=context(dataset,contract,data_roots)
    cfg=config(dataset);hard_ids=pin['hard_set']['class_ids'];native_io=module(dataset,'io')
    out=lease.output_dir
    teachers={};students={}
    gate=recovered_precision_gate(work,assignment,contract)
    for ratio in RATIOS:
        model,ref=recovery_model(work,assignment,contract,dataset,ratio);require_probed_teacher(gate,dataset,ratio,ref);teachers[str(ratio)]=ref;del model
        for seed in SEEDS:
            folder=job_dir(work,assignment,JobKey(dataset,'student',round(ratio*100),seed))
            saved,student_ref=completed_checkpoint(work,assignment,contract,JobKey(dataset,'student',round(ratio*100),seed))
            if saved['contract']['frozen_contract_id']!=contract['contract_id'] or saved['contract']['source']['teacher']!=ref:
                raise ValueError('Student selected checkpoint source differs')
            if native_io.model_state_identity(saved['model_state'])!=saved['model_digest']:raise ValueError('Student tensor digest changed')
            students[f'{ratio}:{seed}']={'path':(folder/'best.pt').as_posix(),'model_digest':saved['model_digest'],
                'contract_id':identity(saved['contract']),'model_spec':saved['model_spec'],'epoch':saved['epoch'],'raw_sha256':sha(folder/'best.pt')}
    source_plan={'schema_version':1,'frozen_contract_id':contract['contract_id'],'assignment_id':assignment['assignment_id'],
        'dataset':dataset,'split_id':pin['split_id'],'hard_set':pin['hard_set'],'teachers':teachers,'students':students,
        'baselines':pin['baselines'],'selection':'Validation only; recovered r00 is the matched20epoch control','Test_used_for_selection':False}

    def model_for(name,ratio,seed):
        if name=='teacher':return recovery_model(work,assignment,contract,dataset,ratio)[0]
        ref=students[f'{ratio}:{seed}'];saved,_=completed_checkpoint(work,assignment,contract,JobKey(dataset,'student',round(ratio*100),seed))
        if sha(ref['path'])!=ref['raw_sha256']:raise ValueError('Selected Student raw bytes changed')
        model=module(dataset,'models').build_from_spec(saved['model_spec']);model.load_state_dict(saved['model_state'],strict=True);return model

    def metric(name,ratio,seed,split,data):
        key=f'{name}_r{round(ratio*100):02d}'+('' if seed is None else f'_seed_{seed}')
        destination=out/'evaluation'/split/key
        ref=teachers[str(ratio)] if name=='teacher' else students[f'{ratio}:{seed}']
        payload_path=destination.with_suffix('.pt')
        if payload_path.exists():payload=native_io.checkpoint_read(payload_path)
        else:
            model=model_for(name,ratio,seed);model.cuda()
            with torch.autocast('cuda',enabled=False):
                logits,labels,ids=module(dataset,'train').predict(model,data,cfg['batch_size'],cfg['num_workers'],'cuda')
            payload={'logits':logits,'labels':labels,'image_ids':ids,'checkpoint':ref,'split':split,'frozen_contract_id':contract['contract_id']}
            native_io.checkpoint_write(payload_path,payload);del model;gc.collect();torch.cuda.empty_cache()
        if (payload['checkpoint']!=ref or payload['split']!=split or payload['frozen_contract_id']!=contract['contract_id']
            or payload['image_ids']!=[r['image_id'] for r in manifest[split]]
            or payload['labels'].tolist()!=[r['label'] for r in manifest[split]]):raise ValueError('Evaluation payload differs')
        values=module(dataset,'metrics').classification_metrics(payload['logits'],payload['labels'],cfg['num_classes'],hard_ids)
        write(destination.with_suffix('.json'),{**values,'checkpoint':ref,'split':split,'frozen_contract_id':contract['contract_id']})
        destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.with_suffix('.csv').open('w',encoding='utf8',newline='') as stream:
            w=csv.writer(stream);w.writerow(['image_id','label','prediction','correct','is_hard'])
            for image,label,prediction in zip(payload['image_ids'],payload['labels'].tolist(),payload['logits'].argmax(1).tolist()):
                w.writerow([image,label,prediction,int(label==prediction),int(label in hard_ids)])
        return {'condition':name,'ratio':ratio,'seed':seed,**values}

    def baseline(seed,split):
        # Completed B1 v2 baseline exports are exact read-only Native baseline checkpoints,
        # already independently matched to Native core. Require original raw SHA from producer seal.
        source=pin['baseline_saved_predictions'][split][str(seed)]
        if sha(source['path'])!=source['sha256']:raise ValueError('Read-only baseline prediction source changed')
        payload=native_io.checkpoint_read(source['path'])
        if (payload['checkpoint']!=pin['baselines'][str(seed)] or payload['split']!=split
            or payload['image_ids']!=[r['image_id'] for r in manifest[split]]
            or payload['labels'].tolist()!=[r['label'] for r in manifest[split]]):raise ValueError('Baseline input/checkpoint pairing changed')
        values=module(dataset,'metrics').classification_metrics(payload['logits'],payload['labels'],cfg['num_classes'],hard_ids)
        return {'condition':'baseline','ratio':None,'seed':seed,'read_only_source':source,**values}

    validation=[]
    for ratio in RATIOS:
        validation.append(metric('teacher',ratio,None,'val',sets['val']))
        for seed in SEEDS:validation.append(metric('KD',ratio,seed,'val',sets['val']))
    validation.extend(baseline(seed,'val') for seed in SEEDS)
    mean=lambda rows,key:statistics.mean(r[key] for r in rows)
    reference=[r for r in validation if r['condition']=='KD' and r['ratio']==0.0]
    candidates=[]
    for ratio in RATIOS:
        rows=[r for r in validation if r['condition']=='KD' and r['ratio']==ratio]
        margins=contract['policy']['validation_preservation_margin_pp']
        if (mean(rows,'accuracy_pct')>=mean(reference,'accuracy_pct')-margins['Overall']
            and mean(rows,'hard_accuracy_pct')>=mean(reference,'hard_accuracy_pct')-margins['Hard']):candidates.append(ratio)
    profiles={str(r):read(job_dir(work,assignment,JobKey(dataset,'recovery',round(r*100),cfg['teacher_seed']))/'profile.json') for r in RATIOS}
    chosen=min(candidates,key=lambda r:profiles[str(r)]['macs'])
    plan={**source_plan,'validation_recommended_ratio':chosen,'validation_eligible_ratios':candidates,
          'profiles':profiles,'policy':contract['policy'],'validation_rows_id':identity(validation)}
    path=out/'evaluation_plan.json'
    if path.exists() and read(path)!=plan:raise ValueError('Frozen pruning evaluation plan differs')
    if not path.exists():write(path,plan)
    write(out/'validation_summary.json',{'rows':validation,'plan_id':identity(plan)})
    # Only now create/access locked Test image dataset; never select using Test.
    _,_,testsets=context(dataset,contract,data_roots,test=True)
    test=[]
    for ratio in RATIOS:
        test.append(metric('teacher',ratio,None,'test',testsets['test']))
        for seed in SEEDS:test.append(metric('KD',ratio,seed,'test',testsets['test']))
    test.extend(baseline(seed,'test') for seed in SEEDS)
    paired=[];groups={}
    for ratio in RATIOS:
        rows=[r for r in test if r['condition']=='KD' and r['ratio']==ratio]
        gains=[]
        for seed in SEEDS:
            a=next(r for r in rows if r['seed']==seed);b=next(r for r in test if r['condition']=='baseline' and r['seed']==seed)
            gains.append({'seed':seed,'Overall_gain_pp':a['accuracy_pct']-b['accuracy_pct'],
                          'Hard_gain_pp':a['hard_accuracy_pct']-b['hard_accuracy_pct']})
        paired.append({'ratio':ratio,'pairs':gains})
        groups[str(ratio)]={key:{'mean':statistics.mean(r[key] for r in rows),'sample_sd':statistics.stdev(r[key] for r in rows),'n':3}
                           for key in ('accuracy_pct','hard_accuracy_pct')}
    write(out/'test_summary.json',{'rows':test,'plan_id':identity(plan),'KD_Gain_paired':paired,'Student_groups':groups,
          'uncertainty':'3 Student seed sample SD conditional on one source/split, not CI',
          'scope':'Frozen pruning ratio comparison; no size-only or latency claim'})
    result={'state':'complete','dataset':dataset,'frozen_contract_id':contract['contract_id'],'plan_id':identity(plan),
            'recovery_Teachers':4,'KD_Students':12,'read_only_Native_baselines':3,'Test_used_for_selection':False}
    write(out/'EVALUATION_COMPLETE.json',result);return result
