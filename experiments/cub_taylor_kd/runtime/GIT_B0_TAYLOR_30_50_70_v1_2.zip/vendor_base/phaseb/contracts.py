"""Keep Native inputs/recipes unchanged while separating recovery, KD and freeze gates."""
from pathlib import Path
from .io import identity,read,sha
from .native import ROOT,config,module,parent

DATASETS=('cub200','flowers102','aircraft')
RATIOS=(0.0,0.3,0.5,0.7)
SEEDS=(42,43,44)
NAMESPACE='teamnative_base_pruning_v1'
WORK_NAME='TeacherCompressionKD_TeamNative_Base_v1'

def output_root(work):
    path=Path(work).expanduser().resolve()
    if path.name!='results' or path.parent.name!=WORK_NAME:
        raise ValueError('Use the explicit separate TeamNative pruning result root')
    if path.is_relative_to(ROOT) or ROOT.is_relative_to(path):raise ValueError('Source and result roots overlap')
    return path

def build_contract(policy,source_pins,code_id):
    if policy['datasets']!=list(DATASETS) or policy['ratios']!=list(RATIOS) or policy['student_seeds']!=list(SEEDS):
        raise ValueError('Frozen dataset/ratio/seed grid changed')
    if policy['recovery_epochs']!=20 or policy['student_epochs']!=60 or policy['Hard_anchor']!='Native Base validation frozen':
        raise ValueError('Recovery budget or Hard anchor changed')
    if source_pins.get('state')!='passed' or set(source_pins['datasets'])!=set(DATASETS):raise ValueError('Source pins require actual passed all3 datasets')
    expected=read(ROOT/'configs/readonly_inputs.json')['datasets']
    for dataset in DATASETS:
        pin=source_pins['datasets'][dataset]
        if not pin.get('raw_sha256') or len(pin['raw_sha256'])!=64 or pin.get('actual_bytes_verified') is not True:
            raise ValueError('Actual dense source raw SHA not verified: '+dataset)
        if pin['native_config_id']!=identity(config(dataset)):
            raise ValueError('Native recipe changed')
        if pin['base_reference']['model_spec'].get('teacher_size')!='base':raise ValueError('Source must be Native Base')
        if pin['base_reference']!=expected[dataset]['base_reference'] or pin['split_id']!=expected[dataset]['split_id']:
            raise ValueError('Source/reference split identity changed')
        ref=pin['source_reference']
        if (ref['sha256']!=pin['raw_sha256'] or ref['model_digest']!=pin['base_reference']['model_digest']
            or ref['contract_id']!=pin['base_reference']['contract_id'] or ref['path']!=pin['base_reference']['path']
            or pin['classes_id']!=expected[dataset]['classes_id']):raise ValueError('Actual source pin differs from independent Native reference')
        if len(pin['branches'])!=4 or [b['ratio'] for b in pin['branches']]!=list(RATIOS) or not all(b['strict_restore'] for b in pin['branches']):
            raise ValueError('Actual source compact restore gate missing')
    value={'schema_version':1,'namespace':NAMESPACE,'code_id':code_id,'policy':policy,'source_pins':source_pins}
    value['contract_id']=identity(value)
    return value

def verify_contract(contract,code_id):
    raw={k:v for k,v in contract.items() if k!='contract_id'}
    if identity(raw)!=contract['contract_id'] or contract['code_id']!=code_id:raise ValueError('Frozen contract identity changed')
    if build_contract(contract['policy'],contract['source_pins'],code_id)!=contract:raise ValueError('Frozen contract payload differs')

def native_context(dataset,native_results):
    # Read-only source metadata only; does not create a Native/B1 context or write their outputs.
    base=Path(native_results).resolve()
    expected=parent()[0].PROFILES[dataset]['result_parent']
    if base.name!='results' or base.parent.name!=expected:raise ValueError('Wrong NEW Native source root')
    manifest=read(base/'data'/dataset/'splits.json')
    experiment=read(base/'main'/dataset/'experiment.json')
    if identity(experiment)!=identity(config(dataset)):raise ValueError('Native config mismatch')
    return manifest

def job_contract(contract,dataset,stage,ratio,seed,source):
    if dataset not in DATASETS or isinstance(ratio,bool) or ratio not in RATIOS or type(seed)is not int:raise ValueError('Job outside frozen grid')
    return {'schema_version':1,'namespace':NAMESPACE,'frozen_contract_id':contract['contract_id'],
            'job':f'{dataset}/{stage}_r{round(ratio*100):02d}','seed':seed,
            'config':config(dataset),'split_id':contract['source_pins']['datasets'][dataset]['split_id'],
            'source':source,'phaseb_code_id':contract['code_id']}

def require_precision_receipt(receipt,contract,phase):
    expected_precision={'AMP':'cuda_autocast_float16'}.get(contract['policy']['KD_Teacher_precision'])
    if (receipt.get('status')!='PASS' or receipt.get('kind')!='phaseb_cuda_amp_full_coverage'
        or receipt.get('evidence_kind')!='actual_cuda_l4_probe'
        or receipt.get('frozen_contract_id')!=contract['contract_id'] or receipt.get('phase_label')!=phase
        or expected_precision is None or receipt.get('teacher_precision')!=expected_precision
        or {c.get('dataset') for c in receipt.get('coverage',[])}!=set(DATASETS)
        or len(receipt.get('role_rows',[]))<216):
        raise ValueError('Actual CUDA precision gate is missing or incompatible')
