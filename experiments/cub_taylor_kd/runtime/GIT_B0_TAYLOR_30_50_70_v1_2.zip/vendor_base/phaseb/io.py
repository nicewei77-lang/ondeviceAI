"""Small metadata identities compatible with the frozen Native engine."""
import hashlib
import json
from pathlib import Path

def identity(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def read(path):return json.loads(Path(path).read_text('utf8'))
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8');tmp.replace(path)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def verify_code(root):
    root=Path(root);frozen=read(root/'FROZEN_SOURCE.json')
    for name,wanted in frozen['sha256'].items():
        path=(root/name).resolve()
        if not path.is_relative_to(root.resolve()) or sha(path)!=wanted:raise ValueError('Preparation source changed: '+name)
    if identity(frozen['sha256'])!=frozen['code_id']:raise ValueError('Invalid code manifest')
    return frozen['code_id']
