"""Team Native anchored physical pruning wrappers; original trainers remain frozen."""
