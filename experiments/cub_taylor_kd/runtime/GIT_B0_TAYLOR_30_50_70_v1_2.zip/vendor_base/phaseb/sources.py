"""Actual source-byte inspection on an already mounted runtime; no training or GPU allocation."""
import gc
from pathlib import Path
import torch
from .adapter import load_native_source,strict_restore_compact
from .contracts import DATASETS,RATIOS,output_root
from .io import identity,read,write,sha
from .native import ROOT,config,module,legacy

def inspect_sources(work,*,path_map=None,verify_zero_output=True):
    work=output_root(work);pins=read(ROOT/'configs/readonly_inputs.json');result={}
    for dataset in DATASETS:
        pin=pins['datasets'][dataset];canonical=pin['base_reference']['path']
        path=Path(path_map[canonical] if path_map and canonical in path_map else canonical).resolve()
        if not path.is_file():raise FileNotFoundError('Actual Native Base source file is unavailable: '+str(path))
        if path.stat().st_size!=int(pin['source_metadata']['size']):raise ValueError('Native Base byte size changed')
        manifest=read(ROOT/pin['reference_manifest'])
        mapped=lambda value:Path(path_map.get(str(value),str(value)) if path_map else value)
        native_root=Path(pin['native_results'])
        if read(mapped(native_root/'data'/dataset/'splits.json'))!=manifest:raise ValueError('Native ordered source manifest changed')
        if identity(read(mapped(native_root/'main'/dataset/'experiment.json')))!=pin['native_config_id']:raise ValueError('Native source recipe changed')
        if identity(read(mapped(pin['hard_set']['path'])))!=pin['hard_set']['identity']:raise ValueError('Native Hard anchor changed')
        native_io=module(dataset,'io')
        observed_sha=sha(path)
        # New raw SHA registration is anchored to previously independently pinned tensor/contract identities.
        source=load_native_source(path,expected_sha256=observed_sha,
          expected_model_digest=pin['base_reference']['model_digest'],expected_contract=pin['expected_full_native_contract'],
          manifest=manifest,expected_classes=manifest['classes'],native_io=native_io,reference_path=canonical)
        branches=[]
        model_forward_calls=0
        for ratio in RATIOS:
            model,spec,provenance=source.prune(ratio,compression_models=legacy('models'),compression_pruning=legacy('pruning'))
            state=model.state_dict();digest=native_io.model_state_identity(state)
            saved={'model_state':state,'model_spec':spec,'model_digest':digest,'adapter_provenance':provenance}
            restored=strict_restore_compact(saved,compression_models=legacy('models'),native_io=native_io,
              expected_source=source.reference,expected_ratio=ratio,expected_classes=manifest['classes'])
            if ratio==0 and digest!=pin['base_reference']['model_digest']:raise ValueError('r00 changed dense tensors')
            zero_output=None
            if ratio==0 and verify_zero_output:
                native_model=module(dataset,'models').build_from_spec(source.reference['model_spec'])
                native_model.load_state_dict(state,strict=True);native_model.eval();model.eval()
                with torch.inference_mode():
                    image=torch.zeros(1,3,224,224,dtype=torch.float32)
                    expected=native_model(image);actual=model(image)
                    if not torch.isfinite(expected).all() or not torch.equal(expected,actual):raise ValueError('r00 Native/tckd CPU output differs')
                zero_output=True;model_forward_calls+=2;del native_model,expected,actual,image
            branches.append({'ratio':ratio,'model_spec_id':identity(spec),'layout_id':identity(spec['pruning_layout']),
                             'retained_hidden':[r['hidden'] for r in spec['pruning_layout']],
                             'initial_compact_digest':digest,
                             'parameters':sum(p.numel() for p in model.parameters()),'strict_restore':True,
                             'zero_percent_identity':digest==pin['base_reference']['model_digest'] if ratio==0 else None,
                             'zero_percent_synthetic_CPU_output_equal':zero_output})
            del restored,saved,state,model;gc.collect()
        initial_receipts={}
        for seed in (42,43,44):
            ref=pin['initializations'][str(seed)];ipath=Path(path_map.get(ref['path'],ref['path']) if path_map else ref['path'])
            saved=native_io.checkpoint_read(ipath)
            if native_io.model_state_identity(saved['model_state'])!=ref['model_digest'] or native_io.identity(saved['contract'])!=ref['contract_id']:
                raise ValueError('Native Student initialization changed')
            student=module(dataset,'models').build_from_spec(saved['model_spec']);student.load_state_dict(saved['model_state'],strict=True)
            initial_receipts[str(seed)]={'path':ref['path'],'raw_sha256':sha(ipath),'model_digest':ref['model_digest'],
                                         'contract_id':ref['contract_id'],'strict_restore':True}
            del saved,student;gc.collect()
        result[dataset]={'dataset':dataset,'actual_bytes_verified':True,'raw_sha256':observed_sha,
          'source_reference':source.reference,'base_reference':pin['base_reference'],'native_config_id':pin['native_config_id'],
          'split_id':pin['split_id'],'classes_id':pin['classes_id'],'manifest_sha256':pin['manifest_sha256'],
          'initializations':initial_receipts,'branches':branches,'source_original_files_written':0,
          'model_forward_calls':model_forward_calls,'forward_scope':'Synthetic zero RGB224 CPU input only; no actual image inference',
          'recovery_or_student_training_calls':0,'CUDA_AMP_verified':False}
        del source;gc.collect()
    record={'state':'passed','datasets':result,'scope':'Actual CPU source bytes/tensor/compact strict restore and r00 synthetic CPU equality; CUDA precision remains a separate gate'}
    destination=work/'preparation/source_pins.json'
    if destination.exists():
        if read(destination)!=record:raise ValueError('Previously registered actual source pins differ')
    else:write(destination,record)
    return record

def load_source(dataset,contract):
    pin=read(ROOT/'configs/readonly_inputs.json')['datasets'][dataset]
    actual=contract['source_pins']['datasets'][dataset]
    manifest=read(ROOT/pin['reference_manifest'])
    return load_native_source(pin['base_reference']['path'],expected_sha256=actual['raw_sha256'],
       expected_model_digest=pin['base_reference']['model_digest'],expected_contract=pin['expected_full_native_contract'],
       manifest=manifest,expected_classes=manifest['classes'],native_io=module(dataset,'io'),reference_path=pin['base_reference']['path'])
