"""Strict Native Base -> existing tckd physical-pruning bridge.

No training loop or pruning score is implemented here. Callers supply the
frozen Native ``io`` module and existing tckd ``models``/``pruning`` modules.
``expected_*`` values must come from independently frozen references, not from
the checkpoint currently being checked. Source bytes are read only once and
loaded from those same bytes, avoiding a hash/load file replacement race.

Public API::

    source = load_native_source(path, expected_sha256=..., expected_model_digest=...,
        expected_contract=..., manifest=..., expected_classes=..., native_io=...)
    model, spec, provenance = source.prune(.3, compression_models=...,
                                         compression_pruning=...)
    # Pass spec unchanged to the frozen Native fit function. Store provenance in
    # contract['source']['adapter_provenance'] for every recovery checkpoint.
    restored = strict_restore_compact(saved, compression_models=..., native_io=...,
        expected_source=source.reference, expected_ratio=.3, expected_classes=...)

``allow_test_fixture=True`` enables only the separate small random architecture;
fixture success establishes neither pretrained correctness nor CUDA/AMP safety.
"""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_CEILING
import hashlib
import io
import math
from numbers import Real
from pathlib import Path
from typing import Any

import torch


UPSTREAM_COMMIT = "6876159a11b4df116f30f667f8c9888617df0751"
BASE_DEPTHS, BASE_DIMS = [3, 3, 27, 3], [128, 256, 512, 1024]
TEST_DEPTHS, TEST_DIMS = [1, 1, 1, 1], [8, 16, 24, 32]
RATIOS = (0.0, 0.3, 0.5, 0.7)


def _digest(value: str, name: str) -> str:
    if (not isinstance(value, str) or len(value) != 64
            or any(character not in "0123456789abcdef" for character in value)):
        raise ValueError(f"{name} must be a lowercase SHA-256 digest")
    return value


def _classes(value: Any) -> list[dict[str, Any]]:
    if (not isinstance(value, list) or len(value) < 2
            or any(not isinstance(row, dict) or set(row) != {"label", "name"}
                   or type(row["label"]) is not int
                   or not isinstance(row["name"], str) or not row["name"] for row in value)
            or [row["label"] for row in value] != list(range(len(value)))
            or len({row["name"] for row in value}) != len(value)):
        raise ValueError("classes must preserve unique names and contiguous ordered integer labels")
    return deepcopy(value)


def _ratio(ratio: float) -> float:
    if (isinstance(ratio, bool) or not isinstance(ratio, Real)
            or not math.isfinite(ratio) or ratio not in RATIOS):
        raise ValueError("ratio must be one frozen branch: 0, .3, .5, .7")
    return float(ratio)


def native_to_dense_spec(native_spec: Mapping[str, Any], *, num_classes: int,
                         allow_test_fixture: bool = False) -> dict[str, Any]:
    """Translate only the exact frozen Native Base (or explicit fixture) spec."""
    if type(allow_test_fixture) is not bool:
        raise ValueError("allow_test_fixture must be a boolean")
    if type(num_classes) is not int or num_classes < 2:
        raise ValueError("num_classes must be an integer of at least two")
    fixture = isinstance(native_spec, Mapping) and native_spec.get("test_fixture") is True
    if fixture and not allow_test_fixture:
        raise ValueError("random fixtures are forbidden for research source checkpoints")
    depths, dims = (TEST_DEPTHS, TEST_DIMS) if fixture else (BASE_DEPTHS, BASE_DIMS)
    expected = {"schema_version": 1, "kind": "teacher",
                "architecture": "convnext_test_fixture" if fixture else "dinov3_convnext",
                "teacher_size": None if fixture else "base", "num_classes": num_classes,
                "depths": depths, "dims": dims, "upstream_commit": UPSTREAM_COMMIT,
                "test_fixture": fixture}
    if not isinstance(native_spec, Mapping) or dict(native_spec) != expected:
        raise ValueError("source must be the exact uncompressed Native Base specification")
    # Equality alone would allow bool == 1 in schema/dimension/class fields.
    if (type(native_spec["schema_version"]) is not int
            or type(native_spec["num_classes"]) is not int
            or type(native_spec["test_fixture"]) is not bool
            or any(type(n) is not int for n in native_spec["depths"] + native_spec["dims"])):
        raise ValueError("native specification dimensions/schema have invalid types")
    return {"schema_version": 1, "kind": "teacher",
            "architecture": "test_convnext" if fixture else "dinov3_convnext_base",
            "num_classes": num_classes, "depths": list(depths), "dims": list(dims),
            "upstream_commit": UPSTREAM_COMMIT, "pruning_layout": None}


def _norm_aliases(state: Mapping[str, torch.Tensor]) -> None:
    for suffix in ("weight", "bias"):
        first, second = f"norm.{suffix}", f"norms.3.{suffix}"
        if first not in state or second not in state:
            raise ValueError("both shared final-norm aliases must be present")
        a, b = state[first], state[second]
        if (not isinstance(a, torch.Tensor) or not isinstance(b, torch.Tensor)
                or a.dtype != b.dtype or a.shape != b.shape or not torch.equal(a, b)):
            raise ValueError("conflicting shared final-norm checkpoint aliases")


def _strict_load(model, state: Mapping[str, torch.Tensor]) -> None:
    if not isinstance(state, Mapping):
        raise ValueError("model_state must be a tensor mapping")
    _norm_aliases(state)
    target = model.state_dict()
    if set(target) != set(state):
        raise ValueError("state keys do not exactly match the reconstructed architecture")
    for name, tensor in state.items():
        if (not isinstance(tensor, torch.Tensor) or tensor.shape != target[name].shape
                or tensor.dtype != target[name].dtype or tensor.layout != torch.strided):
            raise ValueError(f"state shape/dtype/layout differs: {name}")
    model.load_state_dict(state, strict=True)


def _validate_layout(spec, ratio, dense_spec) -> None:
    expected = {**deepcopy(dense_spec), "pruning_layout": spec.get("pruning_layout")}
    if spec != expected:
        raise ValueError("compact specification changed architecture/classes/upstream")
    layout = spec.get("pruning_layout")
    if not isinstance(layout, list) or len(layout) != sum(dense_spec["depths"]):
        raise ValueError("compact specification must identify every block")
    for entry, (stage, block, dim) in zip(layout, (
            (stage, block, dim) for stage, (depth, dim) in enumerate(
                zip(dense_spec["depths"], dense_spec["dims"])) for block in range(depth))):
        hidden = int((Decimal(4 * dim) * (1 - Decimal(str(ratio)))).to_integral_value(rounding=ROUND_CEILING))
        if (not isinstance(entry, dict) or entry.get("stage") != stage or entry.get("block") != block
                or entry.get("original_hidden") != 4 * dim or entry.get("hidden") != hidden):
            raise ValueError("compact layout does not match the frozen ratio or block order")
        if ratio == 0 and entry.get("retained_indices") != list(range(4 * dim)):
            raise ValueError("zero-percent branch must retain all original channels in order")


@dataclass
class VerifiedNativeSource:
    """One verified dense source; each ratio is independently rebuilt from it.

    The private state is rehashed before every branch so accidental in-memory
    source mutation cannot turn later ratios into cumulative pruning.
    """

    _checkpoint: dict[str, Any] = field(repr=False)
    _reference: dict[str, Any] = field(repr=False)
    _dense_spec: dict[str, Any] = field(repr=False)
    _classes: list[dict[str, Any]] = field(repr=False)
    _native_io: Any = field(repr=False)

    @property
    def reference(self):
        return deepcopy(self._reference)

    def prune(self, ratio: float, *, compression_models, compression_pruning):
        """Call the existing tckd factory and L1 surgery; never mutate the source."""
        ratio = _ratio(ratio)
        state = self._checkpoint["model_state"]
        if self._native_io.model_state_identity(state) != self._reference["model_digest"]:
            raise ValueError("verified dense source was mutated before branch creation")
        if (self._native_io.identity(self._checkpoint["model_spec"])
                != self._reference["native_spec_id"]
                or self._native_io.identity(self._checkpoint["contract"])
                != self._reference["contract_id"]):
            raise ValueError("verified source specification/contract was mutated")
        model = compression_models.build_from_spec(deepcopy(self._dense_spec))
        _strict_load(model, state)
        if self._native_io.model_state_identity(model.state_dict()) != self._reference["model_digest"]:
            raise ValueError("Native-to-tckd dense reconstruction changed source tensors")
        layout = compression_pruning.prune_hidden_channels(model, ratio)
        spec = compression_models.model_spec(model)
        _validate_layout(spec, ratio, self._dense_spec)
        if spec["pruning_layout"] != layout:
            raise ValueError("pruning implementation and compact specification disagree")
        compact_digest = self._native_io.model_state_identity(model.state_dict())
        if ratio == 0 and compact_digest != self._reference["model_digest"]:
            raise ValueError("zero-percent physical branch changed source tensors")
        provenance = {"schema_version": 1, "method": "tckd.prune_hidden_channels",
                      "ratio": ratio, "source": self.reference, "classes": deepcopy(self._classes),
                      "dense_spec": deepcopy(self._dense_spec), "compact_spec": deepcopy(spec),
                      "initial_compact_digest": compact_digest,
                      "test_fixture": self._reference["test_fixture"]}
        return model, spec, provenance


def load_native_source(path, *, expected_sha256: str, expected_model_digest: str,
                       expected_contract: Mapping[str, Any], manifest: Mapping[str, Any],
                       expected_classes: list[dict[str, Any]], native_io,
                       allow_test_fixture: bool = False,
                       reference_path: str | None = None) -> VerifiedNativeSource:
    """Verify pinned bytes, digest, exact contract, split/classes, and Native spec.

    The caller owns the completed-45-epoch status/selection-evidence gate. A
    validation-best checkpoint may have any selected epoch from zero through44;
    it must never be replaced with ``last.pt`` or a recovery checkpoint.
    ``reference_path`` preserves the frozen canonical Colab source path while
    ``path`` can point to the same-byte local download used for verification.
    """
    expected_sha256 = _digest(expected_sha256, "expected_sha256")
    expected_model_digest = _digest(expected_model_digest, "expected_model_digest")
    path = Path(path).expanduser().resolve()
    if path.name != "best.pt":
        raise ValueError("Native source must be the pinned validation-best best.pt")
    if reference_path is not None and (not isinstance(reference_path, str)
            or not reference_path or reference_path.replace("\\", "/").split("/")[-1] != "best.pt"):
        raise ValueError("reference_path must identify the canonical validation-best best.pt")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError("Native source checkpoint bytes differ from the frozen SHA-256")
    checkpoint = torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)
    del raw
    if not isinstance(checkpoint, dict):
        raise ValueError("Native source checkpoint must be a dictionary")
    classes = _classes(expected_classes)
    if (not isinstance(manifest, Mapping) or manifest.get("classes") != classes
            or type(manifest.get("num_classes")) is not int or manifest["num_classes"] != len(classes)):
        raise ValueError("source manifest class count/order differs from frozen class order")
    contract = checkpoint.get("contract")
    if (not isinstance(expected_contract, Mapping) or not isinstance(contract, Mapping)
            or native_io.identity(contract) != native_io.identity(expected_contract)):
        raise ValueError("Native source contract differs from the frozen expected contract")
    if (contract.get("split_id") != native_io.identity(manifest)
            or contract.get("job") != f"{manifest.get('dataset')}/teacher_base"
            or contract.get("config", {}).get("dataset") != manifest.get("dataset")
            or contract.get("config", {}).get("num_classes") != len(classes)):
        raise ValueError("Native source dataset/split/classes/Base job contract differs")
    if type(checkpoint.get("epoch")) is not int or not 0 <= checkpoint["epoch"] < 45:
        raise ValueError("source selected epoch must belong to the 45-epoch Native run")
    dense_spec = native_to_dense_spec(checkpoint.get("model_spec"), num_classes=len(classes),
                                     allow_test_fixture=allow_test_fixture)
    state = checkpoint.get("model_state")
    if not isinstance(state, Mapping):
        raise ValueError("Native source has no model tensor mapping")
    _norm_aliases(state)
    if (checkpoint.get("model_digest") != expected_model_digest
            or native_io.model_state_identity(state) != expected_model_digest):
        raise ValueError("Native source model-state digest differs")
    reference = {"path": reference_path if reference_path is not None else str(path),
                 "sha256": expected_sha256, "model_digest": expected_model_digest,
                 "contract_id": native_io.identity(contract), "split_id": contract["split_id"],
                 "classes_id": native_io.identity(classes), "epoch": checkpoint["epoch"],
                 "model_spec": deepcopy(checkpoint["model_spec"]),
                 "native_spec_id": native_io.identity(checkpoint["model_spec"]),
                 "test_fixture": checkpoint["model_spec"]["test_fixture"]}
    return VerifiedNativeSource(checkpoint, reference, dense_spec, classes, native_io)


def strict_restore_compact(checkpoint: Mapping[str, Any], *, compression_models, native_io,
                           expected_source: Mapping[str, Any], expected_ratio: float,
                           expected_classes: list[dict[str, Any]], allow_test_fixture: bool = False):
    """Rebuild compact dimensions with tckd, then load exact state keys/shapes/dtypes.

    Accept provenance either at top level (initial surgery artifact) or inside
    ``contract.source.adapter_provenance`` (unmodified Native fit checkpoints).
    Current model_digest is checked independently from the pre-recovery digest.
    """
    ratio, classes = _ratio(expected_ratio), _classes(expected_classes)
    if not isinstance(checkpoint, Mapping):
        raise ValueError("compact checkpoint must be a mapping")
    provenance = checkpoint.get("adapter_provenance")
    if provenance is None:
        provenance = checkpoint.get("contract", {}).get("source", {}).get("adapter_provenance")
    if (not isinstance(provenance, Mapping) or provenance.get("schema_version") != 1
            or provenance.get("method") != "tckd.prune_hidden_channels"
            or provenance.get("source") != dict(expected_source)
            or provenance.get("classes") != classes or provenance.get("ratio") != ratio
            or type(provenance.get("ratio")) not in (int, float)
            or type(provenance.get("test_fixture")) is not bool):
        raise ValueError("compact checkpoint source/ratio/class-order provenance differs")
    source_spec = expected_source.get("model_spec")
    dense_spec = native_to_dense_spec(source_spec, num_classes=len(classes),
                                     allow_test_fixture=allow_test_fixture)
    if (expected_source.get("classes_id") != native_io.identity(classes)
            or expected_source.get("native_spec_id") != native_io.identity(source_spec)
            or expected_source.get("test_fixture") != source_spec["test_fixture"]
            or provenance["test_fixture"] != source_spec["test_fixture"]
            or provenance.get("dense_spec") != dense_spec):
        raise ValueError("compact checkpoint source architecture/class identity differs")
    spec = checkpoint.get("model_spec")
    if not isinstance(spec, Mapping) or provenance.get("compact_spec") != spec:
        raise ValueError("compact checkpoint model specification differs from surgery provenance")
    _validate_layout(spec, ratio, dense_spec)
    _digest(provenance.get("initial_compact_digest"), "initial_compact_digest")
    state = checkpoint.get("model_state")
    if (not isinstance(state, Mapping)
            or native_io.model_state_identity(state) != checkpoint.get("model_digest")):
        raise ValueError("compact checkpoint tensor digest differs")
    model = compression_models.build_from_spec(deepcopy(dict(spec)))
    _strict_load(model, state)
    if native_io.model_state_identity(model.state_dict()) != checkpoint["model_digest"]:
        raise ValueError("compact reconstruction changed checkpoint tensor contents")
    return model
