"""Immutable two-runtime partition and fail-closed local writer leases.

Safety does NOT depend on Google Drive exclusive-create, rename, or flock being
atomic across clients. A frozen assignment gives every job exactly one slot;
each slot is bound to one OS runtime fingerprint before execution. A kernel lock
in a *local* cache serializes that runtime's processes. Shared owner receipts are
consistency evidence, not a distributed lock. Do not copy a slot's binding to a
different runtime or allow a caller to invent its own runtime fingerprint.

Freeze may run without runtime bindings: that produces prepared_not_executable.
Version 1 deliberately rejects ownership transfer and generation > 1. A reboot,
reprovision, or ambiguous recovery requires an explicit new protocol including
old-writer-dead evidence; this module never guesses that a remote writer died.
Only paths returned by a live lease may be passed to training/output code.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import platform
import re
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Iterable, Iterator, Mapping


SCHEMA = "phaseb.ownership.v1"
_SLOTS = frozenset({"A", "B"})
_FINAL_STAGES = frozenset({"aggregate", "finalizer"})
_NAME = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")


class OwnershipError(RuntimeError):
    """An assignment, writer identity, source, or path failed a safety guard."""


def _canonical(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"), allow_nan=False)
    except (ValueError, TypeError) as exc:
        raise OwnershipError("ownership data must be canonical JSON") from exc


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise OwnershipError(f"{name} must be a nonempty string")
    return value


def _root_string(value: str | Path) -> str:
    text = str(value)
    # Preserve a Colab absolute path when preparing its assignment on Windows.
    path = PureWindowsPath(text) if PureWindowsPath(text).is_absolute() else PurePosixPath(text)
    if not path.is_absolute() or ".." in path.parts:
        raise OwnershipError("output/source path must be absolute and contain no '..'")
    return path.as_posix()


def _runtime_path(value: str | Path) -> Path:
    text = str(value)
    if os.name == "nt" and not PureWindowsPath(text).is_absolute():
        raise OwnershipError("POSIX output/source path cannot execute on Windows")
    if os.name != "nt" and PureWindowsPath(text).is_absolute():
        raise OwnershipError("Windows output/source path cannot execute on POSIX")
    return Path(text).resolve()


@dataclass(frozen=True, order=True)
class JobKey:
    dataset: str
    stage: str
    ratio: int | None
    seed: int | None

    def __post_init__(self) -> None:
        for label, value in (("dataset", self.dataset), ("stage", self.stage)):
            if not isinstance(value, str) or not _NAME.fullmatch(value):
                raise OwnershipError(f"invalid {label} in job key")
        if self.stage in _FINAL_STAGES:
            if self.ratio is not None or self.seed is not None:
                raise OwnershipError("aggregate/finalizer job requires ratio=None, seed=None")
        elif (type(self.ratio) is not int or not 0 <= self.ratio <= 100
              or type(self.seed) is not int or self.seed < 0):
            raise OwnershipError("training job requires integer percent ratio and nonnegative seed")

    @property
    def job_id(self) -> str:
        ratio = "none" if self.ratio is None else f"{self.ratio:02d}"
        seed = "none" if self.seed is None else str(self.seed)
        return f"{self.dataset}__{self.stage}__r{ratio}__s{seed}"

    def to_dict(self) -> dict[str, Any]:
        return {"dataset": self.dataset, "stage": self.stage,
                "ratio": self.ratio, "seed": self.seed}

    @classmethod
    def from_value(cls, value: JobKey | Mapping[str, Any]) -> JobKey:
        if isinstance(value, cls):
            return value
        if not isinstance(value, Mapping) or set(value) != {"dataset", "stage", "ratio", "seed"}:
            raise OwnershipError("job key must contain exactly dataset, stage, ratio, seed")
        return cls(**dict(value))


def _jobs(values: Iterable[JobKey | Mapping[str, Any]]) -> dict[str, JobKey]:
    result: dict[str, JobKey] = {}
    for value in values:
        job = JobKey.from_value(value)
        if job.job_id in result:
            raise OwnershipError(f"duplicate job: {job.job_id}")
        result[job.job_id] = job
    if not result:
        raise OwnershipError("empty job grid")
    return result


def _payload(assignment: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in assignment.items() if key != "assignment_id"}


def freeze_assignment(
    jobs: Iterable[JobKey | Mapping[str, Any]],
    assignments: Mapping[JobKey | str, str],
    *,
    frozen_contract_id: str,
    source_ids: Mapping[str, Any],
    output_root: str | Path,
    slot_owners: Mapping[str, Mapping[str, str]] | None = None,
    source_receipts: Iterable[Mapping[str, str]] = (),
    readonly_roots: Iterable[str | Path] = (),
    local_lock_root: str | Path = "/content/phaseb-local-locks",
    generation: int = 1,
) -> dict[str, Any]:
    """Create JSON-serializable prepared assignment; never creates output files.

    assignments maps JobKey (or job_id) to A/B. slot_owners, when available, maps
    each used slot to {runtime_id, owner_token}. Only the token digest is stored.
    source_receipts are small frozen guard files {path, sha256}; full checkpoint
    identity must additionally be verified by the adapter through source_ids.
    The caller must pin the returned assignment_id in its frozen manifest.
    """
    grid = _jobs(jobs)
    partition: dict[str, str] = {}
    for key, slot in assignments.items():
        job_id = key.job_id if isinstance(key, JobKey) else key
        if job_id in partition:
            raise OwnershipError(f"duplicate assignment: {job_id}")
        if job_id not in grid:
            raise OwnershipError(f"unknown assigned job: {job_id}")
        if slot not in _SLOTS:
            raise OwnershipError("only slots A and B are supported")
        if grid[job_id].stage in _FINAL_STAGES and slot != "A":
            raise OwnershipError("aggregate/finalizer must belong to slot A")
        partition[job_id] = slot
    if set(partition) != set(grid):
        raise OwnershipError("every frozen job needs exactly one slot")
    slots = sorted(set(partition.values()))
    owners: dict[str, Any] = {}
    if slot_owners is not None:
        if set(slot_owners) != set(slots):
            raise OwnershipError("bind exactly all used slots; partial runtime binding is forbidden")
        for slot, owner in slot_owners.items():
            if set(owner) != {"runtime_id", "owner_token"}:
                raise OwnershipError("slot owner requires runtime_id and owner_token")
            owners[slot] = {
                "runtime_id": _text(owner["runtime_id"], "runtime_id"),
                "owner_token_sha256": hashlib.sha256(
                    _text(owner["owner_token"], "owner_token").encode("utf-8")).hexdigest(),
            }
        if len({owner["runtime_id"] for owner in owners.values()}) != len(owners):
            raise OwnershipError("different slots must bind distinct OS runtimes")
    receipts = []
    for receipt in source_receipts:
        if not isinstance(receipt, Mapping) or set(receipt) != {"path", "sha256"}:
            raise OwnershipError("invalid source receipt guard")
        receipts.append({"path": _root_string(receipt["path"]), "sha256": receipt["sha256"]})
    result = {
        "schema": SCHEMA, "generation": generation,
        "state": "executable" if owners else "prepared_not_executable",
        "frozen_contract_id": _text(frozen_contract_id, "frozen_contract_id"),
        "source_ids": json.loads(_canonical(dict(source_ids))),
        "output_root": _root_string(output_root),
        "local_lock_root": _root_string(local_lock_root),
        "readonly_roots": sorted({_root_string(path) for path in readonly_roots}),
        "source_receipts": sorted(receipts, key=lambda item: item["path"]),
        "slots": slots, "slot_owners": owners,
        "jobs": [{"job_id": job_id, "key": grid[job_id].to_dict(), "slot": partition[job_id]}
                 for job_id in sorted(grid)],
    }
    result["assignment_id"] = _digest(result)
    validate_assignment(result, expected_contract_id=frozen_contract_id,
                        expected_source_ids=source_ids, expected_jobs=grid.values(),
                        expected_assignment_id=result["assignment_id"])
    return result


def validate_assignment(
    assignment: Mapping[str, Any], *, expected_contract_id: str,
    expected_source_ids: Mapping[str, Any],
    expected_jobs: Iterable[JobKey | Mapping[str, Any]],
    expected_assignment_id: str,
) -> dict[str, JobKey]:
    """Validate a frozen assignment against separately pinned contract/grid/ID."""
    required = {"schema", "generation", "state", "frozen_contract_id", "source_ids",
                "output_root", "local_lock_root", "readonly_roots", "source_receipts", "slots", "slot_owners",
                "jobs", "assignment_id"}
    if not isinstance(assignment, Mapping) or set(assignment) != required:
        raise OwnershipError("ownership assignment schema mismatch")
    if assignment["schema"] != SCHEMA or type(assignment["generation"]) is not int or assignment["generation"] != 1:
        raise OwnershipError("ownership transfer/generation changes are unsupported; fail closed")
    if (assignment["assignment_id"] != expected_assignment_id
            or assignment["assignment_id"] != _digest(_payload(assignment))):
        raise OwnershipError("frozen assignment identity changed")
    if assignment["frozen_contract_id"] != expected_contract_id:
        raise OwnershipError("frozen contract identity changed")
    if not assignment["source_ids"] or _canonical(assignment["source_ids"]) != _canonical(dict(expected_source_ids)):
        raise OwnershipError("source identity changed or missing")
    grid = _jobs(expected_jobs)
    observed: dict[str, JobKey] = {}
    observed_slots: set[str] = set()
    if not isinstance(assignment["jobs"], list):
        raise OwnershipError("jobs must be a list")
    for record in assignment["jobs"]:
        if not isinstance(record, Mapping) or set(record) != {"job_id", "key", "slot"}:
            raise OwnershipError("invalid assignment record")
        job = JobKey.from_value(record["key"])
        job_id, slot = record["job_id"], record["slot"]
        if job_id != job.job_id or job_id not in grid or grid[job_id] != job:
            raise OwnershipError("unknown or altered job key")
        if job_id in observed:
            raise OwnershipError("duplicate job assignment")
        if slot not in _SLOTS:
            raise OwnershipError("only slots A and B are supported")
        if job.stage in _FINAL_STAGES and slot != "A":
            raise OwnershipError("aggregate/finalizer must belong to slot A")
        observed[job_id] = job
        observed_slots.add(slot)
    if set(observed) != set(grid):
        raise OwnershipError("assignment does not cover the exact frozen grid")
    if assignment["slots"] != sorted(observed_slots) or len(observed_slots) > 2:
        raise OwnershipError("invalid runtime slot list")
    owners = assignment["slot_owners"]
    if not isinstance(owners, Mapping):
        raise OwnershipError("invalid slot owner bindings")
    if owners:
        if assignment["state"] != "executable" or set(owners) != observed_slots:
            raise OwnershipError("incomplete runtime bindings")
        runtime_ids = []
        for owner in owners.values():
            if not isinstance(owner, Mapping) or set(owner) != {"runtime_id", "owner_token_sha256"}:
                raise OwnershipError("invalid runtime owner binding")
            runtime_ids.append(_text(owner["runtime_id"], "runtime_id"))
            if not isinstance(owner["owner_token_sha256"], str) or not _SHA256.fullmatch(owner["owner_token_sha256"]):
                raise OwnershipError("invalid owner token digest")
        if len(set(runtime_ids)) != len(runtime_ids):
            raise OwnershipError("different slots must bind distinct OS runtimes")
    elif assignment["state"] != "prepared_not_executable":
        raise OwnershipError("unbound assignment must remain prepared_not_executable")
    if _root_string(assignment["output_root"]) != assignment["output_root"]:
        raise OwnershipError("output root is not canonical")
    if _root_string(assignment["local_lock_root"]) != assignment["local_lock_root"]:
        raise OwnershipError("local process-lock root is not canonical")
    for root in assignment["readonly_roots"]:
        _root_string(root)
    seen_receipts = set()
    for receipt in assignment["source_receipts"]:
        if not isinstance(receipt, Mapping) or set(receipt) != {"path", "sha256"}:
            raise OwnershipError("invalid source receipt guard")
        path = _root_string(receipt["path"])
        if path in seen_receipts or not isinstance(receipt["sha256"], str) or not _SHA256.fullmatch(receipt["sha256"]):
            raise OwnershipError("duplicate or invalid source receipt guard")
        seen_receipts.add(path)
    return observed


def current_runtime_id() -> str:
    """Read an OS boot identity, independent of caller-provided labels/tokens.

    Linux/Colab uses kernel boot_id. Windows local verification uses the kernel
    boot timestamp and hostname. Unknown platforms fail instead of falling back
    to a user-supplied hostname/environment variable. This is an accidental-run
    guard for cooperative clients, not authentication against malicious code.
    """
    if os.name == "posix":
        try:
            boot = Path("/proc/sys/kernel/random/boot_id").read_text(encoding="ascii").strip()
        except OSError as exc:
            raise OwnershipError("cannot establish local kernel boot identity") from exc
    elif os.name == "nt":
        try:
            import ctypes
            query = ctypes.WinDLL("ntdll").NtQuerySystemInformation
            query.argtypes = [ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong,
                              ctypes.POINTER(ctypes.c_ulong)]
            query.restype = ctypes.c_long
            size = ctypes.c_ulong()
            # SYSTEM_TIMEOFDAY_INFORMATION (3) begins with LARGE_INTEGER BootTime.
            # Ask the kernel for its exact size instead of assuming a struct ABI.
            probe = ctypes.create_string_buffer(256)
            query(3, probe, len(probe), ctypes.byref(size))
            if not 8 <= size.value <= 4096:
                raise OwnershipError("unexpected Windows boot-information size")
            buffer = ctypes.create_string_buffer(size.value)
            status = query(3, buffer, len(buffer), ctypes.byref(size))
            if status != 0:
                raise OwnershipError("Windows kernel boot-information query failed")
            timestamp = ctypes.c_longlong.from_buffer(buffer).value
            if timestamp <= 0:
                raise OwnershipError("invalid Windows boot timestamp")
            boot = str(timestamp)
        except (OSError, AttributeError) as exc:
            raise OwnershipError("cannot establish Windows OS boot identity") from exc
    else:
        raise OwnershipError("unsupported runtime identity platform")
    if not boot:
        raise OwnershipError("empty OS boot identity")
    return "runtime-" + _digest({"host": platform.node(), "os": os.name, "boot": boot})


def _within(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def _require_local_cache(path: Path, output_root: Path) -> None:
    if _within(path, output_root) or _within(output_root, path):
        raise OwnershipError("process lock cache must be separate from shared outputs")
    if os.name == "nt":
        import ctypes
        if ctypes.windll.kernel32.GetDriveTypeW(str(path.anchor)) not in (2, 3, 6):
            raise OwnershipError("process lock cache must be on a local drive")
    elif os.name == "posix":
        try:
            lines = Path("/proc/mounts").read_text(encoding="utf-8").splitlines()
        except OSError as exc:
            raise OwnershipError("cannot verify local process-lock filesystem") from exc
        matches = []
        for line in lines:
            fields = line.split()
            if len(fields) >= 3:
                mount = Path(fields[1].replace("\\040", " ")).resolve()
                if _within(path, mount):
                    matches.append((len(mount.parts), fields[2]))
        kind = max(matches)[1] if matches else ""
        if not kind or kind.startswith(("fuse", "nfs", "cifs", "smb", "9p", "davfs")):
            raise OwnershipError("process lock cache must use a local kernel filesystem")


@contextlib.contextmanager
def _process_lock(path: Path) -> Iterator[None]:
    """Local OS process lock; persistent inode is intentionally never unlinked."""
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = path.open("a+b")
    locked = False
    try:
        if os.name == "nt":
            import msvcrt
            if path.stat().st_size == 0:
                stream.write(b"0")
                stream.flush()
            stream.seek(0)
            try:
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise OwnershipError("slot/job already has a local writer") from exc
        else:
            import fcntl
            try:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise OwnershipError("slot/job already has a local writer") from exc
        locked = True
        yield
    finally:
        if locked:
            if os.name == "nt":
                import msvcrt
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()


def _write_receipt(path: Path, value: Mapping[str, Any]) -> None:
    # Called only by the unique frozen runtime while holding its local OS lock.
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        temporary.write_text(_canonical(value) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


class JobLease:
    """A live single-writer scope; complete() records caller completion only."""

    def __init__(self, guard: OwnershipGuard, key: JobKey, output_dir: Path,
                 receipt_path: Path, receipt: dict[str, Any]):
        self._guard = guard
        self.key = key
        self.output_dir = output_dir
        self._receipt_path = receipt_path
        self._receipt = receipt
        self._live = True

    def assert_active(self) -> None:
        if not self._live:
            raise OwnershipError("writer lease is no longer active")
        self._guard.verify_sources()
        observed = self._guard._read_receipt(self._receipt_path)
        if observed != self._receipt or observed["state"] != "running":
            raise OwnershipError("writer state/attempt changed")
        self._guard._check_path(self.output_dir)

    def assert_output_path(self, path: str | Path) -> Path:
        self.assert_active()
        resolved = Path(path).resolve()
        if not _within(resolved, self.output_dir):
            raise OwnershipError("output path escapes this job namespace")
        self._guard._check_path(resolved)
        return resolved

    def complete(self, receipt: Mapping[str, Any]) -> None:
        self.assert_active()
        self._receipt.update(state="complete", completion_receipt=json.loads(_canonical(dict(receipt))))
        _write_receipt(self._receipt_path, self._receipt)
        self._live = False


class OwnershipGuard:
    """Bind one caller to a pinned assignment and yield guarded job namespaces.

    Runtime identity is read locally, never accepted as an argument. The pipeline
    must recompute/check source_ids with its adapter, pin expected_assignment_id,
    and use with guard.claim(job) for the entire fit/finalization operation.
    """

    def __init__(self, assignment: Mapping[str, Any], slot: str, *,
                 expected_contract_id: str, expected_source_ids: Mapping[str, Any],
                 expected_jobs: Iterable[JobKey | Mapping[str, Any]],
                 expected_assignment_id: str, local_lock_root: str | Path,
                 owner_token: str):
        self._assignment = json.loads(_canonical(assignment))
        self._grid = validate_assignment(
            self._assignment, expected_contract_id=expected_contract_id,
            expected_source_ids=expected_source_ids, expected_jobs=expected_jobs,
            expected_assignment_id=expected_assignment_id,
        )
        if self._assignment["state"] != "executable":
            raise OwnershipError("prepared_not_executable: runtime/owner bindings are missing")
        if slot not in self._assignment["slots"]:
            raise OwnershipError("unknown runtime slot")
        self.slot = slot
        self.assignment_id = expected_assignment_id
        self._runtime_id = current_runtime_id()
        self._owner = self._assignment["slot_owners"][slot]
        if self._owner["runtime_id"] != self._runtime_id:
            raise OwnershipError("wrong OS runtime; ownership transfer requires a new protocol")
        supplied = hashlib.sha256(_text(owner_token, "owner_token").encode("utf-8")).hexdigest()
        if supplied != self._owner["owner_token_sha256"]:
            raise OwnershipError("owner token mismatch")
        self._output_root = _runtime_path(self._assignment["output_root"])
        self._namespace = self._output_root / self.assignment_id / f"slot_{slot}"
        self._readonly = [_runtime_path(path) for path in self._assignment["readonly_roots"]]
        self._source_paths = [_runtime_path(item["path"]) for item in self._assignment["source_receipts"]]
        self._locks = Path(local_lock_root).resolve()
        if self._locks != _runtime_path(self._assignment["local_lock_root"]):
            raise OwnershipError("local lock cache differs from frozen assignment")
        _require_local_cache(self._locks, self._output_root)
        for root in self._readonly:
            if _within(self._output_root, root) or _within(root, self._output_root):
                raise OwnershipError("output root overlaps a read-only source/baseline root")
            if _within(self._locks, root) or _within(root, self._locks):
                raise OwnershipError("local lock cache overlaps a read-only source/baseline root")
        for source in self._source_paths:
            if _within(source, self._output_root) or _within(self._output_root, source):
                raise OwnershipError("output root overlaps a guarded source file")
            if _within(source, self._locks) or _within(self._locks, source):
                raise OwnershipError("local lock cache overlaps a guarded source file")
        self._partition = {record["job_id"]: record["slot"] for record in self._assignment["jobs"]}
        self.verify_sources()

    def verify_sources(self) -> None:
        for receipt, path in zip(self._assignment["source_receipts"], self._source_paths):
            if not path.is_file() or _file_hash(path) != receipt["sha256"]:
                raise OwnershipError("source/runtime receipt changed or is unavailable")

    def _check_path(self, path: Path) -> None:
        resolved = path.resolve()
        if self._namespace.resolve() != self._namespace:
            raise OwnershipError("slot namespace must not be redirected by a symlink")
        if not _within(resolved, self._namespace) or not _within(resolved, self._output_root):
            raise OwnershipError("resolved output path escapes assigned namespace")
        for root in self._readonly:
            if _within(resolved, root):
                raise OwnershipError("output path enters a read-only source/baseline namespace")
        for source in self._source_paths:
            if resolved == source or _within(source, resolved):
                raise OwnershipError("output path overlaps a guarded source file")

    @staticmethod
    def _read_receipt(path: Path) -> dict[str, Any]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise OwnershipError("missing or unreadable writer state") from exc
        if not isinstance(data, dict):
            raise OwnershipError("invalid writer state")
        return data

    @contextlib.contextmanager
    def claim(self, key: JobKey | Mapping[str, Any], *, output_dir: str | Path | None = None) -> Iterator[JobLease]:
        job = JobKey.from_value(key)
        if job.job_id not in self._grid or self._grid[job.job_id] != job:
            raise OwnershipError("unknown job outside frozen grid")
        if self._partition[job.job_id] != self.slot:
            raise OwnershipError("job belongs to another runtime slot")
        destination = self._namespace / "jobs" / job.job_id
        self._check_path(destination)
        if destination.resolve() != destination:
            raise OwnershipError("job namespace must not be redirected by a symlink")
        if output_dir is not None and Path(output_dir).resolve() != destination.resolve():
            raise OwnershipError("caller output path differs from frozen job namespace")
        lock_root = self._locks / self.assignment_id
        with _process_lock(lock_root / f"slot_{self.slot}.lock"), _process_lock(lock_root / f"{job.job_id}.lock"):
            self.verify_sources()
            self._check_path(destination)
            destination.mkdir(parents=True, exist_ok=True)
            receipt_path = destination / ".owner.json"
            if receipt_path.is_symlink():
                raise OwnershipError("writer receipt must not be a symlink")
            permanent = {
                "schema": SCHEMA, "assignment_id": self.assignment_id, "generation": 1,
                "frozen_contract_id": self._assignment["frozen_contract_id"],
                "source_ids_sha256": _digest(self._assignment["source_ids"]),
                "job_id": job.job_id, "slot": self.slot,
                "runtime_id": self._runtime_id,
                "owner_token_sha256": self._owner["owner_token_sha256"],
            }
            if receipt_path.exists():
                previous = self._read_receipt(receipt_path)
                if any(previous.get(name) != value for name, value in permanent.items()):
                    raise OwnershipError("writer owner/source/contract state mismatch")
                if previous.get("state") not in {"running", "idle", "interrupted", "complete"}:
                    raise OwnershipError("unknown writer state")
                if previous["state"] == "complete":
                    raise OwnershipError("job is already complete; duplicate execution refused")
            elif any(destination.iterdir()):
                raise OwnershipError("existing job output has no matching writer state")
            current = {**permanent, "state": "running", "pid": os.getpid(), "attempt_id": uuid.uuid4().hex}
            _write_receipt(receipt_path, current)
            lease = JobLease(self, job, destination.resolve(), receipt_path, current)
            try:
                yield lease
                if lease._live:
                    lease.assert_active()
                    lease._receipt["state"] = "idle"
                    _write_receipt(receipt_path, lease._receipt)
            except BaseException:
                if lease._live and self._read_receipt(receipt_path) == lease._receipt:
                    lease._receipt["state"] = "interrupted"
                    _write_receipt(receipt_path, lease._receipt)
                raise
            finally:
                lease._live = False
