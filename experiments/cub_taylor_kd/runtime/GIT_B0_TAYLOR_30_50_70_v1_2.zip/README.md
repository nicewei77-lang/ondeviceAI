# Git B0 Taylor+CE+KL v1_2 — 평가 batch8 고정

실제 B0는 batch8에서 원본과 동일한1000/1200 정답, CE0.7330620276314581을 확인했습니다. batch16은 한 near-tie 예측이 달라1001/1200으로 원본 검증에 실패했습니다. 정확도 guard1000/1200 및 CE.7331±.0005는 유지합니다.

처음 시작은 새 v1_2 노트북에서 START_TRAINING=True, RESUME=False, EVALUATION_BATCH_SIZE=8을 유지하고 코드 셀1→2→3 순서로 실행합니다. RUN_TEST_AFTER_TRAINING=True, AUTO_RELEASE=True 기본값입니다. 구 노트북을 재실행하지 않습니다. 패키지가 GPU를 할당하지 않으며 기존에 연결한 전용L4 kernel을 사용합니다. 기존 lightio 모듈이 로드된 커널은 격리 검사에서 중단합니다.

학습은 batch16/유효batch64, 평가(B0/모든Val/Test)는8입니다. B0 출발 및 frozen KL Teacher 동일, 새80epoch, 30/50/70 결과 독립 보존, 이전target LAST에서 다음target 시작, train-only400 Taylor, CE+.5*T4²KL, seed20261013, 단계별 fresh AdamW/scaler와 LR restart, Val final-quarter 선택은 그대로입니다. 원래MLP hidden 누적비율이며 전체파라미터비율이 아닙니다. Student0.

소스 B0 exactID1xwR2mviCdrSYJ-n2eZuFbd14reVcXuiq/version12/rawSHA3ceffe27...20f207/epoch10/classdict200/strictrestore 및 실제1200장 batch8 검증은 기존 Colab에서 PASS했습니다. 상세는 assets/ACTUAL_B0_BATCH_EVIDENCE.json입니다. v1_2 새전체 초기화·calibration·80epoch학습·Test는 아직 실행하지 않았습니다. 변경부 실제 frozen kernel CPU fixture의 평가batch전달 시험만 새로 수행했고 기존80epoch CPU 근거는 재사용했습니다.

처음 실행 실패한v1/v1_1은 학습epoch0이며 파일과 오류출력을 보존합니다. v1_2는 새 namespace/runs를 사용합니다. 완료후 중단 재개에만 RESUME=True; owner/lock을 삭제하지 않습니다. Test전 선택본과Hard를 잠그며 이미 관찰한 CUB Test는 새로운 holdout이 아닙니다.

progress/history는 매epoch, local atomic checkpoint, Drive900초+stage/final/planned_pause coalesce입니다. computed/durable을 구분하며 VM손실은 마지막durable후900초+epoch/save지연까지 가능하고 hard15분 보장이 아닙니다. 계획시간2–4시간+환경준비는 미측정 추정치입니다. Git push/기존결과수정/PC모델다운로드는 없습니다.
