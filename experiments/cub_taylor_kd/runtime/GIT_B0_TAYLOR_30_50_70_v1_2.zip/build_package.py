"""New append-only B0 package. No Colab, GPU or model-data execution."""
from pathlib import Path
import ast,json,sys,zipfile
import nbformat
ROOT=Path(__file__).resolve().parent;sys.path[:0]=[str(ROOT),str(ROOT/'vendor_base')]
from lightio.identity import sha,identity,atomic_json,NAMESPACE
BASE=ROOT.parent/'cub_taylor_distill_v1/colab_packages/CUB_TAYLOR_CE_CEKL_v1.zip'
BASE_SHA='dd0ca42f369e66a90ab17baeb331aac66dbdfb07f0b6b2060a43c685d3be5b50'

def notebook(zip_sha,code_id):
    M,C=nbformat.v4.new_markdown_cell,nbformat.v4.new_code_cell
    cells=[M('''# Git B-0 Taylor+CE+KL 30% → 50% → 70% — v1_2
평가 batch8 수정본입니다. 기존 노트북과 결과는 변경하지 않았습니다.

**학습 batch16·유효 batch64 / baseline 및 모든 Validation·Test batch8**을 고정합니다. 실제 B0는 batch8에서 원본과 같은1000/1200, CE0.733062를 확인했습니다. 원본 정확도 검증을 완화하지 않습니다.

처음 시작은 START_TRAINING=True, RESUME=False, EVALUATION_BATCH_SIZE=8을 유지하고 코드1→2→3을 실행합니다. 기존 lightio 모듈이 없는 전용 Python kernel을 사용합니다. 이 준비 작업에서는 GPU를 할당하거나 학습을 시작하지 않았습니다.

출발 및 frozen KL Teacher는 Git B0 exactID/SHA/version12/epoch10입니다. B0를 재학습하지 않습니다. 기존30%나7.5% anchor를 재사용하지 않습니다.
Taylor7.5/15/22.5/30 각10epoch,35/40/45/50/55/60/65/70 각5epoch, 합계 신규80 Teacher epochs입니다. 비율은 원래MLP hidden 누적 제거율이며 전체모델 파라미터비율이 아닙니다. Student0.

기존 실제 B0 strict restore·batch8 검증은 PASS, 새v1_2 전체Colab 초기화·calibration·학습·Test는 미실행입니다. RUN_TEST_AFTER_TRAINING=True이면 세목표 완료와 Validation 선택 잠금 후 Test를 수행합니다. 이미 관찰한CUB Test는 새holdout이 아닙니다.'''),
    M('## 1. 실행 옵션 — 처음에는 START=False'),C('''START_TRAINING = False
RESUME = False
RUN_TEST_AFTER_TRAINING = True
AUTO_RELEASE = True
RUN_NAME = 'GitB0_TaylorCEKL_30_50_70_v1_2'
EVALUATION_BATCH_SIZE = 8
assert EVALUATION_BATCH_SIZE == 8
EXPECTED_B0_SHA256 = '3ceffe27b7d41a711937961e117a28d95b2d5611be4dc473969155b78620f207'
DATA_ROOT = None
PAUSE_AFTER_TARGET = None
STOP_AFTER_SEGMENT_EPOCH = None
RUNTIME_RELEASE_EVIDENCE = None
EVALUATE_SAVED_RESULTS = False
OUTPUT_FOLDER_ID = None
assert PAUSE_AFTER_TARGET in (None,30,50,70)
assert STOP_AFTER_SEGMENT_EPOCH is None or 1<=STOP_AFTER_SEGMENT_EPOCH<=40
print('PREPARED; new80epochs; oldmodels0; START',START_TRAINING,'Test_after_all',RUN_TEST_AFTER_TRAINING)
'''),M('## 2. Drive 및 정확한 새 ZIP 검증'),C(f'''from pathlib import Path,PurePosixPath
from google.colab import drive,auth
import sys,os,hashlib,stat,tempfile,zipfile
if not os.path.ismount('/content/drive'):drive.mount('/content/drive',timeout_ms=900000)
BASE=Path('/content/drive/MyDrive/온디바이스AI')
PROJECT=BASE/'cub_focus_light_io_v1/GIT_B0_TAYLOR_30_50_70_v1_2'
PACKAGE=PROJECT/'GIT_B0_TAYLOR_30_50_70_v1_2.zip'
assert hashlib.sha256(PACKAGE.read_bytes()).hexdigest()=='{zip_sha}','New B0 ZIP SHA mismatch'
if 'B0_CODE' not in globals():
    assert not any(n=='lightio' or n.startswith('lightio.') for n in sys.modules),'Preserve other active work; use dedicated kernel'
    B0_CODE=Path(tempfile.mkdtemp(prefix='GitB0_Taylor_',dir='/content'))
    with zipfile.ZipFile(PACKAGE) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        for m in z.infolist():
            p=PurePosixPath(m.filename)
            assert not p.is_absolute() and '..' not in p.parts and chr(92) not in m.filename and not stat.S_ISLNK(m.external_attr>>16)
        z.extractall(B0_CODE)
    sys.path[:0]=[str(B0_CODE),str(B0_CODE/'vendor_base')]
from lightio.contracts import verify_delivery
assert verify_delivery(B0_CODE)['code_id']=='{code_id}'
from lightio.runtime_bootstrap import cub_runtime_bindings
cfg,_,_=cub_runtime_bindings()
from lightio.eval_policy import EVALUATION_BATCH_SIZE as PINNED_EVAL_BATCH_SIZE
assert EVALUATION_BATCH_SIZE == PINNED_EVAL_BATCH_SIZE == 8
assert cfg['batch_size']==16 and cfg['effective_batch_size']==64
from b1kd.runtime import current_training_runtime
from lightio.extend_runner import plan,run
assert Path(run.__code__.co_filename).resolve().is_relative_to(B0_CODE.resolve())
print('GIT_B0_CODE_VERIFIED','{code_id}',str(B0_CODE));print(plan())
'''),M('''## 3. 일괄 실행
START=True일 때만 동작합니다. 사용자 인증 후 B0 exact-ID를 **Colab 안에서만** 한 번 읽어 SHA/version/class-order/strict load/Val1000÷1200 및 CE를 검증합니다. 실제 SHA는 B0_SOURCE에 고정합니다.
원 checkpoint에 과거 DINO commit이 없으면 unknown으로 기록하고 현재 복원 코드 commit과 구분합니다. 누락 가중치/임의 key 변경은 허용하지 않습니다.
새 Hard40은 B0 Validation에서 기존 confusion/CE 규칙으로 고정합니다. 이전 Hard40은 보조지표이며 새/기존 primary Hard 수치를 직접 비교하지 않습니다.
회복 설정은 기존 TaylorCEKL:seed20261013/batch16eff64/WD.05/LR1e-5·1e-4/local warmup2+cosine/각단계fresh AdamW+scaler입니다. B0 원학습recipe(seed0/batch8/WD.01)와 혼용하지 않습니다.
12경계 train-only400 Taylor, 원본B0 frozen FP32의 CE+.5*T4²KL, 입력stream0..79. 자동 저정확도 중단 없음.
30/50/70 각 best와 last를 보존하고 다음 segment는 이전 LAST에서 출발합니다. best는 목표별 마지막 quarter에서Val OA→CE→earliest로 고릅니다.
RUN_TEST_AFTER_TRAINING=True이면 세 목표가 모두 끝난 뒤 선정본/Hard/TestIDs를 잠그고 B0+30+50+70 Test를 한 번씩 평가한 다음 저장·해제합니다. Test로 재선정하지 않으며 CUB Test는 이미 노출된 데이터입니다.
remote900초+stage/final/pause와 local atomic 저장은 computed/durable을 구분합니다. RESUME=True는 완료 segment/Test를 건너뜁니다. old owner/lock 삭제 금지. 새 runtime은 검증된 release evidence가 필요합니다.
PAUSE/STOP 옵션은 재개할 때None으로 지우세요. segment30은40epoch,50/70은20epoch입니다.
약2–4시간+환경준비는 미측정 계획범위입니다. 첫 정상2epoch·첫durable 후 갱신하며 완료시간 보장이 아닙니다.'''),C('''if START_TRAINING:
    auth.authenticate_user()
    from types import SimpleNamespace
    GIT_B0_REPORT=run(SimpleNamespace(start_training=True,resume=RESUME,auto_release=AUTO_RELEASE,
        test_after_training=RUN_TEST_AFTER_TRAINING,expected_B0_sha=EXPECTED_B0_SHA256,
        pause_after_target=PAUSE_AFTER_TARGET,stop_after_epoch=STOP_AFTER_SEGMENT_EPOCH,
        run_name=RUN_NAME,data_root=DATA_ROOT,runtime_release_evidence=RUNTIME_RELEASE_EVIDENCE,
        inputs=str(BASE/'TeacherSizeKD_NoPruning/inputs')))
    print(GIT_B0_REPORT)
else:
    print('NO_TRAINING_OR_TEST_STARTED: newGPU0/newepoch0')
'''),M('''## 4. 별도 Test-only 재개 — 학습 셀을 다시 실행하지 않습니다
위에서 Test를 포함했다면 추가 실행할 필요 없습니다. 완료 Test는 ref를 확인하고 읽습니다.
훈련만 마쳤거나 Test 중단 후에는 EVALUATE_SAVED_RESULTS=True, RESUME=True와 필요하면 OUTPUT_FOLDER_ID/release evidence를 지정합니다.
새 kernel은 같은 L4 한 세션을 연결하고 위2번setup→이 셀만 실행하세요. 3번 학습 셀은 실행하지 않습니다.
Git용 best.pth/config.json/github_history.json/pruning_spec.json도 각 target 폴더에 저장됩니다. 기존 Git L1 loader 대신 패키지의 restore_export adapter를 사용합니다. Git push/merge는 하지 않습니다.'''),C('''if EVALUATE_SAVED_RESULTS:
    auth.authenticate_user()
    import json,google.auth
    from googleapiclient.discovery import build
    from lightio.identity import identity,read
    from lightio.backend import DriveBackend
    from lightio.extend_test import evaluate
    credentials,_=google.auth.default()
    service=build('drive','v3',credentials=credentials,cache_discovery=False)
    saved=globals().get('GIT_B0_REPORT')
    if saved is None:
        assert OUTPUT_FOLDER_ID,'Set the printed output folder ID; never repeat training'
        rows=service.files().list(q=f"'{OUTPUT_FOLDER_ID}' in parents and name='OPERATIONAL_CONTRACT.json' and trashed=false",fields='files(id),nextPageToken').execute()
        assert len(rows.get('files',[]))==1 and not rows.get('nextPageToken')
        op=json.loads(service.files().get_media(fileId=rows['files'][0]['id']).execute())
        assert identity({k:v for k,v in op.items() if k!='operational_id'})==op['operational_id']
        reader=DriveBackend(OUTPUT_FOLDER_ID,op['operational_id'])
        assert json.loads(reader.get('OWNER.json'))['state']=='complete'
        saved=json.loads(reader.get('COMPLETE.json'))
    released=read(RUNTIME_RELEASE_EVIDENCE) if RUNTIME_RELEASE_EVIDENCE else {}
    GIT_B0_TEST_REPORT=evaluate(saved,B0_CODE,service,inputs=str(BASE/'TeacherSizeKD_NoPruning/inputs'),
        data_root=DATA_ROOT,resume=RESUME,request_release=AUTO_RELEASE,prior_release=released.get('Test'))
    print(GIT_B0_TEST_REPORT)
    if AUTO_RELEASE:
        from google.colab import runtime
        runtime.unassign()
else:
    print('SEPARATE_TEST_NOT_REQUESTED')
''')]
    for c in cells:
        if c.cell_type=='code':ast.parse(c.source)
    nb=nbformat.v4.new_notebook(cells=cells,metadata={'colab':{'name':'START_GIT_B0_TAYLOR_30_50_70_v1_2.ipynb','provenance':[]},'kernelspec':{'name':'python3','display_name':'Python3'},'language_info':{'name':'python'}})
    nbformat.validate(nb);return nb

def main():
    assert sha(BASE)==BASE_SHA
    paths=[ROOT/'README.md',Path(__file__).resolve(),ROOT/'tests/test_github_b0.py',ROOT/'tests/fixture_models.py',ROOT/'tests/__init__.py']
    paths+=list((ROOT/'lightio').glob('*.py'));paths+=[ROOT/'assets/GITHUB_B0_CONDITIONS.json',ROOT/'assets/DRIVE_DESTINATION.json',ROOT/'assets/ACTUAL_B0_BATCH_EVIDENCE.json']
    paths=sorted(set(paths));hashes={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    for p in paths:
        if p.suffix=='.py':ast.parse(p.read_text(encoding='utf8'))
    manifest={'namespace':NAMESPACE,'code_id':identity(hashes),'sha256':hashes,'base_vendor_ZIP_SHA256':BASE_SHA,'new_Teacher_epochs':80,'Student_epochs':0,'actual_GPU_training':False}
    atomic_json(ROOT/'SOURCE_MANIFEST.json',manifest);out=ROOT/'colab_packages';out.mkdir(exist_ok=True);target=out/'GIT_B0_TAYLOR_30_50_70_v1_2.zip'
    with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for m in old.infolist():
            if m.filename.startswith('vendor_base/'):z.writestr(m,old.read(m.filename))
        for p in paths+[ROOT/'SOURCE_MANIFEST.json']:z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    nb=out/'START_GIT_B0_TAYLOR_30_50_70_v1_2.ipynb';nbformat.write(notebook(sha(target),manifest['code_id']),nb)
    result={'state':'PREPARED_LOCAL_ACCEPTANCE_PENDING','code_id':manifest['code_id'],'ZIP_sha256':sha(target),'ZIP_bytes':target.stat().st_size,'notebook_sha256':sha(nb),'notebook_bytes':nb.stat().st_size,'source_files':len(paths),'START_TRAINING':False,'new_GPU_allocations':0,'actual_Git_B0_training':False}
    atomic_json(out/'DELIVERY.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
